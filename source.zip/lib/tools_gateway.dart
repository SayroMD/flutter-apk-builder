import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:otax/anime_page.dart';
import 'package:provider/provider.dart';
import 'package:otax/ui/models/providers/appProvider.dart';
import 'package:otax/tabunganku_module.dart';
import 'package:iconsax/iconsax.dart';
import 'dart:math' as math;

import 'dashboard_page.dart';
import 'home_page.dart';
import 'bug_group_page.dart';
import 'enak_page.dart';
import 'fakestory.dart';
import 'faketweet.dart';
import 'cpanel.dart';
import 'colong.dart';
import 'shortlink_page.dart';
import 'cdrama_page.dart';
import 'obf_page.dart';
import 'botspam.dart';
import 'iphone_iqc.dart';
import 'spam_otp.dart';
import 'ff.dart';
import 'packman.dart';
import 'ular.dart';
import 'gameotax.dart';
import 'tourl.dart';
import 'controller.dart';
import 'auto_detect_page.dart';
import 'create_vps_page.dart';
import 'install_panel_page.dart';
import 'ip_scanner.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'pinterest_downloader.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'spam_pair.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'music_page.dart';
import 'port_scanner.dart';
import 'webapk.dart';
import 'phone_lookup.dart';
import 'ff_stalker_screen.dart';
import 'roblox_stalker_screen.dart';
import 'email_osint.dart';
import 'hentai_page.dart';
import 'am.dart';
import 'ai_page.dart';
import 'code_fixer_page.dart';
import 'check_banned_page.dart';
import 'installubot.dart';
import 'github_builder.dart';
import 'finance_manager_page.dart';
import 'wifi_bruteforce.dart';
import 'manta_mailer.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.username,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  // Neo-Brutalism Palette (shared base — aksen sedikit beda per halaman)
  static const Color bg = Color(0xFFF5F0E8);          // warm off-white
  static const Color black = Color(0xFF1A1A1A);
  static const Color yellow = Color(0xFFFFE566);      // primary accent
  static const Color pink = Color(0xFFFF6B9D);        // secondary
  static const Color blue = Color(0xFF5B8DEF);
  static const Color green = Color(0xFF4ADE80);
  static const Color orange = Color(0xFFFF9F43);
  static const Color purple = Color(0xFFA78BFA);

  static const List<_ToolCategory> _categories = [
    _ToolCategory(
      icon: Icons.cloud_outlined,
      title: "Panel",
      subtitle: "Manajemen server",
      color: yellow,
    ),
    _ToolCategory(
      icon: Icons.sports_esports_outlined,
      title: "Game & AI",
      subtitle: "Catur, pacman, asisten",
      color: pink,
    ),
    _ToolCategory(
      icon: Icons.flash_on_outlined,
      title: "DDoS",
      subtitle: "Stress test",
      color: orange,
    ),
    _ToolCategory(
      icon: Icons.wifi_outlined,
      title: "Network",
      subtitle: "WiFi, spam",
      color: blue,
    ),
    _ToolCategory(
      icon: Icons.search_outlined,
      title: "OSINT",
      subtitle: "NIK, domain, telepon",
      color: green,
    ),
    _ToolCategory(
      icon: Icons.download_outlined,
      title: "Downloader",
      subtitle: "TikTok, Instagram",
      color: purple,
    ),
    _ToolCategory(
      icon: Icons.build_outlined,
      title: "Rat X Spam",
      subtitle: "Rat Malware",
      color: pink,
    ),
    _ToolCategory(
      icon: Icons.rocket_launch_outlined,
      title: "Generator",
      subtitle: "Quote, fake story",
      color: yellow,
    ),
    _ToolCategory(
      icon: Icons.auto_awesome_outlined,
      title: "Anime",
      subtitle: "Streaming, 18+",
      color: blue,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildSectionHeader(),
            const SizedBox(height: 16),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.builder(
                  itemCount: _categories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 14,
                    childAspectRatio: 0.85,
                  ),
                  itemBuilder: (context, index) {
                    final category = _categories[index];
                    return _ToolCard(
                      category: category,
                      onTap: () => _onCategoryTap(context, category),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Row(
        children: [
          // Logo box - neo brutal
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: yellow,
              border: Border.all(color: black, width: 3),
              boxShadow: const [
                BoxShadow(
                  color: black,
                  offset: Offset(4, 4),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Image.asset(
                  'assets/images/otaxlogo.png',
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(
                      Icons.shield_moon_outlined,
                      color: black,
                      size: 28,
                    );
                  },
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "OTAX",
                  style: TextStyle(
                    color: black,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    height: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: pink,
                    border: Border.all(color: black, width: 2),
                  ),
                  child: const Text(
                    "Gateway Tools",
                    style: TextStyle(
                      color: black,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Role badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: black,
              border: Border.all(color: black, width: 3),
              boxShadow: const [
                BoxShadow(
                  color: black,
                  offset: Offset(3, 3),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Text(
              widget.userRole.toUpperCase(),
              style: const TextStyle(
                color: yellow,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 24,
            color: black,
          ),
          const SizedBox(width: 10),
          Text(
            "TOOLS OTAX",
            style: TextStyle(
              color: black,
              fontSize: 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: green,
              border: Border.all(color: black, width: 2),
            ),
            child: Text(
              "${_categories.length} ITEM",
              style: const TextStyle(
                color: black,
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onCategoryTap(BuildContext context, _ToolCategory category) {
    switch (category.title) {
      case "Panel":
        _showVpsTools(context);
        break;
      case "Game & AI":
        _showGamesTools(context);
        break;
      case "DDoS":
        _showDDoSTools(context);
        break;
      case "Network":
        _showNetworkTools(context);
        break;
      case "OSINT":
        _showOSINTTools(context);
        break;
      case "Downloader":
        _showDownloaderTools(context);
        break;
      case "Rat X Spam":
        _showUtilityTools(context);
        break;
      case "Generator":
        _showQuickAccess(context);
        break;
      case "Anime":
        _showAnimeTools(context);
        break;
    }
  }

  // ==================== MODAL SHEETS ====================

  void _showAnimeTools(BuildContext context) {
    _showModalSheet(
      context,
      "Anime",
      Icons.auto_awesome_outlined,
      yellow,
      [
        _buildModalItem(
          icon: Icons.movie_outlined,
          label: "Anime Page",
          color: yellow,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => FutureBuilder(
                  future: ensureAnimeStreamInitialized(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Scaffold(
                        body: Center(child: CircularProgressIndicator()),
                      );
                    }
                    return ChangeNotifierProvider(
                      create: (ctx) => AppProvider(),
                      child: const AnimeStream(),
                    );
                  },
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.tv,
          label: "Drama",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CDramaPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.favorite_rounded,
          label: "Hentai",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Hentaii()),
            );
          },
        ),
      ],
    );
  }

  void _showVpsTools(BuildContext context) {
    _showModalSheet(
      context,
      "Panel",
      Icons.cloud_outlined,
      yellow,
      [
        _buildModalItem(
          icon: Icons.sports_esports_outlined,
          label: "Cpanel",
          color: yellow,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CpanelPage(
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.security_outlined,
          label: "Colong Sender",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CredsStealerAdvancedPage(
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.computer_outlined,
          label: "Buat VPS DigitalOcean",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CreateVpsPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.settings_ethernet_outlined,
          label: "Install Panel Pterodactyl",
          color: green,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstallPanelPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.build_circle_outlined,
          label: "Install Flutter",
          color: purple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstallWeb2apkPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.build_circle_outlined,
          label: "Build Flutter Github",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const GithubBuilderPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.build_circle_outlined,
          label: "Install Ubot",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstallUbotPage()),
            );
          },
        ),
      ],
    );
  }

  void _showGamesTools(BuildContext context) {
    _showModalSheet(
      context,
      "Game & AI",
      Icons.sports_esports_outlined,
      pink,
      [
        _buildModalItem(
          icon: Icons.videogame_asset_outlined,
          label: "Epep Stalk",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FFStalkerScreen()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.games,
          label: "Rosblok Stalk",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const RobloxStalkerScreen()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.sports_esports_outlined,
          label: "Packman",
          color: yellow,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PacmanGamePage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.catching_pokemon_outlined,
          label: "Ular Klasik",
          color: green,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SnakeGame()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.catching_pokemon_outlined,
          label: "OTAX GAMES",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const RetroGameHub()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.smart_toy_outlined,
          label: "AI Assistant",
          color: purple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AIPage(
                 sessionKey: widget.sessionKey,
                 username: widget.username,
                 role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Iconsax.wallet_3,
          label: "Tabunganku",
          color: green,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => TabunganKuModule()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.code_rounded,
          label: "AI Code Fix",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CodeFixerPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showDDoSTools(BuildContext context) {
    _showModalSheet(
      context,
      "DDoS",
      Icons.flash_on_outlined,
      orange,
      [
        _buildModalItem(
          icon: Icons.flash_on_outlined,
          label: "Attack Panel",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: widget.sessionKey,
                  listDoos: widget.listDoos,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.dns_outlined,
          label: "Manage Server",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.sports_esports_outlined,
          label: "Auto Detect Games",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AutoDetectPage(
                  sessionKey: widget.sessionKey,
                  savedVPS: widget.listDoos,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    _showModalSheet(
      context,
      "Network",
      Icons.wifi_outlined,
      blue,
      [
        _buildModalItem(
          icon: Icons.mark_email_unread_outlined,
          label: "Send Mail",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MantaMailerPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.hub,
          label: "Port Scanner",
          color: purple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PortScannerPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.router,
          label: "Ip Scanner",
          color: green,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => IpScannerPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.wifi,
          label: "WiFi Bruteforce",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WifiBruteforcePage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.wifi_off_outlined,
          label: "WiFi Internal",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WifiKillerPage()),
            );
          },
        ),
        if (widget.userRole == "KINGZ" || widget.userRole == "OWNER")
          _buildModalItem(
            icon: Icons.router_outlined,
            label: "WiFi External",
            color: purple,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
                ),
              );
            },
          ),
      ],
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showModalSheet(
      context,
      "OSINT",
      Icons.search_outlined,
      green,
      [
        _buildModalItem(
          icon: Icons.badge_outlined,
          label: "NIK Detail",
          color: green,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NikCheckerPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.domain_outlined,
          label: "Domain OSINT",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DomainOsintPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.person_search_outlined,
          label: "Phone Lookup",
          color: yellow,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PhoneLookupPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.email_outlined,
          label: "Obf Code",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ObfPage(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showModalSheet(
      context,
      "Downloader",
      Icons.download_outlined,
      purple,
      [
        _buildModalItem(
          icon: Icons.video_library_outlined,
          label: "TikTok",
          color: purple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.camera_alt_outlined,
          label: "Instagram",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.push_pin,
          label: "Pinterest",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PinterestDownloaderPage()),
            );
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showModalSheet(
      context,
      "Rat X Spam",
      Icons.build_outlined,
      pink,
      [
        _buildModalItem(
          icon: Icons.badge_outlined,
          label: "RAT Controll",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            AppConfig.sessionKey = widget.sessionKey;
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TargetListPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.verified_user,
          label: "Spam Otp",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            AppConfig.sessionKey = widget.sessionKey;
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SpamOtpPage(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.smart_toy,
          label: "Bot Spam",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            AppConfig.sessionKey = widget.sessionKey;
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const BotSpamPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.shield_outlined,
          label: "Cek Bannido",
          color: green,
          onTap: () {
            Navigator.pop(context);
            AppConfig.sessionKey = widget.sessionKey;
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => CheckBannedPage(sessionKey: widget.sessionKey)),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.mail,
          label: "Spam Pair",
          color: purple,
          onTap: () {
            Navigator.pop(context);
            AppConfig.sessionKey = widget.sessionKey;
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SpamPairPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showModalSheet(
      context,
      "Generator",
      Icons.auto_awesome,
      yellow,
      [
        _buildModalItem(
          icon: Icons.phone_iphone,
          label: "iPhone Quote",
          color: yellow,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const IphoneIqcPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.auto_stories_outlined,
          label: "Fake Story",
          color: pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeStoryPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.flutter_dash,
          label: "Fake Tweet",
          color: blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeTweetPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.cloud_upload_outlined,
          label: "To Url",
          color: green,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UploadToUrlPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.lock_open,
          label: "Am Prem",
          color: orange,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UnlockPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.animation_rounded,
          label: "Shortlink",
          color: purple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ShortlinkPage(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  // ==================== UI HELPERS ====================

  void _showModalSheet(
    BuildContext context,
    String title,
    IconData icon,
    Color accentColor,
    List<Widget> items,
  ) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        height: MediaQuery.of(context).size.height * 0.62,
        decoration: BoxDecoration(
          color: bg,
          border: Border(
            top: BorderSide(color: black, width: 4),
            left: BorderSide(color: black, width: 4),
            right: BorderSide(color: black, width: 4),
          ),
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 48,
              height: 6,
              decoration: BoxDecoration(
                color: black,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 16, 12),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: accentColor,
                      border: Border.all(color: black, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Icon(icon, color: black, size: 26),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    title.toUpperCase(),
                    style: const TextStyle(
                      color: black,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: pink,
                        border: Border.all(color: black, width: 3),
                        boxShadow: const [
                          BoxShadow(
                            color: black,
                            offset: Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.close, color: black, size: 22),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 3,
              color: black,
              margin: const EdgeInsets.symmetric(horizontal: 20),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: ListView.separated(
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, index) => items[index],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModalItem({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: black, width: 3),
            boxShadow: const [
              BoxShadow(
                color: black,
                offset: Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color,
                  border: Border.all(color: black, width: 2.5),
                ),
                child: Icon(icon, color: black, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: black,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: black,
                  border: Border.all(color: black, width: 2),
                ),
                child: const Icon(
                  Icons.arrow_forward,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== MODELS & CARDS ====================

class _ToolCategory {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;

  const _ToolCategory({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
  });
}

class _ToolCard extends StatelessWidget {
  final _ToolCategory category;
  final VoidCallback onTap;

  const _ToolCard({
    required this.category,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: _ToolsPageState.black, width: 3),
          boxShadow: const [
            BoxShadow(
              color: _ToolsPageState.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: category.color,
                border: Border.all(color: _ToolsPageState.black, width: 2.5),
              ),
              child: Icon(
                category.icon,
                color: _ToolsPageState.black,
                size: 26,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              category.title,
              style: const TextStyle(
                color: _ToolsPageState.black,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 3),
            Text(
              category.subtitle,
              style: TextStyle(
                color: _ToolsPageState.black.withOpacity(0.65),
                fontSize: 10,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}