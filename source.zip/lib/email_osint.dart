import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class EmailOsintPage extends StatefulWidget {
  const EmailOsintPage({super.key});

  @override
  State<EmailOsintPage> createState() => _EmailOsintPageState();
}

class _EmailOsintPageState extends State<EmailOsintPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  final TextEditingController _emailController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  
  bool _isLoading = false;
  EmailOsintResult? _result;
  String? _errorMessage;

  static const String _apiUrl = 'https://api.emailvalidation.io/v1/info?email=';

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _lookupEmail() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _result = null;
    });
    
    final email = _emailController.text.trim();
    
    try {
      final response = await http.get(
        Uri.parse('$_apiUrl$email'),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 15));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _result = EmailOsintResult.fromJson(data, email);
          _isLoading = false;
        });
      } else {
        setState(() {
          _result = _getFallbackResult(email);
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Network error: ${e.toString()}';
        _isLoading = false;
      });
      showCyberSnackBar(context, 'Gagal terhubung ke API, menggunakan mode offline', isError: true);
    }
  }
  
  EmailOsintResult _getFallbackResult(String email) {
    final domain = email.split('@').last.toLowerCase();
    bool isDisposable = ['tempmail.com', '10minutemail.com', 'guerrillamail.com'].contains(domain);
    bool hasMx = !isDisposable;
    
    String? provider;
    if (domain.contains('gmail')) provider = 'Google (Gmail)';
    else if (domain.contains('yahoo')) provider = 'Yahoo';
    else if (domain.contains('outlook') || domain.contains('hotmail')) provider = 'Microsoft';
    else if (domain.contains('proton')) provider = 'ProtonMail';
    else provider = 'Custom Domain';
    
    return EmailOsintResult(
      email: email,
      isValid: email.contains('@') && email.contains('.'),
      domain: domain,
      isDisposable: isDisposable,
      hasMx: hasMx,
      provider: provider,
      risk: isDisposable ? 'High' : 'Low',
      rawData: {},
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "EMAIL OSINT",
      child: Column(
        children: [
          _buildInputSection(),
          const SizedBox(height: 16),
          if (_isLoading) _buildLoadingIndicator(),
          if (_errorMessage != null && !_isLoading) _buildErrorMessage(),
          if (_result != null && !_isLoading) _buildResultCard(),
        ],
      ),
    );
  }
  
  Widget _buildInputSection() {
    return GlassCard(
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(width: 3, height: 18,
                    decoration: BoxDecoration(color: AppColors.accent, borderRadius: BorderRadius.circular(2))),
                const SizedBox(width: 8),
                const Text('Email Address Lookup',
                    style: TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _emailController,
              label: "Email",
              hint: "example@email.com",
              icon: Icons.email_rounded,
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            CyberButton(
              label: "LOOKUP EMAIL",
              icon: Icons.search_rounded,
              onTap: _lookupEmail,
              width: double.infinity,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildLoadingIndicator() {
    return GlassCard(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          const CyberLoadingShimmer(),
          const SizedBox(height: 16),
          const Text('Menganalisis email...', style: TextStyle(color: AppColors.textMuted)),
        ],
      ),
    );
  }
  
  Widget _buildErrorMessage() {
    return GlassCard(
      padding: const EdgeInsets.all(20),
      borderColor: AppColors.red.withOpacity(0.3),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: AppColors.red, size: 24),
          const SizedBox(width: 12),
          Expanded(child: Text(_errorMessage!, style: TextStyle(color: AppColors.textSec))),
        ],
      ),
    );
  }
  
  Widget _buildResultCard() {
    final result = _result!;
    
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: result.isValid ? AppColors.green.withOpacity(0.1) : AppColors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: result.isValid ? AppColors.green.withOpacity(0.3) : AppColors.red.withOpacity(0.3),
                  ),
                ),
                child: Icon(
                  result.isValid ? Icons.check_circle_rounded : Icons.error_rounded,
                  color: result.isValid ? AppColors.green : AppColors.red,
                  size: 28,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(result.email,
                        style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(result.isValid ? 'Email Valid' : 'Email Invalid',
                        style: TextStyle(color: result.isValid ? AppColors.green : AppColors.red, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 16),
          _buildInfoRow(icon: Icons.public_rounded, label: 'Domain', value: result.domain),
          const SizedBox(height: 12),
          _buildInfoRow(icon: Icons.business_rounded, label: 'Provider', value: result.provider ?? 'Unknown'),
          const SizedBox(height: 12),
          _buildInfoRow(icon: Icons.email_rounded, label: 'MX Record',
              value: result.hasMx ? 'Tersedia' : 'Tidak Tersedia',
              valueColor: result.hasMx ? AppColors.green : AppColors.orange),
          const SizedBox(height: 12),
          _buildInfoRow(icon: Icons.warning_amber_rounded, label: 'Disposable',
              value: result.isDisposable ? 'Ya (Temporary Email)' : 'Tidak',
              valueColor: result.isDisposable ? AppColors.red : AppColors.green),
          const SizedBox(height: 12),
          _buildInfoRow(icon: Icons.security_rounded, label: 'Risk Level',
              value: result.risk ?? 'Low',
              valueColor: result.risk == 'High' ? AppColors.red : (result.risk == 'Medium' ? AppColors.orange : AppColors.green)),
          if (result.country != null) ...[
            const SizedBox(height: 12),
            _buildInfoRow(icon: Icons.location_on_rounded, label: 'Country', value: result.country!),
          ],
        ],
      ),
    );
  }
  
  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    Color? valueColor,
  }) {
    return Row(
      children: [
        Icon(icon, color: AppColors.accent, size: 18),
        const SizedBox(width: 12),
        SizedBox(width: 100, child: Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 13))),
        Expanded(
          child: Text(value,
              style: TextStyle(color: valueColor ?? AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }
}

class EmailOsintResult {
  final String email;
  final bool isValid;
  final String domain;
  final bool isDisposable;
  final bool hasMx;
  final String? provider;
  final String? risk;
  final String? country;
  final Map<String, dynamic> rawData;

  EmailOsintResult({
    required this.email,
    required this.isValid,
    required this.domain,
    required this.isDisposable,
    required this.hasMx,
    this.provider,
    this.risk,
    this.country,
    required this.rawData,
  });

  factory EmailOsintResult.fromJson(Map<String, dynamic> json, String email) {
    final domain = email.split('@').last.toLowerCase();
    
    String? provider;
    if (domain.contains('gmail')) provider = 'Google (Gmail)';
    else if (domain.contains('yahoo')) provider = 'Yahoo';
    else if (domain.contains('outlook') || domain.contains('hotmail') || domain.contains('live')) provider = 'Microsoft (Outlook)';
    else if (domain.contains('proton')) provider = 'ProtonMail';
    else if (domain.contains('icloud') || domain.contains('me.com')) provider = 'Apple (iCloud)';
    else provider = 'Custom Domain';
    
    return EmailOsintResult(
      email: email,
      isValid: json['format_valid'] ?? false,
      domain: domain,
      isDisposable: json['disposable'] ?? false,
      hasMx: json['mx_found'] ?? false,
      provider: provider,
      risk: json['risk'] ?? (json['disposable'] == true ? 'High' : 'Low'),
      country: json['domain_country'],
      rawData: json,
    );
  }
}