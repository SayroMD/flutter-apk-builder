import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'setoran_config.dart';
import 'storan_theme.dart';
import 'main.dart';

String get kUpRoleBaseUrl => '$baseUrl/api/up-role';

/// Halaman gabungan: tab "BUAT" (jual akun / storan) + tab "UP ROLE"
/// (upgrade role sendiri) + tab "ACC" (approve scoped, cuma muncul
/// buat role TK/OWNER/KINGZ). Masing-masing tab state-nya independen
/// (pake IndexedStack) jadi kalau pindah tab, progress/timer di tab
/// lain gak ke-reset.
class StoranHubPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const StoranHubPage({super.key, required this.sessionKey, required this.username, required this.role});

  @override
  State<StoranHubPage> createState() => _StoranHubPageState();
}

class _StoranHubPageState extends State<StoranHubPage> {
  int _tab = 0;

  bool get _showAccTab => const ['TK', 'OWNER', 'KINGZ'].contains(widget.role);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NBColors.bg,
      appBar: AppBar(
        backgroundColor: NBColors.bg,
        elevation: 0,
        title: const Text('AKSES JUALAN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Row(
                children: [
                  Expanded(child: _tabButton('BUAT', Icons.person_add_alt_1, 0)),
                  const SizedBox(width: 10),
                  Expanded(child: _tabButton('UP ROLE', Icons.arrow_upward, 1)),
                  if (_showAccTab) ...[
                    const SizedBox(width: 10),
                    Expanded(child: _tabButton('ACC', Icons.fact_check, 2)),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: IndexedStack(
                index: _tab,
                children: [
                  _BuatStoranTab(sessionKey: widget.sessionKey),
                  _UpRoleTab(sessionKey: widget.sessionKey),
                  if (_showAccTab) _AccScopedTab(sessionKey: widget.sessionKey),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabButton(String label, IconData icon, int index) {
    final selected = _tab == index;
    return GestureDetector(
      onTap: () => setState(() => _tab = index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? NBColors.gold : NBColors.surface,
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(3, 3))] : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: selected ? Colors.black : NBColors.textDim),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: selected ? Colors.black : NBColors.textDim, fontWeight: FontWeight.w900, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// TAB 1 — BUAT STORAN (jual akun)
// ============================================================
class _BuatStoranTab extends StatefulWidget {
  final String sessionKey;
  const _BuatStoranTab({required this.sessionKey});

  @override
  State<_BuatStoranTab> createState() => _BuatStoranTabState();
}

class _BuatStoranTabState extends State<_BuatStoranTab> {
  Map<String, dynamic>? _products;
  bool _loadingProducts = true;
  Map<String, dynamic>? _stats;

  String _targetRole = 'FULLUP';
  String _packageType = 'permanen';
  final _customDaysController = TextEditingController();
  final _customHargaController = TextEditingController();
  final _buyerUserController = TextEditingController();
  final _buyerPassController = TextEditingController();

  String _status = 'form';
  String? _depositId;
  int? _amount;
  int? _sektor;
  DateTime? _expiresAt;
  Timer? _pollTimer;
  Timer? _tickTimer;
  Duration _remaining = Duration.zero;
  bool _uploading = false;
  String? _formError;
  Map<String, dynamic>? _paymentInfo;

  @override
  void initState() {
    super.initState();
    _loadProducts();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final res = await http.get(Uri.parse('$kStoranBaseUrl/stats?sessionKey=${widget.sessionKey}'));
      if (res.statusCode == 200) setState(() => _stats = jsonDecode(res.body));
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _customDaysController.dispose();
    _customHargaController.dispose();
    _buyerUserController.dispose();
    _buyerPassController.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    try {
      final res = await http.get(Uri.parse('$kStoranBaseUrl/products?sessionKey=${widget.sessionKey}'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        setState(() {
          _products = data;
          if (data.keys.isNotEmpty && !data.keys.contains(_targetRole)) {
            _targetRole = data.keys.first;
          }
          _loadingProducts = false;
        });
      } else {
        setState(() => _loadingProducts = false);
      }
    } catch (_) {
      setState(() => _loadingProducts = false);
    }
  }

  Map<String, dynamic>? get _selectedPackage {
    if (_products == null) return null;
    return _products![_targetRole]?['packages']?[_packageType];
  }

  int get _displayHarga {
    if (_packageType == 'custom') return int.tryParse(_customHargaController.text) ?? 0;
    return (_selectedPackage?['harga'] ?? 0) as int;
  }

  Future<void> _submit() async {
    setState(() => _formError = null);

    if (_buyerUserController.text.trim().isEmpty || _buyerPassController.text.trim().isEmpty) {
      setState(() => _formError = 'Username & password buyer wajib diisi');
      return;
    }
    if (_packageType == 'custom') {
      final d = int.tryParse(_customDaysController.text);
      final h = int.tryParse(_customHargaController.text);
      if (d == null || d <= 0 || h == null || h <= 0) {
        setState(() => _formError = 'Durasi & harga custom harus angka > 0');
        return;
      }
    } else if (_displayHarga <= 0) {
      setState(() => _formError = 'Paket ini belum diaktifin admin (harga masih 0)');
      return;
    }

    setState(() => _status = 'creating');
    try {
      final res = await http.post(
        Uri.parse('$kStoranBaseUrl/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': widget.sessionKey,
          'targetRole': _targetRole,
          'packageType': _packageType,
          if (_packageType == 'custom') 'customDays': _customDaysController.text,
          if (_packageType == 'custom') 'customHarga': _customHargaController.text,
          'buyerUsername': _buyerUserController.text.trim(),
          'buyerPassword': _buyerPassController.text.trim(),
        }),
      );
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _depositId = j['depositId'];
          _amount = j['amount'];
          _sektor = j['sektor'];
          _paymentInfo = j['paymentInfo'] as Map<String, dynamic>?;
          _expiresAt = DateTime.fromMillisecondsSinceEpoch(j['expiresAt']);
          _status = 'pending';
        });
        _startPolling();
        _startCountdown();
      } else {
        setState(() {
          _status = 'form';
          _formError = j['error'] ?? 'Gagal bikin storan';
        });
      }
    } catch (e) {
      setState(() {
        _status = 'form';
        _formError = 'Gagal konek ke server: $e';
      });
    }
  }

  Future<void> _uploadBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null || _depositId == null) return;

    setState(() => _uploading = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$kStoranBaseUrl/upload-bukti'));
      req.fields['depositId'] = _depositId!;
      req.files.add(await http.MultipartFile.fromPath('bukti', picked.path));
      final streamed = await req.send();
      final res = await http.Response.fromStream(streamed);
      if (res.statusCode == 200) {
        setState(() => _status = 'menunggu_review');
      } else if (mounted) {
        final j = jsonDecode(res.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(j['error'] ?? 'Gagal upload')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal upload, coba lagi')));
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _startCountdown() {
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final diff = _expiresAt!.difference(DateTime.now());
      setState(() => _remaining = diff.isNegative ? Duration.zero : diff);
      if (diff.isNegative) _tickTimer?.cancel();
    });
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (_depositId == null) return;
      try {
        final res = await http.get(Uri.parse('$kStoranBaseUrl/status/$_depositId'));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          setState(() => _status = j['status']);
          if (['selesai', 'gagal', 'ditolak', 'expired'].contains(j['status'])) {
            _pollTimer?.cancel();
            _tickTimer?.cancel();
          }
        }
      } catch (_) {}
    });
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _reset() {
    setState(() {
      _status = 'form';
      _depositId = null;
      _amount = null;
      _sektor = null;
      _buyerUserController.clear();
      _buyerPassController.clear();
      _customDaysController.clear();
      _customHargaController.clear();
    });
    _loadStats();
  }

  @override
  Widget build(BuildContext context) {
    return _loadingProducts
        ? const Center(child: CircularProgressIndicator(color: NBColors.gold))
        : Padding(padding: const EdgeInsets.all(16), child: _buildBody());
  }

  Widget _buildBody() {
    switch (_status) {
      case 'form':
        return _buildForm();
      case 'creating':
        return const Center(child: CircularProgressIndicator(color: NBColors.gold));
      case 'pending':
        return _buildPending();
      case 'menunggu_review':
        return _statusCard(Icons.hourglass_top, 'BUKTI DITERIMA', 'Lagi ditinjau admin. Biasanya diproses dalam beberapa menit.', color: NBColors.gold);
      case 'selesai':
        return _statusCard(Icons.check_circle, 'AKUN BERHASIL DIBUAT!', 'Sektor Rp$_sektor udah dikonfirm.', color: NBColors.green, action: _reset, actionLabel: 'BUAT STORAN LAGI');
      case 'gagal':
        return _statusCard(Icons.error, 'AKUN GAGAL DIBUAT', 'Sektor diterima tapi gagal — hubungin admin.', color: NBColors.gold, action: _reset, actionLabel: 'COBA LAGI');
      case 'ditolak':
        return _statusCard(Icons.cancel, 'BUKTI DITOLAK', 'Bukti transfer ditolak admin.', color: NBColors.red, action: _reset, actionLabel: 'ULANGI STORAN');
      case 'expired':
        return _statusCard(Icons.timer_off, 'WAKTU HABIS', 'Waktu transfer udah lewat.', color: NBColors.red, action: _reset, actionLabel: 'COBA LAGI');
      default:
        return _buildForm();
    }
  }

  Widget _statusCard(IconData icon, String title, String? subtitle, {required Color color, VoidCallback? action, String? actionLabel}) {
    return Center(
      child: NBCard(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: color, border: Border.all(color: Colors.black, width: 3)),
              child: Icon(icon, color: Colors.black, size: 40),
            ),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.white, fontSize: 16, fontWeight: FontWeight.w900)),
            if (subtitle != null) ...[
              const SizedBox(height: 6),
              Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.textDim)),
            ],
            if (action != null) ...[
              const SizedBox(height: 18),
              NBButton(onPressed: action, color: color, child: Text(actionLabel ?? 'OK')),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPending() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          NBCard(
            color: NBColors.red,
            child: Column(
              children: [
                const NBBadge(text: 'MENUNGGU TRANSFER', color: NBColors.gold),
                const SizedBox(height: 12),
                Text('Rp$_amount', style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                const Text('TRANSFER TEPAT NOMINAL INI', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 0.5)),
                const SizedBox(height: 2),
                Text('(sektor 10% dari Rp$_displayHarga)', style: const TextStyle(color: Colors.white70, fontSize: 11)),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: Colors.black, border: Border.all(color: NBColors.gold, width: 2)),
                  child: Text(_fmt(_remaining), style: const TextStyle(color: NBColors.gold, fontSize: 24, fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
          if (_paymentInfo != null) ...[
            const SizedBox(height: 20),
            NBPaymentCard(
              qrisUrl: '$kSetoranFileBaseUrl${_paymentInfo!['qrisPath']}',
              danaNumber: _paymentInfo!['danaNumber'] ?? '-',
              danaName: _paymentInfo!['danaName'] ?? '-',
            ),
          ],
          const SizedBox(height: 20),
          _uploading
              ? const Center(child: CircularProgressIndicator(color: NBColors.gold))
              : NBButton(
                  onPressed: _uploadBukti,
                  color: NBColors.gold,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.upload_file, color: Colors.black, size: 18),
                    SizedBox(width: 8),
                    Text('UPLOAD BUKTI TRANSFER'),
                  ]),
                ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildStatsCard() {
    final s = _stats!;
    return NBCard(
      color: NBColors.gold,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(children: [
                Icon(Icons.receipt_long, color: Colors.black),
                SizedBox(width: 8),
                Text('PENGHASILAN JUALAN', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 12)),
              ]),
              Text('${s['totalAkun']} AKUN', style: const TextStyle(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 10),
          Text('Rp${s['totalPenghasilan']}', style: const TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Dari akun yang sudah dibuat (ACC)', style: TextStyle(color: Colors.black87, fontSize: 11)),
          const SizedBox(height: 4),
          Text('ACC Rp${s['accSektor']} · Menunggu ${s['menunggu']} · Ditolak ${s['ditolak']}',
              style: const TextStyle(color: Colors.black87, fontSize: 11, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildForm() {
    final roles = _products?.keys.toList() ?? [];
    final packages = _products?[_targetRole]?['packages'] as Map<String, dynamic>?;

    if (roles.isEmpty) {
      return Center(
        child: NBCard(
          color: NBColors.surfaceAlt,
          padding: const EdgeInsets.all(20),
          child: const Text('Role akun lo belum bisa jual role apapun lewat Storan.',
              textAlign: TextAlign.center, style: TextStyle(color: NBColors.textDim)),
        ),
      );
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_stats != null) _buildStatsCard(),
          if (_stats != null) const SizedBox(height: 24),
          const NBSectionLabel('JENIS AKUN (ROLE)'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: roles.map((r) {
              final selected = r == _targetRole;
              return GestureDetector(
                onTap: () => setState(() {
                  _targetRole = r;
                  _packageType = 'permanen';
                }),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: selected ? NBColors.gold : NBColors.surface,
                    border: Border.all(color: Colors.black, width: 3),
                    boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(3, 3))] : null,
                  ),
                  child: Text(_products?[r]?['label'] ?? r,
                      style: TextStyle(
                        color: selected ? Colors.black : NBColors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                      )),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          // role selain member cuma punya 1 paket (permanen) -> gak perlu
          // dipilih, langsung nampilin harga flat aja.
          if (packages != null && packages.length > 1) ...[
            const NBSectionLabel('PAKET'),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.0,
              children: packages.entries.map((e) {
                final selected = e.key == _packageType;
                final harga = e.value['harga'];
                return GestureDetector(
                  onTap: () => setState(() => _packageType = e.key),
                  child: Container(
                    decoration: BoxDecoration(
                      color: selected ? NBColors.red : NBColors.surface,
                      border: Border.all(color: Colors.black, width: 3),
                      boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(3, 3))] : null,
                    ),
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(e.key.toUpperCase(),
                            style: TextStyle(color: selected ? Colors.white : NBColors.white, fontWeight: FontWeight.w900, fontSize: 12)),
                        Text(e.key == 'custom' ? 'CUSTOM' : 'Rp${harga ?? 0}',
                            style: TextStyle(color: selected ? Colors.white70 : NBColors.textDim, fontSize: 11, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ] else if (packages != null && packages.length == 1) ...[
            NBCard(
              color: NBColors.red,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  const Icon(Icons.sell, color: Colors.white, size: 18),
                  const SizedBox(width: 10),
                  Text('Harga: Rp${packages['permanen']?['harga'] ?? 0} (permanen)',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13)),
                ],
              ),
            ),
          ],
          if (_packageType == 'custom' && packages != null && packages.length > 1) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _customDaysController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: nbInputDecoration('Durasi (hari)', icon: Icons.calendar_today),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _customHargaController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: nbInputDecoration('Harga (Rp)', icon: Icons.payments),
            ),
          ],
          const SizedBox(height: 24),
          const NBSectionLabel('DATA BUYER'),
          const SizedBox(height: 10),
          NBCard(
            child: Column(
              children: [
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('DATA BUYER', style: TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 2),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('isi data pembeli akun di bawah ini.', style: TextStyle(color: NBColors.textDim, fontSize: 12)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _buyerUserController,
                  style: const TextStyle(color: Colors.white),
                  decoration: nbInputDecoration('Username buyer', icon: Icons.person),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _buyerPassController,
                  obscureText: true,
                  style: const TextStyle(color: Colors.white),
                  decoration: nbInputDecoration('Password buyer', icon: Icons.lock),
                ),
              ],
            ),
          ),
          if (_formError != null) ...[
            const SizedBox(height: 10),
            Text(_formError!, style: const TextStyle(color: NBColors.red, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: NBButton(
              onPressed: _submit,
              color: NBColors.gold,
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: const Text('BUAT STORAN'),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

// ============================================================
// TAB 2 — UP ROLE BUYER (seller cek akun buyer, upgrade role AKUN ITU)
// ============================================================
class _UpRoleTab extends StatefulWidget {
  final String sessionKey;
  const _UpRoleTab({required this.sessionKey});

  @override
  State<_UpRoleTab> createState() => _UpRoleTabState();
}

class _UpRoleTabState extends State<_UpRoleTab> {
  // step: 'check' -> 'options' -> creating -> pending -> menunggu_review -> selesai | ditolak | expired
  String _step = 'check';

  final _targetUserController = TextEditingController();
  final _targetPassController = TextEditingController();
  bool _obscurePass = true;
  bool _checking = false;
  String? _checkError;

  String? _currentRole;
  List<dynamic> _options = [];
  String? _selectedRole;

  String? _depositId;
  int? _amount;
  int? _selisih;
  DateTime? _expiresAt;
  Timer? _pollTimer;
  Timer? _tickTimer;
  Duration _remaining = Duration.zero;
  bool _uploading = false;
  String? _submitError;
  Map<String, dynamic>? _paymentInfo;

  @override
  void dispose() {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _targetUserController.dispose();
    _targetPassController.dispose();
    super.dispose();
  }

  Future<void> _cekUsername() async {
    if (_targetUserController.text.trim().isEmpty || _targetPassController.text.trim().isEmpty) {
      setState(() => _checkError = 'Username & password akun wajib diisi');
      return;
    }
    setState(() {
      _checking = true;
      _checkError = null;
    });
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/up-role-buyer/check'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': widget.sessionKey,
          'targetUsername': _targetUserController.text.trim(),
          'targetPassword': _targetPassController.text.trim(),
        }),
      );
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _currentRole = j['currentRole'];
          _options = j['options'];
          _selectedRole = _options.isNotEmpty ? _options[0]['role'] : null;
          _step = 'options';
        });
      } else {
        setState(() => _checkError = j['error'] ?? 'Gagal cek akun');
      }
    } catch (e) {
      setState(() => _checkError = 'Gagal konek: $e');
    } finally {
      setState(() => _checking = false);
    }
  }

  Future<void> _submit() async {
    if (_selectedRole == null) return;
    setState(() {
      _step = 'creating';
      _submitError = null;
    });
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/up-role-buyer/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': widget.sessionKey,
          'targetUsername': _targetUserController.text.trim(),
          'targetPassword': _targetPassController.text.trim(),
          'targetRole': _selectedRole,
        }),
      );
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _depositId = j['depositId'];
          _amount = j['amount'];
          _selisih = j['selisih'];
          _paymentInfo = j['paymentInfo'] as Map<String, dynamic>?;
          _expiresAt = DateTime.fromMillisecondsSinceEpoch(j['expiresAt']);
          _step = 'pending';
        });
        _startPolling();
        _startCountdown();
      } else {
        setState(() {
          _step = 'options';
          _submitError = j['error'] ?? 'Gagal bikin upgrade';
        });
      }
    } catch (e) {
      setState(() {
        _step = 'options';
        _submitError = 'Gagal konek: $e';
      });
    }
  }

  Future<void> _uploadBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null || _depositId == null) return;

    setState(() => _uploading = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/up-role-buyer/upload-bukti'));
      req.fields['depositId'] = _depositId!;
      req.files.add(await http.MultipartFile.fromPath('bukti', picked.path));
      final streamed = await req.send();
      final res = await http.Response.fromStream(streamed);
      if (res.statusCode == 200) {
        setState(() => _step = 'menunggu_review');
      } else if (mounted) {
        final j = jsonDecode(res.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(j['error'] ?? 'Gagal upload')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal upload, coba lagi')));
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _startCountdown() {
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final diff = _expiresAt!.difference(DateTime.now());
      setState(() => _remaining = diff.isNegative ? Duration.zero : diff);
      if (diff.isNegative) _tickTimer?.cancel();
    });
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (_depositId == null) return;
      try {
        final res = await http.get(Uri.parse('$baseUrl/api/up-role-buyer/status/$_depositId'));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          setState(() => _step = j['status']);
          if (['selesai', 'ditolak', 'expired'].contains(j['status'])) {
            _pollTimer?.cancel();
            _tickTimer?.cancel();
          }
        }
      } catch (_) {}
    });
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _resetAll() {
    setState(() {
      _step = 'check';
      _targetUserController.clear();
      _targetPassController.clear();
      _currentRole = null;
      _options = [];
      _selectedRole = null;
      _depositId = null;
      _amount = null;
      _selisih = null;
      _checkError = null;
      _submitError = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.all(16), child: _buildBody());
  }

  Widget _buildBody() {
    switch (_step) {
      case 'check':
        return _buildCheckForm();
      case 'options':
        return _buildOptionsForm();
      case 'creating':
        return const Center(child: CircularProgressIndicator(color: NBColors.gold));
      case 'pending':
      case 'menunggu_review':
        return _buildPayment();
      case 'selesai':
        return _statusResult(Icons.check_circle, NBColors.green, 'AKUN BERHASIL DI-UPGRADE!',
            'Role ${_targetUserController.text} sekarang $_selectedRole.', 'UPGRADE LAGI');
      case 'ditolak':
        return _statusResult(Icons.cancel, NBColors.red, 'BUKTI DITOLAK ADMIN', null, 'ULANGI');
      case 'expired':
        return _statusResult(Icons.timer_off, NBColors.gold, 'WAKTU TRANSFER HABIS', null, 'COBA LAGI');
      default:
        return _buildCheckForm();
    }
  }

  Widget _statusResult(IconData icon, Color color, String title, String? subtitle, String actionLabel) {
    return Center(
      child: NBCard(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: color, border: Border.all(color: Colors.black, width: 3)),
              child: Icon(icon, color: Colors.black, size: 40),
            ),
            const SizedBox(height: 14),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
            if (subtitle != null) ...[
              const SizedBox(height: 6),
              Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.textDim, fontSize: 12)),
            ],
            const SizedBox(height: 16),
            NBButton(onPressed: _resetAll, color: color, child: Text(actionLabel)),
          ],
        ),
      ),
    );
  }

  Widget _buildCheckForm() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NBCard(
            color: NBColors.red,
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: NBColors.gold, border: Border.all(color: Colors.black, width: 3)),
                    child: const Icon(Icons.arrow_upward, color: Colors.black),
                  ),
                  const SizedBox(width: 10),
                  const NBBadge(text: 'UP ROLE', color: NBColors.gold),
                ]),
                const SizedBox(height: 12),
                const Text('NAIKKAN ROLE AKUN BUYER',
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('Cek username & password akun buyer dulu, baru pilih role tujuan & bayar selisih.',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const NBSectionLabel('1 · CEK AKUN'),
          const SizedBox(height: 10),
          NBCard(
            child: Column(
              children: [
                TextField(
                  controller: _targetUserController,
                  style: const TextStyle(color: Colors.white),
                  decoration: nbInputDecoration('Username akun (yang mau di-up)', icon: Icons.person_search),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _targetPassController,
                  obscureText: _obscurePass,
                  style: const TextStyle(color: Colors.white),
                  decoration: nbInputDecoration('Password akun', icon: Icons.lock).copyWith(
                    suffixIcon: IconButton(
                      icon: Icon(_obscurePass ? Icons.visibility : Icons.visibility_off, color: NBColors.textDim),
                      onPressed: () => setState(() => _obscurePass = !_obscurePass),
                    ),
                  ),
                ),
                if (_checkError != null) ...[
                  const SizedBox(height: 8),
                  Text(_checkError!, style: const TextStyle(color: NBColors.red, fontSize: 12, fontWeight: FontWeight.bold)),
                ],
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: _checking
                      ? const Center(child: CircularProgressIndicator(color: NBColors.gold))
                      : NBButton(
                          onPressed: _cekUsername,
                          color: NBColors.gold,
                          child: const Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.search, color: Colors.black, size: 18),
                            SizedBox(width: 8),
                            Text('CEK USERNAME'),
                          ]),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOptionsForm() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              TextButton.icon(
                onPressed: _resetAll,
                icon: const Icon(Icons.arrow_back, color: NBColors.textDim, size: 16),
                label: const Text('Ganti akun', style: TextStyle(color: NBColors.textDim)),
              ),
            ],
          ),
          Row(
            children: [
              const Text('AKUN:', style: TextStyle(color: NBColors.textDim, fontSize: 12, fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              Text(_targetUserController.text, style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
              const SizedBox(width: 10),
              NBBadge(text: _currentRole ?? '-', color: NBColors.gold),
            ],
          ),
          const SizedBox(height: 16),
          if (_options.isEmpty)
            NBCard(
              color: NBColors.surfaceAlt,
              child: const Text('Akun ini udah role tertinggi atau paket belum diaktifin admin.',
                  style: TextStyle(color: NBColors.textDim)),
            )
          else ...[
            const NBSectionLabel('TARGET ROLE BARU'),
            const SizedBox(height: 10),
            ..._options.map<Widget>((o) {
              final selected = o['role'] == _selectedRole;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: GestureDetector(
                  onTap: () => setState(() => _selectedRole = o['role']),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: selected ? NBColors.gold : NBColors.surface,
                      border: Border.all(color: Colors.black, width: 3),
                      boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(4, 4))] : null,
                    ),
                    child: Row(
                      children: [
                        Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
                            color: selected ? Colors.black : NBColors.textDim),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(o['role'],
                                  style: TextStyle(color: selected ? Colors.black : NBColors.white, fontWeight: FontWeight.w900)),
                              Text('Selisih: Rp${o['selisih']}',
                                  style: TextStyle(color: selected ? Colors.black87 : NBColors.textDim, fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
            if (_submitError != null) ...[
              const SizedBox(height: 8),
              Text(_submitError!, style: const TextStyle(color: NBColors.red, fontSize: 12, fontWeight: FontWeight.bold)),
            ],
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: NBButton(
                onPressed: _submit,
                color: NBColors.gold,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: const Text('UPGRADE ROLE'),
              ),
            ),
          ],
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildPayment() {
    if (_step != 'pending') {
      return Center(
        child: NBCard(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: NBColors.gold, border: Border.all(color: Colors.black, width: 3)),
                child: const Icon(Icons.hourglass_top, color: Colors.black, size: 36),
              ),
              const SizedBox(height: 14),
              const Text('Bukti diterima, lagi ditinjau admin.', style: TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          NBCard(
            color: NBColors.red,
            child: Column(
              children: [
                const NBBadge(text: 'MENUNGGU TRANSFER', color: NBColors.gold),
                const SizedBox(height: 12),
                Text('Rp$_amount', style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                Text('(selisih Rp$_selisih)', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: Colors.black, border: Border.all(color: NBColors.gold, width: 2)),
                  child: Text(_fmt(_remaining), style: const TextStyle(color: NBColors.gold, fontSize: 24, fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
          if (_paymentInfo != null) ...[
            const SizedBox(height: 20),
            NBPaymentCard(
              qrisUrl: '$kSetoranFileBaseUrl${_paymentInfo!['qrisPath']}',
              danaNumber: _paymentInfo!['danaNumber'] ?? '-',
              danaName: _paymentInfo!['danaName'] ?? '-',
            ),
          ],
          const SizedBox(height: 20),
          _uploading
              ? const Center(child: CircularProgressIndicator(color: NBColors.gold))
              : NBButton(
                  onPressed: _uploadBukti,
                  color: NBColors.gold,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.upload_file, color: Colors.black, size: 18),
                    SizedBox(width: 8),
                    Text('UPLOAD BUKTI TRANSFER'),
                  ]),
                ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

// ============================================================
// TAB 3 — ACC (approve scoped: TK limit harian, OWNER/KINGZ unlimited)
// ============================================================
class _AccScopedTab extends StatefulWidget {
  final String sessionKey;
  const _AccScopedTab({required this.sessionKey});

  @override
  State<_AccScopedTab> createState() => _AccScopedTabState();
}

class _AccScopedTabState extends State<_AccScopedTab> {
  List<dynamic> _items = [];
  Map<String, dynamic>? _quota;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final pendingRes = await http.get(Uri.parse('$baseUrl/api/acc/pending?sessionKey=${widget.sessionKey}'));
      final quotaRes = await http.get(Uri.parse('$baseUrl/api/acc/quota?sessionKey=${widget.sessionKey}'));
      if (pendingRes.statusCode == 200) _items = jsonDecode(pendingRes.body);
      if (quotaRes.statusCode == 200) _quota = jsonDecode(quotaRes.body);
    } catch (_) {}
    setState(() => _loading = false);
  }

  Future<void> _approve(String depositId) async {
    final res = await http.post(
      Uri.parse('$baseUrl/api/acc/approve/$depositId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'sessionKey': widget.sessionKey}),
    );
    if (mounted) {
      final j = jsonDecode(res.body);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(j['status'] == 'selesai' ? 'Akun berhasil dibuat' : (j['error'] ?? j['reason'] ?? 'Gagal'))),
      );
    }
    _load();
  }

  Future<void> _reject(String depositId) async {
    await http.post(
      Uri.parse('$baseUrl/api/acc/reject/$depositId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'sessionKey': widget.sessionKey}),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: NBColors.gold));

    return Column(
      children: [
        if (_quota != null) Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 0), child: _buildQuotaCard()),
        Expanded(
          child: _items.isEmpty
              ? const Center(child: Text('GAK ADA TRANSAKSI PENDING', style: TextStyle(color: NBColors.textDim, fontWeight: FontWeight.w900)))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(14),
                    itemCount: _items.length,
                    itemBuilder: (context, i) {
                      final item = _items[i];
                      final quotaHabis = _quota != null && _quota!['unlimited'] == false && (_quota!['remaining'] ?? 0) <= 0;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: NBCard(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                NBBadge(text: item['targetRole'], color: NBColors.red, textColor: Colors.white),
                                const SizedBox(width: 6),
                                NBBadge(text: item['packageType'].toString().toUpperCase(), color: NBColors.gold),
                              ]),
                              const SizedBox(height: 10),
                              _kvRow('Reseller', item['resellerUsername']),
                              _kvRow('Buyer', item['buyerUsername']),
                              _kvRow('Harga', 'Rp${item['harga']}'),
                              _kvRow('Sektor', 'Rp${item['sektor']}'),
                              _kvRow('Transfer', 'Rp${item['amount']}'),
                              const SizedBox(height: 10),
                              GestureDetector(
                                onTap: () => Navigator.push(context,
                                    MaterialPageRoute(builder: (_) => _AccFullscreenImage(url: '$kSetoranFileBaseUrl${item['buktiUrl']}'))),
                                child: Container(
                                  decoration: BoxDecoration(border: Border.all(color: Colors.black, width: 3)),
                                  child: Image.network(
                                    '$kSetoranFileBaseUrl${item['buktiUrl']}',
                                    fit: BoxFit.cover,
                                    height: 200,
                                    width: double.infinity,
                                    errorBuilder: (_, __, ___) =>
                                        const SizedBox(height: 100, child: Center(child: Icon(Icons.broken_image, color: NBColors.textDim))),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(children: [
                                Expanded(
                                  child: NBButton(
                                    color: quotaHabis ? NBColors.surfaceAlt : NBColors.green,
                                    onPressed: quotaHabis ? null : () => _approve(item['depositId']),
                                    child: const Text('APPROVE'),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: NBButton(
                                    color: NBColors.red,
                                    textColor: Colors.white,
                                    onPressed: () => _reject(item['depositId']),
                                    child: const Text('TOLAK'),
                                  ),
                                ),
                              ]),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildQuotaCard() {
    final unlimited = _quota!['unlimited'] == true;
    return NBCard(
      color: unlimited ? NBColors.surfaceAlt : (_quota!['remaining'] > 0 ? NBColors.gold : NBColors.red),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Icon(Icons.fact_check, color: unlimited ? NBColors.textDim : Colors.black, size: 18),
          const SizedBox(width: 8),
          Text(
            unlimited ? 'Jatah ACC: UNLIMITED' : 'Jatah ACC hari ini: ${_quota!['used']}/${_quota!['limit']}',
            style: TextStyle(color: unlimited ? NBColors.textDim : Colors.black, fontWeight: FontWeight.bold, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _kvRow(String k, String v) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Row(children: [
        SizedBox(width: 70, child: Text(k, style: const TextStyle(color: NBColors.textDim, fontSize: 12))),
        Expanded(child: Text(v, style: const TextStyle(color: NBColors.white, fontSize: 12, fontWeight: FontWeight.bold))),
      ]),
    );
  }
}

class _AccFullscreenImage extends StatelessWidget {
  final String url;
  const _AccFullscreenImage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, elevation: 0, iconTheme: const IconThemeData(color: Colors.white)),
      body: Center(child: InteractiveViewer(minScale: 0.5, maxScale: 5, child: Image.network(url))),
    );
  }
}
