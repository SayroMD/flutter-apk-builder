import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart' as xml;
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import 'app_theme.dart';
import 'theme_switcher_page.dart';

/// Tema aktif (dibaca ulang tiap build)
AppTheme get _t => ThemeController.instance.theme;

/// ════════════════════════════════════════════════════════════════
/// NEO-BRUTALISM VERSION
/// Border tebal, hard shadow, warna kontras ekstrem, tipografi kasar.
/// ════════════════════════════════════════════════════════════════

const String appFont = 'Orbitron';

class AppColors {
  // Classic (neo-brutalism) tetap sama; Dark Comic 3D pakai palet full dark.
  static bool get _c => ThemeController.instance.theme.isComic;

  static Color get bg => _c ? const Color(0xFF06090C) : const Color(0xFFF5F0E8);
  static Color get surface => _c ? const Color(0xFF0D141A) : const Color(0xFFFFFFFF);
  static Color get surface2 => _c ? const Color(0xFF131D25) : const Color(0xFFFFF8E7);
  static Color get border => _c ? const Color(0xFF19F5C8) : const Color(0xFF1A1A1A);
  static Color get accent => _c ? const Color(0xFF3D8BFF) : const Color(0xFF5B8DEF);
  static Color get accent2 => _c ? const Color(0xFF131D25) : const Color(0xFFFFE566);
  static Color get accent3 => _c ? const Color(0xFFFF2E93) : const Color(0xFFFF6B9D);
  static Color get textPrimary => _c ? const Color(0xFFE8F3EF) : const Color(0xFF1A1A1A);
  static Color get textSec => _c ? const Color(0xFFB4C4BF) : const Color(0xFF333333);
  static Color get textMuted => _c ? const Color(0xFF8FA3AD) : const Color(0xFF666666);
  static Color get green => _c ? const Color(0xFF19F58A) : const Color(0xFF4ADE80);
  static Color get red => _c ? const Color(0xFFFF2E5F) : const Color(0xFFFF2D55);
}

/// Shared data + fetch logic buat RSS News, Berita Slider, dan Weather
/// section, supaya ketiganya bisa dijadiin section drag & drop terpisah
/// di dashboard tanpa masing-masing fetch data sendiri-sendiri.
class NewsWeatherController extends ChangeNotifier {
  double _lat = -6.200000, _lon = 106.816666;

  List<dynamic> beritaList = [];
  List<dynamic> weatherForecast = [];

  int selectedNewsTab = 0;
  final List<Map<String, String>> newsTabs = [
    {"label": "ANTARA TERKINI", "url": "https://www.antaranews.com/rss/terkini.xml"},
    {"label": "DETIK NEWS", "url": "https://rss.detik.com/index.php"},
    {"label": "KOMPAS", "url": "https://www.kompas.com/rss"},
    {"label": "INTERNASIONAL", "url": "https://www.antaranews.com/rss/internasional.xml"},
    {"label": "HIBURAN", "url": "https://www.antaranews.com/rss/hiburan.xml"},
    {"label": "EKONOMI", "url": "https://www.antaranews.com/rss/ekonomi.xml"},
    {"label": "OLAHRAGA", "url": "https://www.antaranews.com/rss/olahraga.xml"},
    {"label": "TEKNOLOGI", "url": "https://www.antaranews.com/rss/teknologi.xml"},
  ];
  final Map<int, List<Map<String, dynamic>>> newsTabData = {};
  final Map<int, bool> newsTabLoading = {};
  final Map<int, String> newsTabError = {};
  bool showAllNews = false;
  String? expandedNewsId;

  bool _started = false;

  /// Idempotent — aman dipanggil dari initState tiap section (RSS/Slider/Weather)
  /// karena data cuma di-fetch sekali walau ada 3 widget yang makai controller ini.
  void start() {
    if (_started) return;
    _started = true;
    _initLocation().then((_) => _fetchAllData());
    _fetchRssNewsForTab(selectedNewsTab);
  }

  void toggleShowAllNews() {
    showAllNews = !showAllNews;
    notifyListeners();
  }

  void toggleExpandedNews(String itemKey) {
    expandedNewsId = expandedNewsId == itemKey ? null : itemKey;
    notifyListeners();
  }

  Future<void> _initLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return;
      }
      Position pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      _lat = pos.latitude;
      _lon = pos.longitude;
    } catch (_) {}
  }

  void _fetchAllData() {
    _fetchBeritaData();
    _fetchWeatherForecast();
  }

  void onNewsTabChanged(int newIndex) {
    selectedNewsTab = newIndex;
    notifyListeners();
    _fetchRssNewsForTab(newIndex);
  }

  Future<void> _fetchRssNewsForTab(int tabIndex) async {
    if (newsTabData.containsKey(tabIndex)) return;
    newsTabLoading[tabIndex] = true;
    newsTabError[tabIndex] = "";
    notifyListeners();
    try {
      final url = Uri.parse(newsTabs[tabIndex]['url']!);
      final response = await http.get(url).timeout(
            const Duration(seconds: 15),
            onTimeout: () => http.Response('Timeout', 408),
          );
      if (response.statusCode == 200) {
        final document = xml.XmlDocument.parse(response.body);
        final items = document.findAllElements('item');
        List<Map<String, dynamic>> tempNews = [];
        for (var item in items) {
          if (tempNews.length >= 10) break;
          final title = item.findElements('title').singleOrNull?.innerText ?? '';
          final pubDate = item.findElements('pubDate').singleOrNull?.innerText ?? '';
          final description = item.findElements('description').singleOrNull?.innerText ?? '';
          final link = item.findElements('link').singleOrNull?.innerText ?? '';
          final enclosure = item.findElements('enclosure').singleOrNull;
          String imageUrl = '';
          if (enclosure != null) {
            imageUrl = enclosure.getAttribute('url') ?? '';
          }
          if (imageUrl.isEmpty && description.contains('src="')) {
            final match = RegExp(r'src="(.*?)"').firstMatch(description);
            if (match != null) imageUrl = match.group(1) ?? '';
          }
          final cleanDesc = description
              .replaceAll(RegExp(r'<[^>]*>'), '')
              .replaceAll('&nbsp;', ' ')
              .trim();
          tempNews.add({
            'title': title,
            'pubDate': pubDate,
            'description': cleanDesc,
            'imageUrl': imageUrl,
            'link': link,
          });
        }
        newsTabData[tabIndex] = tempNews;
        newsTabLoading[tabIndex] = false;
        notifyListeners();
      } else {
        newsTabError[tabIndex] = "Server berita sedang down";
        newsTabLoading[tabIndex] = false;
        notifyListeners();
      }
    } catch (e) {
      newsTabError[tabIndex] = "Gagal memuat berita";
      newsTabLoading[tabIndex] = false;
      notifyListeners();
    }
  }

  Future<void> _fetchBeritaData() async {
    try {
      final res = await http
          .get(Uri.parse('https://api.nexray.eu.cc/berita/kompas'))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == true) {
          beritaList = data['result'] ?? [];
          notifyListeners();
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchWeatherForecast() async {
    try {
      final res = await http.get(Uri.parse(
        'https://api.open-meteo.com/v1/forecast'
        '?latitude=$_lat&longitude=$_lon'
        '&hourly=temperature_2m,weathercode,relativehumidity_2m,windspeed_10m,apparent_temperature'
        '&timezone=auto&forecast_days=2',
      ));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List<dynamic> times = data['hourly']['time'];
        List<dynamic> temps = data['hourly']['temperature_2m'];
        List<dynamic> codes = data['hourly']['weathercode'];
        List<dynamic> humidity = data['hourly']['relativehumidity_2m'];
        List<dynamic> wind = data['hourly']['windspeed_10m'];
        List<dynamic> feelsLike = data['hourly']['apparent_temperature'];

        List<dynamic> combined = [];
        DateTime now = DateTime.now();
        for (int i = 0; i < times.length; i++) {
          DateTime dt = DateTime.parse(times[i]);
          if (dt.isAfter(now.subtract(const Duration(hours: 1))) &&
              combined.length < 24) {
            combined.add({
              "time": dt,
              "temp": temps[i],
              "code": codes[i],
              "humidity": humidity[i],
              "wind": wind[i],
              "feelsLike": feelsLike[i],
            });
          }
        }
        weatherForecast = combined;
        notifyListeners();
      }
    } catch (_) {}
  }
}


/// ════════════════════════════════════════════════════════════════
/// 3 section terpisah (bisa di-drag & drop independen di dashboard),
/// semuanya nempel ke satu NewsWeatherController yang sama supaya
/// data (RSS, berita, cuaca) cuma di-fetch sekali.
/// ════════════════════════════════════════════════════════════════

class RssNewsSection extends StatefulWidget {
  final NewsWeatherController controller;
  const RssNewsSection({super.key, required this.controller});

  @override
  State<RssNewsSection> createState() => _RssNewsSectionState();
}

class _RssNewsSectionState extends State<RssNewsSection> {
  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    ThemeController.instance.addListener(_onThemeChanged);
    widget.controller.start();
  }

  @override
  void dispose() {
    ThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (_, __) => _buildRssNewsWidget(widget.controller),
    );
  }
}

class BeritaSliderSection extends StatefulWidget {
  final NewsWeatherController controller;
  const BeritaSliderSection({super.key, required this.controller});

  @override
  State<BeritaSliderSection> createState() => _BeritaSliderSectionState();
}

class _BeritaSliderSectionState extends State<BeritaSliderSection> {
  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    ThemeController.instance.addListener(_onThemeChanged);
    widget.controller.start();
  }

  @override
  void dispose() {
    ThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (_, __) => _buildBeritaSlider(widget.controller),
    );
  }
}

class WeatherSection extends StatefulWidget {
  final NewsWeatherController controller;
  const WeatherSection({super.key, required this.controller});

  @override
  State<WeatherSection> createState() => _WeatherSectionState();
}

class _WeatherSectionState extends State<WeatherSection> {
  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    ThemeController.instance.addListener(_onThemeChanged);
    widget.controller.start();
  }

  @override
  void dispose() {
    ThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (_, __) => _buildWeatherWidget(widget.controller),
    );
  }
}

  List<BoxShadow> _hardShadow({Color color = Colors.black, double offset = 4}) {
    if (_t.isComic) return _t.hard(offset);
    return [
      BoxShadow(
        color: color,
        offset: Offset(offset, offset),
        blurRadius: 0,
      ),
    ];
  }

  Widget _buildRssNewsWidget(NewsWeatherController c) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _hardShadow(offset: 6)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.accent2,
                  borderRadius: _t.rr(4),
                  border: Border.all(color: _t.line, width: _t.bw(2.5)),
                  boxShadow: _hardShadow(offset: 3)),
                child:  Icon(Icons.newspaper_rounded, color: _t.ink, size: 16),
              ),
              const SizedBox(width: 12),
               Text(
                "BERITA TERKINI",
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: appFont,
                  letterSpacing: 1.2,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.green,
                  borderRadius: _t.rr(4),
                  border: Border.all(color: _t.line, width: _t.bw(2)),
                  boxShadow: _hardShadow(offset: 2)),
                child: const Text(
                  "LIVE",
                  style: TextStyle(
                    fontFamily: appFont,
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Tabs
          SizedBox(
            height: 38,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: c.newsTabs.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final isActive = c.selectedNewsTab == index;
                return GestureDetector(
                  onTap: () => c.onNewsTabChanged(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: isActive ? AppColors.accent : AppColors.surface2,
                      borderRadius: _t.rr(4),
                      border: Border.all(color: _t.line, width: _t.bw(2.5)),
                      boxShadow: isActive ? _hardShadow(offset: 3) : []),
                    child: Text(
                      c.newsTabs[index]['label'] ?? '',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        fontFamily: appFont,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          Container(height: 3, color: AppColors.border),
          const SizedBox(height: 16),
          _buildNewsTabContent(c),
        ],
      ),
    );
  }

  Widget _buildNewsTabContent(NewsWeatherController c) {
    final isLoading = c.newsTabLoading[c.selectedNewsTab] ?? false;
    final error = c.newsTabError[c.selectedNewsTab] ?? '';
    final data = c.newsTabData[c.selectedNewsTab];

    if (isLoading) {
      return  Padding(
        padding: EdgeInsets.symmetric(vertical: 32),
        child: Column(
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(color: AppColors.border, strokeWidth: 3),
            ),
            SizedBox(height: 12),
            Text(
              "MENGAMBIL BERITA...",
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                fontFamily: appFont,
              ),
            ),
          ],
        ),
      );
    }

    if (error.isNotEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.accent3,
              borderRadius: _t.rr(4),
              border: Border.all(color: _t.line, width: _t.bw(3)),
              boxShadow: _hardShadow(offset: 4)),
            child: Column(
              children: [
                const Icon(Icons.wifi_off_rounded, color: Colors.white, size: 28),
                const SizedBox(height: 8),
                Text(
                  error.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: appFont,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (data == null || data.isEmpty) {
      return  Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Text(
            "TIDAK ADA BERITA",
            style: TextStyle(
              color: AppColors.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w800,
              fontFamily: appFont,
            ),
          ),
        ),
      );
    }

    final hasMore = data.length > 5;
    final displayCount = c.showAllNews ? data.length : (data.length > 5 ? 5 : data.length);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: List.generate(displayCount, (index) {
            final isLast = index == displayCount - 1;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildRssNewsItem(c, data[index]),
                if (!isLast)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Container(height: 2, color: AppColors.border),
                  ),
              ],
            );
          }),
        ),
        if (hasMore) ...[
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () {
              c.toggleShowAllNews();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: c.showAllNews ? AppColors.accent3 : AppColors.accent2,
                borderRadius: _t.rr(4),
                border: Border.all(color: _t.line, width: _t.bw(2.5)),
                boxShadow: _hardShadow(offset: 3)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    c.showAllNews ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                    color: _t.ink,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    c.showAllNews ? "SEMBUNYIKAN" : "LIHAT SEMUA (${data.length})",
                    style:  TextStyle(
                      color: _t.ink,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: appFont,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildRssNewsItem(NewsWeatherController c, Map<String, dynamic> news) {
    String formattedTime = "";
    try {
      if (news['pubDate'].toString().isNotEmpty) {
        final dateTime = DateTime.parse(news['pubDate'].toString());
        formattedTime =
            "\( {dateTime.day}/ \){dateTime.month} \( {dateTime.hour}: \){dateTime.minute.toString().padLeft(2, '0')}";
      }
    } catch (e) {
      final raw = news['pubDate'].toString();
      formattedTime = raw.length >= 16 ? raw.substring(0, 16) : raw;
    }

    final String itemKey = (news['link'] ?? news['title'] ?? '').toString();
    final bool isExpanded = c.expandedNewsId == itemKey;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        c.toggleExpandedNews(itemKey);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isExpanded ? AppColors.accent.withOpacity(0.15) : AppColors.surface,
          borderRadius: _t.rr(4),
          border: Border.all(
            color: _t.line,
            width: isExpanded ? 3 : 2,
          ),
          boxShadow: isExpanded ? _hardShadow(offset: 4) : []),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Thumbnail
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: _t.rr(4),
                    border: Border.all(color: _t.line, width: _t.bw(2.5)),
                    boxShadow: _hardShadow(offset: 3)),
                  child: ClipRRect(
                    borderRadius: _t.rr(2),
                    child: news['imageUrl'].toString().isNotEmpty
                        ? Image.network(
                            news['imageUrl'],
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>  Center(
                              child: Icon(Icons.image_not_supported_outlined, color: AppColors.textMuted, size: 20),
                            ),
                          )
                        :  Center(
                            child: Icon(Icons.article_outlined, color: AppColors.textMuted, size: 22),
                          ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        news['title'] ?? 'Tidak ada judul',
                        style:  TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          fontFamily: appFont,
                          height: 1.3,
                        ),
                        maxLines: isExpanded ? null : 2,
                        overflow: isExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.accent2,
                          borderRadius: _t.rr(3),
                          border: Border.all(color: _t.line, width: _t.bw(1.5))),
                        child: Text(
                          formattedTime,
                          style:  TextStyle(
                            color: _t.ink,
                            fontSize: 10,
                            fontFamily: appFont,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                AnimatedRotation(
                  turns: isExpanded ? 0.25 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.accent,
                      borderRadius: _t.rr(4),
                      border: Border.all(color: _t.line, width: _t.bw(2))),
                    child:  Icon(Icons.arrow_forward_ios_rounded, color: _t.ink, size: 12),
                  ),
                ),
              ],
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              alignment: Alignment.topCenter,
              child: isExpanded
                  ? Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(height: 2, color: AppColors.border),
                          const SizedBox(height: 10),
                          Text(
                            news['description'] ?? 'Tidak ada deskripsi',
                            style:  TextStyle(
                              color: AppColors.textSec,
                              fontSize: 12,
                              fontFamily: appFont,
                              height: 1.45,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 12),
                          GestureDetector(
                            onTap: () async {
                              final url = news['link']?.toString() ?? '';
                              if (url.isNotEmpty) {
                                final uri = Uri.parse(url);
                                if (await canLaunchUrl(uri)) {
                                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                                }
                              }
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                color: AppColors.accent,
                                borderRadius: _t.rr(4),
                                border: Border.all(color: _t.line, width: _t.bw(2.5)),
                                boxShadow: _hardShadow(offset: 3)),
                              child:  Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "BACA LENGKAP",
                                    style: TextStyle(
                                      color: _t.ink,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: appFont,
                                    ),
                                  ),
                                  SizedBox(width: 6),
                                  Icon(Icons.open_in_new_rounded, color: _t.ink, size: 14),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : const SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBeritaSlider(NewsWeatherController c) {
    if (c.beritaList.isEmpty) {
      return  Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: CircularProgressIndicator(color: AppColors.border, strokeWidth: 3),
        ),
      );
    }
    return SizedBox(
      height: 260,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: c.beritaList.length,
        itemBuilder: (context, index) {
          final berita = c.beritaList[index];
          final title = berita['title'] ?? 'Unknown';
          final imgUrl = berita['image'] ?? '';
          final link = berita['link'] ?? '';
          final date = berita['date'] ?? '';
          final category = berita['category'] ?? 'News';

          return Container(
            width: 180,
            margin: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: _t.rr(4),
              border: Border.all(color: _t.line, width: _t.bw(3)),
              boxShadow: _hardShadow(offset: 5)),
            clipBehavior: Clip.antiAlias,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 120,
                  width: double.infinity,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      imgUrl.isNotEmpty
                          ? Image.network(
                              imgUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: AppColors.surface2,
                                child:  Icon(Icons.broken_image, color: AppColors.textMuted, size: 32),
                              ),
                            )
                          : Container(
                              color: AppColors.surface2,
                              child:  Icon(Icons.newspaper_rounded, color: AppColors.textMuted, size: 32),
                            ),
                      // Category badge
                      Positioned(
                        bottom: 8,
                        left: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.accent2,
                            borderRadius: _t.rr(3),
                            border: Border.all(color: _t.line, width: _t.bw(2))),
                          child: Text(
                            category.toUpperCase(),
                            style:  TextStyle(
                              fontFamily: appFont,
                              color: _t.ink,
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                      // Baca button
                      Positioned(
                        top: 8,
                        right: 8,
                        child: GestureDetector(
                          onTap: () async {
                            if (link.isNotEmpty) {
                              final uri = Uri.parse(link);
                              if (await canLaunchUrl(uri)) {
                                await launchUrl(uri, mode: LaunchMode.externalApplication);
                              }
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: _t.rr(4),
                              border: Border.all(color: _t.line, width: _t.bw(2)),
                              boxShadow: _hardShadow(offset: 2)),
                            child:  Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  "BACA",
                                  style: TextStyle(
                                    fontFamily: appFont,
                                    color: _t.ink,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                SizedBox(width: 4),
                                Icon(Icons.arrow_outward_rounded, color: _t.ink, size: 12),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          date,
                          style:  TextStyle(
                            fontFamily: appFont,
                            color: AppColors.accent3,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          title,
                          style:  TextStyle(
                            fontFamily: appFont,
                            color: AppColors.textPrimary,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            height: 1.3,
                          ),
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildWeatherWidget(NewsWeatherController c) {
    if (c.weatherForecast.isEmpty) {
      return  Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: CircularProgressIndicator(color: AppColors.border, strokeWidth: 3),
        ),
      );
    }

    final cur = c.weatherForecast.first;
    final info = _weatherInfoFor(cur['code'] as int);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _hardShadow(offset: 6)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCurrentHeader(cur, info),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.accent2,
              borderRadius: _t.rr(3),
              border: Border.all(color: _t.line, width: _t.bw(2))),
            child:  Text(
              "FORECAST",
              style: TextStyle(
                fontFamily: appFont,
                color: _t.ink,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 100,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: c.weatherForecast.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final w = c.weatherForecast[index];
                final wi = _weatherInfoFor(w['code'] as int);
                final isNow = index == 0;
                return Container(
                  width: 72,
                  decoration: BoxDecoration(
                    borderRadius: _t.rr(4),
                    color: isNow ? AppColors.accent : AppColors.surface2,
                    border: Border.all(color: _t.line, width: _t.bw(2.5)),
                    boxShadow: isNow ? _hardShadow(offset: 3) : []),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        DateFormat('HH:mm').format(w['time'] as DateTime),
                        style: TextStyle(
                          fontFamily: appFont,
                          color: _t.ink,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Icon(wi.icon, color: _t.ink, size: 24),
                      const SizedBox(height: 6),
                      Text(
                        "${(w['temp'] as double).toStringAsFixed(0)}°",
                        style:  TextStyle(
                          fontFamily: appFont,
                          color: _t.ink,
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentHeader(Map cur, _WeatherInfo info) {
    final temp = (cur['temp'] as double).toStringAsFixed(0);
    final humidity = cur['humidity'];
    final wind = cur['wind'];
    final feelsLike = cur['feelsLike'];

    return Container(
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.2),
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _hardShadow(offset: 4)),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
            child: Row(
              children: [
                // Icon circle
                Container(
                  width: 78,
                  height: 78,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.accent2,
                    border: Border.all(color: _t.line, width: _t.bw(3)),
                    boxShadow: _hardShadow(offset: 4)),
                  child: Icon(info.icon, color: _t.ink, size: 40),
                ),
                const SizedBox(width: 18),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          temp,
                          style:  TextStyle(
                            fontFamily: appFont,
                            color: _t.ink,
                            fontSize: 52,
                            fontWeight: FontWeight.w900,
                            height: 1,
                          ),
                        ),
                        const SizedBox(width: 4),
                         Padding(
                          padding: EdgeInsets.only(bottom: 8),
                          child: Text(
                            "°C",
                            style: TextStyle(
                              fontFamily: appFont,
                              color: _t.ink,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppColors.accent3,
                        borderRadius: _t.rr(3),
                        border: Border.all(color: _t.line, width: _t.bw(2))),
                      child: Text(
                        info.label.toUpperCase(),
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Stats row
          Container(
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: _t.line, width: _t.bw(2.5)))),
            child: IntrinsicHeight(
              child: Row(
                children: [
                  _statCell(Icons.water_drop_rounded, "$humidity%", "KELEMBAPAN"),
                  Container(width: 2.5, color: AppColors.border),
                  _statCell(Icons.air_rounded, "$wind km/j", "ANGIN"),
                  Container(width: 2.5, color: AppColors.border),
                  _statCell(
                    Icons.thermostat_rounded,
                    "${feelsLike is double ? feelsLike.toStringAsFixed(0) : feelsLike}°",
                    "TERASA",
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCell(IconData icon, String value, String label) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                borderRadius: _t.rr(4),
                color: AppColors.accent2,
                border: Border.all(color: _t.line, width: _t.bw(2))),
              child: Icon(icon, color: _t.ink, size: 18),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    value,
                    style:  TextStyle(
                      fontFamily: appFont,
                      color: _t.ink,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    label,
                    style:  TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textMuted,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

class _WeatherInfo {
  final IconData icon;
  final Color color;
  final String label;
  const _WeatherInfo(this.icon, this.color, this.label);
}

_WeatherInfo _weatherInfoFor(int code) {
  if (code == 0) return const _WeatherInfo(Icons.wb_sunny_rounded, Colors.amber, "Cerah");
  if (code <= 3) return const _WeatherInfo(Icons.cloud_queue_rounded, Colors.lightBlueAccent, "Berawan");
  if (code <= 67) return const _WeatherInfo(Icons.water_drop_rounded, Colors.blueAccent, "Hujan");
  return const _WeatherInfo(Icons.thunderstorm_rounded, Colors.deepPurpleAccent, "Badai Petir");
}
