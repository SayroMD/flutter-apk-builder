import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'ddos_panel.dart';
import 'main.dart';
import 'base_page.dart';

class VpsPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const VpsPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<VpsPage> createState() => _VpsPageState();
}

class _VpsPageState extends State<VpsPage> with SingleTickerProviderStateMixin {
  final TextEditingController _aliasController = TextEditingController();
  final TextEditingController _ipController = TextEditingController();
  final TextEditingController _portController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  List<Map<String, dynamic>> _vpsList = [];
  Map<String, dynamic>? _selectedVps;
  bool _isLoading = true;
  int _activeTab = 0;

  @override
  void initState() {
    super.initState();
    _loadVpsData();
  }

  Future<void> _loadVpsData() async {
    setState(() => _isLoading = true);
    try {
      final uri = Uri.parse("$baseUrl/myServer?key=${widget.sessionKey}");
      final res = await http.get(uri);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        setState(() {
          _vpsList = List<Map<String, dynamic>>.from(data);
          if (_vpsList.isNotEmpty) _selectedVps = _vpsList.first;
        });
      } else if (res.statusCode == 401) {
        showCyberSnackBar(context, 'Sesi tidak valid, silakan login ulang', isError: true);
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.pushReplacementNamed(context, '/login');
        });
      } else {
        showCyberSnackBar(context, 'Gagal memuat VPS: ${res.body}', isError: true);
        setState(() { _vpsList = []; _selectedVps = null; });
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
      setState(() { _vpsList = []; _selectedVps = null; });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _addVps() async {
    if (_aliasController.text.isEmpty || _ipController.text.isEmpty ||
        _usernameController.text.isEmpty || _passwordController.text.isEmpty) {
      showCyberSnackBar(context, 'Semua field wajib diisi!', isError: true);
      return;
    }

    try {
      final uri = Uri.parse("$baseUrl/addServer");
      final res = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'host': _ipController.text.trim(),
          'port': int.tryParse(_portController.text) ?? 22,
          'username': _usernameController.text.trim(),
          'password': _passwordController.text.trim(),
          'alias': _aliasController.text.trim(),
        }),
      );

      if (res.statusCode == 200) {
        showCyberSnackBar(context, '✅ VPS berhasil ditambahkan!');
        _aliasController.clear();
        _ipController.clear();
        _portController.clear();
        _usernameController.clear();
        _passwordController.clear();
        _loadVpsData();
      } else {
        showCyberSnackBar(context, 'Gagal: ${res.body}', isError: true);
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
    }
  }

  Future<void> _deleteVps(String host) async {
    final confirm = await _showConfirmDialog('Hapus VPS?', 'Yakin ingin menghapus VPS ini?');
    if (!confirm) return;

    try {
      final uri = Uri.parse("$baseUrl/delServer");
      final res = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'host': host}),
      );

      if (res.statusCode == 200) {
        showCyberSnackBar(context, '🗑️ VPS berhasil dihapus!');
        _loadVpsData();
      } else {
        showCyberSnackBar(context, 'Gagal: ${res.body}', isError: true);
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
    }
  }

  Future<bool> _showConfirmDialog(String title, String message) async {
    return await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.red.withOpacity(0.5)),
        ),
        title: Text(title, style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: AppColors.textSec)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('BATAL', style: TextStyle(color: AppColors.textMuted)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('LANJUT', style: TextStyle(color: AppColors.red)),
          ),
        ],
      ),
    ) ?? false;
  }

  Future<void> _requestOverlayPermission() async {
    final status = await Permission.systemAlertWindow.request();
    if (status.isGranted) {
      await _showOverlay();
    } else {
      showCyberSnackBar(context, 'Izin overlay diperlukan', isError: true);
    }
  }

  Future<void> _showOverlay() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('session_key', widget.sessionKey);
    await FlutterOverlayWindow.showOverlay(
      height: 280,
      width: 320,
      overlayTitle: 'Live Target',
      overlayContent: 'Menangkap koneksi...',
      enableDrag: true,
      positionGravity: PositionGravity.auto,
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberPage(
      child: Column(
        children: [
          _buildHeader(),
          _buildTabBar(),
          Expanded(
            child: _isLoading
                ? const Center(child: CyberLoadingShimmer())
                : IndexedStack(
                    index: _activeTab,
                    children: [
                      _buildVpsListTab(),
                      _buildAttackTab(),
                      _buildLiveTargetTab(),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [AppColors.accent, AppColors.accent.withOpacity(0.6)]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.terminal_rounded, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("OTAX VPS Manager",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, fontFamily: appFont, color: AppColors.textPrimary)),
                Text("Kelola server VPS dengan mudah dan cepat",
                    style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(Icons.person, color: AppColors.textMuted, size: 14),
                const SizedBox(width: 4),
                Text(widget.username,
                    style: TextStyle(color: AppColors.textSec, fontSize: 11, fontFamily: appFont)),
                if (widget.role.isNotEmpty) ...[
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(widget.role.toUpperCase(),
                        style: TextStyle(color: AppColors.accent, fontSize: 8, fontWeight: FontWeight.bold)),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          _buildTabButton(0, 'DAFTAR VPS', Icons.list_alt_rounded),
          _buildTabButton(1, 'SERANGAN', Icons.bolt_rounded),
          _buildTabButton(2, 'LIVE TARGET', Icons.my_location_rounded),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String label, IconData icon) {
    final isActive = _activeTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _activeTab = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: isActive
                ? LinearGradient(colors: [AppColors.accent.withOpacity(0.15), AppColors.accent.withOpacity(0.05)])
                : null,
            borderRadius: BorderRadius.circular(10),
            border: isActive ? Border.all(color: AppColors.accent.withOpacity(0.3)) : null,
          ),
          child: Column(
            children: [
              Icon(icon, color: isActive ? AppColors.accent : AppColors.textMuted, size: 18),
              const SizedBox(height: 4),
              Text(label,
                  style: TextStyle(
                    color: isActive ? AppColors.accent : AppColors.textMuted,
                    fontSize: 9,
                    fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                    fontFamily: appFont,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVpsListTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.add_circle_outline, color: AppColors.accent),
                    const SizedBox(width: 10),
                    Text('TAMBAH VPS BARU',
                        style: TextStyle(color: AppColors.accent, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: appFont)),
                  ],
                ),
                const SizedBox(height: 16),
                CyberInputField(
                  controller: _aliasController,
                  label: "Nama/Alias",
                  hint: "Contoh: Server Utama",
                  icon: Icons.badge_outlined,
                ),
                const SizedBox(height: 12),
                CyberInputField(
                  controller: _ipController,
                  label: "Alamat IP",
                  hint: "192.168.1.1",
                  icon: Icons.dns_outlined,
                ),
                const SizedBox(height: 12),
                CyberInputField(
                  controller: _portController,
                  label: "Port SSH",
                  hint: "22 (default)",
                  icon: Icons.numbers_outlined,
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),
                CyberInputField(
                  controller: _usernameController,
                  label: "Username",
                  hint: "root atau user",
                  icon: Icons.person_outline,
                ),
                const SizedBox(height: 12),
                CyberInputField(
                  controller: _passwordController,
                  label: "Password",
                  hint: "Password SSH",
                  icon: Icons.lock_outline,
                  obscureText: true,
                ),
                const SizedBox(height: 16),
                CyberButton(
                  label: "TAMBAH VPS",
                  icon: Icons.add_circle_rounded,
                  onTap: _addVps,
                  width: double.infinity,
                ),
              ],
            ),
          ),
          if (_vpsList.isNotEmpty) ...[
            const SizedBox(height: 16),
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.storage_outlined, color: AppColors.accent),
                      const SizedBox(width: 10),
                      Text('VPS TERSIMPAN',
                          style: TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: appFont)),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                        ),
                        child: Text('${_vpsList.length} VPS',
                            style: TextStyle(color: AppColors.accent, fontSize: 11)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ..._vpsList.map((vps) => _buildVpsCard(vps)).toList(),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildVpsCard(Map<String, dynamic> vps) {
    final isSelected = _selectedVps?['host'] == vps['host'];
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isSelected ? AppColors.accent.withOpacity(0.1) : AppColors.surface2.withOpacity(0.5),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isSelected ? AppColors.accent : AppColors.border, width: isSelected ? 2 : 1),
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [AppColors.accent.withOpacity(0.4), AppColors.accent.withOpacity(0.2)]),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.computer_outlined, color: AppColors.accent, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(vps['alias'] ?? vps['host'],
                    style: TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text('${vps['host']}:${vps['port']}',
                    style: TextStyle(color: AppColors.textSec, fontSize: 12)),
                Text('User: ${vps['username']}',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
              ],
            ),
          ),
          Column(
            children: [
              IconButton(
                onPressed: () => setState(() => _selectedVps = vps),
                icon: Icon(Icons.check_circle, color: isSelected ? AppColors.green : AppColors.textMuted, size: 22),
              ),
              IconButton(
                onPressed: () => _deleteVps(vps['host']),
                icon: Icon(Icons.delete_outline, color: AppColors.red.withOpacity(0.8), size: 20),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAttackTab() {
    return Center(
      child: _selectedVps != null
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.bolt, color: AppColors.red, size: 64),
                const SizedBox(height: 16),
                Text('Gunakan DDoS Panel untuk meluncurkan serangan',
                    style: TextStyle(color: AppColors.textSec, fontSize: 16, textAlign: TextAlign.center)),
                const SizedBox(height: 20),
                CyberButton(
                  label: "BUKA DDOS PANEL",
                  icon: Icons.open_in_new_rounded,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AttackPanel(sessionKey: widget.sessionKey),
                      ),
                    );
                  },
                  color: AppColors.red,
                ),
              ],
            )
          : Text('Pilih VPS terlebih dahulu',
              style: TextStyle(color: AppColors.textSec, fontSize: 16)),
    );
  }

  Widget _buildLiveTargetTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: GlassCard(
        child: Column(
          children: [
            Icon(Icons.my_location, color: AppColors.red, size: 56),
            const SizedBox(height: 16),
            Text('LIVE TARGET CAPTURE',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: appFont)),
            const SizedBox(height: 8),
            Text('Aktifkan overlay untuk menangkap IP dan port dari game yang sedang berjalan.\n'
                 'Setelah muncul, tekan "SERANG" untuk meluncurkan serangan.',
                style: TextStyle(color: AppColors.textSec, textAlign: TextAlign.center)),
            const SizedBox(height: 24),
            CyberButton(
              label: "BUKA OVERLAY",
              icon: Icons.open_in_browser_rounded,
              onTap: _requestOverlayPermission,
              color: AppColors.red,
              width: double.infinity,
            ),
          ],
        ),
      ),
    );
  }
}