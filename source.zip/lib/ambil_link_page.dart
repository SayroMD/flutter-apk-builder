import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'setoran_config.dart';
import 'main.dart';
import 'storan_theme.dart';

class AmbilLinkPage extends StatefulWidget {
  final String sessionKey;

  const AmbilLinkPage({super.key, required this.sessionKey});

  @override
  State<AmbilLinkPage> createState() => _AmbilLinkPageState();
}

class _AmbilLinkPageState extends State<AmbilLinkPage> {
  bool _loading = false;
  String? _link;
  String? _role;
  String? _error;

  Future<void> _ambilLink() async {
    setState(() {
      _loading = true;
      _error = null;
      _link = null;
    });
    try {
      final res = await http.get(Uri.parse('$baseUrl/api/ambil-link?sessionKey=${widget.sessionKey}'));
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _link = j['link'];
          _role = j['role'];
        });
      } else {
        setState(() => _error = j['error'] ?? 'Gagal ambil link');
      }
    } catch (e) {
      setState(() => _error = 'Gagal konek ke server: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  void _copyLink() {
    if (_link == null) return;
    Clipboard.setData(ClipboardData(text: _link!));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link disalin ke clipboard')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NBColors.bg,
      appBar: AppBar(
        backgroundColor: NBColors.bg,
        elevation: 0,
        title: const Text('AMBIL LINK', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: NBCard(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: NBColors.gold, border: Border.all(color: Colors.black, width: 3)),
                  child: const Icon(Icons.link, color: Colors.black, size: 40),
                ),
                const SizedBox(height: 14),
                const Text('AMBIL LINK UNDANGAN GROUP',
                    textAlign: TextAlign.center, style: TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                const Text('Sesuai role akun lo', textAlign: TextAlign.center, style: TextStyle(color: NBColors.textDim, fontSize: 12)),
                const SizedBox(height: 20),
                if (_loading) const CircularProgressIndicator(color: NBColors.gold),
                if (!_loading && _link == null)
                  NBButton(
                    onPressed: _ambilLink,
                    color: NBColors.gold,
                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                    child: const Text('AMBIL LINK'),
                  ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.red, fontWeight: FontWeight.bold)),
                ],
                if (_link != null) ...[
                  const SizedBox(height: 10),
                  NBBadge(text: 'ROLE: $_role', color: NBColors.gold),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Colors.black, border: Border.all(color: NBColors.gold, width: 2)),
                    child: SelectableText(_link!, style: const TextStyle(color: NBColors.gold)),
                  ),
                  const SizedBox(height: 6),
                  const Text('Link berlaku 10 menit, sekali pake', style: TextStyle(color: NBColors.textDim, fontSize: 11)),
                  const SizedBox(height: 16),
                  NBButton(
                    onPressed: _copyLink,
                    color: NBColors.gold,
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.copy, color: Colors.black, size: 16),
                      SizedBox(width: 8),
                      Text('SALIN LINK'),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  TextButton(
                    onPressed: _ambilLink,
                    child: const Text('Generate Ulang', style: TextStyle(color: NBColors.textDim)),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
