// get_code_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class GetCodePage extends StatefulWidget {
  const GetCodePage({super.key});

  @override
  State<GetCodePage> createState() => _GetCodePageState();
}

class _GetCodePageState extends State<GetCodePage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  String? _htmlCode;
  String? _error;

  final List<String> _proxyServers = [
    'https://api.allorigins.win/raw?url=',
    'https://corsproxy.io/?',
    'https://cors-anywhere.herokuapp.com/',
  ];

  Future<void> _fetchHtml() async {
    String url = _urlController.text.trim();
    if (url.isEmpty) {
      showCyberSnackBar(context, "Masukkan URL website", isError: true);
      return;
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
      _urlController.text = url;
    }

    setState(() {
      _isLoading = true;
      _error = null;
      _htmlCode = null;
    });

    String? html;
    for (final proxy in _proxyServers) {
      try {
        final response = await http.get(
          Uri.parse('$proxy${Uri.encodeComponent(url)}'),
          headers: {'User-Agent': 'Mozilla/5.0'},
        ).timeout(const Duration(seconds: 15));

        if (response.statusCode == 200 && response.body.length > 100) {
          html = response.body;
          break;
        }
      } catch (_) {
        continue;
      }
    }

    if (html != null) {
      setState(() {
        _htmlCode = html;
        _isLoading = false;
      });
      showCyberSnackBar(context, "Berhasil mengambil HTML dari $url");
    } else {
      setState(() {
        _error = 'Gagal mengambil HTML. Coba URL lain.';
        _isLoading = false;
      });
      showCyberSnackBar(context, "Gagal mengambil HTML", isError: true);
    }
  }

  void _copyToClipboard() {
    if (_htmlCode != null) {
      Clipboard.setData(ClipboardData(text: _htmlCode!));
      showCyberSnackBar(context, "HTML code disalin ke clipboard");
    }
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
        title: "GET CODE",
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: AppColors.orange, size: 20),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    "Beberapa website memiliki proteksi yang mencegah ekstraksi HTML",
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // get_code.dart - Perbaiki onSubmitted
            CyberInputField(
              controller: _urlController,
              label: "URL WEBSITE",
              hint: "contoh: example.com",
              icon: Icons.link_rounded,
              keyboardType: TextInputType.url,
              onSubmitted: (String value) { // <--- UBAH KE String
                _fetchHtml();
              },
            ),
          const SizedBox(height: 16),

          CyberButton(
            label: _isLoading ? "MEMPROSES..." : "GET HTML CODE",
            icon: _isLoading ? Icons.hourglass_top : Icons.code_rounded,
            onTap: _isLoading ? () {} : _fetchHtml,
            isLoading: _isLoading,
            width: double.infinity,
          ),
          const SizedBox(height: 16),

          if (_isLoading)
            const Center(child: CyberLoadingShimmer())
          else if (_error != null)
            GlassCard(
              padding: const EdgeInsets.all(16),
              borderColor: AppColors.red.withOpacity(0.3),
              child: Row(
                children: [
                  Icon(Icons.error_outline_rounded, color: AppColors.red, size: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _error!,
                      style: const TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            )
          else if (_htmlCode != null)
            GlassCard(
              padding: EdgeInsets.zero,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: AppColors.borderLight.withOpacity(0.3))),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.code_rounded, color: AppColors.accent, size: 20),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            "Extracted HTML Code",
                            style: TextStyle(
                              fontFamily: appFont,
                              color: AppColors.textPrimary,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: _copyToClipboard,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: AppColors.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.copy_rounded, color: AppColors.accent, size: 14),
                                SizedBox(width: 6),
                                Text(
                                  "Copy",
                                  style: TextStyle(
                                    fontFamily: appFont,
                                    color: AppColors.accent,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 300,
                    padding: const EdgeInsets.all(16),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        _htmlCode!,
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          color: AppColors.textSec,
                          fontSize: 11,
                          height: 1.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}