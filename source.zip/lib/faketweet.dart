// faketweet.dart - CYBER STYLE
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'base_page.dart';

class FakeTweetPage extends StatefulWidget {
  const FakeTweetPage({Key? key}) : super(key: key);

  @override
  State<FakeTweetPage> createState() => _FakeTweetPageState();
}

class _FakeTweetPageState extends State<FakeTweetPage> {
  final TextEditingController _bgController = TextEditingController();
  final TextEditingController _avatarController = TextEditingController();
  final TextEditingController _imageController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _tweetController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _retweetsController = TextEditingController();
  final TextEditingController _commentsController = TextEditingController();
  final TextEditingController _likesController = TextEditingController();
  bool _verified = true;

  bool _isLoading = false;
  bool _imageGenerated = false;
  Uint8List? _generatedImage;
  bool _isSharing = false;

  @override
  void initState() {
    super.initState();
    _bgController.text = "light";
    _avatarController.text =
        "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
    _imageController.text =
        "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
    _nameController.text = "OTA 💕 Ayun";
    _usernameController.text = "👑 OTAX";
    _tweetController.text = "Selalu Nantikan Pembaruan OTAX";
    _dateController.text = "2025-05-04T10:30:00";
    _retweetsController.text = "999";
    _commentsController.text = "888";
    _likesController.text = "7777";
  }

  Future<void> _generateTweet() async {
    if (_nameController.text.isEmpty) {
      showCyberSnackBar(context, 'Masukkan nama tampilan', isError: true);
      return;
    }
    if (_usernameController.text.isEmpty) {
      showCyberSnackBar(context, 'Masukkan username Twitter', isError: true);
      return;
    }
    if (_tweetController.text.isEmpty) {
      showCyberSnackBar(context, 'Masukkan konten tweet', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
      _imageGenerated = false;
    });

    try {
      final bg = Uri.encodeComponent(_bgController.text);
      final avatar = Uri.encodeComponent(_avatarController.text);
      final image = Uri.encodeComponent(_imageController.text);
      final name = Uri.encodeComponent(_nameController.text);
      final username = Uri.encodeComponent(_usernameController.text);
      final tweet = Uri.encodeComponent(_tweetController.text);
      final date = Uri.encodeComponent(_dateController.text);
      final retweets = Uri.encodeComponent(_retweetsController.text);
      final comment = Uri.encodeComponent(_commentsController.text);
      final likes = Uri.encodeComponent(_likesController.text);
      final verified = _verified ? "true" : "false";

      final apiUrl =
          'https://api.ryzumi.net/api/image/faketweet?bg=$bg&avatar=$avatar&image=$image&name=$name&username=$username&tweet=$tweet&date=$date&retweets=$retweets&comment=$comment&likes=$likes&verified=$verified';

      final response = await http
          .get(
            Uri.parse(apiUrl),
            headers: {'accept': 'image/png'},
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _generatedImage = response.bodyBytes;
          _imageGenerated = true;
        });
        showCyberSnackBar(context, 'Tweet berhasil dibuat! 🎉');
      } else {
        throw Exception('Gagal membuat tweet. Status: ${response.statusCode}');
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: ${e.toString()}', isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveToGallery() async {
    if (_generatedImage == null) {
      showCyberSnackBar(context, 'Buat tweet terlebih dahulu!', isError: true);
      return;
    }

    try {
      setState(() => _isSharing = true);
      final result = await ImageGallerySaverPlus.saveImage(
        _generatedImage!,
        name: "fake_tweet_${DateTime.now().millisecondsSinceEpoch}",
        quality: 100,
      );
      if (result['isSuccess'] == true) {
        showCyberSnackBar(context, '✅ Tweet disimpan ke galeri!');
      } else {
        showCyberSnackBar(context, '❌ Gagal menyimpan tweet', isError: true);
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: ${e.toString()}', isError: true);
    } finally {
      setState(() => _isSharing = false);
    }
  }

  Future<void> _shareTweet() async {
    if (_generatedImage == null) {
      showCyberSnackBar(context, 'Buat tweet terlebih dahulu!', isError: true);
      return;
    }

    try {
      setState(() => _isSharing = true);
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/fake_tweet_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Lihat fake tweet ini!',
        subject: 'Fake Twitter Tweet',
      );
    } catch (e) {
      showCyberSnackBar(context, 'Error membagikan tweet', isError: true);
    } finally {
      setState(() => _isSharing = false);
    }
  }

  void _resetForm() {
    setState(() {
      _bgController.text = "light";
      _avatarController.text =
          "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
      _imageController.text =
          "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
      _nameController.text = "OTAX For You";
      _usernameController.text = "OTAX";
      _tweetController.text = "Just Have Fun Broo";
      _dateController.text = "2025-05-04T10:30:00";
      _retweetsController.text = "999";
      _commentsController.text = "888";
      _likesController.text = "7777";
      _verified = true;
      _generatedImage = null;
      _imageGenerated = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: 'FAKE TWEET',
      showBackButton: true,
      contentPadding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Preview
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                      ),
                      child: Text(
                        'PRATINJAU',
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.accent,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _generatedImage != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.memory(
                          _generatedImage!,
                          fit: BoxFit.contain,
                          height: 280,
                        ),
                      )
                    : Container(
                        height: 280,
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.photo_camera_outlined, size: 48, color: AppColors.textMuted),
                            const SizedBox(height: 12),
                            Text(
                              'Tweet akan muncul di sini',
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.textSec,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                if (_imageGenerated) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.green.withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle, color: AppColors.green, size: 16),
                        const SizedBox(width: 8),
                        Text(
                          'Tweet Siap Digunakan!',
                          style: TextStyle(
                            fontFamily: appFont,
                            color: AppColors.green,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Form
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Theme Dropdown
                _buildCyberDropdown(
                  label: 'TEMA LATAR',
                  icon: Icons.palette_outlined,
                  value: _bgController.text,
                  items: const ["light", "dark"],
                  onChanged: (val) => setState(() => _bgController.text = val!),
                ),
                const SizedBox(height: 16),

                CyberInputField(
                  controller: _nameController,
                  label: 'NAMA TAMPILAN',
                  hint: 'Masukkan nama tampilan',
                  icon: Icons.badge_outlined,
                ),
                const SizedBox(height: 16),

                CyberInputField(
                  controller: _usernameController,
                  label: 'USERNAME TWITTER',
                  hint: 'Masukkan username (tanpa @)',
                  icon: Icons.alternate_email,
                ),
                const SizedBox(height: 16),

                CyberInputField(
                  controller: _tweetController,
                  label: 'KONTEN TWEET',
                  hint: 'Apa yang ingin kamu tweet?',
                  icon: Icons.chat_bubble_outline,
                  maxLines: 3,
                ),
                const SizedBox(height: 16),

                CyberInputField(
                  controller: _avatarController,
                  label: 'URL FOTO PROFIL',
                  hint: 'https://contoh.com/avatar.jpg',
                  icon: Icons.link,
                ),
                const SizedBox(height: 16),

                CyberInputField(
                  controller: _imageController,
                  label: 'URL MEDIA (OPSIONAL)',
                  hint: 'https://contoh.com/gambar.jpg',
                  icon: Icons.image_outlined,
                ),
                const SizedBox(height: 16),

                CyberInputField(
                  controller: _dateController,
                  label: 'WAKTU TWEET (ISO 8601)',
                  hint: '2025-05-04T10:30:00',
                  icon: Icons.calendar_today_outlined,
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: CyberInputField(
                        controller: _retweetsController,
                        label: 'RETWEETS',
                        hint: '999',
                        icon: Icons.repeat,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CyberInputField(
                        controller: _commentsController,
                        label: 'KOMENTAR',
                        hint: '888',
                        icon: Icons.comment_outlined,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CyberInputField(
                        controller: _likesController,
                        label: 'SUKA',
                        hint: '7777',
                        icon: Icons.favorite_border,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Verified Switch
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.verified, color: const Color(0xFF1DA1F2), size: 20),
                      const SizedBox(width: 12),
                      Text(
                        'AKUN TERVERIFIKASI',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textSec,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      Switch(
                        value: _verified,
                        onChanged: (val) => setState(() => _verified = val),
                        activeColor: AppColors.accent,
                        activeTrackColor: AppColors.accent.withOpacity(0.3),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                CyberButton(
                  label: 'BUAT FAKE TWEET',
                  icon: Icons.auto_awesome,
                  onTap: _generateTweet,
                  isLoading: _isLoading,
                  width: double.infinity,
                ),

                if (_imageGenerated) ...[
                  const SizedBox(height: 24),
                  const Divider(color: AppColors.borderLight, height: 1),
                  const SizedBox(height: 20),
                  Text(
                    'BAGIKAN TWEET ANDA',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: CyberButton(
                          label: 'SIMPAN',
                          icon: Icons.save_alt_rounded,
                          onTap: _saveToGallery,
                          isLoading: _isSharing,
                          color: AppColors.textSec,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: CyberButton(
                          label: 'BAGIKAN',
                          icon: Icons.share_rounded,
                          onTap: _shareTweet,
                          isLoading: _isSharing,
                          color: AppColors.accent,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Guide
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                      ),
                      child: Icon(Icons.help_outline_rounded, color: AppColors.accent, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'PANDUAN PENGGUNAAN',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildGuideStep(1, 'Isi semua field yang diperlukan'),
                _buildGuideStep(2, 'Ubah tema latar sesuai keinginan'),
                _buildGuideStep(3, 'Masukkan URL foto profil dan media'),
                _buildGuideStep(4, 'Atur jumlah retweet, komentar, dan suka'),
                _buildGuideStep(5, 'Tentukan status verifikasi akun'),
                _buildGuideStep(6, 'Klik "Buat Fake Tweet" dan tunggu hasilnya'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCyberDropdown({
    required String label,
    required IconData icon,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Row(
            children: [
              Icon(icon, color: AppColors.accent, size: 12),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface2,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.borderLight),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              dropdownColor: AppColors.surface,
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 13,
                fontFamily: appFont,
              ),
              icon: Icon(Icons.arrow_drop_down, color: AppColors.textSec),
              items: items.map((item) {
                return DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item.toUpperCase(),
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textPrimary,
                      fontSize: 13,
                    ),
                  ),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGuideStep(int number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.accent.withOpacity(0.4)),
            ),
            child: Center(
              child: Text(
                "$number",
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                text,
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _bgController.dispose();
    _avatarController.dispose();
    _imageController.dispose();
    _nameController.dispose();
    _usernameController.dispose();
    _tweetController.dispose();
    _dateController.dispose();
    _retweetsController.dispose();
    _commentsController.dispose();
    _likesController.dispose();
    super.dispose();
  }
}