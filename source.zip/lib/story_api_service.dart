import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'story_model.dart';
import 'main.dart';

class StoryApiService {
  // Ambil session key dari SharedPreferences
  static Future<String> _sessionKey() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('key');

    if (key == null || key.isEmpty) {
      throw Exception('Belum login / session key kosong');
    }

    return key;
  }

  // Header autentikasi
  static Future<Map<String, String>> _authHeaders() async {
    return {
      'x-session-key': await _sessionKey(),
    };
  }

  // =========================
  // STORIES
  // =========================

  static Future<List<StoryGroup>> fetchStories() async {
    final res = await http.get(
      Uri.parse('$baseUrl/stories'),
      headers: await _authHeaders(),
    );

    if (res.statusCode != 200) {
      throw Exception('Gagal ambil story: ${res.statusCode}');
    }

    final List data = jsonDecode(res.body);

    return data.map((g) {
      return StoryGroup(
        userId: g['username'],
        userName: g['username'],
        avatarUrl: g['avatarUrl'] ?? '',
        stories: (g['stories'] as List).map((s) {
          return Story(
            id: s['id'],
            userName: g['username'],
            avatarUrl: g['avatarUrl'] ?? '',
            mediaUrl: '$baseUrl${s['mediaUrl']}',
            isVideo: s['isVideo'] ?? false,
            createdAt: DateTime.fromMillisecondsSinceEpoch(
              s['createdAt'],
            ),
          );
        }).toList(),
      );
    }).toList();
  }

  static Future<void> uploadStory({
    required File mediaFile,
  }) async {
    final uri = Uri.parse('$baseUrl/stories');

    final request = http.MultipartRequest(
      'POST',
      uri,
    )
      ..headers.addAll(await _authHeaders())
      ..files.add(
        await http.MultipartFile.fromPath(
          'media',
          mediaFile.path,
        ),
      );

    final streamed = await request.send();

    if (streamed.statusCode != 201) {
      final body = await streamed.stream.bytesToString();

      throw Exception('Upload gagal: $body');
    }
  }

  static Future<void> deleteStory(String storyId) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/stories/$storyId'),
      headers: await _authHeaders(),
    );

    if (res.statusCode != 200) {
      throw Exception(
        'Gagal hapus story: ${res.statusCode}',
      );
    }
  }

  // =========================
  // COMMENTS
  // =========================

  static Future<List<Map<String, dynamic>>> fetchComments(
    String storyId,
  ) async {
    final res = await http.get(
      Uri.parse('$baseUrl/stories/$storyId/comments'),
      headers: await _authHeaders(),
    );

    if (res.statusCode != 200) {
      throw Exception(
        'Gagal ambil komentar: ${res.statusCode}',
      );
    }

    final List data = jsonDecode(res.body);

    return data
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  static Future<Map<String, dynamic>> postComment(
    String storyId,
    String text,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/stories/$storyId/comments'),
      headers: {
        ...await _authHeaders(),
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'text': text,
      }),
    );

    if (res.statusCode != 201) {
      throw Exception(
        'Gagal kirim komentar: ${res.statusCode}',
      );
    }

    return Map<String, dynamic>.from(
      jsonDecode(res.body),
    );
  }

  static Future<void> deleteComment(
    String storyId,
    String commentId,
  ) async {
    final res = await http.delete(
      Uri.parse(
        '$baseUrl/stories/$storyId/comments/$commentId',
      ),
      headers: await _authHeaders(),
    );

    if (res.statusCode != 200) {
      throw Exception(
        'Gagal hapus komentar: ${res.statusCode}',
      );
    }
  }
}