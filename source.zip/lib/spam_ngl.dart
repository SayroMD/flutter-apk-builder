import 'dart:convert';
import 'dart:math' as dart_math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String appFont = 'Orbitron';

// ==================== APP COLORS (TEMA DASHBOARD) ====================
class AppColors {
  static const bg          = Color(0xFF060B19); 
  static const surface     = Color(0xFF0D1424);
  static const surface2    = Color(0xFF131D33);
  static const borderLight = Color(0xFF3B4859); 
  static const accent      = Color(0xFF00E5FF); 
  static const darkBlue    = Color(0xFF0044CC);
  static const textMuted   = Color(0xFF8B9BB4);
  static const red         = Color(0xFFFF1744);
}

// ==================== BACKGROUND HEXAGON 3D ====================
class HexagonBackground extends StatelessWidget {
  final Widget child;
  const HexagonBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: const Color(0xFF030712)),
        Positioned(
          top: -150, left: -150,
          child: Container(
            width: 400, height: 400,
            decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.accent.withOpacity(0.12), blurRadius: 200)]),
          ),
        ),
        Positioned(
          bottom: -150, right: -150,
          child: Container(
            width: 400, height: 400,
            decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.darkBlue.withOpacity(0.25), blurRadius: 200)]),
          ),
        ),
        Positioned.fill(child: CustomPaint(painter: _HexagonPainter())),
        child,
      ],
    );
  }
}

class _HexagonPainter extends CustomPainter {
  void drawHexagon(Canvas canvas, Paint paint, double x, double y, double size) {
    final path = Path();
    for (int i = 0; i <= 6; i++) {
      double angle = (i * 60) * dart_math.pi / 180;
      double px = x + size * dart_math.cos(angle);
      double py = y + size * dart_math.sin(angle);
      if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
    }
    path.close(); canvas.drawPath(path, paint);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final fillPaint = Paint()..color = AppColors.accent.withOpacity(0.04)..style = PaintingStyle.fill;
    final strokePaint = Paint()..color = AppColors.accent.withOpacity(0.15)..style = PaintingStyle.stroke..strokeWidth = 2.5;
    double hexSize = 45.0;
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        double x = size.width - 20 + (i * 78) - (j * 39);
        double y = -20.0 + (j * 68) + (i * 34);
        drawHexagon(canvas, fillPaint, x, y, hexSize); drawHexagon(canvas, strokePaint, x, y, hexSize);
      }
    }
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        double x = -40.0 + (i * 78) - (j * 39);
        double y = size.height - 150 + (j * 68) + (i * 34);
        drawHexagon(canvas, fillPaint, x, y, hexSize); drawHexagon(canvas, strokePaint, x, y, hexSize);
      }
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==================== RESTRICT INPUT FORMATTER MAX 100 ====================
class MaxValueFormatter extends TextInputFormatter {
  final int max;
  MaxValueFormatter(this.max);

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.text.isEmpty) return newValue;
    final int? value = int.tryParse(newValue.text);
    if (value == null || value > max) {
      return oldValue; // Batalkan input jika lebih dari 100
    }
    return newValue;
  }
}

// ==================== MAIN PAGE ====================
class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController _linkCtrl = TextEditingController();
  final TextEditingController _msgCtrl = TextEditingController();
  final TextEditingController _countCtrl = TextEditingController();

  bool _isRunning = false;
  final List<String> _logs = [];

  void _addLog(String message) {
    setState(() {
      final time = "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}:${DateTime.now().second.toString().padLeft(2, '0')}";
      _logs.insert(0, "[$time] $message");
    });
  }

  Future<void> _startSpam() async {
    final link = _linkCtrl.text.trim();
    final msg = _msgCtrl.text.trim();
    final count = _countCtrl.text.trim();

    if (link.isEmpty || msg.isEmpty || count.isEmpty) {
      _addLog("⚠️ Form tidak boleh kosong!");
      return;
    }

    setState(() => _isRunning = true);
    _addLog("🚀 Memulai NGL Spam ke target...");
    
    // Parsing URL secara aman (URL Encoding)
    final url = Uri.parse(
      "https://api.nexray.eu.cc/tools/spamngl?url=${Uri.encodeComponent(link)}&pesan=${Uri.encodeComponent(msg)}&jumlah=$count"
    );

    try {
      final response = await http.get(url).timeout(const Duration(seconds: 30));

      if (!_isRunning) return; // Jika ditekan pause saat loading

      if (response.statusCode == 200) {
        _addLog("✅ Request sukses dikirim ke Server API!");
        try {
          final data = jsonDecode(response.body);
          _addLog("Response: ${data['message'] ?? 'Spam diproses'}");
        } catch (_) {
          _addLog("Response: ${response.body}");
        }
      } else {
        _addLog("❌ Gagal! Server merespon dengan kode ${response.statusCode}");
      }
    } catch (e) {
      if (_isRunning) _addLog("⚠️ Error koneksi: $e");
    } finally {
      setState(() => _isRunning = false);
    }
  }

  void _pauseSpam() {
    if (_isRunning) {
      setState(() => _isRunning = false);
      _addLog("⏸️ Spam dibatalkan / di-pause oleh sistem klien.");
    }
  }

  @override
  void dispose() {
    _linkCtrl.dispose();
    _msgCtrl.dispose();
    _countCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: HexagonBackground(
        child: SafeArea(
          child: Column(
            children: [
              // ==================== HEADER ====================
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.surface2, 
                          borderRadius: BorderRadius.circular(10), 
                          border: Border.all(color: AppColors.borderLight)
                        ),
                        child: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.accent, size: 16),
                      ),
                    ),
                    const Expanded(
                      child: Center(
                        child: Text(
                          "NGL SPAMER",
                          style: TextStyle(
                            fontFamily: appFont, color: Colors.white, fontSize: 18, 
                            fontWeight: FontWeight.w900, letterSpacing: 2, 
                            shadows: [Shadow(color: AppColors.accent, blurRadius: 10)]
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 40), // Placeholder agar header tetap center
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Column(
                    children: [
                      // ==================== KOTAK INPUT AREA ====================
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.surface.withOpacity(0.8),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.borderLight, width: 1.5),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 15)],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // --- INPUT LINK ---
                            _buildInputHeader(Icons.link_rounded, "Masukan Link"),
                            const SizedBox(height: 8),
                            _buildTextField(_linkCtrl, "Contoh: https://ngl.link/username"),
                            const SizedBox(height: 18),

                            // --- INPUT PESAN ---
                            _buildInputHeader(Icons.message_rounded, "Masukan Pesan"),
                            const SizedBox(height: 8),
                            _buildTextField(_msgCtrl, "Pesan anonim kamu...", maxLines: 2),
                            const SizedBox(height: 18),

                            // --- INPUT COUNT ---
                            _buildInputHeader(Icons.bug_report_rounded, "Count"),
                            const SizedBox(height: 8),
                            _buildTextField(
                              _countCtrl, 
                              "Maksimal 100", 
                              isNumber: true,
                              formatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                MaxValueFormatter(100), // Batas validasi
                              ]
                            ),
                            const SizedBox(height: 24),

                            // --- ACTION BUTTONS ---
                            Row(
                              children: [
                                // Tombol PAUSE
                                Expanded(
                                  flex: 2,
                                  child: ElevatedButton.icon(
                                    onPressed: _pauseSpam,
                                    icon: const Icon(Icons.pause_rounded, color: Colors.white, size: 18),
                                    label: const Text("PAUSE", style: TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppColors.red.withOpacity(0.8),
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      side: BorderSide(color: AppColors.red.withOpacity(0.5)),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                // Tombol SEND
                                Expanded(
                                  flex: 3,
                                  child: ElevatedButton.icon(
                                    onPressed: _isRunning ? null : _startSpam,
                                    icon: _isRunning 
                                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: AppColors.bg, strokeWidth: 2)) 
                                      : const Icon(Icons.rocket_launch_rounded, color: AppColors.bg, size: 18),
                                    label: const Text("Send Message", style: TextStyle(fontFamily: appFont, color: AppColors.bg, fontSize: 12, fontWeight: FontWeight.bold)),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppColors.accent,
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      shadowColor: AppColors.accent.withOpacity(0.5),
                                      elevation: 8,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 20),

                      // ==================== KOTAK LOG ACTIVITY ====================
                      Container(
                        height: 220, // Tinggi fix untuk area log
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.borderLight, width: 1.5),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: AppColors.surface2.withOpacity(0.8),
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                                border: const Border(bottom: BorderSide(color: AppColors.borderLight)),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.terminal_rounded, color: AppColors.accent, size: 16),
                                  const SizedBox(width: 8),
                                  const Text("LOG ACTIVITY", style: TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
                                ],
                              ),
                            ),
                            Expanded(
                              child: _logs.isEmpty 
                                ? Center(
                                    child: Text(
                                      "Belum ada aktivitas...", 
                                      style: TextStyle(fontFamily: appFont, color: Colors.white.withOpacity(0.3), fontSize: 11)
                                    ),
                                  )
                                : ListView.builder(
                                    physics: const BouncingScrollPhysics(),
                                    padding: const EdgeInsets.all(12),
                                    itemCount: _logs.length,
                                    itemBuilder: (context, index) {
                                      final isError = _logs[index].contains("Error") || _logs[index].contains("Gagal") || _logs[index].contains("⚠️") || _logs[index].contains("❌");
                                      final isSuccess = _logs[index].contains("Berhasil") || _logs[index].contains("✅") || _logs[index].contains("🚀");
                                      
                                      Color textColor = Colors.white70;
                                      if (isError) textColor = Colors.redAccent;
                                      if (isSuccess) textColor = Colors.greenAccent;

                                      return Padding(
                                        padding: const EdgeInsets.only(bottom: 6),
                                        child: Text(
                                          _logs[index],
                                          style: TextStyle(
                                            fontFamily: 'Courier', // Menggunakan font monospace untuk kesan terminal code
                                            color: textColor,
                                            fontSize: 11,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Helper Widgets ---
  Widget _buildInputHeader(IconData icon, String title) {
    return Row(
      children: [
        Icon(icon, color: AppColors.accent, size: 16),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontFamily: appFont,
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildTextField(
    TextEditingController controller, 
    String hintText, {
    int maxLines = 1, 
    bool isNumber = false,
    List<TextInputFormatter>? formatters
  }) {
    return TextField(
      controller: controller,
      style: const TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 13),
      maxLines: maxLines,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      inputFormatters: formatters,
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(fontFamily: appFont, color: Colors.white.withOpacity(0.3), fontSize: 12),
        filled: true,
        fillColor: Colors.black.withOpacity(0.4),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.borderLight)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.accent, width: 1.5)),
      ),
    );
  }
}