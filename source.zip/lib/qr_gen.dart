import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'base_page.dart';

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  Uint8List? _qrImage;
  String? _errorMessage;

  Future<void> _generateQR() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _errorMessage = "Text tidak boleh kosong.";
        _qrImage = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _qrImage = null;
    });

    final encodedText = Uri.encodeComponent(text);
    final url = Uri.parse("https://api.siputzx.my.id/api/tools/text2qr?text=$encodedText");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          _qrImage = response.bodyBytes;
          _errorMessage = null;
        });
      } else {
        setState(() { _errorMessage = "Gagal generate QR Code."; });
      }
    } catch (e) {
      setState(() { _errorMessage = "Terjadi kesalahan: $e"; });
    } finally {
      setState(() { _isLoading = false; });
    }
  }

  Future<void> _shareQR() async {
    if (_qrImage == null) return;

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/qr_code_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_qrImage!);
      await Share.shareXFiles([XFile(file.path)], text: 'QR Code dari: ${_textController.text}');
    } catch (e) {
      showCyberSnackBar(context, 'Error sharing: $e', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "QR GENERATOR",
      child: Column(
        children: [
          GlassCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.qr_code, color: AppColors.accent, size: 24),
                    const SizedBox(width: 12),
                    const Text("QR GENERATOR",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary, fontFamily: appFont)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          GlassCard(
            child: Column(
              children: [
                CyberInputField(
                  controller: _textController,
                  label: "Text / URL",
                  hint: "Contoh: https://google.com",
                  icon: Icons.text_fields_rounded,
                ),
                const SizedBox(height: 16),
                CyberButton(
                  label: _isLoading ? "GENERATING..." : "GENERATE QR",
                  icon: _isLoading ? Icons.hourglass_top : Icons.qr_code_rounded,
                  onTap: _isLoading ? () {} : _generateQR,
                  isLoading: _isLoading,
                  width: double.infinity,
                ),
              ],
            ),
          ),
          if (_errorMessage != null) ...[
            const SizedBox(height: 12),
            GlassCard(
              padding: const EdgeInsets.all(16),
              borderColor: AppColors.red.withOpacity(0.3),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: AppColors.red),
                  const SizedBox(width: 12),
                  Expanded(child: Text(_errorMessage!, style: TextStyle(color: AppColors.textSec))),
                ],
              ),
            ),
          ],
          if (_qrImage != null) ...[
            const SizedBox(height: 16),
            GlassCard(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Image.memory(_qrImage!, height: 200, width: 200),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surface2,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.text_snippet, color: AppColors.accent, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(_textController.text,
                              style: TextStyle(color: AppColors.textSec, fontSize: 12),
                              overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  CyberButton(
                    label: "SHARE QR CODE",
                    icon: Icons.share_rounded,
                    onTap: _shareQR,
                    width: double.infinity,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}