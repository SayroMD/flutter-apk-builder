import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;

/// Global playback service.
///
/// [SpotifyMusicPlayer] used to own its own [AudioPlayer] instance, which
/// meant playback (and the "now playing" state) died the moment that page
/// was popped from the navigation stack. This singleton owns the single
/// shared [AudioPlayer] instead, so:
///
///  - music keeps playing when the user navigates to another page
///  - [DynamicIslandOverlay] can read/display "now playing" info and control
///    playback from ANY page, not just the music page itself
///
/// The music page still owns all of its search/playlist/download logic —
/// it just delegates the actual [AudioPlayer] calls to
/// `MusicService.instance.player` instead of a page-local player, and
/// mirrors its now-playing fields here via [updateNowPlaying].
class MusicService extends ChangeNotifier {
  MusicService._internal() {
    _bindPlayerStreams();
  }
  static final MusicService instance = MusicService._internal();

  final AudioPlayer player = AudioPlayer();

  Map<String, dynamic>? currentTrack;
  bool isPlaying = false;
  Duration position = Duration.zero;
  Duration duration = Duration.zero;
  bool isFavorite = false;
  double volume = 0.5;

  String? lyrics;
  bool lyricsLoading = false;
  bool lyricsNotFound = false;
  String? _lyricsForTrackId;

  /// Registered by the music page's State while it's mounted, so the island
  /// can trigger next/previous/favorite (which needs the page's playlist /
  /// favorites-list logic) even though the island itself lives outside that
  /// page. Cleared automatically when the page is disposed.
  VoidCallback? onRequestNext;
  VoidCallback? onRequestPrevious;
  VoidCallback? onToggleFavorite;

  /// Separate from [onRequestNext]: track-completion needs repeat-mode
  /// handling (replay same track) that a plain "skip next" doesn't. Falls
  /// back to [onRequestNext] if the page hasn't registered this.
  VoidCallback? onTrackComplete;

  /// Optional hook the music page registers (while mounted) to persist
  /// playback position to shared_preferences on every tick — purely a
  /// convenience so that logic stays in the page, not required for
  /// real-time playback/duration to work.
  void Function(Duration position)? onPositionTick;

  /// These stream subscriptions live for the whole app lifetime (bound once
  /// when this singleton is first created), NOT tied to whichever page
  /// happens to be mounted. This is what keeps play/pause state and
  /// position/duration updating in real time everywhere — including the
  /// Dynamic Island — even after the music page itself has been popped.
  void _bindPlayerStreams() {
    player.setReleaseMode(ReleaseMode.stop);

    player.onPlayerStateChanged.listen((state) {
      isPlaying = state == PlayerState.playing;
      notifyListeners();
    });

    player.onDurationChanged.listen((d) {
      duration = d;
      notifyListeners();
    });

    player.onPositionChanged.listen((p) {
      position = p;
      notifyListeners();
      onPositionTick?.call(p);
    });

    player.onPlayerComplete.listen((_) {
      // Advancing to the next track needs the page's playlist + streaming
      // URL resolution logic, so delegate to it when available. Prefer the
      // dedicated completion handler (handles repeat mode) over a plain skip.
      if (onTrackComplete != null) {
        onTrackComplete!.call();
      } else if (onRequestNext != null) {
        onRequestNext!.call();
      } else {
        isPlaying = false;
        notifyListeners();
      }
    });
  }

  void updateNowPlaying({
    Map<String, dynamic>? track,
    bool? playing,
    Duration? pos,
    Duration? dur,
    bool? favorite,
  }) {
    if (track != null) {
      final newId = track['id']?.toString();
      final oldId = currentTrack?['id']?.toString();
      if (newId != oldId) _clearLyricsCache();
      currentTrack = track;
    }
    if (playing != null) isPlaying = playing;
    if (pos != null) position = pos;
    if (dur != null) duration = dur;
    if (favorite != null) isFavorite = favorite;
    notifyListeners();
  }

  void _clearLyricsCache() {
    lyrics = null;
    lyricsNotFound = false;
    lyricsLoading = false;
    _lyricsForTrackId = null;
  }

  /// Volume is applied directly to the shared player, so this works from
  /// ANY page — no page callback needed, unlike next/previous/favorite.
  Future<void> setVolume(double v) async {
    volume = v;
    await player.setVolume(v);
    notifyListeners();
  }

  /// Mirrors volume set from the music page itself (which already talks to
  /// the shared player directly), so the island's slider stays in sync
  /// without setting the player volume twice.
  void syncVolume(double v) {
    volume = v;
    notifyListeners();
  }

  void toggleFavorite() => onToggleFavorite?.call();

  /// Fetches lyrics for the current track from a public lyrics API, cached
  /// per track. Works from any page since it only needs artist/title.
  Future<void> fetchLyricsIfNeeded() async {
    final track = currentTrack;
    if (track == null) return;
    final trackId = track['id']?.toString() ?? '${track['title']}-${track['artist']}';
    if (_lyricsForTrackId == trackId && (lyrics != null || lyricsNotFound || lyricsLoading)) {
      return;
    }

    _lyricsForTrackId = trackId;
    lyrics = null;
    lyricsNotFound = false;
    lyricsLoading = true;
    notifyListeners();

    try {
      final artist = Uri.encodeComponent((track['artist'] ?? '').toString());
      final title = Uri.encodeComponent((track['title'] ?? '').toString());
      final res = await http
          .get(Uri.parse('https://api.lyrics.ovh/v1/$artist/$title'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final text = (data['lyrics'] ?? '').toString().trim();
        if (text.isNotEmpty) {
          lyrics = text;
        } else {
          lyricsNotFound = true;
        }
      } else {
        lyricsNotFound = true;
      }
    } catch (_) {
      lyricsNotFound = true;
    } finally {
      lyricsLoading = false;
      notifyListeners();
    }
  }

  Future<void> pause() async {
    await player.pause();
    isPlaying = false;
    notifyListeners();
  }

  Future<void> resume() async {
    await player.resume();
    isPlaying = true;
    notifyListeners();
  }

  Future<void> seek(Duration pos) async {
    await player.seek(pos);
  }

  void requestNext() => onRequestNext?.call();
  void requestPrevious() => onRequestPrevious?.call();
}
