import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class FFPlayerData {
  final String nama;
  final String uid;
  final int tingkat;
  final String wilayah;
  final int suka;
  final int brRankPoint;
  final int csRankPoint;
  final String? namaGuild;
  final String dibuatPada;
  final String loginTerakhir;

  FFPlayerData({
    required this.nama,
    required this.uid,
    required this.tingkat,
    required this.wilayah,
    required this.suka,
    required this.brRankPoint,
    required this.csRankPoint,
    this.namaGuild,
    required this.dibuatPada,
    required this.loginTerakhir,
  });

  factory FFPlayerData.fromJson(Map<String, dynamic> json) {
    return FFPlayerData(
      nama: json['nama'] ?? '-',
      uid: json['uid'] ?? '-',
      tingkat: json['tingkat'] ?? 0,
      wilayah: json['wilayah'] ?? '-',
      suka: json['Suka'] ?? 0,
      brRankPoint: json['br_rank_point'] ?? 0,
      csRankPoint: json['cs_rank_point'] ?? 0,
      namaGuild: json['nama_guild'],
      dibuatPada: json['dibuat pada'] ?? '-',
      loginTerakhir: json['login terakhir'] ?? '-',
    );
  }
}

class FFStalkerScreen extends StatefulWidget {
  const FFStalkerScreen({super.key});

  @override
  State<FFStalkerScreen> createState() => _FFStalkerScreenState();
}

class _FFStalkerScreenState extends State<FFStalkerScreen>
    with TickerProviderStateMixin {
  final TextEditingController _uidController = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  FFPlayerData? _playerData;
  bool _isLoading = false;
  String? _errorMessage;

  late AnimationController _pulseController;
  late AnimationController _resultController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _resultController = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));
    _fadeAnimation = CurvedAnimation(parent: _resultController, curve: Curves.easeOut);
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultController, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _uidController.dispose();
    _focusNode.dispose();
    _pulseController.dispose();
    _resultController.dispose();
    super.dispose();
  }

  Future<void> _fetchPlayer() async {
    final uid = _uidController.text.trim();
    if (uid.isEmpty) {
      setState(() => _errorMessage = 'Masukkan UID terlebih dahulu');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _playerData = null;
    });

    _resultController.reset();

    try {
      final uri = Uri.parse('http://api.ikyyxd.my.id/stalk/epepid?uid=$uid');
      final response = await http.get(uri).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true || json['status'] == 'benar') {
          setState(() {
            _playerData = FFPlayerData.fromJson(json['data']);
            _isLoading = false;
          });
          _resultController.forward();
        } else {
          setState(() {
            _errorMessage = 'Player tidak ditemukan';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Server error: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal terhubung ke server';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "FF STALKER",
      child: Column(
        children: [
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('PLAYER UID',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _focusNode.hasFocus ? AppColors.accent.withOpacity(0.5) : AppColors.border,
                            width: 1,
                          ),
                        ),
                        child: TextField(
                          controller: _uidController,
                          focusNode: _focusNode,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          style: TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w600),
                          decoration: InputDecoration(
                            hintText: 'contoh: 2852101933',
                            hintStyle: TextStyle(color: AppColors.textMuted, fontSize: 14),
                            prefixIcon: Icon(Icons.tag_rounded, color: AppColors.textMuted, size: 18),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                          ),
                          onSubmitted: (_) => _fetchPlayer(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: _isLoading ? null : _fetchPlayer,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 50, height: 50,
                        decoration: BoxDecoration(
                          color: _isLoading ? AppColors.textMuted : AppColors.accent,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: _isLoading ? [] : [BoxShadow(color: AppColors.accent.withOpacity(0.3), blurRadius: 12)],
                        ),
                        child: _isLoading
                            ? const Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)))
                            : const Icon(Icons.search_rounded, color: Colors.white, size: 22),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (_isLoading) _buildLoadingState(),
          if (_errorMessage != null) _buildErrorState(),
          if (_playerData != null) _buildResultCard(),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return GlassCard(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          const CyberLoadingShimmer(),
          const SizedBox(height: 16),
          const Text('Mencari data player...', style: TextStyle(color: AppColors.textMuted)),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return GlassCard(
      padding: const EdgeInsets.all(20),
      borderColor: AppColors.red.withOpacity(0.3),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.warning_amber_rounded, color: AppColors.red, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Pencarian Gagal', style: TextStyle(color: AppColors.red, fontSize: 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(_errorMessage!, style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    final p = _playerData!;
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SlideTransition(
        position: _slideAnimation,
        child: Column(
          children: [
            GlassCard(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      color: AppColors.surface2,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.textMuted.withOpacity(0.3), width: 2),
                    ),
                    child: Center(
                      child: Text(p.nama.isNotEmpty ? p.nama[0].toUpperCase() : '?',
                          style: TextStyle(color: AppColors.textPrimary, fontSize: 26, fontWeight: FontWeight.w900)),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.nama,
                            style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w800),
                            overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Icons.tag_rounded, color: AppColors.textMuted, size: 12),
                            const SizedBox(width: 3),
                            Text(p.uid,
                                style: TextStyle(color: AppColors.textMuted, fontSize: 12, fontWeight: FontWeight.w500)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: p.uid));
                            showCyberSnackBar(context, "UID tersalin!");
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.surface2,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.copy_rounded, color: AppColors.textMuted, size: 10),
                                const SizedBox(width: 4),
                                Text('Salin UID', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (p.namaGuild != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Column(
                        children: [
                          Icon(Icons.shield_rounded, color: AppColors.textSec, size: 16),
                          const SizedBox(height: 2),
                          Text(p.namaGuild!,
                              style: TextStyle(color: AppColors.textSec, fontSize: 9, fontWeight: FontWeight.w700),
                              overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _buildStatCard('LIKES', '${p.suka}', Icons.favorite_rounded, AppColors.red)),
                const SizedBox(width: 12),
                Expanded(child: _buildStatCard('LEVEL', '${p.tingkat}', Icons.military_tech_rounded, AppColors.orange)),
                const SizedBox(width: 12),
                Expanded(child: _buildStatCard('REGION', p.wilayah, Icons.public_rounded, AppColors.accent)),
              ],
            ),
            const SizedBox(height: 12),
            GlassCard(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('RANK POINTS',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(child: _buildRankItem('Battle Royale', p.brRankPoint, Icons.sports_esports_rounded, AppColors.orange, maxPoints: 3500)),
                      const SizedBox(width: 16),
                      Container(width: 1, height: 50, color: AppColors.border),
                      const SizedBox(width: 16),
                      Expanded(child: _buildRankItem('Clash Squad', p.csRankPoint, Icons.groups_rounded, AppColors.accent, maxPoints: 100)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            GlassCard(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('INFORMASI AKUN',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2)),
                  const SizedBox(height: 14),
                  _buildInfoRow(Icons.calendar_today_rounded, 'Bergabung', _formatDate(p.dibuatPada)),
                  _buildDivider(),
                  _buildInfoRow(Icons.access_time_rounded, 'Login Terakhir', _formatDate(p.loginTerakhir)),
                  _buildDivider(),
                  _buildInfoRow(Icons.shield_outlined, 'Guild', p.namaGuild ?? 'Tidak ada guild'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color accent) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      child: Column(
        children: [
          Icon(icon, color: accent, size: 20),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
        ],
      ),
    );
  }

  Widget _buildRankItem(String label, int points, IconData icon, Color color, {required int maxPoints}) {
    final progress = (points / maxPoints).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 11, fontWeight: FontWeight.w600)),
          ],
        ),
        const SizedBox(height: 8),
        Text('$points', style: TextStyle(color: AppColors.textPrimary, fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: AppColors.surface2,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 4,
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, color: AppColors.textMuted, size: 14),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(value, style: TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() => Container(height: 1, color: AppColors.border.withOpacity(0.3));

  String _formatDate(String raw) {
    try {
      final dt = DateTime.parse(raw);
      const months = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
      return '${dt.day} ${months[dt.month]} ${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return raw;
    }
  }
}