import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'dart:ui' as ui;
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geocoding/geocoding.dart';
import 'tes_func_page.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:open_file/open_file.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:battery_plus/battery_plus.dart';
import 'dart:io';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:async';
import 'dart:math';

import 'change_password.dart';
import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'pasar_online_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_group_page.dart';
import 'notification_page.dart';
import 'telegram_report_system.dart';
import 'spotify_music_player.dart';
import 'controller.dart';
import 'custom_payload.dart';
import 'update_module_page.dart';
import 'thanks_to_page.dart';
import 'spam_pair.dart';
import 'alquran.dart';
import 'send_notification_page.dart';
import 'main.dart';
import 'jadwal_sholat_card.dart';
import 'news_weather_widgets.dart';
import 'custom_navigation.dart';
import 'tools_landing_page.dart';
import 'chat_public.dart';
import 'chat_page.dart';
import 'bug_report_admin_page.dart';
import 'bug_report_page.dart';
import 'story_bar.dart';
import 'story_bar_loader.dart';
import 'story_model.dart';
import 'control_panel.dart' hide baseUrl;
import 'builder_page.dart';
import 'storan_hub_page.dart';
import 'admin_review_page.dart';
import 'undangan_page.dart';
import 'ambil_link_page.dart';
import 'up_role_page.dart';
import 'app_theme.dart';
import 'theme_switcher_page.dart';

/// Tema aktif (dibaca ulang tiap build)
AppTheme get _t => ThemeController.instance.theme;

class SholatService {
  String _getTimeZone(double longitude) {
    if (longitude >= 105 && longitude < 120) {
      return "WIB";
    } else if (longitude >= 120 && longitude < 135) {
      return "WITA";
    } else if (longitude >= 135 && longitude <= 150) {
      return "WIT";
    } else {
      return "WIB";
    }
  }

  Future<Map<String, dynamic>> getJadwalSholat(String cityId) async {
    try {
      final now = DateTime.now();

      final date =
      "${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}";

      final response = await http.get(
        Uri.parse('https://api.myquran.com/v1/sholat/jadwal/$cityId/$date'),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data;
      }
    } catch (e) {
      print('Error fetching sholat schedule: $e');
    }
    return {};
  }

  // Method untuk mencari kota berdasarkan nama (mirip dengan Python)
  Future<List<dynamic>> searchKota(String query) async {
    try {
      final response = await http.get(
        Uri.parse('https://api.myquran.com/v1/sholat/kota/cari/$query'),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? [];
      }
    } catch (e) {
      print('Error searching cities: $e');
    }
    return [];
  }

  // Method untuk mengambil semua kota (untuk dropdown)
  Future<List<dynamic>> getKotaList() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.myquran.com/v1/sholat/kota/cari/'),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? [];
      }
    } catch (e) {
      print('Error fetching cities: $e');
    }
    return [];
  }

  Future<Map<String, dynamic>?> getCurrentLocationCity() async {
    try {
      final status = await Permission.location.request();
      if (status != PermissionStatus.granted) return null;

      if (!await Geolocator.isLocationServiceEnabled()) {
        print('📍 Location service tidak aktif');
        return null;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final timeZone = _getTimeZone(position.longitude);

      final places = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (places.isEmpty) return null;

      final place = places.first;
      String? cityName = place.locality ??
      place.subLocality ??
      place.subAdministrativeArea ??
      place.administrativeArea;

      if (cityName == null) return null;

      print('📍 Location found: $cityName');
      String cleanName = cityName.toLowerCase();
      cleanName = cleanName
      .replaceAll('kabupaten', '')
      .replaceAll('kab.', '')
      .replaceAll('kota', '')
      .replaceAll('kab', '')
      .replaceAll('kot', '')
      .replaceAll('administrative', '')
      .replaceAll('area', '')
      .trim();
      List<dynamic> searchResults = [];
      searchResults = await searchKota(cleanName);
      if (searchResults.isEmpty && cleanName.contains(' ')) {
        final parts = cleanName.split(' ');
        for (var part in parts) {
          if (part.length > 3) {
            searchResults = await searchKota(part);
            if (searchResults.isNotEmpty) break;
          }
        }
      }
      if (searchResults.isEmpty && cleanName.contains(' ')) {
        final firstWord = cleanName.split(' ')[0];
        if (firstWord.length > 2) {
          searchResults = await searchKota(firstWord);
        }
      }
      if (searchResults.isEmpty) {
        final allCities = await getKotaList();
        Map<String, dynamic>? nearestCity;
        double minDistance = double.infinity;

        for (var city in allCities) {
          final cityLat =
          double.tryParse(city['lintang']?.toString() ?? '0') ?? 0;
          final cityLong =
          double.tryParse(city['bujur']?.toString() ?? '0') ?? 0;

          if (cityLat != 0 && cityLong != 0) {
            final distance = calculateDistance(
              position.latitude, position.longitude, cityLat, cityLong);

            if (distance < minDistance) {
              minDistance = distance;
              nearestCity = city;
            }
          }
        }

        if (nearestCity != null) {
          print('📍 Using nearest city: ${nearestCity['lokasi']}');
          return {
            'cityId': nearestCity['id'].toString(),
            'cityName': nearestCity['lokasi']?.toString() ?? cityName,
            'timeZone': timeZone,
            'latitude': position.latitude,
            'longitude': position.longitude,
          };
        }
      }

      if (searchResults.isNotEmpty) {
        final cityData = searchResults[0];
        print('✅ City matched: ${cityData['lokasi']}');

        return {
          'cityId': cityData['id'].toString(),
          'cityName': cityData['lokasi']?.toString() ?? cityName,
          'timeZone': timeZone,
          'latitude': position.latitude,
          'longitude': position.longitude,
        };
      } else {
        print('⚠️ No matching city found in database');
        return null;
      }
    } catch (e) {
      print('❌ Error getting location: $e');
      return null;
    }
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371; // Radius bumi dalam km

    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);

    final a = sin(dLat / 2) * sin(dLat / 2) +
    cos(_toRadians(lat1)) *
    cos(_toRadians(lat2)) *
    sin(dLon / 2) *
    sin(dLon / 2);

    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  double _toRadians(double degree) {
    return degree * pi / 180;
  }
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String uid;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
      super.key,
      required this.username,
      required this.password,
      required this.role,
      required this.expiredDate,
      required this.listBug,
      required this.listDoos,
      required this.sessionKey,
      required this.news,
      required this.uid,
    });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

// Animated Background
class AnimatedBackground extends StatefulWidget {
  @override
  _AnimatedBackgroundState createState() => _AnimatedBackgroundState();
}

class _AnimatedBackgroundState extends State<AnimatedBackground>
with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(seconds: 20),
      vsync: this,
    )..repeat(reverse: true);
    _animation = Tween<double>(begin: -100, end: 100).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(_animation.value / 100, -0.5),
              radius: 1.5,
              colors: [
                Color(0xFF8B0000).withOpacity(0.1),
                Color(0xFF1F2937).withOpacity(0.1),
                Colors.transparent,
              ],
              stops: [0.1, 0.5, 1.0],
            )),
        );
      },
    );
  }
}

/// Area drag & drop + hide/show buat section-section dashboard.
/// Sengaja dijadiin StatefulWidget SENDIRI (bukan method biasa di
/// _DashboardPageState) supaya setState-nya independen: gak ketahan sama
/// _DashboardPageState yang body Scaffold-nya di-cache di field
/// `_selectedPage` (cuma rebuild pas ganti tab). Widget ini punya Element
/// sendiri, jadi tap "ATUR LAYOUT" / drag / toggle hide langsung
/// keliatan berubah saat itu juga, gak perlu pindah halaman dulu.
class DraggableSectionsArea extends StatefulWidget {
  final Widget Function(String key) sectionBuilder;
  final bool hasNewsLatest;
  const DraggableSectionsArea({
    super.key,
    required this.sectionBuilder,
    required this.hasNewsLatest,
  });

  @override
  State<DraggableSectionsArea> createState() => _DraggableSectionsAreaState();
}

class _DraggableSectionsAreaState extends State<DraggableSectionsArea> {
  static const List<String> _defaultSectionOrder = [
    'app_header',
    'banner',
    'twoinone',
    'story',
    'welcome',
    'jadwal',
    'news_latest',
    'quick_actions',
    'news_rss',
    'hadith',
    'news_slider',
    'weather',
  ];
  List<String> _sectionOrder = List.from(_defaultSectionOrder);
  Set<String> _hiddenSections = {};
  bool _editLayoutMode = false;

  @override
  void initState() {
    super.initState();
    _loadSectionOrder();
    _loadHiddenSections();
  }

  Future<void> _loadSectionOrder() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dashboard_section_order');
    if (saved != null && saved.isNotEmpty) {
      final merged = saved.where((k) => _defaultSectionOrder.contains(k)).toList();
      for (final k in _defaultSectionOrder) {
        if (!merged.contains(k)) merged.add(k);
      }
      if (mounted) setState(() => _sectionOrder = merged);
    }
  }

  Future<void> _saveSectionOrder() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('dashboard_section_order', _sectionOrder);
  }

  Future<void> _loadHiddenSections() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dashboard_hidden_sections');
    if (saved != null && mounted) {
      setState(() => _hiddenSections = saved.toSet());
    }
  }

  Future<void> _saveHiddenSections() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('dashboard_hidden_sections', _hiddenSections.toList());
  }

  void _toggleSectionVisibility(String key) {
    setState(() {
      if (_hiddenSections.contains(key)) {
        _hiddenSections.remove(key);
      } else {
        _hiddenSections.add(key);
      }
    });
    _saveHiddenSections();
  }

  void _onReorderSections(int oldIndex, int newIndex, List<String> visibleOrder) {
    setState(() {
      if (newIndex > oldIndex) newIndex -= 1;
      final item = visibleOrder.removeAt(oldIndex);
      visibleOrder.insert(newIndex, item);
      final hidden = _sectionOrder.where((k) => !visibleOrder.contains(k)).toList();
      _sectionOrder = [...visibleOrder, ...hidden];
    });
    _saveSectionOrder();
  }

  @override
  Widget build(BuildContext context) {
    // 'news_latest' emang cuma nongol kalo ada datanya — itu bukan pilihan
    // user, jadi tetep difilter baik di mode edit maupun normal.
    final orderForEdit = _sectionOrder
        .where((k) => k != 'news_latest' || widget.hasNewsLatest)
        .toList();
    // Mode normal: section yang di-hide user gak dirender sama sekali.
    // Mode edit: semua section tetep dirender (yang hidden diredupin) biar
    // bisa di-toggle balik.
    final visibleOrder = _editLayoutMode
        ? orderForEdit
        : orderForEdit.where((k) => !_hiddenSections.contains(k)).toList();
    return Column(
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: GestureDetector(
            onTap: () => setState(() => _editLayoutMode = !_editLayoutMode),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                  color: _editLayoutMode ? _t.dk(const Color(0xFFFF6B9D)) : _t.surface,
                  border: Border.all(color: _t.line, width: _t.bw(2)),
                  boxShadow: _t.hard(2)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(_editLayoutMode ? Icons.check : Icons.drag_indicator,
                      size: 16, color: _editLayoutMode ? Colors.white : _t.ink),
                  const SizedBox(width: 4),
                  Text(_editLayoutMode ? 'SELESAI' : 'ATUR LAYOUT',
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                          color: _editLayoutMode ? Colors.white : _t.ink)),
                ],
              ),
            ),
          ),
        ),
        ReorderableListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          buildDefaultDragHandles: false,
          onReorder: (oldIndex, newIndex) =>
              _onReorderSections(oldIndex, newIndex, List.from(visibleOrder)),
          children: [
            for (int i = 0; i < visibleOrder.length; i++)
              Padding(
                key: ValueKey(visibleOrder[i]),
                padding: const EdgeInsets.only(bottom: 16),
                child: !_editLayoutMode
                    ? widget.sectionBuilder(visibleOrder[i])
                    : Builder(builder: (context) {
                        final key = visibleOrder[i];
                        final isHidden = _hiddenSections.contains(key);
                        return Stack(
                          children: [
                            IgnorePointer(child: widget.sectionBuilder(key)),
                            Positioned.fill(
                              child: Container(
                                  color: _t.scaffoldBg
                                      .withOpacity(isHidden ? 0.8 : 0.35)),
                            ),
                            Positioned(
                              right: 8,
                              top: 8,
                              child: Row(
                                children: [
                                  GestureDetector(
                                    onTap: () => _toggleSectionVisibility(key),
                                    child: Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                          color: isHidden
                                              ? _t.dk(const Color(0xFFFF6B9D))
                                              : _t.surface,
                                          border: Border.all(
                                              color: _t.line, width: _t.bw(2)),
                                          boxShadow: _t.hard(2)),
                                      child: Icon(
                                        isHidden
                                            ? Icons.visibility_off
                                            : Icons.visibility,
                                        color: isHidden ? Colors.white : _t.ink,
                                        size: 20,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  ReorderableDragStartListener(
                                    index: i,
                                    child: Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                          color: _t.yellow,
                                          border: Border.all(
                                              color: _t.line, width: _t.bw(2)),
                                          boxShadow: _t.hard(2)),
                                      child: Icon(Icons.drag_handle,
                                          color: _t.ink, size: 20),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        );
                      }),
              ),
          ],
        ),
      ],
    );
  }
}

class _DashboardPageState extends State<DashboardPage>
with SingleTickerProviderStateMixin {
  Map<String, dynamic>? _jadwalSholat;
  List<dynamic> _cityList = [];
  String _selectedCityId = "1227"; // Default: Jakarta
  String _selectedCityName = "Jakarta";
  // Dipakai kartu "Lokasi & Langganan" di _buildHoxtenStyleDashboard.
  // Belum ada fetcher-nya — tetep null sampai dihubungkan ke API cuaca.
  Map<String, dynamic>? weatherData;
  bool _isLoadingSholat = false;
  Timer? _sholatTimer;
  final SholatService _sholatService = SholatService();
  String? _currentLocation;
  bool _useCurrentLocation = false;
  late AnimationController _controller;
  late Animation<double> _animation;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _slideAnimation;
  late WebSocketChannel channel;
  late DateTime _lastStatsUpdate;
  late Timer _healthCheckTimer;
  late Timer _timeTimer;
  late Timer _fetchTimer;
  late VideoPlayerController? _digitalVideoController;
  DateTime _wibTime = DateTime.now();
  DateTime _witaTime = DateTime.now().add(const Duration(hours: 1));
  DateTime _witTime = DateTime.now().add(const Duration(hours: 2));
  String _dayPeriod = "Morning";
  bool get _isVideoInitialized =>
  _digitalVideoController != null &&
  _digitalVideoController!.value.isInitialized;
  late PackageInfo _packageInfo;
  bool _isChecking = false;
  String? _updateError;
  Map<String, dynamic>? _updateInfo;
  List<String> _changelog = [];
  bool _showUpdateBanner = false;
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late String uid;
  List<dynamic> notifications = [];
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late Timer _realTimeClockTimer;
  String _currentTime = "00:00:00";
  String _currentTimeZoneDisplay = "WIB";
  String androidId = "unknown";

  late AnimationController _pulseRingController;
  late AnimationController _dashRingController;
  late AnimationController _fanMenuController;
  late AnimationController _fanStaggerController;

  bool _isFanMenuOpen = false;
  int _currentNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  bool isLoading = false;
  bool hasUnreadNotif = false;
  bool isNotifLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  List<dynamic> senderList = [];
  List<dynamic> _hadithList = [];
  Map<String, dynamic>? _currentHadith;
  Timer? _hadithTimer;
  bool _isLoadingHadith = false;
  int _currentPage = 1;
  int _totalPages = 493;
  int onlineUsers = 0;
  int activeConnections = 0;
  int _carouselCurrentIndex = 0;
  int _headerCarouselIndex = 0;
  int _quickActionIndex = 0;
  bool _envelopeOpened = false;

  // Account stats
  int _accountDaysLeft = 0;
  double _accountProgress = 0.0;
  String _accountStatus = "ACTIVE";
  bool _isAccountExpired = false;

  // Device stats
  String deviceModel = "Unknown";
  String osVersion = "Unknown";
  int sdkInt = 0;
  int batteryLevel = 0;
  String batteryState = "Unknown";
  String _networkType = "Unknown";
  int _signalStrength = 0;
  int _totalRamMb = 0;
  int _usedRamMb = 0;
  int _totalStorageGb = 0;
  int _freeStorageGb = 0;
  final PageController _headerPageController = PageController();
  int _headerPageIndex = 0;

  // Satu controller dishare ke 3 section (RSS News, Berita Slider, Weather)
  // biar datanya cuma di-fetch sekali walau tampil sebagai 3 card terpisah.
  final NewsWeatherController _newsWeatherController = NewsWeatherController();

  // Dulu SliverAppBar (pinned + parallax collapse) yang nempel di paling
  // atas CustomScrollView. Sekarang dijadiin widget section biasa (height
  // tetap 320, gak collapse/parallax lagi) supaya bisa ikut di-drag & drop
  // bareng section lain.
  Widget _buildAppHeaderSection() {
    return Container(
      height: 320,
      decoration: BoxDecoration(
          color: _t.yellow,
          border: Border(
            bottom: BorderSide(color: _t.line, width: _t.bw(4)),
          )),
      child: Stack(
        children: [
          // Geometric accents (neo-brutal)
          Positioned(
            right: 0,
            top: 0,
            child: Container(
              width: 100,
              height: 100,
              color: _t.dk(const Color(0xFFFF6B9D)),
            ),
          ),
          Positioned(
            left: 16,
            bottom: 24,
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                  color: _t.dk(const Color(0xFF2D7FFF)),
                  border: Border.all(color: _t.line, width: _t.bw(3)),
                  boxShadow: _t.hard(3)),
            ),
          ),
          // Swipeable header pages (struktur asli)
          Positioned.fill(
            bottom: 16,
            child: PageView(
              controller: _headerPageController,
              onPageChanged: (index) {
                setState(() => _headerPageIndex = index);
              },
              children: [
                // PAGE 1 — LOGO
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                        color: _t.surface,
                        border: Border.all(color: _t.line, width: _t.bw(3)),
                        boxShadow: _t.hard(4)),
                    child: Image.asset(
                      'assets/images/logo.jpg',
                      width: 100,
                      height: 100,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Text(
                        "OTAX",
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          color: _t.ink,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ),
                // PAGE 2 — full Unified Stats Card
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 20),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: _buildUnifiedStatsCard(),
                  ),
                ),
              ],
            ),
          ),
          // Page dots
          Positioned(
            bottom: 6,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(2, (i) {
                final active = i == _headerPageIndex;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 18 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                      color: active ? _t.ink : _t.inkSub,
                      border: Border.all(color: _t.line, width: _t.bw(1.5))),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
  
  // ── Palet khusus Hoxten dashboard — ikut tema aktif ──
  Color get _bgCard => _t.isComic ? _t.surface : const Color(0xFFFFFFFF);
  Color get _bgSurface => _t.isComic ? _t.surfaceAlt : const Color(0xFFF2F2F2);
  Color get _border => _t.isComic
      ? _t.accentTeal.withOpacity(0.5)
      : Colors.black;
  Color get _accentColor => _t.isComic ? _t.accentTeal : const Color(0xFFFF2D55);
  Color get _textLight => _t.ink;
  Color get _textSub => _t.inkSub;
  Color get _textMuted => _t.isComic
      ? _t.textSecondary.withOpacity(0.7)
      : const Color(0xFF888888);
  Color get _ratRed => _t.isComic ? _t.accentPink : const Color(0xFFFF2D2D);

  Widget _buildHoxtenStyleDashboard() {
    final t = _t;
    // Hitung session persen dari expiredDate
    String sessionPct = '0%';
    try {
      final expParts = expiredDate.split(RegExp(r'[/\-]'));
      if (expParts.length >= 3) {
        final expDt = DateTime(
          int.parse(expParts[2].split(' ')[0]),
          int.parse(expParts[1]),
          int.parse(expParts[0]),
        );
        final now = DateTime.now();
        final total = expDt.difference(now).inDays;
        final pct = (total > 0 ? (total / 365.0).clamp(0.0, 1.0) * 100 : 0).round();
        sessionPct = '$pct%';
      }
    } catch (_) {}

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── ROW 1 : STATUS SERVER (kiri) + LOKASI & LANGGANAN (kanan) ──
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── STATUS SERVER ───────────────────────────────
              Expanded(
                flex: 5,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _bgCard,
                    borderRadius: t.rr(18),
                    border: Border.all(color: _border, width: t.bw(1.5)),
                    boxShadow: t.hard(4),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'STATUS SERVER',
                        style: TextStyle(
                          color: _textSub,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.4,
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Users + Active row
                      Row(
                        children: [
                          Expanded(
                            child: _statMiniBox(
                              icon: Icons.people_outline,
                              iconColor: _accentColor,
                              label: 'Users',
                              value: '$onlineUsers',
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _statMiniBox(
                              icon: Icons.toggle_on_outlined,
                              iconColor: _neonGreen,
                              label: 'Active',
                              value: '$activeConnections',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      // Bug + DDoS row
                      Row(
                        children: [
                          Expanded(
                            child: _statMiniBox(
                              icon: Icons.bug_report_outlined,
                              iconColor: _neonRed,
                              label: 'Bug',
                              value: '${listBug.length}',
                              danger: true,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _statMiniBox(
                              icon: Icons.bolt,
                              iconColor: _neonOrange,
                              label: 'DDoS',
                              value: '${listDoos.length}',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // ── LOKASI & LANGGANAN ──────────────────────────
              Expanded(
                flex: 5,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _bgCard,
                    borderRadius: t.rr(18),
                    border: Border.all(color: _border, width: t.bw(1.5)),
                    boxShadow: t.hard(4),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'LOKASI & LANGGANAN',
                            style: TextStyle(
                              color: _textSub,
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                            ),
                          ),
                          const Spacer(),
                          // Cuaca mini
                          if (weatherData != null)
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  _getWeatherIcon(weatherData!['weather'][0]['main']),
                                  color: _neonBlue,
                                  size: 11,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '${weatherData!['main']['temp'].round()}°C',
                                  style: TextStyle(
                                    color: _neonBlue,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              ],
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      // lokasi kota
                      Row(
                        children: [
                          Icon(Icons.location_on, color: _accentColor, size: 13),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Text(
                              weatherData != null
                                  ? (weatherData!['name'] ?? _selectedCityName)
                                  : _selectedCityName,
                              style: TextStyle(
                                color: _textLight,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      // detail cuaca
                      if (weatherData != null) ...[
                        _locDetailRow(Icons.air, 'Wind',
                            '${(weatherData!['wind']['speed'] * 3.6).round()} m/s'),
                        const SizedBox(height: 4),
                        _locDetailRow(FontAwesomeIcons.droplet, 'Humid',
                            '${weatherData!['main']['humidity']}%'),
                        const SizedBox(height: 4),
                        _locDetailRow(Icons.compress, 'Press',
                            '${weatherData!['main']['pressure']} hPa'),
                      ] else
                        Text(
                          'Memuat cuaca...',
                          style: TextStyle(color: _textSub, fontSize: 11),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // ── ROW 2 : SESSION AKTIF + QUICK NAV ICONS ────────
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── SESSION / LANGGANAN ─────────────────────────
              Expanded(
                flex: 5,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _bgCard,
                    borderRadius: t.rr(18),
                    border: Border.all(color: _border, width: t.bw(1.5)),
                    boxShadow: t.hard(4),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Donut lingkaran persen session
                      SizedBox(
                        width: 70,
                        height: 70,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CircularProgressIndicator(
                              value: double.tryParse(sessionPct.replaceAll('%','')) != null
                                  ? (double.parse(sessionPct.replaceAll('%','')) / 100)
                                  : 0,
                              strokeWidth: 6,
                              backgroundColor: _bgSurface,
                              valueColor: AlwaysStoppedAnimation<Color>(_accentColor),
                            ),
                            Text(
                              sessionPct,
                              style: TextStyle(
                                color: _textLight,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'SESSION AKTIF',
                        style: TextStyle(
                          color: _textLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Exp: $expiredDate',
                        style: TextStyle(
                          color: _textSub,
                          fontSize: 9,
                          fontFamily: 'ShareTechMono',
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // ── QUICK NAV ICONS (5 kotak kecil) ────────────
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                    // Row atas: Telegram, WhatsApp, TikTok
                    Row(
                      children: [
                        Expanded(
                          child: _quickNavIcon(
                            icon: FontAwesomeIcons.telegram,
                            label: 'Telegram',
                            color: const Color(0xFF0088CC),
                            onTap: () => launchUrl(Uri.parse('https://t.me/rdvspproject'),
                                mode: LaunchMode.externalApplication),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _quickNavIcon(
                            icon: FontAwesomeIcons.whatsapp,
                            label: 'WhatsApp',
                            color: const Color(0xFF25D366),
                            onTap: () {
                              setState(() {
                                _selectedPage = HomePage(
                                  username: username,
                                  password: password,
                                  listBug: listBug,
                                  role: role,
                                  expiredDate: expiredDate,
                                  sessionKey: sessionKey,
                                );
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _quickNavIcon(
                            icon: FontAwesomeIcons.tiktok,
                            label: 'TikTok',
                            color: t.dk(Colors.pink),
                            onTap: () {
                              setState(() {
                                _currentNavIndex = 1;
                                _selectedPage = ToolsLandingPage(
                                  sessionKey: sessionKey,
                                  userRole: role,
                                  listDoos: listDoos,
                                  username: username,
                                  uid: uid,
                                );
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    // Row bawah: RAT, Sender
                    Row(
                      children: [
                        Expanded(
                          child: _quickNavIcon(
                            icon: FontAwesomeIcons.skull,
                            label: 'RAT',
                            color: _ratRed,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const ControlPanelPage(),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _quickNavIcon(
                            icon: Icons.devices_rounded,
                            label: 'Sender',
                            color: _accentColor,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => BugSenderPage(
                                    sessionKey: sessionKey,
                                    username: username,
                                    role: role,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Slot kosong / upgrade
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => UpRolePage(sessionKey: sessionKey),
                                ),
                              );
                            },
                            child: Container(
                              height: 62,
                              decoration: BoxDecoration(
                                color: t.isComic
                                    ? Color.alphaBlend(t.accentPurple.withOpacity(0.18), t.surface)
                                    : const Color(0xFF1A0535),
                                borderRadius: _t.rr(14),
                                border: Border.all(
                                  color: t.dk(const Color(0xFFB388FF)).withValues(alpha: 0.5),
                                ),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.auto_awesome,
                                      color: t.tx(const Color(0xFFEA80FC)), size: 20),
                                  const SizedBox(height: 3),
                                  Text(
                                    'VIP',
                                    style: TextStyle(
                                      color: t.tx(const Color(0xFFB388FF)),
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // ── ROW 3 : INFORMATION BANNER ─────────────────────
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _bgCard,
              borderRadius: t.rr(14),
              border: Border.all(color: _border, width: t.bw(1.5)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _accentColor.withValues(alpha: 0.12),
                    borderRadius: t.rr(10),
                  ),
                  child: Icon(Icons.notifications_active_outlined, color: _accentColor, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Info Penggunaan',
                        style: TextStyle(
                          color: _textSub,
                          fontSize: 10,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        'Mulai Baca',
                        style: TextStyle(
                          color: _textLight,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: _textMuted, size: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── helper: stat mini box ──
  Widget _statMiniBox({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    bool danger = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: danger
            ? _neonRed.withValues(alpha: 0.07)
            : _bgSurface.withValues(alpha: 0.6),
        borderRadius: _t.rr(12),
        border: Border.all(
          color: danger
              ? _neonRed.withValues(alpha: 0.25)
              : _border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: iconColor, size: 16),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: danger ? _neonRed : _textLight,
              fontSize: 20,
              fontWeight: FontWeight.w900,
              fontFamily: 'ShareTechMono',
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: _textSub,
              fontSize: 9,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ── helper: ikon cuaca dari kode kondisi OpenWeatherMap ("Clear", "Rain", dll) ──
  IconData _getWeatherIcon(String condition) {
    switch (condition.toLowerCase()) {
      case 'clear':
        return Icons.wb_sunny_rounded;
      case 'clouds':
        return Icons.cloud_rounded;
      case 'rain':
      case 'drizzle':
        return Icons.water_drop_rounded;
      case 'thunderstorm':
        return Icons.thunderstorm_rounded;
      case 'snow':
        return Icons.ac_unit_rounded;
      case 'mist':
      case 'fog':
      case 'haze':
        return Icons.foggy;
      default:
        return Icons.cloud_queue_rounded;
    }
  }

  // ── helper: lokasi detail row ──
  Widget _locDetailRow(dynamic icon, String label, String value) {
    return Row(
      children: [
        icon is IconData
            ? Icon(icon, color: _textMuted, size: 11)
            : FaIcon(icon as FaIconData, color: _textMuted, size: 11),
        const SizedBox(width: 5),
        Text(
          label,
          style: TextStyle(color: _textSub, fontSize: 10),
        ),
        const Spacer(),
        Text(
          value,
          style: TextStyle(
            color: _textLight,
            fontSize: 11,
            fontWeight: FontWeight.bold,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }

  // ── helper: quick nav icon box ──
  Widget _quickNavIcon({
    required dynamic icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.08),
          borderRadius: _t.rr(14),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon is IconData
                ? Icon(icon, color: color, size: 20)
                : FaIcon(icon as FaIconData, color: color, size: 20),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: _textSub,
                fontSize: 9,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionByKey(String key) {
    switch (key) {
      case 'app_header':
        return _buildAppHeaderSection();
      case 'banner':
        return _buildBanner();
      case 'twoinone':
        return _buildHoxtenStyleDashboard();
      case 'story':
        return StoryBarLoader();
      case 'welcome':
        return _buildWelcomeCard();
      case 'jadwal':
        return _buildJadwalSholatArea();
      case 'news_latest':
        return _buildLatestUpdatesSection();
      case 'quick_actions':
        return _buildQuickActionsSection();
      case 'news_rss':
        return RssNewsSection(controller: _newsWeatherController);
      case 'hadith':
        return _buildHadithQuoteCard();
      case 'news_slider':
        return BeritaSliderSection(controller: _newsWeatherController);
      case 'weather':
        return WeatherSection(controller: _newsWeatherController);
      default:
        return const SizedBox();
    }
  }

  // Bungkus dalam widget State terpisah (lihat class DraggableSectionsArea
  // di bawah) supaya tombol "ATUR LAYOUT", drag, dan hide/show punya
  // setState sendiri — gak numpang ke _DashboardPageState yang body-nya
  // di-cache di field _selectedPage (baru rebuild pas ganti tab).
  Widget _buildDraggableSections() {
    return DraggableSectionsArea(
      sectionBuilder: _sectionByKey,
      hasNewsLatest: newsList.isNotEmpty,
    );
  }

  @override
  void initState() {
    super.initState();

    print("📱 DashboardPage initialized for user: ${widget.username}");
    ThemeController.instance.load();
    ThemeController.instance.addListener(_onThemeChanged);
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    uid = widget.uid;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug ?? [];
    listDoos = widget.listDoos ?? [];
    newsList = widget.news ?? [];
    _calculateAccountStats();
    _fetchDeviceStats();
    _initPackageInfo();
    _jadwalSholat = {
      'lokasi': 'Jakarta',
      'daerah': 'DKI Jakarta',
      'jadwal': {
        'imsak': '04:22',
        'subuh': '04:32',
        'terbit': '05:46',
        'dzuhur': '12:08',
        'ashar': '15:30',
        'maghrib': '18:20',
        'isya': '19:33',
      }
    };
    _digitalVideoController = VideoPlayerController.asset('assets/videos/digital.mp4')
    ..initialize().then((_) {
        _digitalVideoController!.setVolume(0.0);
        _digitalVideoController!.setLooping(true);
        _digitalVideoController!.play();
        if (mounted) setState(() {});
      });
    _selectedPage = _buildEnhancedNewsPage();
    _initAnimations();
    _pulseRingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _dashRingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
    _fanMenuController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..addListener(() {
        if (mounted) setState(() {});
      });
    _fanStaggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    )..addListener(() {
        if (mounted) setState(() {});
      });
    WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _initRealTimeSystems();
        }
      });
    _timeTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted) {
          _updateTimes();
        } else {
          timer.cancel();
        }
      });
    _setFallbackHadith();
    Future.delayed(Duration(seconds: 2), () {
        if (mounted) {
          _fetchHadith();
        }
      });
    Future.delayed(Duration(seconds: 3), () {
        if (mounted) {
          _initSholatData();
        }
      });

    _realTimeClockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted) {
          _updateRealTimeClock();
        } else {
          timer.cancel();
        }
      });
  }

  String _getTimeZone(double longitude) {
    if (longitude >= 105 && longitude < 120) {
      return "WIB";
    } else if (longitude >= 120 && longitude < 135) {
      return "WITA";
    } else if (longitude >= 135 && longitude <= 150) {
      return "WIT";
    } else {
      return "WIB";
    }
  }

  String _currentTimeZone = "WIB";
  String _timeZoneAbbreviation = "WIB";
  void _initRealTimeSystems() async {
    print("🔄 Initializing real-time systems...");

    try {
      await _initAndroidIdAndConnect();
      await Future.delayed(const Duration(seconds: 2));
      await Future.wait([
          _fetchAdvancedStats(),
          _fetchSenders(),
          _fetchNotifications(),
        ]);

      print("✅ Real-time systems initialized");
    } catch (e) {
      print("❌ Error initializing real-time systems: $e");
      _startPollingFallback();
    }
  }

  Future<void> _initPackageInfo() async {
    try {
      _packageInfo = await PackageInfo.fromPlatform();
      print(
        "📦 Package Info: ${_packageInfo.version} (${_packageInfo.buildNumber})");
      _checkForUpdates();
    } catch (e) {
      print("❌ Error getting package info: $e");
    }
  }

  Future<void> _checkForUpdates() async {
    if (_isChecking) return;

    setState(() {
        _isChecking = true;
        _updateError = null;
      });

    try {
      final response = await Dio()
      .get(
        'http://nodemyayun.otax.store:2048/api/check-update',
        queryParameters: {
          'version': _packageInfo.version,
          'build': _packageInfo.buildNumber,
          'platform': Platform.isAndroid ? 'android' : 'ios',
        },
        options: Options(
          headers: {
            'Authorization': 'Bearer ${widget.sessionKey}',
          },
        ),
      )
      .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = response.data;

        if (data['error'] != null) {
          setState(() {
              _updateError = data['error'].toString();
              _updateInfo = null;
              _changelog = [];
              _showUpdateBanner = false;
            });
        } else if (data['has_update'] == true && data['update_info'] != null) {
          setState(() {
              _updateInfo = data['update_info'];
              _changelog =
              List<String>.from(data['update_info']['changelog'] ?? []);
              _showUpdateBanner = true;
            });
          _showUpdateNotification(data['update_info']);
        } else {
          setState(() {
              _updateInfo = null;
              _changelog = [];
              _showUpdateBanner = false;
            });
        }
      } else {
        setState(() {
            _updateError = 'Server merespon dengan kode ${response.statusCode}';
            _showUpdateBanner = false;
          });
      }
    } catch (e) {
      setState(() {
          _updateError = 'Gagal mengecek update: ${e.toString()}';
          _showUpdateBanner = false;
        });
    } finally {
      setState(() {
          _isChecking = false;
        });
    }
  }

  void _showUpdateNotification(Map<String, dynamic> updateInfo) {
    final version = updateInfo['version'] ?? 'terbaru';
    final isCritical = updateInfo['critical'] == true;
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isCritical ? '🚨 UPDATE KRITIS TERSEDIA' : '🔄 UPDATE TERSEDIA',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'Versi $version telah tersedia. Update sekarang untuk mendapatkan fitur terbaru!',
              style: TextStyle(color: Colors.white70),
            ),
            if (_changelog.isNotEmpty) ...[
              SizedBox(height: 8),
              Text(
                'Perubahan:',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ..._changelog.take(3).map((change) => Text(
                  '• $change',
                  style: TextStyle(color: Colors.white70, fontSize: 11),
                )),
            ],
          ],
        ),
        backgroundColor: isCritical ? _t.dk(Colors.red[800])! : _t.dk(Colors.blue[800])!,
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => UpdateModulePage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  ),
                ),
              );
            },
            child: Text('UPDATE', style: TextStyle(color: Colors.white)),
          ),
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
            },
            child: Text('NANTI', style: TextStyle(color: Colors.white70)),
          ),
        ],
        padding: EdgeInsets.all(16),
      ),
    );
    if (!isCritical) {
      Future.delayed(Duration(seconds: 10), () {
          if (mounted) {
            ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
          }
        });
    }
  }

  void _initAnimations() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut));
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _controller.forward();
  }

  void _startWebSocketHealthCheck() {
    Timer.periodic(Duration(seconds: 30), (timer) {
        if (channel?.closeCode != null) {
          print("⚠️ WebSocket disconnected, reconnecting...");
          _reconnectWebSocket();
        }
      });
  }

  void _updateRealTimeClock() {
    final now = DateTime.now();
    final timeString = '${now.hour.toString().padLeft(2, '0')}:'
    '${now.minute.toString().padLeft(2, '0')}:'
    '${now.second.toString().padLeft(2, '0')}';
    String timeZone;
    final hour = now.hour;

    if (hour >= 5 && hour < 18) {
      timeZone = _timeZoneAbbreviation;
    } else {
      timeZone = _timeZoneAbbreviation; // tetap sama
    }

    if (mounted) {
      setState(() {
          _currentTime = timeString;
          _currentTimeZoneDisplay = timeZone;
        });
    }
  }

  Future<void> _initSholatData() async {
    if (_isLoadingSholat || !mounted) return;

    setState(() {
        _isLoadingSholat = true;
      });

    try {
      final locationData = await _sholatService.getCurrentLocationCity();

      if (locationData != null && mounted) {
        final cityId = locationData['cityId'];
        final cityName = locationData['cityName'];
        final timeZone = locationData['timeZone'];

        print('📍 Using current location: $cityName (ID: $cityId)');

        setState(() {
            _selectedCityId = cityId;
            _selectedCityName = cityName;
            _useCurrentLocation = true;
            _currentTimeZone = timeZone;
            _timeZoneAbbreviation = timeZone;
          });

        await _fetchSholatSchedule(cityId);
        _saveLocationPreference(cityId, cityName);
      } else {
        await _loadSavedLocation();
      }
    } catch (e) {
      print('❌ Error initializing sholat data: $e');
      _setDefaultSholatSchedule();
    } finally {
      if (mounted) {
        setState(() {
            _isLoadingSholat = false;
          });
      }
    }
  }

  Future<void> _saveLocationPreference(String cityId, String cityName) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('last_city_id', cityId);
      await prefs.setString('last_city_name', cityName);
      await prefs.setBool('use_current_location', true);
      print('💾 Location preference saved: $cityName ($cityId)');
    } catch (e) {
      print('Error saving location preference: $e');
    }
  }

  Future<void> _loadSavedLocation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedCityId = prefs.getString('last_city_id');
      final savedCityName = prefs.getString('last_city_name');
      final useCurrentLocation = prefs.getBool('use_current_location') ?? false;

      if (savedCityId != null && savedCityName != null) {
        print('📂 Loading saved location: $savedCityName ($savedCityId)');

        setState(() {
            _selectedCityId = savedCityId;
            _selectedCityName = savedCityName;
            _useCurrentLocation = useCurrentLocation;
          });

        await _fetchSholatSchedule(savedCityId);
      } else {
        _setDefaultSholatSchedule();
        print('📍 Using default location: Jakarta');
      }
    } catch (e) {
      print('Error loading saved location: $e');
      _setDefaultSholatSchedule();
    }
  }

  // Fungsi helper untuk membersihkan nama kota
  String _cleanCityName(String cityName) {
    if (cityName.isEmpty) return '';

    String cleaned = cityName.toLowerCase();
    List<String> prefixes = [
      'kecamatan',
      'kelurahan',
      'kota',
      'kab.',
      'kabupaten',
      'kab',
      'kec',
      'kel',
      'desa',
      'kabkota'
    ];

    for (var prefix in prefixes) {
      cleaned = cleaned.replaceAll(prefix, '').trim();
    }
    List<String> directions = ['selatan', 'utara', 'timur', 'barat'];
    for (var dir in directions) {
      cleaned = cleaned.replaceAll(' $dir', '').replaceAll('$dir ', '');
    }

    return cleaned.trim();
  }

  bool _isCityMatch(String apiCityName, String geocodingCityName) {
    if (apiCityName.isEmpty || geocodingCityName.isEmpty) return false;
    String cleanApi = apiCityName.replaceAll(RegExp(r'[^a-z]'), '');
    String cleanGeo = geocodingCityName.replaceAll(RegExp(r'[^a-z]'), '');
    return cleanApi.contains(cleanGeo) ||
    cleanGeo.contains(cleanApi) ||
    cleanApi == cleanGeo;
  }

  Future<void> _fetchSholatSchedule(String cityId) async {
    if (!mounted) return;

    try {
      _safeSetState(() {
          _isLoadingSholat = true;
        });

      final data = await _sholatService
      .getJadwalSholat(cityId)
      .timeout(Duration(seconds: 10), onTimeout: () {
          return {};
        });

      if (mounted && data.isNotEmpty && data['status'] == true) {
        _safeSetState(() {
            _jadwalSholat = data['data']; // Perhatikan struktur response v1
          });
      } else {
        _setDefaultSholatSchedule();
      }
    } catch (e) {
      print('Error fetching sholat schedule: $e');
      _setDefaultSholatSchedule();
    } finally {
      if (mounted) {
        _safeSetState(() {
            _isLoadingSholat = false;
          });
      }
    }
  }

  void _toggleFanMenu() {
    setState(() => _isFanMenuOpen = !_isFanMenuOpen);
    if (_isFanMenuOpen) {
      _fanMenuController.forward();
      _fanStaggerController.forward();
    } else {
      _fanMenuController.reverse();
      _fanStaggerController.reverse();
    }
  }

  void _closeFanMenu() {
    if (_isFanMenuOpen) {
      setState(() => _isFanMenuOpen = false);
      _fanMenuController.reverse();
      _fanStaggerController.reverse();
    }
  }

  void _setDefaultSholatSchedule() {
    if (mounted) {
      _safeSetState(() {
          _jadwalSholat = {
            'lokasi': 'Jakarta',
            'daerah': 'DKI Jakarta',
            'jadwal': {
              'imsak': '04:22',
              'subuh': '04:32',
              'terbit': '05:46',
              'dzuhur': '12:08',
              'ashar': '15:30',
              'maghrib': '18:20',
              'isya': '19:33',
            }
          };
          _isLoadingSholat = false;
        });
    }
  }

  String _getNextSholatTime() {
    if (_jadwalSholat == null || _jadwalSholat!['jadwal'] == null) {
      return "Mengambil jadwal...";
    }

    final jadwal = _jadwalSholat!['jadwal'];
    final now = DateTime.now();
    final currentTime =
    '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    final sholatTimes = [
      {'name': 'Subuh', 'time': jadwal['subuh']?.toString() ?? '04:32'},
      {'name': 'Dzuhur', 'time': jadwal['dzuhur']?.toString() ?? '12:08'},
      {'name': 'Ashar', 'time': jadwal['ashar']?.toString() ?? '15:30'},
      {'name': 'Maghrib', 'time': jadwal['maghrib']?.toString() ?? '18:20'},
      {'name': 'Isya', 'time': jadwal['isya']?.toString() ?? '19:33'},
    ];

    for (var sholat in sholatTimes) {
      if (_isTimeLater(sholat['time']!, currentTime)) {
        return "Menuju ${sholat['name']} : ${sholat['time']}";
      }
    }

    final imsakTime = jadwal['imsak']?.toString() ?? '04:22';
    return "Menuju Imsak : $imsakTime";
  }

  bool _isTimeLater(String time1, String time2) {
    try {
      final t1 = time1.split(':');
      final t2 = time2.split(':');

      final hour1 = int.tryParse(t1[0]) ?? 0;
      final minute1 = int.tryParse(t1[1]) ?? 0;
      final hour2 = int.tryParse(t2[0]) ?? 0;
      final minute2 = int.tryParse(t2[1]) ?? 0;

      return hour1 > hour2 || (hour1 == hour2 && minute1 > minute2);
    } catch (e) {
      return false;
    }
  }

  void _showCitySelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.8,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF0F172A),
                    Color(0xFF1E293B),
                  ],
                ),
                borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.location_on,
                                  color: _t.tx(Color(0xFFFF6B9D))),
                                SizedBox(width: 12),
                                Text(
                                  'Pilih Lokasi Sholat',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            IconButton(
                              icon: Icon(Icons.close, color: Colors.white),
                              onPressed: () => Navigator.pop(context),
                            ),
                          ],
                        ),
                        SizedBox(height: 16),
                        Container(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () async {
                              Navigator.pop(context);
                              if (mounted) {
                                setState(() {
                                    _isLoadingSholat = true;
                                  });
                              }
                              await _initSholatData();
                            },
                            icon: Icon(Icons.gps_fixed),
                            label: Text('Gunakan Lokasi Saat Ini'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _t.dk(Color(0xFFFF6B9D)),
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        TextField(
                          decoration: InputDecoration(
                            hintText: 'Cari kota/kabupaten...',
                            hintStyle: TextStyle(color: Colors.white70),
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            prefixIcon:
                            Icon(Icons.search, color: Colors.white70),
                          ),
                          style: TextStyle(color: Colors.white),
                          onChanged: (value) async {
                            if (value.length > 2) {
                              final results =
                              await _sholatService.searchKota(value);
                              setState(() {
                                  _cityList = results;
                                });
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.1),
                  ),
                  Expanded(
                    child: _cityList.isEmpty
                    ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.search,
                            color: Colors.white30, size: 50),
                          SizedBox(height: 16),
                          Text(
                            'Cari kota atau kabupaten',
                            style: TextStyle(color: Colors.white70),
                          ),
                          Text(
                            'Minimal 3 karakter',
                            style: TextStyle(
                              color: Colors.white54, fontSize: 12),
                          ),
                        ],
                      ),
                    )
                    : ListView.builder(
                      itemCount: _cityList.length,
                      itemBuilder: (context, index) {
                        final city = _cityList[index];
                        return Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12)),
                          child: ListTile(
                            leading: Icon(
                              Icons.location_city,
                              color: _t.tx(Color(0xFFFF6B9D)).withOpacity(0.7),
                            ),
                            title: Text(
                              city['lokasi']?.toString() ?? 'Unknown',
                              style: TextStyle(color: Colors.white),
                            ),
                            subtitle: city['daerah'] != null
                            ? Text(
                              city['daerah'].toString(),
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12),
                            )
                            : null,
                            trailing:
                            _selectedCityId == city['id'].toString()
                            ? Icon(Icons.check,
                              color: _t.tx(Color(0xFFFF6B9D)))
                            : null,
                            onTap: () async {
                              if (mounted) {
                                setState(() {
                                    _selectedCityId = city['id'].toString();
                                    _selectedCityName =
                                    city['lokasi']?.toString() ??
                                    'Jakarta';
                                    _useCurrentLocation = false;
                                    _isLoadingSholat = true;
                                  });
                              }
                              await _fetchSholatSchedule(
                                city['id'].toString());
                              if (mounted) {
                                setState(() {
                                    _isLoadingSholat = false;
                                  });
                                Navigator.pop(context);
                              }
                            },
                          ),
                        );
                      },
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius:
                      BorderRadius.vertical(bottom: Radius.circular(25))),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline,
                          color: Colors.white70, size: 16),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Pilih kota untuk mendapatkan jadwal sholat yang akurat',
                            style:
                            TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSholatTimeItem(String name, String time, bool isActive) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color:
        isActive ? _t.dk(Color(0xFFFF6B9D)).withOpacity(0.2) : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isActive
          ? _t.dk(Color(0xFFFF6B9D)).withOpacity(0.5)
          : Colors.white.withOpacity(0.1),
        )),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(
              color:
              isActive ? _t.tx(Color(0xFFFF6B9D)) : Colors.white.withOpacity(0.8),
              fontSize: 14,
              fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
          Text(
            time,
            style: TextStyle(
              color: isActive ? _t.tx(Color(0xFFFF6B9D)) : Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w800,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  // Helper function untuk safe setState
  void _safeSetState(VoidCallback fn) {
    if (mounted) {
      try {
        WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              setState(fn);
            }
          });
      } catch (e) {
        print("⚠️ Error in setState: $e");
      }
    }
  }

  // Helper untuk mendapatkan waktu sholat dengan null safety
  String _getSholatTime(String key) {
    if (_jadwalSholat == null ||
      _jadwalSholat!['jadwal'] == null ||
      _jadwalSholat!['jadwal'][key] == null) {
      return '--:--';
    }
    return _jadwalSholat!['jadwal'][key]?.toString() ?? '--:--';
  }

  Future<void> _fetchHadith() async {
    if (_isLoadingHadith) return;

    setState(() {
        _isLoadingHadith = true;
      });

    try {
      print("📖 Fetching hadith from API...");

      final randomPage = Random().nextInt(10) + 1;

      final res = await http.get(
        Uri.parse(
          "http://nodemyayun.otax.store:2112/hadith/muslim?page=$randomPage&limit=10"),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        if (data['items'] is List && data['items'].isNotEmpty) {
          final items = data['items'] as List;
          final validItems = items.where((item) {
              final arabic = item['arab']?.toString() ?? '';
              final translation = item['id']?.toString() ?? '';
              return arabic.isNotEmpty && translation.isNotEmpty;
            }).toList();

          if (validItems.isEmpty) {
            print("⚠️ No valid hadith items after filtering");
            _setFallbackHadith();
            return;
          }
          final item = validItems[0];
          String arabic = item['arab']?.toString() ?? '';
          String translation = item['id']?.toString() ?? '';
          final number = item['number']?.toString() ?? '';
          arabic = _cleanArabicText(arabic);
          translation = _cleanTranslationText(translation);
          if (translation.isEmpty) {
            print(
              "🔄 Translation empty after cleaning, trying alternative extraction");
            translation = _extractHadithFromText(item['id']?.toString() ?? '');
          }

          setState(() {
              _currentHadith = {
                'number': number,
                'arab': arabic,
                'id': translation,
              };
            });

          print("✅ Hadith #$number loaded successfully");
          print("✅ Arabic: ${arabic.length} chars");
          print("✅ Translation: ${translation.length} chars");
        } else {
          print("⚠️ No hadith items in response");
          _setFallbackHadith();
        }
      } else {
        print("⚠️ API returned ${res.statusCode}");
        _setFallbackHadith();
      }
    } catch (e) {
      print("❌ Error fetching hadith: $e");
      _setFallbackHadith();
    } finally {
      if (mounted) {
        setState(() {
            _isLoadingHadith = false;
          });
      }
    }
  }

  String _extractHadithFromText(String text) {
    if (text.isEmpty) return '';
    final quoteMatches = RegExp(r'"([^"]*)"').allMatches(text);
    if (quoteMatches.isNotEmpty) {
      final lastMatch = quoteMatches.last;
      return lastMatch.group(1) ?? text;
    }
    final index = text.lastIndexOf('bersabda:');
    if (index != -1) {
      return text.substring(index + 9).trim();
    }
    return text;
  }

  String _cleanArabicText(String arabic) {
    if (arabic.isEmpty) return '';

    arabic = arabic
    .replaceAll('&amp;', '&')
    .replaceAll('&quot;', '"')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&nbsp;', ' ');

    arabic = arabic.replaceAll(RegExp(r'<[^>]*>'), '');
    arabic = arabic.replaceAll(RegExp(r'\[.*?\]'), '');
    arabic = arabic.replaceAll(RegExp(r'\s+'), ' ').trim();

    return arabic;
  }

  String _cleanTranslationText(String translation) {
    if (translation.isEmpty) return '';

    translation = translation
    .replaceAll('&amp;', '&')
    .replaceAll('&quot;', '"')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&nbsp;', ' ');

    translation = translation.replaceAll(RegExp(r'<[^>]*>'), '');
    translation = translation.replaceAll(RegExp(r'\[.*?\]'), '');
    translation = translation.replaceAll(RegExp(r'\s+'), ' ').trim();

    return translation;
  }

  void _pickRandomHadith() {
    if (_hadithList.isEmpty) {
      _setFallbackHadith();
      return;
    }

    final random = Random();
    final randomIndex = random.nextInt(_hadithList.length);
    final hadith = _hadithList[randomIndex];

    setState(() {
        _currentHadith = hadith is Map<String, dynamic>
        ? hadith
        : Map<String, dynamic>.from(hadith);
      });
  }

  void _setFallbackHadith() {
    final fallbackHadithList = [
      {
        'number': '1',
        'arab': 'مَنْ صَلَّى عَلَيَّ وَاحِدَةً صَلَّى اللَّهُ عَلَيْهِ عَشْرًا',
        'id':
        'Rasulullah ﷺ bersabda: "Barangsiapa yang bershalawat kepadaku sekali, niscaya Allah bershalawat kepadanya sepuluh kali."',
      },
      {
        'number': '2',
        'arab': 'الدُّنْيَا سَجْنُ الْمُؤْمِنِ وَجَنَّةُ الْكَافِرِ',
        'id':
        'Rasulullah ﷺ bersabda: "Dunia adalah penjara bagi orang mukmin dan surga bagi orang kafir."',
      },
      {
        'number': '3',
        'arab':
        'لَا تَكْذِبُوا عَلَيَّ فَإِنَّهُ مَنْ يَكْذِبْ عَلَيَّ يَلِجْ النَّارَ',
        'id':
        'Rasulullah ﷺ bersabda: "Janganlah kalian berdusta atas namaku, karena siapa yang berdusta atas namaku niscaya dia masuk neraka."',
      },
      {
        'number': '4',
        'arab': 'كَفَى بِالْمَرْءِ كَذِبًا أَنْ يُحَدِّثَ بِكُلِّ مَا سَمِعَ',
        'id':
        'Rasulullah ﷺ bersabda: "Cukuplah seseorang (dianggap) berbohong apabila dia menceritakan semua yang dia dengarkan."',
      },
      {
        'number': '5',
        'arab':
        'الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ',
        'id':
        'Rasulullah ﷺ bersabda: "Seorang muslim adalah orang yang kaum muslimin selamat dari lisan dan tangannya."',
      },
    ];

    final random = Random();
    final randomIndex = random.nextInt(fallbackHadithList.length);

    setState(() {
        _currentHadith = fallbackHadithList[randomIndex];
      });

    print("✅ Using fallback hadith #${_currentHadith!['number']}");
  }

  Future<void> _fetchAdvancedStats({int retryCount = 3}) async {
    if (retryCount <= 0 || !mounted) return;

    try {
      final uri = Uri.parse(
        "$baseUrl/api/stats/real-time?key=$sessionKey",
      );

      final response = await http.get(
        uri,
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $sessionKey',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (!mounted) return;
        setState(() {
            onlineUsers = data['online_users'] ??
            data['global_stats']?['online_users'] ??
            onlineUsers;

            activeConnections = data['connections_count'] ??
            data['personal_stats']?['active_connections'] ??
            activeConnections;

            _lastStatsUpdate = DateTime.now();
          });
        return;
      }

      if (response.statusCode == 401) {
        _handleInvalidSession("Session expired");
        return;
      }
    } catch (_) {}

    await Future.delayed(const Duration(seconds: 2));
    await _fetchAdvancedStats(retryCount: retryCount - 1);
  }

  Future<void> _fetchNotifications() async {
    if (isNotifLoading) return;

    setState(() {
        isNotifLoading = true;
      });

    try {
      print("📢 Fetching notifications...");

      final uri = Uri.parse("$baseUrl/notify/list").replace(queryParameters: {
          'key': sessionKey,
          'username': username,
          'timestamp': DateTime.now().millisecondsSinceEpoch.toString(),
        });

      final res = await http.get(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $sessionKey',
        },
      ).timeout(const Duration(seconds: 10));

      print("📢 Notifications status: ${res.statusCode}");

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is List) {
          setState(() {
              notifications = data;
              hasUnreadNotif = data.isNotEmpty;
            });
          print("✅ ${notifications.length} notifications loaded");
        } else if (data is Map) {
          final notifList = data['notifications'] ?? data['data'] ?? [];
          if (notifList is List) {
            setState(() {
                notifications = notifList;
                hasUnreadNotif = notifList.isNotEmpty;
              });
            print("✅ ${notifications.length} notifications loaded from map");
          }
        }
      } else {
        print("⚠️ Failed to fetch notifications: ${res.statusCode}");
      }
    } catch (e) {
      print("❌ Error fetching notifications: $e");
    } finally {
      if (mounted) {
        setState(() {
            isNotifLoading = false;
          });
      }
    }
  }

  void _openNotifications() {
    print("📢 [UI] Opening notifications panel");
    print("📢 [UI] Notifications count: ${notifications.length}");

    setState(() {
        hasUnreadNotif = false;
      });

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.5),
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          decoration: BoxDecoration(
            color: Color(0xFF0F1419),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border.all(
              color: Color(0xFF2A2F35),
              width: _t.bw(1),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Color(0xFF1A1F25),
                  borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(24)),
                  border: Border(
                    bottom: BorderSide(
                      color: Color(0xFF2A2F35),
                      width: _t.bw(1),
                    ),
                  )),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: bloodRed.withOpacity(0.1)),
                      child: Center(
                        child: Icon(
                          Icons.notifications_outlined,
                          color: bloodRed,
                          size: 22,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Notifikasi",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "${notifications.length} pesan baru",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.6),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.05)),
                      child: IconButton(
                        icon: Icon(
                          Icons.close,
                          size: 20,
                          color: Colors.white.withOpacity(0.8),
                        ),
                        onPressed: () => Navigator.pop(context),
                        padding: EdgeInsets.zero,
                      ),
                    ),
                  ],
                ),
              ),

              // Content Area
              Expanded(
                child: notifications.isEmpty
                ? _buildEmptyNotifications()
                : _buildNotificationsList(),
              ),

              // Footer Actions
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFF1A1F25),
                  border: Border(
                    top: BorderSide(
                      color: Color(0xFF2A2F35),
                      width: _t.bw(1),
                    ),
                  )),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Color(0xFF3A3F45),
                            width: _t.bw(1),
                          ),
                          color: Colors.white.withOpacity(0.03)),
                        child: TextButton.icon(
                          onPressed: () {
                            // Mark all as read logic
                          },
                          icon: Icon(
                            Icons.check_circle_outline,
                            size: 18,
                            color: Colors.white.withOpacity(0.7),
                          ),
                          label: Text(
                            "Tandai Semua Dibaca",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.9),
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          style: TextButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: bloodRed.withOpacity(0.1),
                        border: Border.all(
                          color: bloodRed.withOpacity(0.2),
                          width: _t.bw(1),
                        )),
                      child: IconButton(
                        icon: Icon(
                          Icons.refresh,
                          size: 20,
                          color: bloodRed,
                        ),
                        onPressed: () async {
                          Navigator.pop(context);
                          await _fetchNotifications();
                          _openNotifications();
                        },
                        tooltip: "Refresh",
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyNotifications() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.04)),
              child: Icon(
                Icons.notifications_none_outlined,
                size: 36,
                color: Colors.white.withOpacity(0.2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              "Tidak Ada Notifikasi",
              style: TextStyle(
                color: Colors.white.withOpacity(0.9),
                fontSize: 18,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Tidak ada notifikasi untuk ditampilkan saat ini",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 24),
            Container(
              width: 180,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Color(0xFF3A3F45),
                  width: _t.bw(1),
                )),
              child: TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  await _fetchNotifications();
                  _openNotifications();
                },
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.refresh,
                      size: 16,
                      color: Colors.white.withOpacity(0.8),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Refresh",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationsList() {
    return RefreshIndicator(
      onRefresh: () async {
        print("🔄 [UI] Pull to refresh notifications");
        await _fetchNotifications();
      },
      color: bloodRed,
      backgroundColor: Color(0xFF0F1419),
      child: ListView.builder(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        itemCount: notifications.length,
        itemBuilder: (context, index) {
          final notification = notifications[index];
          final title = notification["title"]?.toString() ?? "Notifikasi";
          final message = notification["message"]?.toString() ?? "-";
          final createdAt = notification["createdAt"]?.toString() ?? "";
          final isNew = index == 0;

          // Format waktu
          String formattedTime;
          try {
            final date = DateTime.parse(createdAt);
            final now = DateTime.now();
            final difference = now.difference(date);

            if (difference.inMinutes < 1) {
              formattedTime = "Baru saja";
            } else if (difference.inMinutes < 60) {
              formattedTime = "${difference.inMinutes}m yang lalu";
            } else if (difference.inHours < 24) {
              formattedTime = "${difference.inHours}j yang lalu";
            } else {
              formattedTime = "${difference.inDays}h yang lalu";
            }
          } catch (e) {
            formattedTime = "Waktu tidak diketahui";
          }

          return _buildNotificationItem(
            title: title,
            message: message,
            time: formattedTime,
            isNew: isNew,
            index: index,
          );
        },
      ),
    );
  }

  Widget _buildNotificationItem({
      required String title,
      required String message,
      required String time,
      required bool isNew,
      required int index,
    }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: () {
            // Handle notification tap
          },
          borderRadius: BorderRadius.circular(16),
          splashColor: bloodRed.withOpacity(0.1),
          highlightColor: Colors.white.withOpacity(0.02),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isNew
              ? bloodRed.withOpacity(0.05)
              : Colors.white.withOpacity(0.03),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isNew
                ? bloodRed.withOpacity(0.15)
                : Colors.white.withOpacity(0.08),
                width: _t.bw(1),
              )),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                          height: 1.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (isNew)
                    Container(
                      margin: const EdgeInsets.only(left: 8),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: bloodRed.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8)),
                      child: Text(
                        "BARU",
                        style: TextStyle(
                          color: bloodRed,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 8),

                // Message
                Text(
                  message,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    height: 1.4,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),

                const SizedBox(height: 12),

                // Time and actions
                Row(
                  children: [
                    Icon(
                      Icons.access_time_outlined,
                      size: 14,
                      color: Colors.white.withOpacity(0.4),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      time,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.05)),
                      child: IconButton(
                        icon: Icon(
                          Icons.more_vert,
                          size: 16,
                          color: Colors.white.withOpacity(0.5),
                        ),
                        onPressed: () {
                          _showNotificationActions(context, index);
                        },
                        padding: EdgeInsets.zero,
                        splashRadius: 14,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showNotificationActions(BuildContext context, int index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          margin: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Color(0xFF1A1F25),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Color(0xFF2A2F35),
                    width: _t.bw(1),
                  )),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      leading: Icon(
                        Icons.check_circle_outline,
                        color: Colors.white.withOpacity(0.8),
                        size: 22,
                      ),
                      title: Text(
                        "Tandai Dibaca",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        // Implement mark as read
                      },
                    ),
                    Divider(
                      height: 1,
                      color: Color(0xFF2A2F35),
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.delete_outline,
                        color: _t.tx(Colors.red).withOpacity(0.8),
                        size: 22,
                      ),
                      title: Text(
                        "Hapus Notifikasi",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        // Implement delete
                      },
                    ),
                    Divider(
                      height: 1,
                      color: Color(0xFF2A2F35),
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.content_copy_outlined,
                        color: Colors.white.withOpacity(0.8),
                        size: 22,
                      ),
                      title: Text(
                        "Salin Pesan",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        // Implement copy
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Color(0xFF1A1F25),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Color(0xFF2A2F35),
                    width: _t.bw(1),
                  )),
                child: ListTile(
                  leading: Icon(
                    Icons.cancel_outlined,
                    color: Colors.white.withOpacity(0.8),
                    size: 22,
                  ),
                  title: Text(
                    "Tutup",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      print("🌐 Connecting to WebSocket...");

      // Close existing connection if any
      if (channel != null && channel.closeCode == null) {
        try {
          channel.sink.close(status.goingAway);
        } catch (e) {
          print("⚠️ Error closing old connection: $e");
        }
      }

      // Connect to WebSocket
      channel = WebSocketChannel.connect(
        Uri.parse('ws://nodemyayun.otax.store:3000/ws'),
        protocols: ['otax-protocol'],
      );

      print("✅ WebSocket connection established");

      // Setup message handler
      channel.stream.listen(
        (dynamic message) {
          print(
            "📨 WebSocket message received: ${message.toString().substring(0, min(100, message.toString().length))}");
          _handleWebSocketMessage(message);
        },
        onError: (error) {
          print("❌ WebSocket error: $error");
          _reconnectWebSocket();
        },
        onDone: () {
          print("🔌 WebSocket connection closed");
          if (channel.closeCode != 1000) {
            _reconnectWebSocket();
          }
        },
        cancelOnError: true,
      );

      // Send authentication after 1 second
      Future.delayed(const Duration(seconds: 1), () {
          if (channel != null && channel.closeCode == null) {
            _sendWebSocketAuth();
          }
        });
    } catch (e) {
      print("❌ Failed to connect WebSocket: $e");
      _reconnectWebSocket();
    }
  }

  void _sendWebSocketAuth() {
    try {
      print("🔐 Sending WebSocket authentication...");

      final authMessage = jsonEncode({
          "type": "auth",
          "token": sessionKey,
          "username": username,
          "role": role,
          "androidId": androidId,
          "timestamp": DateTime.now().millisecondsSinceEpoch,
        });

      channel.sink.add(authMessage);
      print("✅ Authentication sent");
    } catch (e) {
      print("❌ Error sending auth: $e");
    }
  }

  void _handleWebSocketMessage(dynamic event) {
    try {
      print("📨 Raw WebSocket message: $event");

      final data = jsonDecode(event.toString());
      final type = data['type']?.toString().toLowerCase();

      print("📨 Processing message type: $type");

      switch (type) {
        case 'stats_update':
        case 'stats':
        _handleStatsUpdate(data);
        break;

        case 'notification':
        case 'notify':
        _handleNewNotification(data);
        break;

        case 'connections_update':
        case 'senders':
        _handleConnectionsUpdate(data);
        break;

        case 'user_online':
        case 'online':
        _handleUserOnlineUpdate(data);
        break;

        case 'ping':
        // Respond to ping
        channel.sink.add(jsonEncode({
              'type': 'pong',
              'timestamp': DateTime.now().millisecondsSinceEpoch
            }));
        break;

        case 'auth_success':
        print("✅ WebSocket authentication successful");
        // Request initial data after auth
        channel.sink.add(jsonEncode({
              'type': 'get_initial_data',
              'token': sessionKey,
            }));
        break;

        default:
        print(
          "📨 Unknown message type: $type, data: ${data.toString().substring(0, min(100, data.toString().length))}");
      }
    } catch (e) {
      print("❌ Error parsing WebSocket message: $e");
    }
  }

  void _handleStatsUpdate(Map<String, dynamic> data) {
    if (mounted) {
      setState(() {
          // Update online users dari server
          onlineUsers = data['total_online_users'] ??
          data['onlineUsers'] ??
          data['online_count'] ??
          onlineUsers;

          // Update active connections untuk user ini
          activeConnections = data['your_active_connections'] ??
          data['myConnections'] ??
          data['connections_count'] ??
          activeConnections;

          print(
            "📊 Stats Updated: Online=$onlineUsers, Connections=$activeConnections");
        });
    }
  }

  void _showInAppNotification(Map<String, dynamic> notification) {
    // Tampilkan banner notifikasi
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              notification['title'],
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 4),
            Text(
              notification['message'],
              style: TextStyle(color: Colors.white70),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        backgroundColor: _getNotificationColor(notification['type']),
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
              _openNotifications();
            },
            child: Text('BUKA', style: TextStyle(color: Colors.white)),
          ),
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
            },
            child: Text('TUTUP', style: TextStyle(color: Colors.white70)),
          ),
        ],
        padding: EdgeInsets.all(16),
      ),
    );

    // Auto-hide setelah 5 detik
    Future.delayed(Duration(seconds: 5), () {
        if (mounted) {
          ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
        }
      });
  }

  Color _getNotificationColor(String type) {
    switch (type) {
      case 'warning':
      return _t.dk(Colors.orange[800])!;
      case 'error':
      return _t.dk(Colors.red[800])!;
      case 'success':
      return _t.dk(Colors.green[800])!;
      case 'info':
      default:
      return _t.dk(Colors.blue[800])!;
    }
  }

  Color _getTimeZoneColor(String timeZone) {
    switch (timeZone) {
      case "WIB":
      return _t.dk(Color(0xFF2196F3)); // Biru
      case "WITA":
      return _t.dk(Color(0xFF4CAF50)); // Hijau
      case "WIT":
      return _t.dk(Color(0xFFFF9800)); // Oranye
      default:
      return _t.dk(Color(0xFF00B4D8));
    }
  }

  bool _isCurrentSholat(String sholatName, String? sholatTime) {
    if (sholatTime == null) return false;

    try {
      final now = DateTime.now();
      final currentTime =
      '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

      // Ambil hanya jam dan menit dari waktu sholat (hapus detik jika ada)
      final sholatTimeFormatted =
      sholatTime.length >= 5 ? sholatTime.substring(0, 5) : sholatTime;

      return sholatTimeFormatted == currentTime;
    } catch (e) {
      return false;
    }
  }

  void _handleNewNotification(Map<String, dynamic> data) {
    final notification = {
      'id': data['id'] ?? DateTime.now().millisecondsSinceEpoch,
      'title': data['title'] ?? 'Notification',
      'message': data['message'] ?? '',
      'createdAt': data['timestamp'] ?? DateTime.now().toIso8601String(),
      'type': data['notification_type'] ?? 'info',
      'read': false,
    };

    if (mounted) {
      setState(() {
          // Tambahkan notifikasi baru di urutan teratas
          notifications.insert(0, notification);
          hasUnreadNotif = true;

          // Batasi jumlah notifikasi (misal 50 terbaru)
          if (notifications.length > 50) {
            notifications = notifications.sublist(0, 50);
          }
        });

      // Tampilkan snackbar atau banner notifikasi
      _showInAppNotification(notification);
    }
  }

  void _handleConnectionsUpdate(Map<String, dynamic> data) {
    final List<dynamic> connections = data['connections'] ?? [];
    if (mounted) {
      setState(() {
          senderList = connections.cast<Map<String, dynamic>>();
          activeConnections = connections.length;
        });
    }
  }

  void _handleUserOnlineUpdate(Map<String, dynamic> data) {
    final String action = data['action'] ?? 'update';
    final int count = data['count'] ?? onlineUsers;

    if (mounted) {
      setState(() {
          if (action == 'increment') {
            onlineUsers += 1;
          } else if (action == 'decrement') {
            onlineUsers -= 1;
            if (onlineUsers < 0) onlineUsers = 0;
          } else {
            onlineUsers = count;
          }
        });
    }
  }

  int _reconnectAttempts = 0;
  bool _isReconnecting = false;

  void _reconnectWebSocket() {
    if (_isReconnecting) return;

    _isReconnecting = true;
    _reconnectAttempts++;

    // Exponential backoff: 3, 6, 12, 24, 30 seconds
    final delaySeconds =
    _reconnectAttempts <= 5 ? pow(2, _reconnectAttempts).toInt() : 30;

    print(
      "🔄 Reconnecting WebSocket in $delaySeconds seconds (attempt $_reconnectAttempts)...");

    Future.delayed(Duration(seconds: delaySeconds), () {
        if (mounted) {
          _isReconnecting = false;
          _connectToWebSocket();
        }
      });
  }

  // Di dalam _buildEnhancedNewsPage(), tambahkan widget ini:
  Widget _buildConnectionStatusIndicator() {
    final isConnected = channel?.closeCode == null;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isConnected
        ? _t.dk(Colors.green).withOpacity(0.1)
        : _t.dk(Colors.orange).withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isConnected ? _t.dk(Colors.green) : _t.dk(Colors.orange),
          width: _t.bw(1),
        )),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isConnected ? _t.dk(Colors.green) : _t.dk(Colors.orange),
              boxShadow: [
                BoxShadow(
                  color: isConnected
                  ? _t.dk(Colors.green).withOpacity(0.8)
                  : _t.dk(Colors.orange).withOpacity(0.8),
                  blurRadius: 8,
                ),
              ]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isConnected ? "REAL-TIME CONNECTED" : "CONNECTING...",
                  style: TextStyle(
                    color: isConnected ? _t.tx(Colors.green) : _t.tx(Colors.orange),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  isConnected
                  ? "WebSocket connection active"
                  : "Attempting to reconnect...",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          if (!isConnected)
          IconButton(
            icon: const Icon(Icons.refresh, size: 18),
            color: _t.dk(Colors.orange),
            onPressed: _reconnectWebSocket,
          ),
        ],
      ),
    );
  }

  void _startPollingFallback() {
    print("🔄 Starting polling fallback...");

    // Poll setiap 15 detik jika WebSocket tidak tersedia
    Timer.periodic(Duration(seconds: 15), (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        // Hanya poll jika WebSocket tidak terhubung
        if (channel?.closeCode != null) {
          print("🔄 Polling data (WebSocket disconnected)...");
          Future.wait([
              _fetchAdvancedStats(),
              _fetchSenders(),
              _fetchNotifications(),
            ]);
        }
      });
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: glassBlack,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: bloodRed.withOpacity(0.5), width: _t.bw(1)),
          ),
          title: Row(
            children: [
              Icon(Icons.warning_rounded, color: bloodRed, size: 28),
              const SizedBox(width: 10),
              Text("Session Expired",
                style:
                TextStyle(color: bloodRed, fontWeight: FontWeight.bold)),
            ],
          ),
          content: Text(message, style: const TextStyle(color: Colors.white70)),
          actions: [
            Container(
              decoration: BoxDecoration(
                color: bloodRed,
                borderRadius: BorderRadius.circular(12)),
              child: TextButton(
                onPressed: () {
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                },
                child: Text("OK", style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Halaman aktif disimpan sebagai widget jadi (_selectedPage), makanya harus
  // dibangun ulang manual pas tema berubah.
  void _onThemeChanged() {
    if (!mounted) return;
    _onNavTap(_currentNavIndex);
  }

  void _onNavTap(int index) {
    setState(() {
        _currentNavIndex = index;
        if (index == 0) {
          _selectedPage = _buildEnhancedNewsPage();
        } else if (index == 1) {
          _selectedPage = ToolsLandingPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos,
            username: username,
            uid: uid,
          );
        } else if (index == 2) {
          try {
            _selectedPage = _buildWhatsAppMenuPage();
          } catch (e) {
            print('Error creating BugGroupPage: $e');
            _selectedPage = Center(
              child: Text('Error: $e', style: TextStyle(color: _t.tx(Colors.red))),
            );
          }
        } else if (index == 3) {
          _selectedPage = ChatPage(sessionKey: sessionKey, username: username, role: role, androidId: androidId);
        }
      });
  }

  Widget _buildWhatsAppMenuPage() {
    final List<Map<String, dynamic>> menuOptions = [
      {
        'title': 'OTAX RAT',
        'subtitle': 'Developer Rat @Otapengenkawin',
        'description': 'Belum ada base phising nya rek',
        'icon': Icons.bug_report,
        'iconColor': _t.ink,
        'fillColor': _t.yellow,
        'badgeText': 'COMING SOON',
        'badgeColor': _t.dk(const Color(0xFFFF2D55)),
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const TargetListPage(),
          ),
        ),
      },
      {
        'title': 'X5-5X RAT',
        'subtitle': 'Developer Rat @mizukisnji',
        'description': 'All menu gacor anti ampas',
        'icon': Icons.settings_applications,
        'iconColor': _t.ink,
        'fillColor': _t.dk(const Color(0xFF00A3FF)),
        'badgeText': 'RECOMMENDED',
        'badgeColor': _t.dk(const Color(0xFFFF2D55)),
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const ControlPanelPage(),
          ),
        ),
      },
      {
        'title': 'BUILDER RAT',
        'subtitle': 'Tempat Build Apk Phising',
        'description': 'Build Di Sini',
        'icon': Icons.android,
        'iconColor': _t.ink,
        'fillColor': _t.dk(const Color(0xFF7CFF6B)),
        'badgeText': 'NEW',
        'badgeColor': _t.dk(const Color(0xFFFF2D55)),
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BuilderPage(
              sessionKey: sessionKey,
              username: username,
            ),
          ),
        ),
      },
    ];

    return Scaffold(
      backgroundColor: _t.scaffoldBg,
      body: Container(
        color: _t.dk(const Color(0xFFFFFBF0)),
        child: Column(
          children: [
            _buildWhatsAppHeader(),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final carouselHeight =
                  (constraints.maxHeight - 80).clamp(280.0, 520.0);

                  return Column(
                    children: [
                      const SizedBox(height: 12),
                      SizedBox(
                        height: carouselHeight,
                        child: CarouselSlider.builder(
                          options: CarouselOptions(
                            height: carouselHeight,
                            viewportFraction: 0.85,
                            initialPage: 0,
                            enableInfiniteScroll: true,
                            autoPlay: true,
                            autoPlayInterval: const Duration(seconds: 4),
                            autoPlayAnimationDuration:
                            const Duration(milliseconds: 700),
                            autoPlayCurve: Curves.easeInOutCubic,
                            enlargeCenterPage: true,
                            enlargeFactor: 0.15,
                            scrollDirection: Axis.horizontal,
                            onPageChanged: (index, reason) {
                              setState(() {
                                  _carouselCurrentIndex = index;
                                });
                            },
                          ),
                          itemCount: menuOptions.length,
                          itemBuilder: (context, index, realIndex) {
                            return _buildCarouselCard(
                              menuOptions[index], index);
                          },
                        ),
                      ),
                      const SizedBox(height: 14),
                      // Dot indicators
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(menuOptions.length, (i) {
                            final bool active = i == _carouselCurrentIndex;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width: active ? 28 : 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: active
                                ? _t.yellow
                                : const Color(0xFFFFFFFF),
                                borderRadius: _t.rr(0),
                                border: Border.all(
                                  color: _t.line,
                                  width: _t.bw(2.5),
                                ),
                                boxShadow: active ? _t.hard(3) : []),
                            );
                          }),
                      ),
                      const SizedBox(height: 12),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWhatsAppHeader() {
    return Container(
      height: 175,
      width: double.infinity,
      decoration: BoxDecoration(
        color: _t.surface,
        border: Border(
          bottom: BorderSide(color: _t.line, width: _t.bw(4)),
        )),
      child: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.03,
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/logo.jpg'),
                    repeat: ImageRepeat.repeat,
                    scale: 2.5,
                  )),
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: _t.yellow,
                    borderRadius: _t.rr(0),
                    border: Border.all(color: _t.line, width: _t.bw(4)),
                    boxShadow: _t.hard(5)),
                  child: Center(
                    child: FaIcon(
                      FontAwesomeIcons.whatsapp,
                      color: _t.ink,
                      size: 36,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  "FORTUNITE MENU",
                  style: TextStyle(
                    color: _t.ink,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Pilih menu yang tersedia bosque!",
                  style: TextStyle(
                    color: _t.inkSub,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  width: 100,
                  height: 6,
                  decoration: BoxDecoration(
                    color: _t.yellow,
                    borderRadius: _t.rr(0),
                    border: Border.all(color: _t.line, width: _t.bw(2)),
                    boxShadow: _t.hard(3)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCarouselCard(Map<String, dynamic> option, int index) {
    final fillColor = option['fillColor'] as Color;
    final badgeColor = option['badgeColor'] as Color;

    return Animate(
      effects: [
        FadeEffect(duration: 350.ms, delay: (80 * index).ms),
        SlideEffect(
          begin: const Offset(0, 0.04),
          end: Offset.zero,
          duration: 350.ms,
          delay: (80 * index).ms,
          curve: Curves.easeOut,
        ),
      ],
      child: GestureDetector(
        onTap: option['onTap'] as VoidCallback,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
          decoration: BoxDecoration(
            color: fillColor,
            borderRadius: _t.rr(0),
            border: Border.all(color: _t.line, width: _t.bw(4)),
            boxShadow: _t.hard(6)),
          child: ClipRRect(
            borderRadius: _t.rr(0),
            child: Stack(
              children: [
                Positioned(
                  bottom: -10,
                  right: -10,
                  child: Opacity(
                    opacity: 0.12,
                    child: Text(
                      "GACOR",
                      style: TextStyle(
                        color: _t.ink,
                        fontSize: 80,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Top: icon + badge
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              color: _t.surface,
                              borderRadius: _t.rr(0),
                              border: Border.all(
                                color: _t.line,
                                width: _t.bw(3),
                              ),
                              boxShadow: _t.hard(3)),
                            child: Center(
                              child: Icon(
                                option['icon'] as IconData,
                                color: _t.ink,
                                size: 26,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: badgeColor,
                              borderRadius: _t.rr(0),
                              border: Border.all(
                                color: _t.line,
                                width: _t.bw(2.5),
                              ),
                              boxShadow: _t.hard(3)),
                            child: Text(
                              option['badgeText'] as String,
                              style: const TextStyle(
                                color: Color(0xFFFFFFFF),
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      // Title
                      Text(
                        option['title'] as String,
                        style: TextStyle(
                          color: _t.ink,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 6),
                      // Subtitle
                      Text(
                        option['subtitle'] as String,
                        style: TextStyle(
                          color: _t.ink.withOpacity(0.7),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.3,
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Divider
                      Container(
                        height: 4,
                        width: 60,
                        color: _t.line,
                      ),
                      const SizedBox(height: 12),
                      // Description
                      Text(
                        option['description'] as String,
                        style: TextStyle(
                          color: _t.ink.withOpacity(0.8),
                          fontSize: 13,
                          height: 1.5,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const Spacer(),
                      // START MODULE button
                      Container(
                        margin: const EdgeInsets.only(bottom: 18),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: _t.surface,
                          borderRadius: _t.rr(0),
                          border: Border.all(
                            color: _t.line,
                            width: _t.bw(3),
                          ),
                          boxShadow: _t.hard(4)),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: option['onTap'] as VoidCallback,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "START MODULE",
                                    style: TextStyle(
                                      color: _t.ink,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.4,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Container(
                                    width: 24,
                                    height: 24,
                                    decoration: BoxDecoration(
                                      color: fillColor,
                                      borderRadius: _t.rr(0),
                                      border: Border.all(
                                        color: _t.line,
                                        width: _t.bw(2),
                                      )),
                                    child: Icon(
                                      Icons.arrow_forward,
                                      color: _t.ink,
                                      size: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: _t.surface,
        borderRadius: _t.rr(0),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _t.hard(4)),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _t.yellow,
              borderRadius: _t.rr(0),
              border: Border.all(color: _t.line, width: _t.bw(2.5)),
              boxShadow: _t.hard(2)),
            child: Icon(
              Icons.info_outline_rounded,
              color: _t.ink,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Semua menu telah diuji coba dan tanpa gimmick real work 100%",
                  style: TextStyle(
                    color: _t.ink,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: _t.yellow,
                        borderRadius: _t.rr(0),
                        border: Border.all(
                          color: _t.line,
                          width: _t.bw(1.5),
                        )),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "OTAX TEAM",
                      style: TextStyle(
                        color: _t.inkSub,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureItem(String text, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: _t.yellow,
              borderRadius: _t.rr(0),
              border: Border.all(color: _t.line, width: _t.bw(2))),
            child: Icon(icon, color: _t.ink, size: 14),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: _t.ink,
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToAdminPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AdminPage(sessionKey: sessionKey)),
    );
  }

  void _navigateToSellerPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SellerPage(keyToken: sessionKey)),
    );
  }

  Future<void> _fetchSenders({bool refresh = false}) async {
    if (isLoading && !refresh) return;

    if (!refresh && mounted) {
      setState(() {
          isLoading = true;
          errorMessage = null;
        });
    }

    try {
      final uri = Uri.parse(
        "$baseUrl/mySender?key=$sessionKey",
      );

      final response = await http.get(
        uri,
        headers: {
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is Map && data['valid'] == true) {
          final List connections = data['connections'] ?? [];

          if (!mounted) return;
          setState(() {
              senderList = List<Map<String, dynamic>>.from(connections);
              activeConnections = senderList.length;
            });
        } else {
          if (!mounted) return;
          setState(() {
              senderList.clear();
              activeConnections = 0;
              errorMessage = "Data sender tidak valid";
            });
        }
        return;
      }

      if (response.statusCode == 401) {
        final data = jsonDecode(response.body);
        if (!mounted) return;
        setState(() {
            senderList.clear();
            activeConnections = 0;
            errorMessage = data['error'] ?? "Session expired";
          });
        return;
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
          errorMessage = "Gagal mengambil data sender";
        });
    } finally {
      if (!mounted) return;
      setState(() {
          isLoading = false;
          isRefreshing = false;
        });
    }
  }

  // NEO-BRUTALISM palette (shared base — aksen sedikit beda: red + yellow)
  Color get bloodRed => _t.dk(const Color(0xFFFF6B9D)); // pink-red (match tools pink)
  Color get darkRed => _t.dk(const Color(0xFFE11D48));
  Color get lightRed => _t.dk(const Color(0xFFFFF0F3));

  final Color deepBlack = const Color(0xFF1A1A1A);
  final Color glassBlack = const Color(0xFF1A1A1A);

  final Color primaryDark = const Color(0xFF1A1A1A);

  Color get primaryPurple => _t.dk(const Color(0xFFFF6B9D));
  Color get accentPurple => _t.dk(const Color(0xFFFF6B9D));
  Color get lightPurple => _t.dk(const Color(0xFFFFF0F3));

  final Color primaryWhite = const Color(0xFFFFFFFF);
  final Color accentGrey = const Color(0xFF333333);

  final Color cardDark = const Color(0xFFFFFFFF);

  Color get purpleGradientStart => _t.dk(const Color(0xFFFF6B9D));
  Color get purpleGradientEnd => _t.yellow;

  Color get _neonRed => _t.dk(const Color(0xFFFF4757));
  Color get _neonOrange => _t.dk(const Color(0xFFFF9F43));
  Color get _neonCyan => _t.dk(const Color(0xFF5B8DEF)); // blue match tools
  Color get _neonGreen => _t.dk(const Color(0xFF4ADE80));
  Color get _neonPurple => _t.dk(const Color(0xFFA78BFA));
  Color get _neonBlue => _t.dk(const Color(0xFF5B8DEF));
  Color get _neonPink => _t.dk(const Color(0xFFFF6B9D));
  final Color _neonWhite = const Color(0xFFFFFFFF);
  Color get _neoYellow => _t.yellow;

  Widget _buildCompactInfoItem({
      required IconData icon,
      required String label,
      required String value,
      Color valueColor = Colors.white,
    }) {
    // PERUBAHAN: Bungkus seluruh item dalam Container untuk border penuh
    return Container(
      margin: const EdgeInsets.only(bottom: 12), // Beri jarak antar item
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(10),
        border:
        Border.all(color: primaryPurple.withOpacity(0.3)), // Border penuh
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.2),
              shape: BoxShape.circle),
            child: Icon(icon, color: lightPurple, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: accentGrey,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: valueColor,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                    shadows: valueColor == primaryWhite
                    ? [
                      Shadow(
                        color: primaryPurple.withOpacity(0.5),
                        blurRadius: 5,
                      ),
                    ]
                    : null,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showRealTimeNotification(Map<String, dynamic> data) {
    if (!mounted) return;

    final message = data['message']?.toString() ?? 'New notification';
    final title = data['title']?.toString() ?? 'Notification';

    setState(() {
        notifications.insert(0, {
            'title': title,
            'message': message,
            'createdAt': DateTime.now().toIso8601String(),
          });
        hasUnreadNotif = true;
      });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: bloodRed,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _fetchConnectionsFromBackend() async {
    try {
      channel.sink.add(jsonEncode({
            "type": "get_connections",
            "token": sessionKey,
          }));

      await _fetchSenders();
    } catch (e) {
      print("Error fetching connections: $e");
    }
  }

  void _updateTimes() {
    if (!mounted) return;

    final now = DateTime.now();
    final hour = now.hour;
    if (hour >= 5 && hour < 10) {
      _dayPeriod = "Pagi 🌅";
    } else if (hour >= 10 && hour < 15) {
      _dayPeriod = "Siang ☀️";
    } else if (hour >= 15 && hour < 18) {
      _dayPeriod = "Sore 🌇";
    } else {
      _dayPeriod = "Malam 🌙";
    }
    _wibTime = now;
    _witaTime = now.add(const Duration(hours: 1));
    _witTime = now.add(const Duration(hours: 2));

    if (mounted) {
      setState(() {});
    }
  }

  // Helper untuk format waktu dengan efek gradient
  String _formatTime(DateTime time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}';
  }

  Color _getTimeBackgroundColor(String period) {
    if (period.contains("Pagi")) {
      return const Color(0xFF0F2027); // Dark blue gradient for morning
    } else if (period.contains("Siang")) {
      return const Color(0xFF1A1A2E); // Deep navy for afternoon
    } else if (period.contains("Sore")) {
      return const Color(0xFF16213E); // Purple-blue for evening
    } else {
      return const Color(0xFF0D1117); // Darkest for night
    }
  }

  Color _getTimeAccentColor(String period) {
    if (period.contains("Pagi")) {
      return _t.dk(const Color(0xFF00B4D8)); // Morning blue
    } else if (period.contains("Siang")) {
      return _t.yellow; // Afternoon gold
    } else if (period.contains("Sore")) {
      return _t.dk(const Color(0xFFE76F51)); // Evening orange
    } else {
      return _t.dk(const Color(0xFF7209B7)); // Night purple
    }
  }

  // Ganti widget jam menjadi lebih compact dan jelas
  Widget _buildCompactTimeZone({
      required String timeZone,
      required DateTime time,
      required Color primaryColor,
      required Color accentColor,
    }) {
    String periodText = '';
    IconData periodIcon = Icons.wb_sunny;

    final hour = time.hour;
    if (hour >= 5 && hour < 10) {
      periodText = '🌅';
      periodIcon = Icons.wb_twilight;
    } else if (hour >= 10 && hour < 15) {
      periodText = '☀️';
      periodIcon = Icons.wb_sunny;
    } else if (hour >= 15 && hour < 18) {
      periodText = '🌇';
      periodIcon = Icons.nights_stay;
    } else {
      periodText = '🌙';
      periodIcon = Icons.nightlight_round;
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            primaryColor.withOpacity(0.8),
            primaryColor.withOpacity(0.4),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: accentColor.withOpacity(0.3),
          width: _t.bw(1),
        ),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.3),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ]),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            timeZone,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: accentColor.withOpacity(0.2),
              )),
            child: Text(
              '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w800,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                periodIcon,
                color: accentColor,
                size: 14,
              ),
              const SizedBox(width: 4),
              Text(
                periodText,
                style: TextStyle(
                  color: accentColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Text(
            '${time.second.toString().padLeft(2, '0')}',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 11,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStat({
      required IconData icon,
      required String label,
      required String value,
    }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            Icon(icon, color: Colors.white70, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                  Text(
                    value,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _calculateAccountStats() {
    try {
      final now = DateTime.now();
      final expired = DateTime.parse(expiredDate);
      final difference = expired.difference(now);
      if (difference.inDays <= 0) {
        _isAccountExpired = true;
        _accountStatus = "EXPIRED";
        _accountDaysLeft = 0;
        _accountProgress = 0.0;
      } else {
        _isAccountExpired = false;
        _accountDaysLeft = difference.inDays;
        const totalDays = 30;
        _accountProgress = (_accountDaysLeft / totalDays).clamp(0.0, 1.0);
        if (_accountDaysLeft <= 3) {
          _accountStatus = "CRITICAL";
        } else if (_accountDaysLeft <= 7) {
          _accountStatus = "WARNING";
        } else {
          _accountStatus = "ACTIVE";
        }
      }
    } catch (e) {
      _accountStatus = "UNKNOWN";
      _accountDaysLeft = 0;
      _accountProgress = 0.0;
    }
  }

  Future<void> _fetchDeviceStats() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      String model = "${deviceInfo.brand} ${deviceInfo.model}";
      String os = "Android ${deviceInfo.version.release}";
      int sdk = deviceInfo.version.sdkInt;

      int batLevel = 0;
      String batState = "Unknown";
      try {
        final battery = Battery();
        batLevel = await battery.batteryLevel;
        final state = await battery.batteryState;
        if (state == BatteryState.charging) {
          batState = "Charging";
        } else if (state == BatteryState.discharging) {
          batState = "Discharging";
        } else if (state == BatteryState.full) {
          batState = "Full";
        } else {
          batState = "Unknown";
        }
      } catch (e) {
        print("Battery error: $e");
      }

      String netType = "Unknown";
      int signal = 0;
      try {
        final connectivity = await Connectivity().checkConnectivity();
        if (connectivity.contains(ConnectivityResult.wifi)) {
          netType = "WiFi";
          signal = 90;
        } else if (connectivity.contains(ConnectivityResult.mobile)) {
          netType = "Mobile";
          signal = 70;
        } else if (connectivity.contains(ConnectivityResult.ethernet)) {
          netType = "Ethernet";
          signal = 100;
        } else {
          netType = "Offline";
          signal = 0;
        }
      } catch (e) {
        print("Connectivity error: $e");
      }

      // Approximate RAM/Storage (device_info doesn't expose these reliably)
      int totalRam = 4096;
      int usedRam = 2048;
      int totalStorage = 128;
      int freeStorage = 40;
      try {
        // Heuristic based on common Android tiers
        if (sdk >= 33) {
          totalRam = 8192;
          usedRam = 3200;
          totalStorage = 256;
          freeStorage = 80;
        } else if (sdk >= 30) {
          totalRam = 6144;
          usedRam = 2800;
          totalStorage = 128;
          freeStorage = 45;
        }
      } catch (_) {}

      if (mounted) {
        setState(() {
            deviceModel = model;
            osVersion = os;
            sdkInt = sdk;
            batteryLevel = batLevel;
            batteryState = batState;
            _networkType = netType;
            _signalStrength = signal;
            _totalRamMb = totalRam;
            _usedRamMb = usedRam;
            _totalStorageGb = totalStorage;
            _freeStorageGb = freeStorage;
          });
      }
    } catch (e) {
      print("Device stats error: $e");
    }
  }

  Color _getAccountStatusColor(String status) {
    switch (status) {
      case "ACTIVE":
      return _t.dk(const Color(0xFF34D399));
      case "WARNING":
      return _t.dk(const Color(0xFFFB923C));
      case "CRITICAL":
      return _t.dk(const Color(0xFFFF6B9D));
      case "EXPIRED":
      return _t.dk(Colors.red[700]);
      default:
      return Colors.grey;
    }
  }

  IconData _getAccountStatusIcon(String status) {
    switch (status) {
      case "ACTIVE":
      return Icons.check_circle_rounded;
      case "WARNING":
      return Icons.warning_rounded;
      case "CRITICAL":
      return Icons.error_rounded;
      case "EXPIRED":
      return Icons.cancel_rounded;
      default:
      return Icons.help_rounded;
    }
  }

  String _formatExpiredDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr);
      return "${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}";
    } catch (e) {
      return dateStr;
    }
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner":
      case "kingz":
      // Merah polos tabrakan sama palet neon — pake pink aksen tema
      return _t.isComic ? _t.accentPink : _t.dk(Colors.red);
      case "tk":
      return primaryPurple;
      case "pt":
      return _t.dk(Colors.green);
      case "reseller":
      return _t.dk(Colors.orange);
      default:
      return lightPurple;
    }
  }

  // Widget untuk membangun video background
  Widget _buildVideoBackground() {
    if (_isVideoInitialized) {
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _digitalVideoController!.value.size.width,
            height: _digitalVideoController!.value.size.height,
            child: VideoPlayer(_digitalVideoController!),
          ),
        ),
      );
    } else {
      // Tampilkan layar hitam jika video belum dimuat
      return Container(color: deepBlack);
    }
  }

  // Widget stat dengan indikator live
  Widget _buildRealTimeStatChip({
      required IconData icon,
      required String value,
      required String label,
      required Color color,
      bool isLive = false,
    }) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: color,
                border: Border.all(color: _t.line, width: _t.bw(2.5)),
                boxShadow: _t.hard(2)),
              child: Center(
                child: Icon(
                  icon,
                  color: _t.ink,
                  size: 22,
                ),
              ),
            ),
            if (isLive)
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _t.dk(const Color(0xFF00E676)),
                  border: Border.all(color: _t.line, width: _t.bw(1.5))),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: _t.ink,
            fontSize: 15,
            fontWeight: FontWeight.w900,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: _t.ink.withOpacity(0.55),
            fontSize: 10,
            fontWeight: FontWeight.w600,
          ),
          textAlign: TextAlign.center,
        ),
        if (isLive)
        Container(
          margin: EdgeInsets.only(top: 4),
          padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: _t.dk(Colors.green).withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: _t.dk(Colors.green).withOpacity(0.4),
            )),
          child: Text(
            "LIVE",
            style: TextStyle(
              color: _t.tx(Colors.green),
              fontSize: 8,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDebugPanel() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _t.dk(Colors.orange))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "DEBUG INFO",
            style: TextStyle(color: _t.tx(Colors.orange), fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            "WebSocket: ${channel?.closeCode == null ? 'CONNECTED ✅' : 'DISCONNECTED ❌'}",
            style: TextStyle(color: Colors.white),
          ),
          Text(
            "Online Users: $onlineUsers",
            style: TextStyle(color: Colors.white),
          ),
          Text(
            "Active Connections: $activeConnections",
            style: TextStyle(color: Colors.white),
          ),
          Text(
            "Notifications: ${notifications.length}",
            style: TextStyle(color: Colors.white),
          ),
          Text(
            "Has Unread: $hasUnreadNotif",
            style: TextStyle(color: Colors.white),
          ),
          SizedBox(height: 8),
          Row(
            children: [
              ElevatedButton(
                onPressed: () {
                  _fetchAdvancedStats();
                  _fetchSenders();
                  _fetchNotifications();
                },
                child: Text("Refresh Data"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _t.dk(Colors.orange),
                  foregroundColor: _t.ink,
                ),
              ),
              SizedBox(width: 8),
              ElevatedButton(
                onPressed: _reconnectWebSocket,
                child: Text("Reconnect WS"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _t.dk(Colors.blue),
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEnhancedNewsPage() {
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
            isRefreshing = true;
          });
        await _fetchSenders();
        await _fetchNotifications();
        setState(() {
            isRefreshing = false;
          });
      },
      color: bloodRed,
      backgroundColor: _t.scaffoldBg,
      child: Stack(
        children: [
          ComicBackdrop(theme: _t),
          Container(
            color: Colors.transparent,
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // ========== MAIN CONTENT ==========
                // (dulu ada SliverAppBar pinned/parallax di sini — sekarang
                // udah jadi section biasa 'app_header' di _buildAppHeaderSection()
                // biar bisa ikut di-drag & drop. Efek pinned+parallax-nya hilang,
                // tapi isinya tetep sama persis.)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        // Sections di bawah ini bisa di-drag & drop urutannya
                        // (termasuk StoryBarLoader — udah gabung jadi section 'story')
                        // (tap "ATUR LAYOUT" buat masuk mode reorder)
                        _buildDraggableSections(),
                        const SizedBox(height: 100),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLatestUpdatesSection() {
    if (newsList.isEmpty) return const SizedBox();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: _t.yellow,
            border: Border.all(color: _t.line, width: _t.bw(3)),
            boxShadow: _t.hard(3)),
          child: Text(
            "LATEST UPDATES",
            style: TextStyle(
              color: _t.ink,
              fontSize: 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 200,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              final item = newsList[index];
              if (item is! Map) return const SizedBox();
              return _buildNewsCard(Map<String, dynamic>.from(item), index);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildJadwalSholatArea() {
    final prayerInfo = _getNextPrayerInfo();
    final nextPrayerName = prayerInfo?['name'] ?? '';
    final nextPrayerTime = prayerInfo?['time'] ?? '';
    final countdown = _getTimeRemaining(nextPrayerTime);

    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: _t.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _t.hard(4)),
      child: Column(
        children: [
          // Yellow header strip
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: _t.yellow,
              border: Border(bottom: BorderSide(color: _t.line, width: _t.bw(3)))),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: _t.surface,
                    border: Border.all(color: _t.line, width: _t.bw(2))),
                  child: Icon(Icons.mosque_rounded, color: _t.ink, size: 16),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    "JADWAL SHOLAT",
                    style: TextStyle(
                      color: _t.ink,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                if (nextPrayerName.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _t.dk(const Color(0xFFFF6B9D)),
                    border: Border.all(color: _t.line, width: _t.bw(2)),
                    boxShadow: _t.hard(2)),
                  child: Text(
                    "$nextPrayerName • $countdown",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Prayer times row
          Padding(
            padding: const EdgeInsets.all(10),
            child: (_jadwalSholat == null || _jadwalSholat!.isEmpty)
            ? Padding(
              padding: EdgeInsets.all(16),
              child: Text("LOADING...",
                style: TextStyle(fontWeight: FontWeight.w900, color: _t.ink)),
            )
            : Row(
              children: [
                _buildCompactSholatItem(
                  name: "Subuh",
                  time: _jadwalSholat?['jadwal']?['subuh'] ?? '--:--',
                  color: _t.dk(const Color(0xFF2D7FFF)),
                ),
                _buildCompactSholatItem(
                  name: "Dzuhur",
                  time: _jadwalSholat?['jadwal']?['dzuhur'] ?? '--:--',
                  color: _t.dk(const Color(0xFFFF6B00)),
                ),
                _buildCompactSholatItem(
                  name: "Ashar",
                  time: _jadwalSholat?['jadwal']?['ashar'] ?? '--:--',
                  color: _t.yellow,
                ),
                _buildCompactSholatItem(
                  name: "Maghrib",
                  time: _jadwalSholat?['jadwal']?['maghrib'] ?? '--:--',
                  color: _t.dk(const Color(0xFFFF2D95)),
                ),
                _buildCompactSholatItem(
                  name: "Isya",
                  time: _jadwalSholat?['jadwal']?['isya'] ?? '--:--',
                  color: _t.dk(const Color(0xFF5B8DEF)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactSholatItem({
      required String name,
      required String time,
      required Color color,
    }) {
    bool isActive = false;
    try {
      final now = DateTime.now();
      final parts = time.split(':');
      if (parts.length == 2) {
        final hour = int.tryParse(parts[0]) ?? 0;
        final minute = int.tryParse(parts[1]) ?? 0;
        final prayerTime = DateTime(now.year, now.month, now.day, hour, minute);
        final diff = now.difference(prayerTime).inMinutes;
        isActive = diff >= 0 && diff <= 5;
      }
    } catch (_) {}

    final prayerInfo = _getNextPrayerInfo();
    final isNext = prayerInfo != null &&
    prayerInfo['name']?.toLowerCase() == name.toLowerCase();
    final highlight = isActive || isNext;

    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 2),
        decoration: BoxDecoration(
          color: highlight ? color : (_t.isComic ? _t.surface : Colors.white),
          border: Border.all(color: _t.line, width: _t.bw(2.5)),
          boxShadow: _t.hard(2)),
        child: Column(
          children: [
            Text(
              name.toUpperCase(),
              style: TextStyle(
                color: (highlight && !_t.isComic) ? Colors.black : _t.ink,
                fontSize: 9,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              time,
              style: TextStyle(
                color: (highlight && !_t.isComic) ? Colors.black : _t.ink,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
            if (isActive)
            Padding(
              padding: EdgeInsets.only(top: 3),
              child: Text("NOW",
                style: TextStyle(
                  color: _t.ink, fontSize: 8, fontWeight: FontWeight.w900)),
            )
            else if (isNext)
            Padding(
              padding: EdgeInsets.only(top: 3),
              child: Text("NEXT",
                style: TextStyle(
                  color: _t.ink, fontSize: 8, fontWeight: FontWeight.w900)),
            ),
          ],
        ),
      ),
    );
  }

  String _getCurrentDateFormatted() {
    final now = DateTime.now();
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return '${now.day} ${months[now.month - 1]} ${now.year}';
  }

  Map<String, String>? _getNextPrayerInfo() {
    if (_jadwalSholat == null || _jadwalSholat!.isEmpty) return null;

    final now = DateTime.now();
    final currentMinutes = now.hour * 60 + now.minute;

    final jadwal = _jadwalSholat!['jadwal'] ?? {};

    final prayers = [
      {'name': 'Subuh', 'time': jadwal['subuh'] ?? ''},
      {'name': 'Dzuhur', 'time': jadwal['dzuhur'] ?? ''},
      {'name': 'Ashar', 'time': jadwal['ashar'] ?? ''},
      {'name': 'Maghrib', 'time': jadwal['maghrib'] ?? ''},
      {'name': 'Isya', 'time': jadwal['isya'] ?? ''},
    ];

    for (var prayer in prayers) {
      if (prayer['time']!.isEmpty) continue;
      try {
        final parts = prayer['time']!.split(':');
        final minutes = int.tryParse(parts[0])! * 60 + int.tryParse(parts[1])!;
        if (minutes > currentMinutes) {
          return {'name': prayer['name']!, 'time': prayer['time']!};
        }
      } catch (_) {}
    }

    return {'name': 'Subuh', 'time': jadwal['subuh'] ?? '04:32'};
  }

  String _getTimeRemaining(String targetTime) {
    if (targetTime.isEmpty) return '--:--';

    try {
      final now = DateTime.now();
      final targetParts = targetTime.split(':');
      final targetMinutes = int.tryParse(targetParts[0])! * 60 + int.tryParse(targetParts[1])!;
      final currentMinutes = now.hour * 60 + now.minute;

      int diff = targetMinutes - currentMinutes;
      if (diff < 0) diff += 24 * 60;

      final hours = diff ~/ 60;
      final minutes = diff % 60;

      if (hours > 0) {
        return '${hours}j ${minutes}m';
      } else {
        return '${minutes}m';
      }
    } catch (_) {
      return '--:--';
    }
  }

  // ============ UNIFIED STATS CARD ============

  Widget _neoHeaderChip(IconData icon, String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _t.surface,
        border: Border.all(color: _t.line, width: _t.bw(2.5)),
        boxShadow: _t.hard(3)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _t.ink, size: 18),
          const SizedBox(height: 4),
          Text(value,
            style: TextStyle(
              color: _t.ink, fontSize: 13, fontWeight: FontWeight.w900)),
          Text(label,
            style: TextStyle(
              color: _t.inkSub, fontSize: 9, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  // ========== QUICK ACTIONS (struktur sama, style neo-brutal) ==========
  Widget _buildQuickActionsSection() {
    final actions = [
      _ModernActionCard(
        title: "Manage Bug Sender",
        subtitle: "Pairing & Configuration",
        icon: Icons.bug_report_rounded,
        iconColor: Colors.white,
        gradient: LinearGradient(
          colors: [_t.dk(Color(0xFF9C27B0)), _t.dk(Color(0xFFE91E63)), _t.dk(Color(0xFFFF5252))],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
        index: 0,
      ),
      _ModernActionCard(
        title: "Chat Room",
        subtitle: "Global Communication",
        icon: Icons.chat_bubble_rounded,
        iconColor: Colors.white,
        gradient: LinearGradient(
          colors: [_t.dk(Color(0xFF2D7FFF)), _t.dk(Color(0xFF5B8DEF))],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChatPage(
                sessionKey: sessionKey,
                username: username,
                androidId: androidId,
                role: role,
              ),
            ),
          );
        },
        index: 1,
      ),
      _ModernActionCard(
        title: "Telegram Report",
        subtitle: "OTAX Report System",
        icon: FontAwesomeIcons.telegram,
        iconColor: Colors.white,
        gradient: LinearGradient(
          colors: [_t.dk(Color(0xFF0088CC)), _t.dk(Color(0xFF2D7FFF))],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MultiProvider(
                providers: [
                  ChangeNotifierProvider<SessionProvider>(
                    create: (_) {
                      final provider = SessionProvider();
                      provider.initialize();
                      return provider;
                    },
                  ),
                ],
                child: const DashboardPageTelegram(),
              ),
            ),
          );
        },
        index: 2,
      ),
      _ModernActionCard(
        title: "TES FUNC",
        subtitle: "Test Function & Message",
        icon: Icons.code_rounded,
        iconColor: Colors.white,
        gradient: LinearGradient(
          colors: [_t.dk(Color(0xFFFF6B00)), _t.yellow],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TesFuncPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
        index: 3,
      ),
      _ModernActionCard(
        title: "Al-QURAN",
        subtitle: "Alquran Lengkap Beserta Terjemahan",
        icon: Icons.menu_book_rounded,
        iconColor: Colors.white,
        gradient: LinearGradient(
          colors: [_t.dk(Color(0xFF00E676)), _t.dk(Color(0xFF00C853))],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AlQuranPage()),
          );
        },
        index: 4,
      ),
      _ModernActionCard(
        title: "Pasar Online",
        subtitle: "JasaPost Marketplace",
        icon: Icons.storefront_rounded,
        iconColor: Colors.white,
        gradient: LinearGradient(
          colors: [_t.dk(Color(0xFFFF6B9D)), _t.dk(Color(0xFFCC0000))],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PasarOnlinePage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
        index: 5,
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Row(
          children: [
            Builder(builder: (context) {
                final t = ThemeController.instance.theme;
                return Container(
                  padding: const EdgeInsets.all(8),
                  decoration: t.isComic
                  ? t.iconButton(t.accentGold)
                  : BoxDecoration(
                    color: _t.yellow,
                    border: Border.all(color: _t.line, width: _t.bw(2.5)),
                    boxShadow: _t.hard(2)),
                  child: Icon(Icons.bolt_rounded,
                    color: _t.ink, size: 20),
                );
              }),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "QUICK ACTIONS",
                    style: TextStyle(
                      color: ThemeController.instance.theme.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                    ),
                  ),
                  Text(
                    "Beberapa Menu Tambahan",
                    style: TextStyle(
                      color: _t.inkSub,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 30),
        _StackedActionDeck(cards: actions),
      ],
    );
  }

  // ========== WELCOME CARD (NEO BRUTAL - struktur sama, style diganti) ==========
  Widget _buildWelcomeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _t.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _t.hard(5)),
      child: Column(
        children: [
          Row(
            children: [
              // Avatar
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: bloodRed,
                  border: Border.all(color: _t.line, width: _t.bw(3)),
                  boxShadow: _t.hard(3)),
                child: const Icon(Icons.verified_user, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Welcome To OTAX",
                      style: TextStyle(
                        color: _t.inkSub,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          username,
                          style: TextStyle(
                            color: _t.ink,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Icon(Icons.verified, color: _t.tx(Color(0xFFFFE566)), size: 20),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getRoleColor(role),
                        border: Border.all(color: _t.line, width: _t.bw(2)),
                        boxShadow: _t.hard(2)),
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Timer badge
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _t.yellow,
                  border: Border.all(color: _t.line, width: _t.bw(2.5)),
                  boxShadow: _t.hard(2)),
                child: Icon(Icons.timer, color: _t.ink, size: 22),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Social links
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                  FaIcon(FontAwesomeIcons.tiktok, color: _t.ink, size: 14),
                  const SizedBox(width: 6),
                  Text("Tiktok: @sayroaja",
                    style: TextStyle(color: _t.ink, fontSize: 11, fontWeight: FontWeight.w600)),
                ]),
              Row(children: [
                  Icon(Icons.telegram, color: _t.tx(Color(0xFF2D7FFF)), size: 16),
                  const SizedBox(width: 6),
                  Text("Telegram: @S4YRO0FC",
                    style: TextStyle(color: _t.ink, fontSize: 11, fontWeight: FontWeight.w600)),
                ]),
            ],
          ),
          const SizedBox(height: 14),
          Container(height: 2, color: _t.line),
          const SizedBox(height: 14),
          // Stats row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildRealTimeStatChip(
                icon: Icons.people,
                value: '$onlineUsers',
                label: "Online Users",
                color: bloodRed,
                isLive: onlineUsers > 0,
              ),
              _buildRealTimeStatChip(
                icon: Icons.link,
                value: '$activeConnections',
                label: "Active Connections",
                color: _t.yellow,
                isLive: activeConnections > 0,
              ),
              _buildStatChip(
                icon: Icons.calendar_today,
                value: expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                label: "Expiration",
                color: Colors.black,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUnifiedStatsCard() {
    final statusColor = _getAccountStatusColor(_accountStatus);
    final statusIcon = _getAccountStatusIcon(_accountStatus);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _t.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _t.hard(4)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Remaining time
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "SISA WAKTU",
                style: TextStyle(
                  color: _t.ink,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                "$_accountDaysLeft HARI",
                style: TextStyle(
                  color: statusColor,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            height: 10,
            decoration: BoxDecoration(
              color: const Color(0xFFE0E0E0),
              border: Border.all(color: _t.line, width: _t.bw(2))),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: _accountProgress.clamp(0.0, 1.0),
              child: Container(color: statusColor),
            ),
          ),
          const SizedBox(height: 14),

          // Stats grid - row 1
          Row(
            children: [
              Expanded(child: _neoBox(Icons.devices_rounded, "DEVICE",
                  deviceModel.length > 12 ? "${deviceModel.substring(0, 12)}.." : deviceModel,
                  _t.dk(const Color(0xFF9C27B0)))),
              const SizedBox(width: 8),
              Expanded(child: _neoBox(Icons.battery_full_rounded, "BATTERY",
                  "$batteryLevel%", batteryLevel > 20 ? _t.dk(const Color(0xFF00E676)) : bloodRed)),
              const SizedBox(width: 8),
              Expanded(child: _neoBox(Icons.wifi_rounded, "NET",
                  _networkType, _t.dk(const Color(0xFF2D7FFF)))),
            ],
          ),
          const SizedBox(height: 8),
          // Stats grid - row 2
          Row(
            children: [
              Expanded(child: _neoBox(Icons.memory_rounded, "RAM",
                  "${(_usedRamMb / 1024).toStringAsFixed(1)}G", _t.dk(const Color(0xFFFF2D95)))),
              const SizedBox(width: 8),
              Expanded(child: _neoBox(Icons.storage_rounded, "STORAGE",
                  "${_freeStorageGb}G free", _t.dk(const Color(0xFF5B8DEF)))),
              const SizedBox(width: 8),
              Expanded(child: _neoBox(Icons.link, "CONN",
                  "$activeConnections", _t.dk(const Color(0xFFFF6B00)))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _neoBox(IconData icon, String label, String value, Color bg) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
      decoration: BoxDecoration(
        color: bg,
        border: Border.all(color: _t.line, width: _t.bw(2.5)),
        boxShadow: _t.hard(3)),
      child: Column(
        children: [
          Icon(icon, color: _t.ink, size: 18),
          const SizedBox(height: 4),
          Text(label,
            style: TextStyle(
              color: _t.ink, fontSize: 9, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(value,
            style: TextStyle(
              color: _t.ink, fontSize: 11, fontWeight: FontWeight.w900),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _unifiedStatChip({
      required IconData icon,
      required String label,
      required String value,
      required Color color,
      bool showProgress = false,
      double progressValue = 0.0,
      Color? progressColor,
    }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 10),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: accentGrey.withOpacity(0.65),
                fontSize: 6,
                fontFamily: 'Orbitron',
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: TextStyle(
            color: primaryWhite.withOpacity(0.95),
            fontSize: 8,
            fontWeight: FontWeight.w600,
            fontFamily: 'Orbitron',
          ),
          overflow: TextOverflow.ellipsis,
        ),
        if (showProgress) ...[
          SizedBox(height: 4),
          ClipRRect(
            borderRadius: _t.rr(2),
            child: LinearProgressIndicator(
              value: progressValue.clamp(0.0, 1.0),
              minHeight: 2.5,
              backgroundColor: deepBlack.withOpacity(0.6),
              valueColor: AlwaysStoppedAnimation<Color>(progressColor ?? color),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildBanner() {
    final t = _t;
    // Classic: border hitam tebal + hard shadow kuning-hitam (neo-brutal)
    // Comic : sudut membulat + glow neon teal (ikut _t.card / _t.hard)
    final borderColor = t.isComic ? t.accentTeal : Colors.black;
    final badgeColor = t.isComic ? t.accentGold : const Color(0xFFFFD600);
    final badgeInk = t.isComic ? t.ink : Colors.black;
    final titleColor = t.isComic ? t.accentTeal : Colors.black;

    return Container(
      height: 160,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: t.rr(20),
        border: Border.all(color: borderColor, width: t.bw(2.5)),
        boxShadow: t.hard(t.isComic ? 4 : 5),
      ),
      child: ClipRRect(
        borderRadius: t.rr(17.5),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // GAMBAR ASLI
            Image.asset(
              'assets/images/otak_banner.jpg',
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                // fallback kalau asset belum ada
                return Container(
                  decoration: BoxDecoration(
                    gradient: t.isComic
                        ? LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              t.scaffoldBg,
                              Color.alphaBlend(
                                  t.accentTeal.withOpacity(0.18), t.surface),
                              Color.alphaBlend(
                                  t.accentPurple.withOpacity(0.16), t.surface),
                            ],
                          )
                        : const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFFFFE566),
                              Color(0xFFFFC93C),
                            ],
                          ),
                  ),
                );
              },
            ),

            // LIVE badge
            Positioned(
              top: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: badgeColor,
                  borderRadius: t.rr(20),
                  border: t.isComic
                      ? null
                      : Border.all(color: Colors.black, width: 2),
                  boxShadow: t.isComic
                      ? [
                          BoxShadow(
                            color: badgeColor.withOpacity(0.45),
                            blurRadius: 8,
                          ),
                        ]
                      : t.hard(2),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.circle, color: badgeInk, size: 8),
                    const SizedBox(width: 5),
                    Text(
                      'LIVE',
                      style: TextStyle(
                        color: badgeInk,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Lightning button
            Positioned(
              top: 10,
              right: 12,
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: badgeColor,
                  borderRadius: t.rr(10),
                  border: t.isComic
                      ? null
                      : Border.all(color: Colors.black, width: 2),
                  boxShadow: t.isComic
                      ? [
                          BoxShadow(
                            color: badgeColor.withOpacity(0.45),
                            blurRadius: 10,
                          ),
                        ]
                      : t.hard(2),
                ),
                child: Icon(Icons.bolt, color: badgeInk, size: 22),
              ),
            ),

            // Text OTAX X ONE
            Positioned(
              left: 16,
              bottom: 14,
              child: Text(
                '• OTAX X ONE',
                style: TextStyle(
                  color: titleColor,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                  shadows: t.isComic
                      ? [
                          Shadow(color: t.accentTeal, blurRadius: 12),
                          const Shadow(
                              color: Colors.black54,
                              blurRadius: 4,
                              offset: Offset(0, 2)),
                        ]
                      : const [
                          Shadow(
                              color: Colors.white,
                              blurRadius: 0,
                              offset: Offset(1.5, 1.5)),
                        ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHadithQuoteCard() {
    final hadith = _currentHadith;
    final arabic = hadith?['arab'] ?? '';
    final translation = hadith?['id'] ?? '';
    final number = hadith?['number'] ?? '';

    // Ambil teks hadis saja (tanpa sanad panjang)
    String getShortHadith(String arabicText) {
      // Cari kata 'قَالَ' yang menandakan awal hadis
      final parts = arabicText.split('قَالَ');
      if (parts.length > 1) {
        for (var part in parts) {
          if (part.contains('رَسُولُ اللَّهِ') || part.contains('النَّبِيُّ')) {
            final hadithText = 'قَالَ$part'.trim();
            // Ambil maksimal 100 karakter
            return hadithText.length > 100
            ? '${hadithText.substring(0, 100)}...'
            : hadithText;
          }
        }
        // Ambil bagian terakhir jika tidak menemukan pola
        final lastPart = parts.last;
        return lastPart.length > 100
        ? '${lastPart.substring(0, 100)}...'
        : lastPart;
      }
      // Jika tidak ditemukan, ambil 100 karakter pertama
      return arabicText.length > 100
      ? '${arabicText.substring(0, 100)}...'
      : arabicText;
    }

    String getShortTranslation(String translationText) {
      // Cari terjemah yang sebenarnya (biasanya setelah 'Rasulullah ﷺ bersabda:')
      if (translationText.contains('Rasulullah ﷺ bersabda:')) {
        final index = translationText.indexOf('Rasulullah ﷺ bersabda:');
        return translationText.substring(index);
      }

      // Cari baris yang berisi terjemah (biasanya diawali dengan tanda —)
      final lines = translationText.split('\n');
      for (var line in lines) {
        line = line.trim();
        if (line.startsWith('—') ||
          line.contains('bersabda') ||
          line.contains('Rasulullah')) {
          return line.length > 120 ? '${line.substring(0, 120)}...' : line;
        }
      }

      // Jika tidak ditemukan, ambil 120 karakter pertama
      return translationText.length > 120
      ? '${translationText.substring(0, 120)}...'
      : translationText;
    }

    final shortArabic = getShortHadith(arabic);
    final shortTranslation = getShortTranslation(translation);

    // Loading state dengan pesan motivasi
    if (_isLoadingHadith || shortArabic.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _t.surface,
          borderRadius: _t.rr(4),
          border: Border.all(color: _t.line, width: _t.bw(3)),
          boxShadow: _t.hard(4)),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [_t.dk(Color(0xFFFF6B9D)), _t.yellow],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.4),
                        blurRadius: 10,
                      ),
                    ]),
                  child: Center(
                    child: Icon(
                      Icons.book,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "HADITH OF THE DAY",
                        style: TextStyle(
                          color: _t.ink,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        "Sahih Muslim • Loading...",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Motivasi Message dengan animasi
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.2),
                )),
              child: Column(
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    color: Color(0xFFFFFFFF),
                    size: 32,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    "Sempatkan Waktumu",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Untuk Membaca 1 Hadist",
                    style: TextStyle(
                      color: Color(0xFFFFFFFF),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 4,
                    child: LinearProgressIndicator(
                      backgroundColor: Colors.black.withOpacity(0.3),
                      color: _t.dk(Color(0xFFFF6B9D)),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // Hadis sudah loaded, tampilkan hadis
    return GestureDetector(
      onTap: () {
        _showFullHadithPage();
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _t.surface,
          borderRadius: _t.rr(4),
          border: Border.all(color: _t.line, width: _t.bw(3)),
          boxShadow: _t.hard(4)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header dengan judul hadis
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [_t.dk(Color(0xFFFF6B9D)), _t.yellow],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.4),
                        blurRadius: 10,
                      ),
                    ]),
                  child: Center(
                    child: Icon(
                      Icons.book,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "HADITH OF THE DAY",
                        style: TextStyle(
                          color: _t.ink,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        "Sahih Muslim • Tap to read full",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Arabic Hadith Text (pendek)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.1),
                )),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      shortArabic,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Uthmanic',
                        height: 1.6,
                      ),
                      textAlign: TextAlign.right,
                      textDirection: ui.TextDirection.rtl,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Short Translation
            if (shortTranslation.isNotEmpty && shortTranslation != shortArabic)
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10)),
              child: Text(
                shortTranslation,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 13,
                  fontStyle: FontStyle.italic,
                  height: 1.4,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),

            const SizedBox(height: 12),

            // Footer dengan info hadis
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.3),
                    )),
                  child: Row(
                    children: [
                      Icon(
                        Icons.library_books,
                        size: 12,
                        color: _t.tx(Color(0xFFFF6B9D)),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        "Muslim #${number}",
                        style: TextStyle(
                          color: _t.tx(Color(0xFFFF6B9D)),
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                // Indicator bahwa ini bisa di-tap
                Row(
                  children: [
                    Icon(
                      Icons.touch_app,
                      size: 14,
                      color: Colors.white.withOpacity(0.6),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "Tap for full",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showFullHadithPage() {
    final currentHadith = _currentHadith;

    if (currentHadith == null) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.9),
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF0F172A),
                Color(0xFF1E293B),
              ],
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: _t.bw(1),
            )),
          child: Column(
            children: [
              // Header dengan close button
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFF1E293B),
                  borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(25)),
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.1),
                    ),
                  )),
                child: Row(
                  children: [
                    Icon(
                      Icons.book_outlined,
                      color: _t.tx(Color(0xFFFF6B9D)),
                      size: 22,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "HADITH FULL TEXT",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            "Sahih Muslim • Hadith #${currentHadith['number']}",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.white, size: 20),
                      onPressed: () => Navigator.pop(context),
                      padding: EdgeInsets.zero,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Section: Arabic Text
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.1),
                          )),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.text_snippet,
                                  color: _t.tx(Color(0xFFFF6B9D)),
                                  size: 16,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  "ARABIC TEXT",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              currentHadith['arab'] ?? '',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontFamily: 'Uthmanic',
                                height: 1.7,
                              ),
                              textAlign: TextAlign.right,
                              textDirection: ui.TextDirection.rtl,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Section: Translation
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.1),
                          )),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.translate,
                                  color: _t.tx(Color(0xFFFF6B9D)),
                                  size: 16,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  "TRANSLATION",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              currentHadith['id'] ?? '',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.9),
                                fontSize: 14,
                                height: 1.6,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Kitab Info
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: _t.dk(Color(0xFFFF6B9D)).withOpacity(0.3),
                          )),
                        child: Row(
                          children: [
                            Icon(
                              Icons.info_outline,
                              color: _t.tx(Color(0xFFFF6B9D)),
                              size: 16,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                "Hadith ini berasal dari Sahih Muslim, salah satu kitab hadis paling shahih setelah Sahih Bukhari.",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),

              // Footer Actions - tampilkan refresh di sini saja
              Container(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                decoration: BoxDecoration(
                  color: Color(0xFF1E293B),
                  border: Border(
                    top: BorderSide(
                      color: Colors.white.withOpacity(0.1),
                    ),
                  )),
                child: Column(
                  children: [
                    // Refresh Button - lebih besar di halaman full
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          _fetchHadith();
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Mengambil hadis baru...'),
                              backgroundColor: _t.dk(Color(0xFFFF6B9D)),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        },
                        icon: Icon(Icons.refresh, size: 18),
                        label: Text("AMBIL HADIS BARU"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _t.dk(Color(0xFFFF6B9D)),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          elevation: 3,
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Close Button
                    SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          "TUTUP",
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 13,
                          ),
                        ),
                        style: TextButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatChip({
      required IconData icon,
      required String value,
      required String label,
      required Color color,
    }) {
    return Column(
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: _t.yellow,
            border: Border.all(color: _t.line, width: _t.bw(2.5)),
            boxShadow: _t.hard(2)),
          child: Center(
            child: Icon(
              icon,
              color: _t.ink,
              size: 22,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: _t.ink,
            fontSize: 12,
            fontWeight: FontWeight.w900,
          ),
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        Text(
          label,
          style: TextStyle(
            color: _t.ink.withOpacity(0.55),
            fontSize: 10,
            fontWeight: FontWeight.w600,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // News Card — Neo-Brutalism
  Widget _buildNewsCard(Map<String, dynamic> item, int index) {
    final accentColors = [
      _t.yellow,
      _t.dk(const Color(0xFFFF6B9D)),
      _t.dk(const Color(0xFF2D7FFF)),
      _t.dk(const Color(0xFF00E676)),
      _t.dk(const Color(0xFFFF6B00)),
    ];
    final accent = accentColors[index % accentColors.length];

    return Container(
      width: 260,
      margin: const EdgeInsets.only(right: 14),
      decoration: BoxDecoration(
        color: _t.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _t.hard(4)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            // Handle news tap
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 3,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (item['image'] != null)
                    Image.network(
                      item['image'].toString(),
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: accent),
                    )
                    else
                    Container(color: accent),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      height: 4,
                      child: Container(color: Colors.black),
                    ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _t.dk(const Color(0xFFFF6B9D)),
                          border: Border.all(color: _t.line, width: _t.bw(2)),
                          boxShadow: _t.hard(2)),
                        child: const Text(
                          "NEW",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        item['title']?.toString() ?? 'No Title',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _t.ink,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          height: 1.25,
                        ),
                      ),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: accent,
                              border:
                              Border.all(color: _t.line, width: _t.bw(1.5))),
                            child: Text(
                              "JUST NOW",
                              style: TextStyle(
                                color: _t.ink,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: Colors.black,
                              border: Border.all(color: _t.line, width: _t.bw(2))),
                            child: const Icon(
                              Icons.arrow_forward,
                              color: Colors.white,
                              size: 14,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Action Tile for Quick Actions
  Widget _buildActionTile({
      required String title,
      required String subtitle,
      required IconData icon,
      required Color iconColor,
      required List<Color> gradient,
      required VoidCallback onTap,
    }) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: gradient,
            ),
            boxShadow: [
              BoxShadow(
                color: gradient[0].withOpacity(0.3),
                blurRadius: 20,
                offset: Offset(0, 10),
              ),
            ]),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                    )),
                  child: Center(
                    child: Icon(
                      icon,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 11,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Spacer(),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8)),
                      child: Icon(
                        Icons.arrow_forward,
                        color: Colors.white,
                        size: 12,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatLastUpdate(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inSeconds < 60) {
      return '${difference.inSeconds}s ago';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  // Status Indicator
  Widget _buildStatusIndicator({
      required String title,
      required String status,
      required Color color,
      required int value,
    }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color,
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 8,
                  ),
                ]),
            ),
            SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            Spacer(),
            Text(
              status,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        Container(
          height: 4,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: _t.rr(2)),
          child: Row(
            children: [
              Expanded(
                flex: value,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [color, color.withOpacity(0.7)],
                    ),
                    borderRadius: _t.rr(2)),
                ),
              ),
              Expanded(
                flex: 100 - value,
                child: SizedBox(),
              ),
            ],
          ),
        ),
        SizedBox(height: 4),
        Text(
          "$value%",
          style: TextStyle(
            color: Colors.white.withOpacity(0.6),
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  // Social Button
  Widget _buildSocialButton({
      required IconData icon,
      required Color color,
      required String label,
      String? url,
      VoidCallback? onTap,
    }) {
    return GestureDetector(
      onTap: onTap ??
      () async {
        if (url != null) {
          final uri = Uri.parse(url);
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri);
          } else {
            await launchUrl(uri);
          }
        }
      },
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.1),
              border: Border.all(
                color: color.withOpacity(0.3),
                width: _t.bw(1.5),
              )),
            child: Center(
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
          ),
          SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // Widget untuk membuat Premium Card yang elegant
  Widget _buildPremiumCard({
      required String title,
      required String subtitle,
      required IconData icon,
      required Color iconColor,
      required List<Color> gradientColors,
      required VoidCallback onTap,
      required List<String> features,
    }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradientColors,
          ),
          boxShadow: [
            BoxShadow(
              color: gradientColors[0].withOpacity(0.4),
              blurRadius: 25,
              spreadRadius: 3,
              offset: const Offset(0, 8),
            ),
          ],
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: _t.bw(1.5),
          )),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            children: [
              Positioned.fill(
                child: Opacity(
                  opacity: 0.05,
                  child: Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage('assets/images/logo.jpg'),
                        repeat: ImageRepeat.repeat,
                      )),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header with Icon
                    Row(
                      children: [
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withOpacity(0.3),
                              width: _t.bw(2),
                            )),
                          child: Center(
                            child: Icon(
                              icon,
                              color: iconColor,
                              size: 32,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                title,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.0,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                subtitle,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // Features List
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: features.map((feature) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.check_circle,
                                  color: Colors.white.withOpacity(0.7),
                                  size: 16,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  feature,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.9),
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                    ),

                    const Spacer(),

                    // Tap Indicator
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.2),
                        )),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            "TAP TO OPEN",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.0,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.white,
                            size: 12,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Glow Effect
              Positioned(
                top: -50,
                right: -50,
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        Colors.white.withOpacity(0.1),
                        Colors.transparent,
                      ],
                    )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Widget untuk Mini Action Button
  Widget _buildMiniActionButton({
      required IconData icon,
      required String label,
      required Color color,
    }) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: color.withOpacity(0.4),
              width: _t.bw(1.5),
            )),
          child: Center(
            child: Icon(
              icon,
              color: color,
              size: 28,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Colors.white70,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  // Fungsi untuk membangun tombol kontak
  List<Widget> _buildContactActions() {
    return [
      _contactActionButton(
        icon: FontAwesomeIcons.telegram,
        label: "Telegram",
        url: 'https://t.me/Otapengenkawin',
        color: lightRed,
      ),
      _contactActionButton(
        icon: FontAwesomeIcons.telegram,
        label: "Channel",
        url: 'https://t.me/',
        color: lightRed,
      ),
      _contactActionButton(
        icon: FontAwesomeIcons.tiktok,
        label: "TikTok",
        url: 'https://www.tiktok.com/Otax',
        color: lightRed,
      ),
    ];
  }

  Widget _contactActionButton({
      required FaIconData icon,
      required String label,
      required String url,
      required Color color,
    }) {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri);
        } else {
          await launchUrl(uri);
        }
      },
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color.withOpacity(0.5)),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.2),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ]),
            child: FaIcon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _enhancedGlassCard({required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: glassBlack,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: bloodRed.withOpacity(0.3),
          width: _t.bw(1.5),
        ),
        boxShadow: [
          BoxShadow(
            color: bloodRed.withOpacity(0.15),
            blurRadius: 25,
            spreadRadius: 2,
          ),
        ]),
      child: child,
    );
  }

  Widget _enhancedInfoRow(IconData icon, String label, String value,
    {Color valueColor = Colors.white}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: bloodRed.withOpacity(0.2))),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: bloodRed.withOpacity(0.2),
              shape: BoxShape.circle),
            child: Icon(icon, color: bloodRed, size: 20),
          ),
          const SizedBox(width: 12),
          Text("$label: ", style: const TextStyle(color: Colors.white70)),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: valueColor,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ThemeController.instance,
      builder: (context, _) {
        final t = ThemeController.instance.theme;
        return _buildScaffold(context, t);
      },
    );
  }

  Widget _buildScaffold(BuildContext context, AppTheme t) {
    return Scaffold(
      drawer: _buildDrawer(),
      backgroundColor: t.scaffoldBg,
      extendBody: true,
      appBar: AppBar(
        backgroundColor: t.isComic ? t.surface : _t.yellow,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: t.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: t.isComic
          ? t.sticker()
          : BoxDecoration(
            color: _t.surface,
            border: Border.all(color: _t.line, width: _t.bw(3)),
            boxShadow: _t.hard(3)),
          child: Text(
            "OTAX",
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 18,
              color: _t.ink,
              letterSpacing: 2,
            ),
          ),
        ),
        actions: [
          // Ganti tema button
          Container(
            margin: const EdgeInsets.only(right: 6),
            decoration: t.iconButton(t.accentGold, classicFill: null),
            child: IconButton(
              icon: Icon(Icons.palette_rounded,
                color: _t.ink, size: 20),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ThemeSwitcherPage()),
                );
              },
            ),
          ),
          // Music button
          Container(
            margin: const EdgeInsets.only(right: 6),
            decoration: t.iconButton(t.accentTeal, classicFill: null),
            child: IconButton(
              icon: Icon(Icons.music_note,
                color: _t.ink, size: 20),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Scaffold(
                      backgroundColor: _t.scaffoldBg,
                      body: SpotifyMusicPlayer(
                        sessionKey: sessionKey,
                        username: username,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          // Notif button
          Container(
            margin: const EdgeInsets.only(right: 6),
            decoration: t.iconButton(t.accentTeal, classicFill: null),
            child: IconButton(
              icon: Stack(
                children: [
                  Icon(Icons.notifications,
                    color: _t.ink, size: 20),
                  if (hasUnreadNotif)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      width: 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: bloodRed,
                        shape: BoxShape.circle,
                        border: Border.all(color: _t.line, width: _t.bw(1))),
                    ),
                  ),
                ],
              ),
              onPressed: _openNotifications,
            ),
          ),
          // Logout button
          Container(
            margin: const EdgeInsets.only(right: 10),
            decoration: t.iconButton(t.accentPink, classicFill: bloodRed),
            child: IconButton(
              icon: Icon(Icons.logout,
                color: (t.isComic ? const Color(0xFFD9738F) : Colors.white), size: 20),
              onPressed: () async {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    backgroundColor: _t.surface,
                    shape: RoundedRectangleBorder(
                      borderRadius: _t.rr(4),
                      side: BorderSide(color: _t.line, width: _t.bw(3)),
                    ),
                    title: Text(
                      "Keluar",
                      style: TextStyle(
                        color: _t.ink,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    content: Text(
                      "Apakah Anda yakin ingin keluar?",
                      style: TextStyle(
                        color: _t.ink,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          "Batal",
                          style: TextStyle(
                            color: bloodRed,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () async {
                          Navigator.pop(context);
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.clear();
                          if (!mounted) return;
                          Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              builder: (_) => const LoginPage()),
                            (route) => false,
                          );
                        },
                        child: Text(
                          "Keluar",
                          style: TextStyle(
                            color: bloodRed,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),

      // ✅ BODY DIBUNGKUS STACK - masjid di pojok bawah
      body: Stack(
        children: [
          // Background rame: grid + blob neon + halftone (no-op di classic)
          ComicBackdrop(theme: t),

          // Konten halaman utama
          FadeTransition(opacity: _animation, child: _selectedPage),

          // Fan Menu Overlay
          if (_isFanMenuOpen || _fanStaggerController.value > 0)
          FanMenuOverlay(
            fanStaggerController: _fanStaggerController,
            onClose: _closeFanMenu,
            onContactBugTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => HomePage(
                    username: username,
                    password: password,
                    listBug: listBug,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  ),
                ),
              );
            },
            onGroupBugTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BugGroupPage(
                    sessionKey: sessionKey,
                    role: role,
                  ),
                ),
              );
            },
            onCustomBugTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CustomPayloadPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                    listBug: listBug,
                  ),
                ),
              );
            },
            onSenderBugTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BugSenderPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNav(
        currentIndex: _currentNavIndex,
        onTap: _onNavTap,
        pulseRingController: _pulseRingController,
        dashRingController: _dashRingController,
        onFanMenuTap: _toggleFanMenu,
        isFanMenuOpen: _isFanMenuOpen,
      ),
    );
  }

  Widget _buildDrawer() {
    // Neo-Brutal colors (local — shared base, aksen yellow + pink)
    final Color bloodRed = _t.dk(const Color(0xFFFF6B9D));
    final Color darkRed = _t.dk(const Color(0xFFE11D48));
    final Color deepBlack = _t.scaffoldBg;
    final Color cardDark = _t.surface;
    final Color accentGlow = _t.yellow;
    final Color textGrey = _t.isComic ? _t.textSecondary : const Color(0xFF333333);

    return Drawer(
      width: MediaQuery.of(context).size.width * 0.9,
      backgroundColor: _t.scaffoldBg,
      child: Stack(
        children: [
          ComicBackdrop(theme: _t),
          Column(
            children: [
              // ===== HEADER =====
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    height: 230,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: _t.yellow,
                      border: Border(
                        bottom: BorderSide(color: _t.line, width: _t.bw(4)),
                      ),
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(4),
                      )),
                    child: Stack(
                      children: [
                        Positioned(
                          top: -40,
                          left: -40,
                          child: Container(
                            width: 170,
                            height: 170,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [accentGlow.withOpacity(0.35), Colors.transparent],
                              )),
                          ),
                        ),
                        Positioned(
                          bottom: -30,
                          right: -30,
                          child: Container(
                            width: 140,
                            height: 140,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [bloodRed.withOpacity(0.18), Colors.transparent],
                              )),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Avatar dengan ring gradient
                  Positioned(
                    top: 22,
                    left: 17,
                    child: Container(
                      width: 88,
                      height: 88,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _t.surface,
                        border: Border.all(color: _t.line, width: _t.bw(3)),
                        boxShadow: _t.hard(4)),
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _t.surface,
                          border: Border.all(color: _t.line, width: _t.bw(2))),
                        child: const CircleAvatar(
                          radius: 40,
                          backgroundImage: AssetImage('assets/images/logo.jpg'),
                        ),
                      ),
                    ),
                  ),

                  // Nama app di samping avatar
                  Positioned(
                    top: 48,
                    left: 120,
                    child: RichText(
                      text: TextSpan(
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                          shadows: [
                            Shadow(color: Colors.black.withOpacity(0.6), blurRadius: 10, offset: const Offset(0, 2)),
                          ],
                        ),
                        children: [
                          TextSpan(text: 'OTAX', style: TextStyle(color: _t.ink)),
                          TextSpan(text: 'APP', style: TextStyle(color: bloodRed)),
                        ],
                      ),
                    ),
                  ),

                  // Card overlap — neo-brutal white card
                  Positioned(
                    left: 20,
                    right: 20,
                    bottom: -68,
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: _t.surface,
                        borderRadius: _t.rr(4),
                        border: Border.all(color: _t.line, width: _t.bw(3)),
                        boxShadow: _t.hard(5)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.username.toUpperCase(),
                                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: _t.ink, letterSpacing: 1),
                                  ),
                                  const SizedBox(height: 6),
                                  Container(
                                    width: 50,
                                    height: 4,
                                    decoration: BoxDecoration(
                                      color: bloodRed,
                                      border: Border.all(color: _t.line, width: _t.bw(1))),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: accentGlow,
                                  border: Border.all(color: _t.line, width: _t.bw(2.5)),
                                  borderRadius: _t.rr(4),
                                  boxShadow: _t.hard(2)),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.black),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      widget.role.toUpperCase(),
                                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: _t.ink),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                            decoration: BoxDecoration(
                              color: _t.surfaceAlt,
                              border: Border.all(color: _t.line, width: _t.bw(2.5)),
                              borderRadius: _t.rr(4),
                              boxShadow: _t.hard(3)),
                            child: Row(
                              children: [
                                Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(
                                    color: bloodRed,
                                    border: Border.all(color: _t.line, width: _t.bw(2)),
                                    boxShadow: _t.hard(2)),
                                  child: const Icon(Icons.access_time_rounded, color: Colors.white, size: 18),
                                ),
                                const SizedBox(width: 12),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'ACCESS UNTIL',
                                      style: TextStyle(fontSize: 10.5, color: textGrey, fontWeight: FontWeight.w800, letterSpacing: 0.6),
                                    ),
                                    Text(
                                      widget.expiredDate,
                                      style: TextStyle(fontSize: 14.5, color: _t.ink, fontWeight: FontWeight.w900),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 100), // jarak biar card gak ketiban menu

              // ===== MENU LIST =====
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 4, bottom: 12, top: 10),
                      child: Text(
                        'MENU UTAMA',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: textGrey, letterSpacing: 1),
                      ),
                    ),
                    if (widget.role == "KINGZ" || widget.role == "OWNER")
                    _buildMenuItem(
                      icon: Icons.admin_panel_settings,
                      title: 'Admin Page',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        _navigateToAdminPage();
                      },
                    ),
                    if (widget.role == "KINGZ" || widget.role == "OWNER" || widget.role == "TK" )
                    _buildMenuItem(
                      icon: Icons.receipt,
                      title: 'Approve Stor',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AdminReviewPage(),
                          ),
                        );
                      },
                    ),
                    if (widget.role == "OWNER" || widget.role == "RESELLER" || widget.role == "KINGZ" || widget.role == "TK" || widget.role == "PT" )
                    _buildMenuItem(
                      icon: Icons.article,
                      title: 'Akses Jualan',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => StoranHubPage(
                              sessionKey: widget.sessionKey,
                              username: widget.username,
                              role: widget.role,
                            ),
                          ),
                        );
                      },
                    ),
                    if (widget.role == "KINGZ")
                    _buildMenuItem(
                      icon: Icons.notifications_active,
                      title: 'Kirim Notifikasi',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SendNotificationPage(
                              sessionKey: widget.sessionKey,
                              username: widget.username,
                            ),
                          ),
                        );
                      },
                    ),
                    if (widget.role == "KINGZ")
                    _buildMenuItem(
                      icon: Icons.request_quote,
                      title: 'Undang User',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const UndanganPage(),
                          ),
                        );
                      },
                    ),
                    if (widget.role == "KINGZ")
                    _buildMenuItem(
                      icon: Icons.bug_report,
                      title: 'Laporan Error',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BugReportAdminPage(
                              sessionKey: widget.sessionKey,
                              username: widget.username,
                            ),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      icon: Icons.bug_report_outlined,
                      title: 'Lapor Bug/Error',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BugReportPage(
                              sessionKey: widget.sessionKey,
                            ),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      icon: Icons.bug_report_outlined,
                      title: 'Up Role',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => UpRolePage(sessionKey: widget.sessionKey),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      icon: Icons.bug_report_outlined,
                      title: 'Ambil Link Gb',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AmbilLinkPage(sessionKey: widget.sessionKey),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      icon: Icons.lock_reset,
                      title: 'Change Password',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChangePasswordPage(
                              username: widget.username,
                              sessionKey: widget.sessionKey,
                            ),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      icon: Icons.fingerprint,
                      title: 'NIK Check',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => NikCheckerPage()),
                        );
                      },
                    ),
                    _buildMenuItem(
                      icon: Icons.system_update_alt,
                      title: 'Update App',
                      cardDark: cardDark,
                      accentGlow: accentGlow,
                      darkRed: darkRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => UpdateModulePage(
                              sessionKey: widget.sessionKey,
                              username: widget.username,
                              role: widget.role,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Helper menu item — neo-brutal style
  Widget _buildMenuItem({
      required IconData icon,
      required String title,
      required Color cardDark,
      required Color accentGlow,
      required Color darkRed,
      required VoidCallback onTap,
    }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      child: Material(
        color: Colors.transparent,
        borderRadius: _t.rr(4),
        child: InkWell(
          onTap: onTap,
          borderRadius: _t.rr(4),
          splashColor: accentGlow.withOpacity(0.2),
          highlightColor: darkRed.withOpacity(0.1),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _t.surface,
              borderRadius: _t.rr(4),
              border: Border.all(color: _t.line, width: _t.bw(3)),
              boxShadow: _t.hard(4)),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: darkRed,
                    border: Border.all(color: _t.line, width: _t.bw(2.5)),
                    boxShadow: _t.hard(2)),
                  child: Icon(
                    icon,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      color: _t.ink,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: accentGlow,
                    border: Border.all(color: _t.line, width: _t.bw(2))),
                  child: Icon(
                    Icons.arrow_forward_ios,
                    color: _t.ink,
                    size: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: glassBlack,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
            border: Border.all(color: bloodRed.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: bloodRed.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ]),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: bloodRed.withOpacity(0.5),
                    borderRadius: _t.rr(2)),
                ),
                const SizedBox(height: 24),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [bloodRed, lightRed],
                  ).createShader(bounds),
                  child: const Text(
                    "Account Info",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                  ),
                ),
                const SizedBox(height: 24),
                _enhancedInfoRow(Icons.person, "Username", username),
                _enhancedInfoRow(Icons.shield, "Role", role),
                _enhancedInfoRow(Icons.calendar_today, "Expired", expiredDate),
                const SizedBox(height: 32),
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [bloodRed, darkRed],
                    ),
                    borderRadius: BorderRadius.circular(16)),
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                    icon: const Icon(Icons.logout),
                    label: const Text("Logout"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                      minimumSize: const Size(double.infinity, 50),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    ThemeController.instance.removeListener(_onThemeChanged);
    // Cancel semua timer dengan aman
    try {
      _timeTimer?.cancel();
      _hadithTimer?.cancel();
      _fetchTimer?.cancel();
      _healthCheckTimer?.cancel();
      _sholatTimer?.cancel();
      _realTimeClockTimer?.cancel();
    } catch (e) {
      print("⚠️ Error cancelling timers: $e");
    }
    try {
      if (channel != null) {
        channel.sink.close(1000, 'App disposed');
      }
    } catch (e) {
      print("⚠️ Error closing WebSocket: $e");
    }
    _controller?.dispose();
    ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
    _pulseRingController.dispose();
    _dashRingController.dispose();
    _fanMenuController.dispose();
    _fanStaggerController.dispose();
    _digitalVideoController?.dispose();
    _headerPageController.dispose();
    _newsWeatherController.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
  url.endsWith(".mp4") ||
  url.endsWith(".webm") ||
  url.endsWith(".mov") ||
  url.endsWith(".mkv");

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return Center(child: CircularProgressIndicator(color: _t.dk(Colors.red)));
      }
    } else {
      return Image.network(widget.url, fit: BoxFit.cover);
    }
  }
}

// ════════════════════════════════════════════════
// 🃏 STACKED ACTION CARD — Neo-Brutalism
// ════════════════════════════════════════════════
class _ModernActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final dynamic icon;
  final Color iconColor;
  final Gradient gradient;
  final VoidCallback onTap;
  final int index;

  const _ModernActionCard({
      required this.title,
      required this.subtitle,
      required this.icon,
      required this.iconColor,
      required this.gradient,
      required this.onTap,
      required this.index,
    });

  Color get _solidColor {
    if (gradient is LinearGradient) {
      final colors = (gradient as LinearGradient).colors;
      if (colors.isNotEmpty) return colors.first;
    }
    return _t.yellow;
  }

  @override
  Widget build(BuildContext context) {
    final bg = _solidColor;
    final isLight = bg.computeLuminance() > 0.55;
    final fg = isLight ? Colors.black : Colors.white;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3.5)),
        boxShadow: _t.hard(6)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: _t.surface,
                    border: Border.all(color: _t.line, width: _t.bw(2.5)),
                    boxShadow: _t.hard(3)),
                  child: icon is IconData
                      ? Icon(icon, color: _t.ink, size: 26)
                      : FaIcon(icon as FaIconData, color: _t.ink, size: 26),
                ),
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    border: Border.all(color: _t.line, width: _t.bw(2))),
                  child: const Text(
                    "TAP →",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.toUpperCase(),
                  style: TextStyle(
                    color: fg,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.6,
                    height: 1.15,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Container(
                  height: 3,
                  width: 48,
                  color: isLight ? Colors.black : Colors.white,
                ),
                const SizedBox(height: 8),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: fg.withOpacity(0.85),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════
// 🎴 STACKED DECK — swipe + auto-cycle + tap
// front card: tap = buka fitur, drag = ganti kartu
// belakang: peek layers (offset ke atas & scale turun)
// idle beberapa detik → auto maju sendiri
// ════════════════════════════════════════════════
class _StackedActionDeck extends StatefulWidget {
  final List<_ModernActionCard> cards;
  const _StackedActionDeck({required this.cards});

  @override
  State<_StackedActionDeck> createState() => _StackedActionDeckState();
}

class _StackedActionDeckState extends State<_StackedActionDeck> {
  late List<int> _order;
  Timer? _autoTimer;
  double _dragDx = 0;
  bool _dragging = false;

  @override
  void initState() {
    super.initState();
    _order = List.generate(widget.cards.length, (i) => i);
    _startAutoCycle();
  }

  void _startAutoCycle() {
    _autoTimer?.cancel();
    _autoTimer = Timer.periodic(Duration(seconds: 4), (_) {
        if (!_dragging) _advance();
      });
  }

  void _advance() {
    if (!mounted || _order.length < 2) return;
    setState(() {
        final front = _order.removeAt(0);
        _order.add(front);
      });
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visibleCount = math.min(3, _order.length);
    final frontIndex = _order[0];
    final frontCard = widget.cards[frontIndex];

    return SizedBox(
      height: 240,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanStart: (_) {
          _dragging = true;
          _autoTimer?.cancel();
        },
        onPanUpdate: (details) {
          setState(() => _dragDx += details.delta.dx);
        },
        onPanEnd: (details) {
          _dragging = false;
          final flung = details.velocity.pixelsPerSecond.dx.abs() > 300;
          if (_dragDx.abs() > 70 || flung) {
            _advance();
          }
          setState(() => _dragDx = 0);
          _startAutoCycle();
        },
        onTap: () {
          if (_dragDx.abs() < 4) frontCard.onTap();
        },
        child: Stack(
          alignment: Alignment.topCenter,
          clipBehavior: Clip.none,
          children: List.generate(visibleCount, (depthFromTop) {
              final depth = visibleCount - 1 - depthFromTop; // render belakang dulu
              final cardIndex = _order[depth];
              final card = widget.cards[cardIndex];
              final isFront = depth == 0;

              final targetOffsetY = depth * 10.0;
              final targetScale = 1 - (depth * 0.04);
              final targetOpacity = (1 - (depth * 0.22)).clamp(0.0, 1.0);
              final dragProgress = (_dragDx.abs() / 200).clamp(0.0, 1.0);

              return TweenAnimationBuilder<double>(
                key: ValueKey(cardIndex),
                tween: Tween(begin: targetOffsetY, end: targetOffsetY),
                duration: Duration(milliseconds: 350),
                curve: Curves.easeOutCubic,
                builder: (context, animatedOffsetY, _) {
                  return Transform.translate(
                    offset: Offset(
                      isFront ? _dragDx : (1 - dragProgress) * 0,
                      -animatedOffsetY + (isFront ? 0 : dragProgress * 6),
                    ),
                    child: Transform.rotate(
                      angle: isFront ? (_dragDx / 900) : 0,
                      child: Transform.scale(
                        scale: isFront
                        ? targetScale
                        : (targetScale + dragProgress * 0.03)
                        .clamp(0.0, 1.0),
                        child: AnimatedOpacity(
                          opacity: targetOpacity,
                          duration: Duration(milliseconds: 250),
                          child: SizedBox(
                            height: 200,
                            width: double.infinity,
                            child: card,
                          )
                          .animate(key: ValueKey('anim_$cardIndex'))
                          .fadeIn(duration: 300.ms)
                          .scaleXY(begin: 0.94, end: 1, duration: 300.ms),
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════
// ⭐ STAR PATTERN PAINTER FOR IDUL FITRI CARD
// ════════════════════════════════════════════════
class _BuntingGarlandPainter extends CustomPainter {
  // Menghitung titik & sudut kemiringan di sepanjang kurva bezier kuadratik
  Offset _bezierPoint(Offset p0, Offset p1, Offset p2, double t) {
    final x = (1 - t) * (1 - t) * p0.dx +
    2 * (1 - t) * t * p1.dx +
    t * t * p2.dx;
    final y = (1 - t) * (1 - t) * p0.dy +
    2 * (1 - t) * t * p1.dy +
    t * t * p2.dy;
    return Offset(x, y);
  }

  double _bezierAngle(Offset p0, Offset p1, Offset p2, double t) {
    final dx = 2 * (1 - t) * (p1.dx - p0.dx) + 2 * t * (p2.dx - p1.dx);
    final dy = 2 * (1 - t) * (p1.dy - p0.dy) + 2 * t * (p2.dy - p1.dy);
    return math.atan2(dy, dx);
  }

  void _drawStrand(
    Canvas canvas,
    Size size, {
      required double baseY,
      required double sagDepth,
      required int swagCount,
      required double stringOpacity,
      required double flagOpacity,
      required double flagWidth,
      required double flagHeight,
      required double phase,
    }) {
    final stringPaint = Paint()
    ..color = Colors.white.withOpacity(stringOpacity)
    ..strokeWidth = 1.2
    ..style = PaintingStyle.stroke;

    // titik jangkar sepanjang lebar layar
    final anchorCount = swagCount + 1;
    final anchors = List.generate(anchorCount, (i) {
        final x = size.width * i / swagCount;
        // jangkar ganjil sedikit lebih tinggi biar gak monoton lurus
        final y = baseY + (i.isOdd ? -3.0 : 3.0);
        return Offset(x, y);
      });

    final path = Path()..moveTo(anchors[0].dx, anchors[0].dy);
    final controls = <List<Offset>>[];
    for (int i = 0; i < swagCount; i++) {
      final p0 = anchors[i];
      final p2 = anchors[i + 1];
      final midX = (p0.dx + p2.dx) / 2;
      final dip = sagDepth * (i.isEven ? 1.0 : 0.8);
      final p1 = Offset(midX, math.max(p0.dy, p2.dy) + dip);
      path.quadraticBezierTo(p1.dx, p1.dy, p2.dx, p2.dy);
      controls.add([p0, p1, p2]);
    }
    canvas.drawPath(path, stringPaint);

    // sebar bendera di sepanjang tiap lengkungan, ngikutin sudut tali
    final flagsPerSwag = 3;
    int flagIndex = phase.round();
    for (final ctrl in controls) {
      final p0 = ctrl[0], p1 = ctrl[1], p2 = ctrl[2];
      for (int f = 1; f <= flagsPerSwag; f++) {
        final t = f / (flagsPerSwag + 1);
        final hang = _bezierPoint(p0, p1, p2, t);
        final angle = _bezierAngle(p0, p1, p2, t);

        final isRed = flagIndex.isEven;
        flagIndex++;

        canvas.save();
        canvas.translate(hang.dx, hang.dy);
        canvas.rotate(angle); // bendera nempel & miring ngikutin tali

        final flagPaint = Paint()
        ..color = (isRed ? _t.dk(const Color(0xFFFF6B9D)) : Colors.white)
        .withOpacity(flagOpacity)
        ..style = PaintingStyle.fill;

        final flagPath = Path();
        flagPath.moveTo(-flagWidth / 2, 0);
        flagPath.lineTo(flagWidth / 2, 0);
        flagPath.lineTo(0, flagHeight);
        flagPath.close();

        canvas.drawShadow(
          flagPath, Colors.black.withOpacity(0.25), 1.2, false);
        canvas.drawPath(flagPath, flagPaint);
        if (!isRed) {
          final borderPaint = Paint()
          ..color = _t.dk(const Color(0xFFFF6B9D)).withOpacity(0.35)
          ..strokeWidth = 0.7
          ..style = PaintingStyle.stroke;
          canvas.drawPath(flagPath, borderPaint);
        }
        canvas.restore();
      }
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    // strand belakang: lebih redup, lengkungan lebih dalam, bendera lebih kecil
    _drawStrand(
      canvas,
      size,
      baseY: -2,
      sagDepth: 30,
      swagCount: 3,
      stringOpacity: 0.18,
      flagOpacity: 0.55,
      flagWidth: 16,
      flagHeight: 18,
      phase: 0,
    );
    // strand depan: lebih terang, lengkungan lebih landai, bendera lebih besar
    _drawStrand(
      canvas,
      size,
      baseY: 4,
      sagDepth: 20,
      swagCount: 4,
      stringOpacity: 0.32,
      flagOpacity: 0.95,
      flagWidth: 22,
      flagHeight: 26,
      phase: 1,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _StarPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
    ..color = _t.yellow.withOpacity(0.07)
    ..style = PaintingStyle.fill;

    final random = Random(42);
    for (int i = 0; i < 40; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      final r = random.nextDouble() * 3 + 1;
      canvas.drawCircle(Offset(x, y), r, paint);
    }

    final crescentPaint = Paint()
    ..color = _t.yellow.withOpacity(0.05)
    ..style = PaintingStyle.fill;
    canvas.drawCircle(
      Offset(size.width * 0.1, size.height * 0.1), 24, crescentPaint);
    canvas.drawCircle(
      Offset(size.width * 0.9, size.height * 0.85), 18, crescentPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
    ..color = _t.dk(Colors.red).withOpacity(0.05)
    ..strokeWidth = 0.5;

    const gridSize = 30.0;

    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

// ============ TECH GRID PAINTER ============
class _TechGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
    ..color = _t.yellow.withOpacity(0.04)
    ..strokeWidth = 0.5;

    const gridSize = 32.0;

    // Vertical lines
    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    // Horizontal lines
    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _BuntingClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path()
    ..moveTo(0, 0)
    ..lineTo(size.width, 0)
    ..lineTo(size.width / 2, size.height)
    ..close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
