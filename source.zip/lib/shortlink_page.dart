// shortlink_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'base_page.dart';

class ShortlinkPage extends StatefulWidget {
  final String sessionKey;

  const ShortlinkPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<ShortlinkPage> createState() => _ShortlinkPageState();
}

class _ShortlinkPageState extends State<ShortlinkPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  String? _shortUrl;
  String? _errorMessage;
  List<Map<String, String>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = prefs.getString('shortlink_history_user');
    if (historyJson != null) {
      final List<dynamic> decoded = jsonDecode(historyJson);
      setState(() {
        _history = decoded.map((e) => Map<String, String>.from(e)).toList();
      });
    }
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shortlink_history_user', jsonEncode(_history));
  }

  Future<void> _shortenUrl() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() => _errorMessage = "Masukkan URL yang ingin dipendekkan");
      return;
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      setState(() => _errorMessage = "URL harus dimulai dengan http:// atau https://");
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _shortUrl = null;
    });

    try {
      final apiUrl = "https://tinyurl.com/api-create.php?url=${Uri.encodeComponent(url)}";
      final response = await http.get(Uri.parse(apiUrl)).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final shortUrl = response.body.trim();
        setState(() {
          _shortUrl = shortUrl;
        });
        
        _history.insert(0, {
          'original': url,
          'short': shortUrl,
          'date': DateTime.now().toString(),
        });
        if (_history.length > 20) _history.removeLast();
        await _saveHistory();
        showCyberSnackBar(context, "Berhasil memendekkan URL!");
      } else {
        setState(() => _errorMessage = "Gagal memendekkan URL");
        showCyberSnackBar(context, "Gagal memendekkan URL", isError: true);
      }
    } catch (e) {
      setState(() => _errorMessage = "Koneksi gagal: $e");
      showCyberSnackBar(context, "Koneksi gagal", isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _copyToClipboard(String text) {
    Clipboard.setData(ClipboardData(text: text));
    showCyberSnackBar(context, "Disalin ke clipboard");
  }

  void _clearHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: AppColors.accent.withOpacity(0.3)),
        ),
        title: const Text(
          "HAPUS RIWAYAT",
          style: TextStyle(
            fontFamily: appFont,
            color: AppColors.textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: const Text(
          "Yakin ingin menghapus semua riwayat shortlink?",
          style: TextStyle(
            fontFamily: appFont,
            color: AppColors.textSec,
            fontSize: 13,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "BATAL",
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.textMuted,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _history.clear();
                _saveHistory();
              });
              Navigator.pop(context);
              showCyberSnackBar(context, "Riwayat berhasil dihapus");
            },
            child: const Text(
              "HAPUS",
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.red,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
        title: "SHORTLINK URL",
        actions: [
          if (_history.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_outline, color: AppColors.red, size: 20),
              onPressed: _clearHistory,
            ),
        ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
            CyberInputField(
              controller: _urlController,
              label: "URL PANJANG",
              hint: "https://example.com/very-long-url",
              icon: Icons.link_rounded,
              keyboardType: TextInputType.url,
              onSubmitted: (String value) { 
                _shortenUrl();
              },
            ),
          const SizedBox(height: 16),

          CyberButton(
            label: _isLoading ? "MEMPROSES..." : "SHORTLINK URL",
            icon: _isLoading ? Icons.hourglass_top : Icons.auto_awesome_rounded,
            onTap: _isLoading ? () {} : _shortenUrl,
            isLoading: _isLoading,
            width: double.infinity,
          ),
          const SizedBox(height: 16),

          if (_errorMessage != null)
            GlassCard(
              padding: const EdgeInsets.all(16),
              borderColor: AppColors.red.withOpacity(0.3),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: AppColors.red, size: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          if (_shortUrl != null)
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "HASIL SHORTLINK",
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.accent,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surface2,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.borderLight),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            _shortUrl!,
                            style: const TextStyle(
                              fontFamily: appFont,
                              color: AppColors.textPrimary,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.copy_rounded, color: AppColors.accent, size: 20),
                          onPressed: () => _copyToClipboard(_shortUrl!),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 16),

          if (_history.isNotEmpty)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "RIWAYAT",
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                ..._history.map((item) => Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item['original']!,
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textMuted,
                          fontSize: 11,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              item['short']!,
                              style: const TextStyle(
                                fontFamily: appFont,
                                color: AppColors.accent,
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.copy_rounded, color: AppColors.accent, size: 16),
                            onPressed: () => _copyToClipboard(item['short']!),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(minWidth: 32),
                          ),
                        ],
                      ),
                    ],
                  ),
                )).toList(),
              ],
            ),
        ],
      ),
    );
  }
}