// roblox_stalker_screen.dart - CYBER STYLE
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class RobloxUser {
  final int id;
  final String name;
  final String displayName;
  final String? description;
  final String? created;
  final bool isBanned;
  final bool hasVerifiedBadge;
  final int friendsCount;
  final int followersCount;
  final int followingsCount;
  final String profilePicture;

  RobloxUser({
    required this.id,
    required this.name,
    required this.displayName,
    this.description,
    this.created,
    required this.isBanned,
    required this.hasVerifiedBadge,
    required this.friendsCount,
    required this.followersCount,
    required this.followingsCount,
    required this.profilePicture,
  });

  factory RobloxUser.fromJson(Map<String, dynamic> j) => RobloxUser(
    id: j['id'] ?? 0,
    name: j['name'] ?? '',
    displayName: j['displayName'] ?? '',
    description: j['description'],
    created: j['created'],
    isBanned: j['isBanned'] ?? false,
    hasVerifiedBadge: j['hasVerifiedBadge'] ?? false,
    friendsCount: j['friendsCount'] ?? 0,
    followersCount: j['followersCount'] ?? 0,
    followingsCount: j['followingsCount'] ?? 0,
    profilePicture: j['profilePicture'] ??
        'https://www.roblox.com/headshot-thumbnail/image?userId=${j['id']}&width=150&height=150&format=png',
  );
}

class RobloxFriend {
  final int id;
  final String name;
  final String displayName;
  final String profilePicture;

  RobloxFriend({
    required this.id,
    required this.name,
    required this.displayName,
    required this.profilePicture,
  });

  factory RobloxFriend.fromJson(Map<String, dynamic> j) => RobloxFriend(
    id: j['id'] ?? 0,
    name: j['name'] ?? '',
    displayName: j['displayName'] ?? '',
    profilePicture: j['profilePicture'] ??
        'https://www.roblox.com/headshot-thumbnail/image?userId=${j['id']}&width=150&height=150&format=png',
  );
}

class RobloxResult {
  final RobloxUser user;
  final List<RobloxFriend> friends;

  RobloxResult({required this.user, required this.friends});

  factory RobloxResult.fromJson(Map<String, dynamic> j) {
    final data = j['data'] ?? j;
    final userJson = data['user'] ?? data;
    final friendsList = (data['friends'] as List<dynamic>? ?? [])
        .map((e) => RobloxFriend.fromJson(e as Map<String, dynamic>))
        .toList();
    return RobloxResult(
      user: RobloxUser.fromJson(userJson as Map<String, dynamic>),
      friends: friendsList,
    );
  }
}

class RobloxStalkerScreen extends StatefulWidget {
  const RobloxStalkerScreen({super.key});

  @override
  State<RobloxStalkerScreen> createState() => _RobloxStalkerScreenState();
}

class _RobloxStalkerScreenState extends State<RobloxStalkerScreen> {
  final TextEditingController _ctrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  RobloxResult? _result;
  bool _isLoading = false;
  String? _errorMsg;

  @override
  void dispose() {
    _ctrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final username = _ctrl.text.trim();
    if (username.isEmpty) {
      showCyberSnackBar(context, 'Masukkan username Roblox', isError: true);
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _isLoading = true;
      _errorMsg = null;
      _result = null;
    });

    try {
      final uri = Uri.parse(
          'http://api.ikyyxd.my.id/stalk/roblox?username=${Uri.encodeComponent(username)}');
      final res = await http.get(uri).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        final ok = json['status'] == true || json['status'] == 'benar';
        if (ok) {
          setState(() {
            _result = RobloxResult.fromJson(json);
            _isLoading = false;
          });
          await Future.delayed(const Duration(milliseconds: 300));
          _scrollCtrl.animateTo(
            200,
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOut,
          );
        } else {
          setState(() {
            _errorMsg = json['message'] ?? 'Username tidak ditemukan';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMsg = 'Server error: ${res.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMsg = 'Gagal terhubung ke server';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: 'ROBLOX STALKER',
      showBackButton: true,
      contentPadding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: const Text(
                  'R',
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ROBLOX STALKER',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      'Cek Info Roblox Player',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
              StatusBadge(label: 'LIVE', isOnline: true),
            ],
          ),
          const SizedBox(height: 20),

          // Search Bar
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'USERNAME',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.borderLight),
                        ),
                        child: TextField(
                          controller: _ctrl,
                          textInputAction: TextInputAction.search,
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 13,
                            fontFamily: appFont,
                          ),
                          decoration: InputDecoration(
                            hintText: 'contoh: Builderman',
                            hintStyle: TextStyle(
                              color: AppColors.textMuted,
                              fontSize: 12,
                              fontFamily: appFont,
                            ),
                            prefixIcon: Icon(Icons.person_search_rounded,
                                color: AppColors.textSec, size: 18),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 14),
                          ),
                          onSubmitted: (_) => _search(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: _isLoading ? null : _search,
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: _isLoading ? AppColors.textMuted : AppColors.accent,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: _isLoading
                              ? []
                              : [
                                  BoxShadow(
                                    color: AppColors.accent.withOpacity(0.3),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  )
                                ],
                        ),
                        child: _isLoading
                            ? const Center(
                                child: SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                ),
                              )
                            : const Icon(Icons.search_rounded,
                                color: Colors.white, size: 22),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          if (_isLoading) ...[
            GlassCard(
              padding: const EdgeInsets.all(32),
              child: Column(
                children: [
                  const CyberLoadingShimmer(),
                  const SizedBox(height: 12),
                  Text(
                    'Mencari data player...',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],

          if (_errorMsg != null && !_isLoading)
            GlassCard(
              padding: const EdgeInsets.all(16),
              borderColor: AppColors.red.withOpacity(0.3),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: AppColors.red, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Pencarian Gagal',
                          style: TextStyle(
                            fontFamily: appFont,
                            color: AppColors.red,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          _errorMsg!,
                          style: TextStyle(
                            fontFamily: appFont,
                            color: AppColors.textSec,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          if (_result != null && !_isLoading) _buildResult(),
        ],
      ),
    );
  }

  Widget _buildResult() {
    final u = _result!.user;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Profile Card
        GlassCard(
          padding: const EdgeInsets.all(20),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.borderLight, width: 2),
                      color: AppColors.surface2,
                    ),
                    child: ClipOval(
                      child: Image.network(
                        u.profilePicture,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Center(
                          child: Text(
                            u.displayName.isNotEmpty ? u.displayName[0].toUpperCase() : '?',
                            style: TextStyle(
                              fontFamily: appFont,
                              color: Colors.white,
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (u.hasVerifiedBadge)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1565C0),
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.surface, width: 2),
                        ),
                        child: const Icon(Icons.verified_rounded,
                            color: Colors.white, size: 10),
                      ),
                    ),
                  if (u.isBanned)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: AppColors.red,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.surface, width: 2),
                        ),
                        child: const Icon(Icons.block_rounded,
                            color: Colors.white, size: 10),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            u.displayName,
                            style: TextStyle(
                              fontFamily: appFont,
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (u.isBanned)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.red.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: AppColors.red.withOpacity(0.3)),
                            ),
                            child: Text(
                              'BANNED',
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.red,
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                      ],
                    ),
                    Text('@${u.name}',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textSec,
                          fontSize: 11,
                        )),
                    Text('ID: ${u.id}',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textMuted,
                          fontSize: 10,
                        )),
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: '${u.id}'));
                        showCyberSnackBar(context, 'User ID tersalin!');
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.borderLight),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.copy_rounded, color: AppColors.textSec, size: 10),
                            const SizedBox(width: 4),
                            Text(
                              'Salin User ID',
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.textSec,
                                fontSize: 9,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Stats
        Row(
          children: [
            _buildStatTile('FRIENDS', '${u.friendsCount}', Icons.group_rounded),
            const SizedBox(width: 10),
            _buildStatTile('FOLLOWERS', '${u.followersCount}', Icons.people_alt_rounded),
            const SizedBox(width: 10),
            _buildStatTile('FOLLOWING', '${u.followingsCount}', Icons.person_add_rounded),
          ],
        ),
        const SizedBox(height: 16),

        // Bio
        if (u.description != null && u.description!.isNotEmpty)
          GlassCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'DESKRIPSI',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    u.description!,
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textPrimary,
                      fontSize: 12,
                      height: 1.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
        if (u.description != null && u.description!.isNotEmpty)
          const SizedBox(height: 16),

        // Account Info
        GlassCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'INFORMASI AKUN',
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              _infoRow(Icons.calendar_today_rounded, 'Dibuat', _formatDate(u.created ?? '')),
              _divider(),
              _infoRow(
                Icons.verified_user_rounded,
                'Status',
                u.isBanned ? 'Akun Dibanned' : (u.hasVerifiedBadge ? 'Verified ✓' : 'Normal'),
              ),
              _divider(),
              _infoRow(Icons.tag_rounded, 'User ID', '${u.id}'),
              _divider(),
              _infoRow(Icons.alternate_email_rounded, 'Username', '@${u.name}'),
            ],
          ),
        ),

        // Friends
        if (_result!.friends.isNotEmpty) ...[
          const SizedBox(height: 20),
          Row(
            children: [
              Text(
                'DAFTAR TEMAN',
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.borderLight),
                ),
                child: Text(
                  '${_result!.friends.length}',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.85,
            ),
            itemCount: _result!.friends.length,
            itemBuilder: (context, i) {
              return _buildFriendTile(_result!.friends[i]);
            },
          ),
        ],
      ],
    );
  }

  Widget _buildStatTile(String label, String value, IconData icon) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, color: AppColors.accent, size: 18),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                fontFamily: appFont,
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.textMuted,
                fontSize: 7,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: AppColors.textSec, size: 14),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textMuted,
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontFamily: appFont,
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _divider() => Container(
    height: 1,
    color: AppColors.borderLight.withOpacity(0.3),
  );

  Widget _buildFriendTile(RobloxFriend f) {
    return GlassCard(
      padding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.borderLight, width: 1.5),
              color: AppColors.surface2,
            ),
            child: ClipOval(
              child: Image.network(
                f.profilePicture,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Center(
                  child: Text(
                    f.displayName.isNotEmpty ? f.displayName[0].toUpperCase() : '?',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            f.displayName.isNotEmpty ? f.displayName : f.name,
            style: TextStyle(
              fontFamily: appFont,
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
          Text(
            '@${f.name}',
            style: TextStyle(
              fontFamily: appFont,
              color: AppColors.textMuted,
              fontSize: 8,
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  String _formatDate(String raw) {
    if (raw.isEmpty) return '-';
    try {
      final dt = DateTime.parse(raw).toLocal();
      const months = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
      return '${dt.day} ${months[dt.month]} ${dt.year}';
    } catch (_) {
      return raw;
    }
  }
}