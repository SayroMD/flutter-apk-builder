import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:archive/archive.dart';
import 'package:mime/mime.dart';
import 'base_page.dart';

class UploadToUrlPage extends StatefulWidget {
  const UploadToUrlPage({super.key});

  @override
  State<UploadToUrlPage> createState() => _UploadToUrlPageState();
}

class _UploadToUrlPageState extends State<UploadToUrlPage> {
  static const int maxCatboxSize = 50 * 1024 * 1024;

  FilePickerResult? _pickedFile;
  String? _fileName;
  int? _fileSize;
  String? _mimeType;
  Uint8List? _previewBytes;
  String? _uploadedUrl;
  bool _isUploading = false;

  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: false,
        type: FileType.any,
        withData: true,
      );
      if (result != null) {
        setState(() {
          _pickedFile = result;
          _fileName = result.files.single.name;
          _fileSize = result.files.single.size;
          _mimeType = lookupMimeType(_fileName!);
          _previewBytes = _mimeType?.startsWith('image/') == true ? result.files.single.bytes : null;
          _uploadedUrl = null;
        });
      }
    } catch (e) {
      showCyberSnackBar(context, 'Gagal memilih file: $e', isError: true);
    }
  }

  Future<String> _zipFile(File file) async {
    final tempDir = await getTemporaryDirectory();
    final zipPath = '${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.zip';
    final encoder = ZipEncoder();
    final archive = Archive();
    final bytes = await file.readAsBytes();
    archive.addFile(ArchiveFile(file.path.split('/').last, bytes.length, bytes));
    final zipData = encoder.encode(archive);
    if (zipData == null) throw Exception('Gagal mengompres file');
    await File(zipPath).writeAsBytes(zipData);
    return zipPath;
  }

  Future<String> _uploadToCatbox(String path) async {
    final uri = Uri.parse('https://catbox.moe/user/api.php');
    final request = http.MultipartRequest('POST', uri)
      ..fields['reqtype'] = 'fileupload'
      ..fields['userhash'] = ''
      ..files.add(await http.MultipartFile.fromPath('fileToUpload', path));
    final response = await request.send().timeout(const Duration(seconds: 60));
    final body = await response.stream.bytesToString();
    if (response.statusCode == 200 && body.startsWith('https://')) {
      return body.trim();
    }
    throw Exception('Upload gagal: ${response.reasonPhrase}');
  }

  Future<void> _uploadFile() async {
    if (_pickedFile == null) {
      showCyberSnackBar(context, 'Pilih file terlebih dahulu', isError: true);
      return;
    }

    setState(() => _isUploading = true);

    String? tempPath;
    String? zipPath;
    try {
      final fileData = _pickedFile!.files.single;
      final tempDir = await getTemporaryDirectory();
      final originalFile = File('${tempDir.path}/${fileData.name}');
      await originalFile.writeAsBytes(fileData.bytes!);
      tempPath = originalFile.path;

      String uploadPath = tempPath;
      if (fileData.size > maxCatboxSize) {
        showCyberSnackBar(context, 'File besar, sedang dikompres...');
        zipPath = await _zipFile(originalFile);
        uploadPath = zipPath;
      }

      showCyberSnackBar(context, 'Mengupload...');
      final url = await _uploadToCatbox(uploadPath);
      setState(() => _uploadedUrl = url);
      showCyberSnackBar(context, 'Upload berhasil!');
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
    } finally {
      if (tempPath != null && File(tempPath).existsSync()) File(tempPath).deleteSync();
      if (zipPath != null && File(zipPath).existsSync()) File(zipPath).deleteSync();
      setState(() => _isUploading = false);
    }
  }

  void _copyToClipboard() {
    if (_uploadedUrl == null) return;
    Clipboard.setData(ClipboardData(text: _uploadedUrl!));
    showCyberSnackBar(context, 'URL disalin ke clipboard');
  }

  void _shareUrl() {
    if (_uploadedUrl == null) return;
    Share.share(_uploadedUrl!);
  }

  void _reset() {
    setState(() {
      _pickedFile = null;
      _fileName = null;
      _fileSize = null;
      _mimeType = null;
      _previewBytes = null;
      _uploadedUrl = null;
    });
  }

  String _formatBytes(int bytes, {int decimals = 2}) {
    if (bytes <= 0) return '0 B';
    const suffixes = ['B', 'KB', 'MB', 'GB', 'TB'];
    double size = bytes.toDouble();
    int unitIndex = 0;
    while (size >= 1024 && unitIndex < suffixes.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return '${size.toStringAsFixed(decimals)} ${suffixes[unitIndex]}';
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "UPLOAD MEDIA",
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh_rounded, color: AppColors.textMuted),
          onPressed: _reset,
        ),
      ],
      child: Column(
        children: [
          GlassCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text('Pratinjau Media',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.accent)),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildPreviewContent(),
                const SizedBox(height: 16),
                if (_pickedFile != null) _buildFileInfo(),
              ],
            ),
          ),
          const SizedBox(height: 16),
          GlassCard(
            child: Column(
              children: [
                CyberButton(
                  label: "PILIH MEDIA",
                  icon: Icons.attach_file_rounded,
                  onTap: _isUploading ? () {} : _pickFile,
                  color: AppColors.accent,
                  width: double.infinity,
                ),
                const SizedBox(height: 12),
                CyberButton(
                  label: _isUploading ? "MENGUPLOAD..." : "UPLOAD KE CATBOX",
                  icon: _isUploading ? Icons.hourglass_top : Icons.cloud_upload_rounded,
                  onTap: (_pickedFile == null || _isUploading) ? () {} : _uploadFile,
                  isLoading: _isUploading,
                  width: double.infinity,
                ),
                if (_uploadedUrl != null) ...[
                  const SizedBox(height: 24),
                  const Divider(color: AppColors.border),
                  const SizedBox(height: 16),
                  Text('URL Hasil Upload',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.surface2,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: SelectableText(_uploadedUrl!,
                        style: TextStyle(color: AppColors.textSec, fontSize: 13)),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: CyberButton(
                          label: "COPY",
                          icon: Icons.copy_rounded,
                          onTap: _copyToClipboard,
                          color: AppColors.textSec,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: CyberButton(
                          label: "BAGIKAN",
                          icon: Icons.share_rounded,
                          onTap: _shareUrl,
                          color: AppColors.accent,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewContent() {
    if (_pickedFile == null) {
      return Container(
        height: 180,
        decoration: BoxDecoration(
          color: AppColors.surface2.withOpacity(0.5),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.upload_file, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 12),
            Text('Belum ada file dipilih', style: TextStyle(color: AppColors.textMuted)),
          ],
        ),
      );
    }

    if (_previewBytes != null) {
      return Container(
        height: 220,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(image: MemoryImage(_previewBytes!), fit: BoxFit.cover),
        ),
      );
    } else {
      return Container(
        height: 140,
        decoration: BoxDecoration(
          color: AppColors.surface2.withOpacity(0.5),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.insert_drive_file, size: 40, color: AppColors.textMuted),
              const SizedBox(height: 8),
              Text('File non-gambar', style: TextStyle(color: AppColors.textMuted)),
            ],
          ),
        ),
      );
    }
  }

  Widget _buildFileInfo() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface2.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.insert_drive_file, color: AppColors.textMuted),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_fileName!, style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(_formatBytes(_fileSize!),
                        style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                  ],
                ),
              ),
            ],
          ),
          if (_fileSize! > maxCatboxSize) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.orange.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: AppColors.orange, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text('File lebih dari 50 MB, akan dikompres menjadi ZIP sebelum upload.',
                        style: TextStyle(color: AppColors.orange, fontSize: 13)),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}