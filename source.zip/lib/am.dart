import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String baseUrl = 'https://satriam.satriadeveloperz.workers.dev';

const Map<String, String> apiHeaders = {
  'User-Agent':
      'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
  'Content-Type': 'application/json',
  'Origin': baseUrl,
  'Referer': '$baseUrl/',
};

// ==================== COLORS ====================
class AppColor {
  static const bg = Color(0xFFF5F7FA);
  static const card = Colors.white;
  static const border = Color(0xFF0F172A);
  static const primary = Color(0xFF29B6C6);
  static const primaryDark = Color(0xFF1E8F9C);
  static const textDark = Color(0xFF0F172A);
  static const textGrey = Color(0xFF94A3B8);
  static const warning = Color(0xFFF59E0B);
  static const softBlue = Color(0xFFE0F2FE);
}

// ==================== MAIN PAGE ====================
class UnlockPage extends StatefulWidget {
  const UnlockPage({super.key});

  @override
  State<UnlockPage> createState() => _UnlockPageState();
}

class _UnlockPageState extends State<UnlockPage> {
  final _emailCtrl = TextEditingController();
  final _linkCtrl = TextEditingController();

  bool _loadingSend = false;
  bool _loadingVerify = false;
  bool _activated = false;

  String _statusText = 'BELUM AKTIF';
  Color _statusColor = AppColor.warning;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _linkCtrl.dispose();
    super.dispose();
  }

  // ---------------- API ----------------
  Future<void> _sendMagicLink() async {
    final email = _emailCtrl.text.trim();
    if (!email.contains('@')) {
      _snack('Email tidak valid', error: true);
      return;
    }

    setState(() => _loadingSend = true);
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/api/satriam/send-link'),
            headers: apiHeaders,
            body: jsonEncode({'email': email}),
          )
          .timeout(const Duration(seconds: 15));

      final data = _parse(res.body);
      if (data['success'] != true) {
        throw Exception('Gagal kirim link');
      }
      _snack('Magic link terkirim! Cek email 📬');
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      setState(() => _loadingSend = false);
    }
  }

  Future<void> _verifyLink() async {
    final email = _emailCtrl.text.trim();
    final link = _linkCtrl.text.trim();

    if (email.isEmpty || !email.contains('@')) {
      _snack('Isi email dulu', error: true);
      return;
    }
    if (!link.startsWith('http')) {
      _snack('Magic link tidak valid', error: true);
      return;
    }

    setState(() => _loadingVerify = true);
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/api/satriam/verify-link'),
            headers: apiHeaders,
            body: jsonEncode({'email': email, 'magicLink': link}),
          )
          .timeout(const Duration(seconds: 15));

      final data = _parse(res.body);
      if (data['success'] != true) {
        throw Exception('Verifikasi gagal');
      }

      setState(() {
        _activated = true;
        _statusText = 'AKTIF';
        _statusColor = AppColor.primary;
      });

      if (mounted) {
        _showResultDialog(data);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      setState(() => _loadingVerify = false);
    }
  }

  Map<String, dynamic> _parse(String body) {
    try {
      return jsonDecode(body) as Map<String, dynamic>;
    } catch (_) {
      return {'success': false};
    }
  }

  void _snack(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: error ? Colors.red : AppColor.primaryDark,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showResultDialog(Map<String, dynamic> data) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: AppColor.primary),
            SizedBox(width: 8),
            Text('Login Berhasil'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _resultRow('UID', '${data['uid']}'),
            _resultRow('Plan', '${data['planName']}'),
            _resultRow('Valid Until', '${data['validUntil']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Widget _resultRow(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 90,
              child: Text(k,
                  style: const TextStyle(
                      color: AppColor.textGrey, fontSize: 13)),
            ),
            Expanded(
              child: Text(v,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 13)),
            ),
          ],
        ),
      );

  // ---------------- BUILD ----------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _topBar(),
              const SizedBox(height: 12),
              _headerCard(),
              const SizedBox(height: 12),
              _formCard(),
              const SizedBox(height: 12),
              _guideCard(),
              const SizedBox(height: 12),
              const Text(
                'v6.6.0',
                style: TextStyle(color: AppColor.textGrey, fontSize: 12),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // Top bar with back & refresh
  Widget _topBar() {
    return Row(
      children: [
        _iconButton(
          Icons.arrow_back,
          () => _snack('Back button pressed'),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Text(
            'Alight Unlock',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: AppColor.textDark,
            ),
          ),
        ),
        _iconButton(Icons.refresh, () {
          setState(() {
            _emailCtrl.clear();
            _linkCtrl.clear();
            _activated = false;
            _statusText = 'BELUM AKTIF';
            _statusColor = AppColor.warning;
          });
        }),
      ],
    );
  }

  Widget _iconButton(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColor.border, width: 1.5),
          boxShadow: const [
            BoxShadow(
                color: Color(0x22000000),
                offset: Offset(2, 3),
                blurRadius: 0),
          ],
        ),
        child: Icon(icon, color: AppColor.textDark, size: 20),
      ),
    );
  }

  // Header card with icon + status pill
  Widget _headerCard() {
    return _card(
      child: Column(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: const BoxDecoration(
              color: Color(0xFF1E293B),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.bolt, color: AppColor.primary, size: 42),
          ),
          const SizedBox(height: 16),
          const Text(
            'Alight Unlock',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w800,
              color: AppColor.textDark,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Aktifkan premium lewat magic link',
            style: TextStyle(color: AppColor.textGrey, fontSize: 13),
          ),
          const SizedBox(height: 16),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: AppColor.border, width: 1.8),
              boxShadow: const [
                BoxShadow(
                    color: Color(0x22000000),
                    offset: Offset(2, 3),
                    blurRadius: 0),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: _statusColor,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  _statusText,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: _statusColor,
                    letterSpacing: 0.5,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Form: email + magic link
  Widget _formCard() {
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label('EMAIL'),
          const SizedBox(height: 8),
          _inputField(
            controller: _emailCtrl,
            hint: 'Masukkan email kamu',
            icon: Icons.email_outlined,
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 12),
          _primaryButton(
            label: 'KIRIM MAGIC LINK',
            icon: Icons.send_rounded,
            onTap: _loadingSend ? null : _sendMagicLink,
            loading: _loadingSend,
          ),
          const SizedBox(height: 20),
          const Divider(color: Color(0xFFE2E8F0)),
          const SizedBox(height: 12),
          _label('MAGIC LINK'),
          const SizedBox(height: 8),
          _inputField(
            controller: _linkCtrl,
            hint: 'Tempel link dari email',
            icon: Icons.link,
            suffix: IconButton(
              icon: const Icon(Icons.content_paste,
                  size: 20, color: AppColor.textDark),
              onPressed: () async {
                final data = await Clipboard.getData('text/plain');
                if (data?.text != null) {
                  _linkCtrl.text = data!.text!;
                }
              },
            ),
          ),
          const SizedBox(height: 12),
          _secondaryButton(
            label: 'VERIFIKASI & AKTIFKAN',
            icon: Icons.verified_user_outlined,
            enabled: _linkCtrl.text.trim().startsWith('http') &&
                !_loadingVerify,
            loading: _loadingVerify,
            onTap: _verifyLink,
          ),
        ],
      ),
    );
  }

  // Guide card
  Widget _guideCard() {
    const steps = [
      'Masukkan email yang terdaftar',
      'Tekan Kirim Magic Link',
      'Cek email (termasuk folder spam)',
      'Salin link lalu tempel di bawah',
      'Tekan Verifikasi & Aktifkan',
    ];

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.lightbulb_outline,
                  color: AppColor.warning, size: 20),
              SizedBox(width: 8),
              Text(
                'CARA PAKAI',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                  color: AppColor.textDark,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...List.generate(steps.length, (i) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 26,
                    height: 26,
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(
                      color: AppColor.primary,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${i + 1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: Text(
                        steps[i],
                        style: const TextStyle(
                          fontSize: 13.5,
                          color: AppColor.textDark,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColor.softBlue.withOpacity(0.4),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFBAE6FD)),
            ),
            child: Row(
              children: const [
                Icon(Icons.info_outline,
                    color: AppColor.primaryDark, size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Magic link hanya berlaku 15 menit',
                    style: TextStyle(
                      color: AppColor.primaryDark,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------- Reusable widgets ----------------
  Widget _card({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColor.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColor.border, width: 1.8),
        boxShadow: const [
          BoxShadow(
              color: Color(0x22000000),
              offset: Offset(3, 4),
              blurRadius: 0),
        ],
      ),
      child: child,
    );
  }

  Widget _label(String text) => Text(
        text,
        style: const TextStyle(
          fontWeight: FontWeight.w800,
          fontSize: 12,
          color: AppColor.textDark,
          letterSpacing: 0.8,
        ),
      );

  Widget _inputField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    Widget? suffix,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      onChanged: (_) => setState(() {}),
      style: const TextStyle(fontSize: 14, color: AppColor.textDark),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColor.textGrey, fontSize: 14),
        prefixIcon: Icon(icon, color: AppColor.textGrey, size: 20),
        suffixIcon: suffix,
        filled: true,
        fillColor: Colors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColor.border, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColor.primary, width: 2),
        ),
      ),
    );
  }

  Widget _primaryButton({
    required String label,
    required IconData icon,
    required VoidCallback? onTap,
    bool loading = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: onTap == null
              ? AppColor.primary.withOpacity(0.6)
              : AppColor.primary,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColor.border, width: 1.8),
          boxShadow: const [
            BoxShadow(
                color: Color(0x22000000),
                offset: Offset(2, 3),
                blurRadius: 0),
          ],
        ),
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation(Colors.white),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 10),
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _secondaryButton({
    required String label,
    required IconData icon,
    required bool enabled,
    required VoidCallback onTap,
    bool loading = false,
  }) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Container(
        height: 52,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: enabled ? Colors.white : const Color(0xFFE2E8F0),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColor.border, width: 1.8),
          boxShadow: const [
            BoxShadow(
                color: Color(0x22000000),
                offset: Offset(2, 3),
                blurRadius: 0),
          ],
        ),
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation(AppColor.textDark),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon,
                      color: enabled
                          ? AppColor.textDark
                          : AppColor.textGrey,
                      size: 18),
                  const SizedBox(width: 10),
                  Text(
                    label,
                    style: TextStyle(
                      color: enabled
                          ? AppColor.textDark
                          : AppColor.textGrey,
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}