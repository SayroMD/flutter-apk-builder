import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';

import 'main.dart' show baseUrl;

/// Tema disamakan dengan bug_report_admin_page.dart (NB = Neo-Brutalism tokens)
class NB {
  static const bg = Color(0xFFF4F1EA);
  static const black = Color(0xFF111111);
  static const blue = Color(0xFF2B5FE0);
  static const yellow = Color(0xFFFFD23F);
  static const green = Color(0xFF3DDC84);
  static const pink = Color(0xFFFF6B6B);
  static const borderWidth = 2.5;

  static BoxDecoration card({Color color = Colors.white, double radius = 14}) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: black, width: borderWidth),
      boxShadow: const [BoxShadow(color: black, offset: Offset(4, 4), blurRadius: 0)],
    );
  }

  static BoxDecoration flatCard({Color color = Colors.white, double radius = 14}) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: black, width: borderWidth),
    );
  }
}

class BugReportPage extends StatefulWidget {
  final String sessionKey;

  const BugReportPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<BugReportPage> createState() => _BugReportPageState();
}

class _BugReportPageState extends State<BugReportPage> {
  final _descController = TextEditingController();
  File? _screenshot;
  bool _sending = false;

  Future<void> _pickScreenshot() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (picked != null) {
      setState(() => _screenshot = File(picked.path));
    }
  }

  Future<Map<String, String>> _collectDeviceInfo() async {
    final packageInfo = await PackageInfo.fromPlatform();
    String deviceLabel = 'Unknown device';

    try {
      final deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        final info = await deviceInfo.androidInfo;
        deviceLabel = '${info.manufacturer} ${info.model} (Android ${info.version.release})';
      } else if (Platform.isIOS) {
        final info = await deviceInfo.iosInfo;
        deviceLabel = '${info.name} (${info.systemName} ${info.systemVersion})';
      }
    } catch (_) {}

    return {
      'app_version': '${packageInfo.version}+${packageInfo.buildNumber}',
      'device': deviceLabel,
    };
  }

  Future<void> _submit() async {
    final desc = _descController.text.trim();
    if (desc.isEmpty) {
      _showSnack('Deskripsi masalah wajib diisi', color: NB.pink);
      return;
    }

    setState(() => _sending = true);
    try {
      final deviceInfo = await _collectDeviceInfo();
      final uri = Uri.parse('$baseUrl/api/bug-report');
      final request = http.MultipartRequest('POST', uri);
      request.headers['x-session-key'] = widget.sessionKey;
      request.fields['description'] = desc;
      request.fields['app_version'] = deviceInfo['app_version']!;
      request.fields['device'] = deviceInfo['device']!;

      if (_screenshot != null) {
        request.files.add(await http.MultipartFile.fromPath('screenshot', _screenshot!.path));
      }

      final streamed = await request.send();
      final res = await http.Response.fromStream(streamed);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == 'ok') {
          if (mounted) {
            _showSnack('Laporan terkirim, makasih!', color: NB.green);
            _descController.clear();
            setState(() => _screenshot = null);
            Future.delayed(const Duration(milliseconds: 900), () {
              if (mounted) Navigator.pop(context);
            });
          }
          return;
        }
      }
      _showSnack('Gagal kirim laporan (${res.statusCode})', color: NB.pink);
    } catch (e) {
      _showSnack('Error: $e', color: NB.pink);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _showSnack(String msg, {required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w700, color: NB.black)),
        backgroundColor: color,
      ),
    );
  }

  @override
  void dispose() {
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NB.bg,
      appBar: AppBar(
        backgroundColor: NB.bg,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'LAPORKAN BUG',
          style: TextStyle(color: NB.black, fontWeight: FontWeight.w900, fontSize: 17),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: NB.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionLabel('APA YANG TERJADI?'),
          const SizedBox(height: 8),
          Container(
            decoration: NB.card(),
            child: TextField(
              controller: _descController,
              maxLines: 6,
              style: const TextStyle(color: NB.black, fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Ceritain bug/error yang lo alami, sedetail mungkin...',
                hintStyle: TextStyle(color: Colors.black38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(14),
              ),
            ),
          ),
          const SizedBox(height: 20),
          _sectionLabel('SCREENSHOT (OPSIONAL)'),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _pickScreenshot,
            child: Container(
              height: _screenshot != null ? 200 : 100,
              width: double.infinity,
              decoration: NB.flatCard(color: Colors.white, radius: 12),
              clipBehavior: Clip.antiAlias,
              child: _screenshot != null
                  ? Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(_screenshot!, fit: BoxFit.cover),
                        Positioned(
                          top: 8,
                          right: 8,
                          child: GestureDetector(
                            onTap: () => setState(() => _screenshot = null),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: NB.card(color: NB.pink, radius: 8),
                              child: const Icon(Icons.close_rounded, size: 16, color: NB.black),
                            ),
                          ),
                        ),
                      ],
                    )
                  : const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add_photo_alternate_rounded, color: NB.black, size: 26),
                          SizedBox(height: 6),
                          Text('Tap buat pilih screenshot',
                              style: TextStyle(color: NB.black, fontWeight: FontWeight.w700, fontSize: 12)),
                        ],
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: InkWell(
              onTap: _sending ? null : _submit,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: NB.card(color: NB.blue, radius: 12),
                alignment: Alignment.center,
                child: _sending
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                      )
                    : const Text(
                        'KIRIM LAPORAN',
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: Colors.white),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: NB.black, letterSpacing: 0.5),
    );
  }
}
