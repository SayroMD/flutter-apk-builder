import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'story_bar.dart';
import 'story_model.dart';
import 'story_api_service.dart';

class StoryBarLoader extends StatefulWidget {
  const StoryBarLoader({super.key});

  @override
  State<StoryBarLoader> createState() => _StoryBarLoaderState();
}

class _StoryBarLoaderState extends State<StoryBarLoader> {
  late Future<List<StoryGroup>> _future;
  String _currentUsername = '';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    _currentUsername = prefs.getString('username') ?? '';
    _reload();
  }

  void _reload() {
    setState(() => _future = StoryApiService.fetchStories());
  }

  Future<void> _pickAndUpload() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    try {
      await StoryApiService.uploadStory(mediaFile: File(picked.path));
      _reload();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload gagal: $e')),
        );
      }
    }
  }

  Future<void> _deleteStory(String storyId) async {
    try {
      await StoryApiService.deleteStory(storyId);
      _reload();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Hapus gagal: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<StoryGroup>>(
      future: _future,
      builder: (context, snapshot) {
        final groups = snapshot.data ?? [];
        return StoryBar(
          groups: groups,
          currentUsername: _currentUsername,
          onAddStory: _pickAndUpload,
          onDelete: _deleteStory,
        );
      },
    );
  }
}
