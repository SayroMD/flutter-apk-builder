import 'package:flutter/foundation.dart';

/// Notifier global buat ngatur visibility floating nav bar.
/// Set jadi true kalau lagi di halaman yang gak butuh nav bar (misal chat detail).
class NavBarVisibility {
  static final ValueNotifier<bool> hidden = ValueNotifier<bool>(false);
}
