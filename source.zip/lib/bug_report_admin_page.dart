import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'main.dart' show baseUrl;

/// ============================================================
/// NEO-BRUTALISM DESIGN TOKENS
/// ============================================================
class NB {
  static const bg = Color(0xFFF4F1EA); // off-white background
  static const black = Color(0xFF111111);
  static const blue = Color(0xFF2B5FE0); // primary accent
  static const yellow = Color(0xFFFFD23F); // status: open
  static const green = Color(0xFF3DDC84); // status: selesai
  static const pink = Color(0xFFFF6B6B);

  static const double borderWidth = 2.5;

  static BoxDecoration card({Color color = Colors.white, double radius = 14}) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: black, width: borderWidth),
      boxShadow: const [
        BoxShadow(
          color: black,
          offset: Offset(4, 4),
          blurRadius: 0,
        ),
      ],
    );
  }

  static BoxDecoration flatCard({Color color = Colors.white, double radius = 14}) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: black, width: borderWidth),
    );
  }
}

/// ============================================================
/// MODEL
/// ============================================================
class BugReport {
  final String id;
  final String username;
  final String description;
  final String appVersion;
  final String device;
  final String? screenshotUrl;
  final String status; // open | selesai
  final DateTime createdAt;

  BugReport({
    required this.id,
    required this.username,
    required this.description,
    required this.appVersion,
    required this.device,
    required this.status,
    required this.createdAt,
    this.screenshotUrl,
  });

  factory BugReport.fromJson(Map<String, dynamic> j) {
    return BugReport(
      id: j['id'].toString(),
      username: j['username'] ?? '-',
      description: j['description'] ?? '',
      appVersion: j['app_version'] ?? '-',
      device: j['device'] ?? '-',
      screenshotUrl: j['screenshot_url'],
      status: j['status'] ?? 'open',
      createdAt: DateTime.tryParse(j['created_at'] ?? '') ?? DateTime.now(),
    );
  }
}

/// ============================================================
/// ADMIN PAGE — LIST
/// ============================================================
class BugReportAdminPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const BugReportAdminPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<BugReportAdminPage> createState() => _BugReportAdminPageState();
}

class _BugReportAdminPageState extends State<BugReportAdminPage> {
  String _filter = 'open'; // open | selesai | all
  bool _loading = true;
  String? _error;
  List<BugReport> _reports = [];
  Map<String, int> _counts = {'open': 0, 'selesai': 0, 'all': 0};

  @override
  void initState() {
    super.initState();
    _fetchReports();
  }

  Future<void> _fetchReports() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uri = Uri.parse('$baseUrl/api/bug-report?status=all');
      final res = await http.get(uri, headers: {
        'x-session-key': widget.sessionKey,
      });

      if (res.statusCode != 200) {
        setState(() {
          _error = 'Gagal load (${res.statusCode})';
          _loading = false;
        });
        return;
      }

      final List data = jsonDecode(res.body);
      final all = data.map((e) => BugReport.fromJson(e)).toList();

      setState(() {
        _reports = all;
        _counts = {
          'open': all.where((r) => r.status == 'open').length,
          'selesai': all.where((r) => r.status == 'selesai').length,
          'all': all.length,
        };
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _loading = false;
      });
    }
  }

  List<BugReport> get _filtered {
    if (_filter == 'all') return _reports;
    return _reports.where((r) => r.status == _filter).toList();
  }

  Future<void> _openDetail(BugReport report) async {
    final changed = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => BugReportDetailPage(
          report: report,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
    if (changed == true) _fetchReports();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NB.bg,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          const SizedBox(height: 14),
          _buildTabs(),
          const SizedBox(height: 14),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: NB.bg,
      elevation: 0,
      centerTitle: true,
      title: const Text(
        'LAPORAN ERROR USER',
        style: TextStyle(
          color: NB.black,
          fontWeight: FontWeight.w900,
          fontSize: 17,
          letterSpacing: 0.5,
        ),
      ),
      leading: _iconButton(Icons.arrow_back_rounded, () => Navigator.pop(context)),
      actions: [
        _iconButton(Icons.refresh_rounded, _fetchReports),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _iconButton(IconData icon, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          width: 38,
          height: 38,
          decoration: NB.card(color: Colors.white, radius: 10),
          child: Icon(icon, color: NB.black, size: 20),
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _tabChip('open', 'Open (${_counts['open']})', NB.yellow),
          const SizedBox(width: 10),
          _tabChip('selesai', 'Selesai (${_counts['selesai']})', NB.green),
          const SizedBox(width: 10),
          _tabChip('all', 'Semua (${_counts['all']})', NB.blue),
        ],
      ),
    );
  }

  Widget _tabChip(String value, String label, Color activeColor) {
    final active = _filter == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _filter = value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? activeColor : Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: NB.black, width: NB.borderWidth),
            boxShadow: active
                ? const [BoxShadow(color: NB.black, offset: Offset(3, 3), blurRadius: 0)]
                : [],
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 12.5,
              color: NB.black,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: NB.black),
      );
    }
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!, style: const TextStyle(color: NB.black, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            _brutalButton('Coba Lagi', NB.pink, _fetchReports),
          ],
        ),
      );
    }
    final list = _filtered;
    if (list.isEmpty) {
      return const Center(
        child: Text(
          'Belum ada laporan',
          style: TextStyle(color: NB.black, fontWeight: FontWeight.w700),
        ),
      );
    }
    return RefreshIndicator(
      color: NB.black,
      onRefresh: _fetchReports,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (_, i) => _ReportCard(
          report: list[i],
          onTap: () => _openDetail(list[i]),
        ),
      ),
    );
  }

  Widget _brutalButton(String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: NB.card(color: color, radius: 10),
        child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, color: NB.black)),
      ),
    );
  }
}

/// ============================================================
/// REPORT CARD
/// ============================================================
class _ReportCard extends StatelessWidget {
  final BugReport report;
  final VoidCallback onTap;

  const _ReportCard({required this.report, required this.onTap});

  Color get _statusColor => report.status == 'open' ? NB.yellow : NB.green;

  String _formatDate(DateTime d) {
    final dd = d.day.toString().padLeft(2, '0');
    final mm = d.month.toString().padLeft(2, '0');
    final hh = d.hour.toString().padLeft(2, '0');
    final min = d.minute.toString().padLeft(2, '0');
    return '$dd/$mm/${d.year} $hh:$min';
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: NB.card(),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: NB.flatCard(color: NB.bg, radius: 10),
              child: const Icon(Icons.bug_report_rounded, color: NB.black),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '@${report.username}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            color: NB.black,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: _statusColor,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: NB.black, width: 2),
                        ),
                        child: Text(
                          report.status.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: NB.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    report.description,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, color: NB.black, height: 1.3),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _formatDate(report.createdAt),
                    style: TextStyle(fontSize: 11.5, color: NB.black.withOpacity(0.55), fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: NB.black),
          ],
        ),
      ),
    );
  }
}

/// ============================================================
/// DETAIL PAGE
/// ============================================================
class BugReportDetailPage extends StatefulWidget {
  final BugReport report;
  final String sessionKey;

  const BugReportDetailPage({
    super.key,
    required this.report,
    required this.sessionKey,
  });

  @override
  State<BugReportDetailPage> createState() => _BugReportDetailPageState();
}

class _BugReportDetailPageState extends State<BugReportDetailPage> {
  bool _updating = false;
  late String _status;

  @override
  void initState() {
    super.initState();
    _status = widget.report.status;
  }

  Future<void> _toggleStatus() async {
    final newStatus = _status == 'open' ? 'selesai' : 'open';
    setState(() => _updating = true);
    try {
      final uri = Uri.parse('$baseUrl/api/bug-report/${widget.report.id}/status');
      final res = await http.patch(
        uri,
        headers: {
          'x-session-key': widget.sessionKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'status': newStatus}),
      );
      if (res.statusCode == 200) {
        setState(() => _status = newStatus);
      } else {
        _showSnack('Gagal update status (${res.statusCode})');
      }
    } catch (e) {
      _showSnack('Error: $e');
    } finally {
      setState(() => _updating = false);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w700)),
        backgroundColor: NB.black,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.report;
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, _status != r.status);
        return false;
      },
      child: Scaffold(
        backgroundColor: NB.bg,
        appBar: AppBar(
          backgroundColor: NB.bg,
          elevation: 0,
          title: const Text(
            'DETAIL LAPORAN',
            style: TextStyle(color: NB.black, fontWeight: FontWeight.w900, fontSize: 16),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: NB.black),
            onPressed: () => Navigator.pop(context, _status != r.status),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _statusBanner(),
            const SizedBox(height: 16),
            _infoCard('Username', '@${r.username}', Icons.person_rounded),
            const SizedBox(height: 12),
            _infoCard('App Version', r.appVersion, Icons.info_rounded),
            const SizedBox(height: 12),
            _infoCard('Device', r.device, Icons.phone_android_rounded),
            const SizedBox(height: 12),
            _infoCard('Waktu Laporan', r.createdAt.toString(), Icons.access_time_rounded),
            const SizedBox(height: 16),
            _descriptionCard(),
            if (r.screenshotUrl != null) ...[
              const SizedBox(height: 16),
              _screenshotCard(r.screenshotUrl!),
            ],
            const SizedBox(height: 24),
            _actionButton(),
          ],
        ),
      ),
    );
  }

  Widget _statusBanner() {
    final color = _status == 'open' ? NB.yellow : NB.green;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: NB.card(color: color, radius: 12),
      alignment: Alignment.center,
      child: Text(
        _status.toUpperCase(),
        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: NB.black),
      ),
    );
  }

  Widget _infoCard(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: NB.flatCard(),
      child: Row(
        children: [
          Icon(icon, size: 20, color: NB.black),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 11, fontWeight: FontWeight.w700, color: NB.black.withOpacity(0.55))),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: NB.black)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _descriptionCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: NB.card(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('DESKRIPSI',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: NB.black, letterSpacing: 0.5)),
          const SizedBox(height: 8),
          Text(widget.report.description,
              style: const TextStyle(fontSize: 14, height: 1.5, color: NB.black)),
        ],
      ),
    );
  }

  String _resolveUrl(String url) {
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    // path relatif dari backend (mis. "/bug_screenshots/xxx.jpg") -> gabung sama baseUrl
    final cleanBase = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    final cleanPath = url.startsWith('/') ? url : '/$url';
    return '$cleanBase$cleanPath';
  }

  Widget _screenshotCard(String url) {
    final fullUrl = _resolveUrl(url);
    return Container(
      decoration: NB.card(),
      clipBehavior: Clip.antiAlias,
      child: Image.network(
        fullUrl,
        fit: BoxFit.cover,
        width: double.infinity,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return Container(
            height: 180,
            alignment: Alignment.center,
            child: const CircularProgressIndicator(color: NB.black),
          );
        },
        errorBuilder: (context, error, stack) {
          return Container(
            height: 100,
            alignment: Alignment.center,
            padding: const EdgeInsets.all(12),
            child: Text(
              'Gagal load gambar\n$fullUrl',
              textAlign: TextAlign.center,
              style: const TextStyle(color: NB.black, fontSize: 11, fontWeight: FontWeight.w600),
            ),
          );
        },
      ),
    );
  }

  Widget _actionButton() {
    final toSelesai = _status == 'open';
    return SizedBox(
      width: double.infinity,
      child: InkWell(
        onTap: _updating ? null : _toggleStatus,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: NB.card(color: toSelesai ? NB.green : NB.yellow, radius: 12),
          alignment: Alignment.center,
          child: _updating
              ? const SizedBox(
                  width: 20, height: 20, child: CircularProgressIndicator(color: NB.black, strokeWidth: 2.5))
              : Text(
                  toSelesai ? 'TANDAI SELESAI' : 'BUKA LAGI',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: NB.black),
                ),
        ),
      ),
    );
  }
}
