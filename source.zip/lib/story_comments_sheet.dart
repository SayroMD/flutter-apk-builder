import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'story_api_service.dart';
import 'story_bar.dart'; // kInk, kAccentYellow, kAccentRed

class StoryCommentsSheet extends StatefulWidget {
  final String storyId;

  const StoryCommentsSheet({super.key, required this.storyId});

  @override
  State<StoryCommentsSheet> createState() => _StoryCommentsSheetState();
}

class _StoryCommentsSheetState extends State<StoryCommentsSheet> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _comments = [];
  bool _loading = true;
  bool _sending = false;
  String _currentUsername = '';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    _currentUsername = prefs.getString('username') ?? '';
    await _fetchComments();
  }

  Future<void> _fetchComments() async {
    setState(() => _loading = true);
    try {
      final data = await StoryApiService.fetchComments(widget.storyId);
      setState(() => _comments = data);
    } catch (_) {} finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _sendComment() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() => _sending = true);
    try {
      final comment = await StoryApiService.postComment(widget.storyId, text);
      _ctrl.clear();
      setState(() => _comments.add(comment));
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(
            _scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal kirim: $e')),
        );
      }
    } finally {
      setState(() => _sending = false);
    }
  }

  Future<void> _deleteComment(String commentId) async {
    try {
      await StoryApiService.deleteComment(widget.storyId, commentId);
      setState(() => _comments.removeWhere((c) => c['id'] == commentId));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal hapus: $e')),
        );
      }
    }
  }

  String _timeAgo(int ms) {
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inHours >= 1) return '${diff.inHours}j';
    if (diff.inMinutes >= 1) return '${diff.inMinutes}m';
    return 'baru';
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: kInk, width: 3)),
      ),
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // handle bar
          Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: kInk,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: kInk,
                    border: Border.all(color: kInk, width: 2),
                  ),
                  child: Text(
                    'KOMENTAR (${_comments.length})',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      border: Border.all(color: kInk, width: 2),
                      boxShadow: const [BoxShadow(color: kInk, offset: Offset(2, 2))],
                    ),
                    child: const Icon(Icons.close, size: 16),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(height: 2, color: kInk),

          // list komentar
          SizedBox(
            height: 320,
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _comments.isEmpty
                    ? const Center(
                        child: Text(
                          'Belum ada komentar.',
                          style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black54),
                        ),
                      )
                    : ListView.separated(
                        controller: _scroll,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        itemCount: _comments.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, i) {
                          final c = _comments[i];
                          final isOwn = c['username'] == _currentUsername;
                          return Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: isOwn ? const Color(0xFFFFF8DC) : Colors.white,
                              border: Border.all(color: kInk, width: 2),
                              boxShadow: const [BoxShadow(color: kInk, offset: Offset(2, 2))],
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // avatar
                                Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: kInk, width: 2),
                                    color: kAccentYellow,
                                  ),
                                  child: ClipOval(
                                    child: c['avatarUrl'] != null && c['avatarUrl'].isNotEmpty
                                        ? Image.network(c['avatarUrl'], fit: BoxFit.cover)
                                        : Center(
                                            child: Text(
                                              (c['username'] as String)[0].toUpperCase(),
                                              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
                                            ),
                                          ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            c['username'],
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w900,
                                              fontSize: 12,
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            _timeAgo(c['createdAt']),
                                            style: const TextStyle(
                                              fontSize: 10,
                                              color: Colors.black45,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        c['text'],
                                        style: const TextStyle(fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                                if (isOwn)
                                  GestureDetector(
                                    onTap: () => _deleteComment(c['id']),
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: kAccentRed,
                                        border: Border.all(color: kInk, width: 1.5),
                                        boxShadow: const [BoxShadow(color: kInk, offset: Offset(1, 1))],
                                      ),
                                      child: const Icon(Icons.delete, size: 12, color: Colors.white),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
          ),

          Container(height: 2, color: kInk),

          // input bar
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: kInk, width: 3),
                      boxShadow: const [BoxShadow(color: kInk, offset: Offset(3, 3))],
                    ),
                    child: TextField(
                      controller: _ctrl,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'Tulis komentar...',
                        hintStyle: TextStyle(color: Colors.black38, fontSize: 13),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        border: InputBorder.none,
                      ),
                      onSubmitted: (_) => _sendComment(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _sendComment,
                  child: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: kAccentYellow,
                      border: Border.all(color: kInk, width: 3),
                      boxShadow: const [BoxShadow(color: kInk, offset: Offset(3, 3))],
                    ),
                    child: _sending
                        ? const Padding(
                            padding: EdgeInsets.all(12),
                            child: CircularProgressIndicator(strokeWidth: 2, color: kInk),
                          )
                        : const Icon(Icons.send, color: kInk, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Helper function — panggil dari mana aja
Future<void> showStoryComments(BuildContext context, String storyId) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => StoryCommentsSheet(storyId: storyId),
  );
}
