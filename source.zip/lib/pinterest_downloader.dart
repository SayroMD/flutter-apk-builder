// pinterest_downloader_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'base_page.dart';

class PinterestDownloaderPage extends StatefulWidget {
  const PinterestDownloaderPage({super.key});

  @override
  State<PinterestDownloaderPage> createState() => _PinterestDownloaderPageState();
}

class _PinterestDownloaderPageState extends State<PinterestDownloaderPage> {
  final TextEditingController _searchController = TextEditingController();
  
  List<String> _images = [];
  bool _isLoading = false;
  String? _error;

  final String _apiUrl = 'http://api.ikyyxd.my.id/download/pindl?url=';

  Future<void> _searchPinterest() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      showCyberSnackBar(context, "Masukkan kata kunci pencarian!", isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
      _images = [];
    });

    try {
      final response = await http.get(
        Uri.parse('$_apiUrl${Uri.encodeComponent(query)}'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['result'] != null) {
          final List<dynamic> results = data['result'];
          setState(() {
            _images = results.map((e) => e.toString()).toList();
            _isLoading = false;
          });
          showCyberSnackBar(context, "✅ Ditemukan ${_images.length} gambar!");
        } else {
          setState(() {
            _error = 'Tidak ada hasil ditemukan.';
            _isLoading = false;
          });
          showCyberSnackBar(context, "Tidak ada hasil ditemukan.", isError: true);
        }
      } else {
        setState(() {
          _error = 'Server error: ${response.statusCode}';
          _isLoading = false;
        });
        showCyberSnackBar(context, "Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      setState(() {
        _error = 'Koneksi error. Coba lagi nanti.';
        _isLoading = false;
      });
      showCyberSnackBar(context, "Koneksi error", isError: true);
    }
  }

  Future<void> _downloadImage(String url) async {
    showCyberSnackBar(context, "⬇️ Mengunduh gambar...");
    
    try {
      final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 30));
      
      if (response.statusCode == 200) {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/pinterest_${DateTime.now().millisecondsSinceEpoch}.jpg');
        await file.writeAsBytes(response.bodyBytes);
        await Share.shareXFiles(
          [XFile(file.path)],
          text: 'Pinterest image from Tramflok',
        );
        showCyberSnackBar(context, "✅ Gambar siap dibagikan!");
      } else {
        showCyberSnackBar(context, "Gagal mengunduh gambar", isError: true);
      }
    } catch (e) {
      showCyberSnackBar(context, "Gagal mengunduh gambar", isError: true);
    }
  }

  void _showImageDetail(String url) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: AppColors.borderLight.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              child: Image.network(
                url,
                height: MediaQuery.of(context).size.height * 0.5,
                fit: BoxFit.contain,
                loadingBuilder: (context, child, progress) => progress == null
                    ? child
                    : Container(
                        height: 200,
                        color: AppColors.surface2,
                        child: const Center(child: CyberLoadingShimmer()),
                      ),
                errorBuilder: (context, _, __) => Container(
                  height: 200,
                  color: AppColors.surface2,
                  child: const Icon(Icons.broken_image, color: AppColors.textMuted, size: 50),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: CyberButton(
                      label: "DOWNLOAD",
                      icon: Icons.download_rounded,
                      onTap: () {
                        Navigator.pop(context);
                        _downloadImage(url);
                      },
                      width: double.infinity,
                    ),
                  ),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.borderLight),
                      ),
                      child: const Text(
                        "CLOSE",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textMuted,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "PINTEREST",
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(Icons.image_rounded, color: AppColors.accent, size: 24),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    "Search and download Pinterest images",
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: // pinterest_downloader.dart - Perbaiki onSubmitted
                CyberInputField(
                  controller: _searchController,
                  label: "CARI GAMBAR",
                  hint: "Cari wallpaper, anime, aesthetic...",
                  icon: Icons.search_rounded,
                  onSubmitted: (String value) { // <--- UBAH KE String
                    _searchPinterest();
                  },
                ),
              ),
              const SizedBox(width: 12),
              CyberButton(
                label: "SEARCH",
                icon: Icons.search_rounded,
                onTap: _searchPinterest,
              ),
            ],
          ),
          const SizedBox(height: 16),

          if (_isLoading)
            const Center(child: CyberLoadingShimmer())
          else if (_error != null)
            GlassCard(
              padding: const EdgeInsets.all(16),
              borderColor: AppColors.red.withOpacity(0.3),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: AppColors.red, size: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _error!,
                      style: const TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            )
          else if (_images.isEmpty)
            const CyberEmptyState(
              title: "Cari Gambar",
              subtitle: "Masukkan kata kunci untuk mencari gambar Pinterest",
              icon: Icons.image_rounded,
            )
          else
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.8,
              ),
              itemCount: _images.length,
              itemBuilder: (context, index) {
                final url = _images[index];
                return TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0.0, end: 1.0),
                  duration: Duration(milliseconds: 300 + (index * 30).clamp(0, 600)),
                  curve: Curves.easeOutCubic,
                  builder: (context, value, _) => Opacity(
                    opacity: value,
                    child: Transform.translate(
                      offset: Offset(0, 20 * (1 - value)),
                      child: GestureDetector(
                        onTap: () => _showImageDetail(url),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: AppColors.borderLight),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.network(
                                  url,
                                  fit: BoxFit.cover,
                                  loadingBuilder: (context, child, progress) => progress == null
                                      ? child
                                      : Container(color: AppColors.surface2),
                                  errorBuilder: (context, _, __) => Container(
                                    color: AppColors.surface2,
                                    child: const Icon(Icons.broken_image, color: AppColors.textMuted, size: 40),
                                  ),
                                ),
                                Positioned(
                                  bottom: 0,
                                  left: 0,
                                  right: 0,
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                      ),
                                    ),
                                    child: Center(
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                        decoration: BoxDecoration(
                                          color: AppColors.accent.withOpacity(0.9),
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: const Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(Icons.download_rounded, color: Colors.white, size: 12),
                                            SizedBox(width: 4),
                                            Text(
                                              "Download",
                                              style: TextStyle(
                                                fontFamily: appFont,
                                                color: Colors.white,
                                                fontSize: 9,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}