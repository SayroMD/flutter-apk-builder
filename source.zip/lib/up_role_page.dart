import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'main.dart';
import 'setoran_config.dart';
import 'storan_theme.dart';

String get kUpRoleBaseUrl => '$baseUrl/api/up-role';

class UpRolePage extends StatefulWidget {
  final String sessionKey;

  const UpRolePage({super.key, required this.sessionKey});

  @override
  State<UpRolePage> createState() => _UpRolePageState();
}

class _UpRolePageState extends State<UpRolePage> {
  bool _loadingOptions = true;
  String? _currentRole;
  List<dynamic> _options = [];
  String? _selectedRole;

  String _status = 'form'; // form -> creating -> pending -> menunggu_review -> selesai | ditolak | expired
  String? _depositId;
  int? _amount;
  int? _selisih;
  DateTime? _expiresAt;
  Timer? _pollTimer;
  Timer? _tickTimer;
  Duration _remaining = Duration.zero;
  bool _uploading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadOptions();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadOptions() async {
    setState(() => _loadingOptions = true);
    try {
      final res = await http.get(Uri.parse('$kUpRoleBaseUrl/options?sessionKey=${widget.sessionKey}'));
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _currentRole = j['currentRole'];
          _options = j['options'];
          if (_options.isNotEmpty) _selectedRole = _options[0]['role'];
        });
      } else {
        setState(() => _error = j['error'] ?? 'Gagal load data');
      }
    } catch (e) {
      setState(() => _error = 'Gagal konek: $e');
    } finally {
      setState(() => _loadingOptions = false);
    }
  }

  Future<void> _submit() async {
    if (_selectedRole == null) return;
    setState(() => _status = 'creating');
    try {
      final res = await http.post(
        Uri.parse('$kUpRoleBaseUrl/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'sessionKey': widget.sessionKey, 'targetRole': _selectedRole}),
      );
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _depositId = j['depositId'];
          _amount = j['amount'];
          _selisih = j['selisih'];
          _expiresAt = DateTime.fromMillisecondsSinceEpoch(j['expiresAt']);
          _status = 'pending';
        });
        _startPolling();
        _startCountdown();
      } else {
        setState(() {
          _status = 'form';
          _error = j['error'] ?? 'Gagal bikin upgrade';
        });
      }
    } catch (e) {
      setState(() {
        _status = 'form';
        _error = 'Gagal konek: $e';
      });
    }
  }

  Future<void> _uploadBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null || _depositId == null) return;

    setState(() => _uploading = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$kUpRoleBaseUrl/upload-bukti'));
      req.fields['depositId'] = _depositId!;
      req.files.add(await http.MultipartFile.fromPath('bukti', picked.path));
      final streamed = await req.send();
      final res = await http.Response.fromStream(streamed);
      if (res.statusCode == 200) {
        setState(() => _status = 'menunggu_review');
      } else if (mounted) {
        final j = jsonDecode(res.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(j['error'] ?? 'Gagal upload')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal upload, coba lagi')));
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _startCountdown() {
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final diff = _expiresAt!.difference(DateTime.now());
      setState(() => _remaining = diff.isNegative ? Duration.zero : diff);
      if (diff.isNegative) _tickTimer?.cancel();
    });
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (_depositId == null) return;
      try {
        final res = await http.get(Uri.parse('$kUpRoleBaseUrl/status/$_depositId'));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          setState(() => _status = j['status']);
          if (['selesai', 'ditolak', 'expired'].contains(j['status'])) {
            _pollTimer?.cancel();
            _tickTimer?.cancel();
          }
        }
      } catch (_) {}
    });
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NBColors.bg,
      appBar: AppBar(
        backgroundColor: NBColors.bg,
        elevation: 0,
        title: const Text('UPGRADE ROLE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      ),
      body: SafeArea(
        child: _loadingOptions
            ? const Center(child: CircularProgressIndicator(color: NBColors.gold))
            : Padding(padding: const EdgeInsets.all(16), child: _buildBody()),
      ),
    );
  }

  Widget _buildBody() {
    if (_status == 'creating') return const Center(child: CircularProgressIndicator(color: NBColors.gold));
    if (_status == 'pending' || _status == 'menunggu_review') return _buildPayment();
    if (_status == 'selesai') {
      return Center(
        child: NBCard(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: NBColors.green, border: Border.all(color: Colors.black, width: 3)),
              child: const Icon(Icons.check_circle, color: Colors.black, size: 40),
            ),
            const SizedBox(height: 14),
            const Text('ROLE BERHASIL DI-UPGRADE!', style: TextStyle(color: NBColors.white, fontSize: 15, fontWeight: FontWeight.w900)),
          ]),
        ),
      );
    }
    if (_status == 'ditolak' || _status == 'expired') {
      final color = _status == 'ditolak' ? NBColors.red : NBColors.gold;
      return Center(
        child: NBCard(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: color, border: Border.all(color: Colors.black, width: 3)),
                child: Icon(_status == 'ditolak' ? Icons.cancel : Icons.timer_off, color: Colors.black, size: 40),
              ),
              const SizedBox(height: 14),
              Text(_status == 'ditolak' ? 'BUKTI DITOLAK ADMIN' : 'WAKTU TRANSFER HABIS',
                  style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
              const SizedBox(height: 16),
              NBButton(onPressed: () => setState(() => _status = 'form'), color: color, child: const Text('COBA LAGI')),
            ],
          ),
        ),
      );
    }
    return _buildForm();
  }

  Widget _buildForm() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NBCard(
            color: NBColors.surfaceAlt,
            child: const Text(
              'Naikkan role akun ANDA sendiri. Bayar selisih harga permanen antar role, lalu Owner ACC. Role lama tetap kamu miliki.',
              style: TextStyle(color: NBColors.textDim, fontSize: 12),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              const Text('ROLE SEKARANG:', style: TextStyle(color: NBColors.textDim, fontSize: 12, fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              NBBadge(text: _currentRole ?? '-', color: NBColors.gold),
            ],
          ),
          const SizedBox(height: 16),
          if (_options.isEmpty)
            NBCard(
              color: NBColors.surfaceAlt,
              child: const Text('Belum ada role yang bisa di-upgrade. Role lo udah tertinggi atau ada kendala.',
                  style: TextStyle(color: NBColors.textDim)),
            )
          else ...[
            const NBSectionLabel('TARGET ROLE BARU'),
            const SizedBox(height: 10),
            ..._options.map<Widget>((o) {
              final selected = o['role'] == _selectedRole;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: GestureDetector(
                  onTap: () => setState(() => _selectedRole = o['role']),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: selected ? NBColors.gold : NBColors.surface,
                      border: Border.all(color: Colors.black, width: 3),
                      boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(4, 4))] : null,
                    ),
                    child: Row(
                      children: [
                        Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
                            color: selected ? Colors.black : NBColors.textDim),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(o['role'],
                                  style: TextStyle(color: selected ? Colors.black : NBColors.white, fontWeight: FontWeight.w900)),
                              Text('Selisih: Rp${o['selisih']}',
                                  style: TextStyle(color: selected ? Colors.black87 : NBColors.textDim, fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: NBColors.red, fontSize: 12, fontWeight: FontWeight.bold)),
            ],
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: NBButton(
                onPressed: _submit,
                color: NBColors.gold,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: const Text('UPGRADE ROLE'),
              ),
            ),
          ],
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildPayment() {
    return Center(
      child: SingleChildScrollView(
        child: NBCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_status == 'pending') ...[
                const NBBadge(text: 'MENUNGGU TRANSFER', color: NBColors.gold),
                const SizedBox(height: 14),
                Text('Rp$_amount', style: const TextStyle(color: NBColors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                Text('(selisih Rp$_selisih)', style: const TextStyle(color: NBColors.textDim, fontSize: 12)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: Colors.black, border: Border.all(color: NBColors.red, width: 2)),
                  child: Text(_fmt(_remaining), style: const TextStyle(color: NBColors.red, fontSize: 24, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 20),
                const Text('Abis transfer, upload screenshot bukti', textAlign: TextAlign.center, style: TextStyle(color: NBColors.textDim)),
                const SizedBox(height: 14),
                _uploading
                    ? const CircularProgressIndicator(color: NBColors.gold)
                    : NBButton(
                        onPressed: _uploadBukti,
                        color: NBColors.gold,
                        child: const Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.upload, color: Colors.black, size: 18),
                          SizedBox(width: 8),
                          Text('UPLOAD BUKTI TRANSFER'),
                        ]),
                      ),
              ] else ...[
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: NBColors.gold, border: Border.all(color: Colors.black, width: 3)),
                  child: const Icon(Icons.hourglass_top, color: Colors.black, size: 36),
                ),
                const SizedBox(height: 14),
                const Text('Bukti diterima, lagi ditinjau admin.', style: TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
