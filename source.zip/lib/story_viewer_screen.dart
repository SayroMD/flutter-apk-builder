import 'dart:async';
import 'package:flutter/material.dart';
import 'story_model.dart';
import 'story_bar.dart';
import 'story_comments_sheet.dart';

class StoryViewerScreen extends StatefulWidget {
  final List<StoryGroup> groups;
  final int initialIndex;
  final String currentUsername;
  final Future<void> Function(String storyId)? onDelete;

  const StoryViewerScreen({
    super.key,
    required this.groups,
    required this.initialIndex,
    required this.currentUsername,
    this.onDelete,
  });

  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen>
    with SingleTickerProviderStateMixin {
  late int groupIndex;
  int storyIndex = 0;
  late AnimationController _controller;
  static const _duration = Duration(seconds: 4);

  StoryGroup get currentGroup => widget.groups[groupIndex];
  Story get currentStory => currentGroup.stories[storyIndex];
  bool get isOwnStory => currentGroup.userName == widget.currentUsername;

  @override
  void initState() {
    super.initState();
    groupIndex = widget.initialIndex;
    _controller = AnimationController(vsync: this, duration: _duration)
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) _next();
      });
    _startStory();
  }

  void _startStory() {
    _controller.reset();
    _controller.forward();
    setState(() => currentGroup.seen = true);
  }

  void _next() {
    if (storyIndex < currentGroup.stories.length - 1) {
      setState(() => storyIndex++);
      _startStory();
    } else if (groupIndex < widget.groups.length - 1) {
      setState(() {
        groupIndex++;
        storyIndex = 0;
      });
      _startStory();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (storyIndex > 0) {
      setState(() => storyIndex--);
      _startStory();
    } else if (groupIndex > 0) {
      setState(() {
        groupIndex--;
        storyIndex = widget.groups[groupIndex].stories.length - 1;
      });
      _startStory();
    } else {
      _startStory();
    }
  }

  void _pause() => _controller.stop();
  void _resume() => _controller.forward();

  Future<void> _deleteCurrentStory() async {
    _pause();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
          side: const BorderSide(color: kInk, width: 3),
        ),
        title: const Text(
          'HAPUS STORY INI?',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
        ),
        content: const Text('Story ini bakal dihapus permanen.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('BATAL',
                style: TextStyle(color: kInk, fontWeight: FontWeight.w900)),
          ),
          Container(
            decoration: BoxDecoration(
              color: kAccentRed,
              border: Border.all(color: kInk, width: 2),
              boxShadow: const [BoxShadow(color: kInk, offset: Offset(2, 2))],
            ),
            child: TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('HAPUS',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true && widget.onDelete != null) {
      await widget.onDelete!(currentStory.id);
      // kalau story terakhir di group ini, pop viewer
      if (currentGroup.stories.length <= 1) {
        if (mounted) Navigator.pop(context);
      } else {
        // hapus dari list lokal, lanjut ke story berikutnya
        currentGroup.stories.removeAt(storyIndex);
        if (storyIndex >= currentGroup.stories.length) {
          storyIndex = currentGroup.stories.length - 1;
        }
        _startStory();
      }
    } else {
      _resume();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inHours >= 1) return '${diff.inHours}j';
    if (diff.inMinutes >= 1) return '${diff.inMinutes}m';
    return 'baru';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            border: Border.all(color: kInk, width: 4),
            boxShadow: const [BoxShadow(color: kInk, offset: Offset(6, 6))],
          ),
          child: GestureDetector(
            onVerticalDragEnd: (details) {
              if (details.primaryVelocity != null && details.primaryVelocity! < -300) {
                _pause();
                showStoryComments(context, currentStory.id).then((_) => _resume());
              }
            },
            child: Stack(
            fit: StackFit.expand,
            children: [
              Image.network(currentStory.mediaUrl, fit: BoxFit.cover),

              // progress bar segmented
              Positioned(
                top: 8,
                left: 8,
                right: 8,
                child: Row(
                  children: List.generate(currentGroup.stories.length, (i) {
                    return Expanded(
                      child: Container(
                        height: 6,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          border: Border.all(color: kInk, width: 2),
                          color: Colors.white.withOpacity(0.4),
                        ),
                        child: i < storyIndex
                            ? Container(color: kAccentRed)
                            : i == storyIndex
                                ? AnimatedBuilder(
                                    animation: _controller,
                                    builder: (_, __) => FractionallySizedBox(
                                      alignment: Alignment.centerLeft,
                                      widthFactor: _controller.value,
                                      child: Container(color: kAccentYellow),
                                    ),
                                  )
                                : const SizedBox(),
                      ),
                    );
                  }),
                ),
              ),

              // header
              Positioned(
                top: 22,
                left: 8,
                right: 8,
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: kInk, width: 2),
                      ),
                      child: ClipOval(
                        child: currentGroup.avatarUrl.isNotEmpty
                            ? Image.network(currentGroup.avatarUrl, fit: BoxFit.cover)
                            : Container(
                                color: kAccentYellow,
                                child: Center(
                                  child: Text(
                                    currentGroup.userName[0].toUpperCase(),
                                    style: const TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: kAccentYellow,
                        border: Border.all(color: kInk, width: 2),
                        boxShadow: const [BoxShadow(color: kInk, offset: Offset(2, 2))],
                      ),
                      child: Text(
                        currentGroup.userName.toUpperCase(),
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      color: Colors.black.withOpacity(0.5),
                      child: Text(
                        _timeAgo(currentStory.createdAt),
                        style: const TextStyle(
                            fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white),
                      ),
                    ),
                    const Spacer(),
                    // tombol hapus — muncul cuma kalau story milik sendiri
                    if (isOwnStory)
                      GestureDetector(
                        onTap: _deleteCurrentStory,
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: kAccentRed,
                            border: Border.all(color: kInk, width: 2),
                            boxShadow: const [BoxShadow(color: kInk, offset: Offset(2, 2))],
                          ),
                          child: const Icon(Icons.delete, color: Colors.white, size: 18),
                        ),
                      ),
                  ],
                ),
              ),

              // tap zones
              Positioned.fill(
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: _prev,
                        onLongPressStart: (_) => _pause(),
                        onLongPressEnd: (_) => _resume(),
                        behavior: HitTestBehavior.translucent,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: GestureDetector(
                        onLongPressStart: (_) => _pause(),
                        onLongPressEnd: (_) => _resume(),
                        behavior: HitTestBehavior.translucent,
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: _next,
                        onLongPressStart: (_) => _pause(),
                        onLongPressEnd: (_) => _resume(),
                        behavior: HitTestBehavior.translucent,
                      ),
                    ),
                  ],
                ),
              ),

              // bottom bar: swipe hint + tombol komentar
              Positioned(
                bottom: 10,
                left: 8,
                right: 8,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // swipe up hint
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.keyboard_arrow_up, color: Colors.white70, size: 16),
                        SizedBox(width: 4),
                        Text(
                          'Swipe up untuk komentar',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              _pause();
                              showStoryComments(context, currentStory.id)
                                  .then((_) => _resume());
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.9),
                                border: Border.all(color: kInk, width: 3),
                                boxShadow: const [BoxShadow(color: kInk, offset: Offset(3, 3))],
                              ),
                              child: const Text(
                                'Tulis komentar...',
                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.black45),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            _pause();
                            showStoryComments(context, currentStory.id)
                                .then((_) => _resume());
                          },
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: kAccentYellow,
                              border: Border.all(color: kInk, width: 3),
                              boxShadow: const [BoxShadow(color: kInk, offset: Offset(3, 3))],
                            ),
                            child: const Icon(Icons.chat_bubble_outline, color: kInk, size: 20),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          ),
        ),
      ),
    );
  }
}
