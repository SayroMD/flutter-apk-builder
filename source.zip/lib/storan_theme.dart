import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Neo-brutalism design tokens khusus fitur STORAN.
/// Thick border, zero radius, hard offset shadow (no blur), palet
/// charcoal/white/red/gold — konsisten sama gaya neo brutalism Otax.
class NBColors {
  static const bg = Color(0xFF1A1A1A);
  static const surface = Color(0xFF232323);
  static const surfaceAlt = Color(0xFF2E2E2E);
  static const border = Colors.black;
  static const red = Color(0xFFD7263D);
  static const gold = Color(0xFFE8B923);
  static const white = Color(0xFFF5F5F5);
  static const textDim = Color(0xFFB8B8B8);
  static const green = Color(0xFF2ECC71);
}

const _kBorderWidth = 3.0;

BoxDecoration nbCardDecoration({Color? color, Color borderColor = NBColors.border, Offset shadowOffset = const Offset(5, 5)}) {
  return BoxDecoration(
    color: color ?? NBColors.surface,
    border: Border.all(color: borderColor, width: _kBorderWidth),
    boxShadow: [BoxShadow(color: Colors.black, offset: shadowOffset, blurRadius: 0)],
  );
}

/// Card neo brutalism generik.
class NBCard extends StatelessWidget {
  final Widget child;
  final Color? color;
  final EdgeInsetsGeometry padding;
  final Offset shadowOffset;

  const NBCard({
    super.key,
    required this.child,
    this.color,
    this.padding = const EdgeInsets.all(14),
    this.shadowOffset = const Offset(5, 5),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: shadowOffset.dx, bottom: shadowOffset.dy),
      padding: padding,
      decoration: nbCardDecoration(color: color, shadowOffset: shadowOffset),
      child: child,
    );
  }
}

/// Tombol neo brutalism: border tebal, sudut kotak, shadow keras, nge-"tekan"
/// (shadow ilang & bergeser) pas ditap.
class NBButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final Color color;
  final Color textColor;
  final EdgeInsetsGeometry padding;

  const NBButton({
    super.key,
    required this.child,
    required this.onPressed,
    this.color = NBColors.gold,
    this.textColor = Colors.black,
    this.padding = const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
  });

  @override
  State<NBButton> createState() => _NBButtonState();
}

class _NBButtonState extends State<NBButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final disabled = widget.onPressed == null;
    return GestureDetector(
      onTapDown: disabled ? null : (_) => setState(() => _pressed = true),
      onTapUp: disabled ? null : (_) => setState(() => _pressed = false),
      onTapCancel: disabled ? null : () => setState(() => _pressed = false),
      onTap: widget.onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        margin: EdgeInsets.only(right: _pressed ? 0 : 4, bottom: _pressed ? 0 : 4, left: _pressed ? 4 : 0, top: _pressed ? 4 : 0),
        padding: widget.padding,
        decoration: BoxDecoration(
          color: disabled ? NBColors.surfaceAlt : widget.color,
          border: Border.all(color: Colors.black, width: _kBorderWidth),
          boxShadow: _pressed ? [] : const [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)],
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: disabled ? NBColors.textDim : widget.textColor,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.5,
          ),
          child: Center(widthFactor: 1, child: widget.child),
        ),
      ),
    );
  }
}

/// Badge/chip kotak buat status atau label kecil.
class NBBadge extends StatelessWidget {
  final String text;
  final Color color;
  final Color textColor;

  const NBBadge({super.key, required this.text, this.color = NBColors.gold, this.textColor = Colors.black});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: Colors.black, width: 2),
      ),
      child: Text(text, style: TextStyle(color: textColor, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 0.5)),
    );
  }
}

/// Header section — garis tebal vertikal + label, konsisten sama referensi.
class NBSectionLabel extends StatelessWidget {
  final String text;

  const NBSectionLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 5, height: 16, color: NBColors.gold),
        const SizedBox(width: 8),
        Text(text, style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 0.5)),
      ],
    );
  }
}

/// Kartu pembayaran neo-brutalism: gambar QRIS + tombol unduh,
/// nomor DANA (bisa disalin), dan instruksi bernomor. Dipake di
/// semua alur bayar (Storan, Up Role, Up Role Buyer).
class NBPaymentCard extends StatelessWidget {
  final String qrisUrl;
  final String danaNumber;
  final String danaName;

  const NBPaymentCard({super.key, required this.qrisUrl, required this.danaNumber, required this.danaName});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        NBCard(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              ClipRRect(
                child: Image.network(
                  qrisUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    height: 180,
                    alignment: Alignment.center,
                    child: const Text('QRIS belum diupload admin', style: TextStyle(color: NBColors.textDim, fontSize: 11)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: NBButton(
                  color: NBColors.surfaceAlt,
                  textColor: NBColors.red,
                  onPressed: () => _downloadQris(context, qrisUrl),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.download, color: NBColors.red, size: 16),
                    SizedBox(width: 8),
                    Text('UNDUH QRIS'),
                  ]),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        NBCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('NO. DANA', style: TextStyle(color: NBColors.textDim, fontSize: 11, fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      Text(danaNumber, style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: danaNumber));
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nomor disalin')));
                        },
                        child: const Icon(Icons.copy, color: NBColors.gold, size: 16),
                      ),
                    ],
                  ),
                ],
              ),
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(color: Color(0xFF2A2A2A), height: 1)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('A/N', style: TextStyle(color: NBColors.textDim, fontSize: 11, fontWeight: FontWeight.bold)),
                  Text(danaName, style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.w900, fontSize: 13)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        NBCard(
          color: NBColors.surfaceAlt,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              _NBStep(1, 'Transfer sesuai nominal ke QRIS / DANA'),
              _NBStep(2, 'Upload bukti transfer di bawah'),
              _NBStep(3, 'Submit — notif otomatis ke admin'),
              _NBStep(4, 'Tunggu ACC — role/akun auto update di app'),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _downloadQris(BuildContext context, String url) async {
    try {
      final res = await http.get(Uri.parse(url));
      if (res.statusCode != 200) throw Exception('gagal ambil gambar');
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/qris_payment.jpg');
      await file.writeAsBytes(res.bodyBytes);
      await Share.shareXFiles([XFile(file.path)], text: 'QRIS Pembayaran');
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal unduh QRIS: $e')));
      }
    }
  }
}

class _NBStep extends StatelessWidget {
  final int number;
  final String text;
  const _NBStep(this.number, this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 20,
            height: 20,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: NBColors.red, border: Border.all(color: Colors.black, width: 2)),
            child: Text('$number', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(color: NBColors.white, fontSize: 12))),
        ],
      ),
    );
  }
}

InputDecoration nbInputDecoration(String hint, {IconData? icon}) {
  return InputDecoration(
    hintText: hint,
    hintStyle: const TextStyle(color: NBColors.textDim),
    prefixIcon: icon != null ? Icon(icon, color: NBColors.gold) : null,
    filled: true,
    fillColor: NBColors.surfaceAlt,
    border: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: const BorderSide(color: Colors.black, width: _kBorderWidth)),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: const BorderSide(color: Colors.black, width: _kBorderWidth)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: const BorderSide(color: NBColors.gold, width: _kBorderWidth)),
    contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
  );
}
