import 'dart:async';
import 'dart:convert';
import 'dart:math' as dart_math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String appFont = 'Orbitron';

// ==================== APP COLORS ====================
class AppColors {
  static const bg          = Color(0xFF060B19); 
  static const surface     = Color(0xFF0D1424);
  static const surface2    = Color(0xFF131D33);
  static const borderLight = Color(0xFF3B4859); 
  static const accent      = Color(0xFF00E5FF); // Tema Utama Cyan
  static const darkBlue    = Color(0xFF0044CC);
  static const textMuted   = Color(0xFF8B9BB4);
}

// ==================== BACKGROUND HEXAGON 3D ====================
class _HexagonBackground extends StatelessWidget {
  final Widget child;
  const _HexagonBackground({required this.child});
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: const Color(0xFF030712)),
        Positioned(
          top: -150, left: -150,
          child: Container(
            width: 400, height: 400,
            decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.accent.withOpacity(0.12), blurRadius: 200)]),
          ),
        ),
        Positioned(
          bottom: -150, right: -150,
          child: Container(
            width: 400, height: 400,
            decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.darkBlue.withOpacity(0.25), blurRadius: 200)]),
          ),
        ),
        Positioned.fill(child: CustomPaint(painter: _HexagonPainter())),
        child,
      ],
    );
  }
}

class _HexagonPainter extends CustomPainter {
  void drawHexagon(Canvas canvas, Paint paint, double x, double y, double size) {
    final path = Path();
    for (int i = 0; i <= 6; i++) {
      double angle = (i * 60) * dart_math.pi / 180;
      double px = x + size * dart_math.cos(angle);
      double py = y + size * dart_math.sin(angle);
      if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
    }
    path.close(); canvas.drawPath(path, paint);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final fillPaint = Paint()..color = AppColors.accent.withOpacity(0.04)..style = PaintingStyle.fill;
    final strokePaint = Paint()..color = AppColors.accent.withOpacity(0.15)..style = PaintingStyle.stroke..strokeWidth = 2.5;
    double hexSize = 45.0;
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        double x = size.width - 20 + (i * 78) - (j * 39);
        double y = -20.0 + (j * 68) + (i * 34);
        drawHexagon(canvas, fillPaint, x, y, hexSize); drawHexagon(canvas, strokePaint, x, y, hexSize);
      }
    }
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        double x = -40.0 + (i * 78) - (j * 39);
        double y = size.height - 150 + (j * 68) + (i * 34);
        drawHexagon(canvas, fillPaint, x, y, hexSize); drawHexagon(canvas, strokePaint, x, y, hexSize);
      }
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==================== SCREEN UTAMA STREAMING ====================
class Hentaii extends StatefulWidget {
  const Hentaii({super.key});

  @override
  State<Hentaii> createState() => _HentaiiState();
}

class _HentaiiState extends State<Hentaii> {
  bool _isBlocked = false;
  bool _isLoading = true;
  List<Map<String, String>> _movies = [];
  List<Map<String, String>> _filteredMovies = [];
  List<Map<String, String>> _watchHistory = []; 
  final TextEditingController _searchController = TextEditingController();

  final List<String> _categories = ["All", "Action", "Romance", "Harem", "School", "Fantasy", "Drama"];
  String _selectedCategory = "All";

  @override
  void initState() {
    super.initState();
    _checkTimeRestriction();
    _loadWatchHistory();
    if (!_isBlocked) {
      _fetchMoviesFromRSS();
    }
  }

  void _checkTimeRestriction() {
    DateTime now = DateTime.now();
    int hour = now.hour;
    if (hour >= 23 || hour < 3) {
      setState(() => _isBlocked = true);
    }
  }

  Future<void> _loadWatchHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final String? historyString = prefs.getString('watch_history');
    if (historyString != null) {
      final List<dynamic> decoded = jsonDecode(historyString);
      if (mounted) {
        setState(() {
          _watchHistory = decoded.map((e) => Map<String, String>.from(e)).toList();
        });
      }
    }
  }

  Future<void> _addToHistory(Map<String, String> movie) async {
    setState(() {
      _watchHistory.removeWhere((m) => m['slug'] == movie['slug']);
      _watchHistory.insert(0, movie);
      if (_watchHistory.length > 10) _watchHistory.removeLast(); 
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('watch_history', jsonEncode(_watchHistory));
  }

  Future<void> _fetchMoviesFromRSS() async {
    try {
      final res = await http.get(Uri.parse('https://hentaiocean.com/rss.xml'));
      if (res.statusCode == 200) {
        RegExp itemRegExp = RegExp(r'<item>(.*?)</item>', dotAll: true);
        RegExp titleRegExp = RegExp(r'<title><!\[CDATA\[(.*?)\]\]></title>|<title>(.*?)</title>');
        RegExp linkRegExp = RegExp(r'<link>(.*?)</link>');
        RegExp imgRegExp = RegExp(r'<img[^>]+src="([^">]+)"');

        List<Map<String, String>> temp = [];
        var items = itemRegExp.allMatches(res.body);

        for (var match in items) {
          String itemContent = match.group(1) ?? '';
          
          var titleMatch = titleRegExp.firstMatch(itemContent);
          String title = titleMatch?.group(1) ?? titleMatch?.group(2) ?? 'Unknown';

          var linkMatch = linkRegExp.firstMatch(itemContent);
          String link = linkMatch?.group(1) ?? '';
          String slug = '';
          var slugMatch = RegExp(r'/watch/([^/?]+)').firstMatch(link);
          if (slugMatch != null) slug = slugMatch.group(1)!;

          var imgMatch = imgRegExp.firstMatch(itemContent);
          String cover = imgMatch?.group(1) ?? '';

          if (slug.isNotEmpty) {
            temp.add({'title': title, 'slug': slug, 'cover': cover});
          }
        }

        if (mounted) {
          setState(() {
            _movies = temp;
            _filteredMovies = temp;
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _filterSearch(String query) {
    if (query.isEmpty) {
      setState(() => _filteredMovies = _movies);
      return;
    }
    setState(() {
      _filteredMovies = _movies.where((m) => m['title']!.toLowerCase().contains(query.toLowerCase())).toList();
    });
  }

  void _navigateToWatch(Map<String, String> movie) {
    _addToHistory(movie);
    Navigator.push(context, MaterialPageRoute(builder: (context) => WatchScreen(movie: movie)));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: _HexagonBackground(
        child: Stack(
          children: [
            SafeArea(
              child: _isLoading
                  ? Column(
                      children: [
                        _buildHeader(),
                        const Expanded(child: Center(child: CircularProgressIndicator(color: AppColors.accent))),
                      ],
                    )
                  : CustomScrollView(
                      physics: const BouncingScrollPhysics(),
                      slivers: [
                        SliverToBoxAdapter(child: _buildHeader()),
                        if (_watchHistory.isNotEmpty) SliverToBoxAdapter(child: _buildLatestShows()),
                        SliverToBoxAdapter(child: _buildSearchArea()),
                        SliverToBoxAdapter(child: _buildCategories()),
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                            child: Row(
                              children: [
                                const Icon(Icons.movie_filter_rounded, color: AppColors.accent, size: 20),
                                const SizedBox(width: 8),
                                Text("Movie Film (${_filteredMovies.length})", style: const TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                        _buildMovieGrid(),
                        const SliverToBoxAdapter(child: SizedBox(height: 30)),
                      ],
                    ),
            ),

            if (_isBlocked)
              Positioned.fill(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                  child: Container(
                    color: Colors.black.withOpacity(0.6),
                    child: Center(
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 24),
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.redAccent, width: 2),
                          boxShadow: [
                            BoxShadow(color: Colors.redAccent.withOpacity(0.3), blurRadius: 30, spreadRadius: 5)
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 60),
                            const SizedBox(height: 16),
                            const Text(
                              "PERINGATAN",
                              style: TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              "Halaman Ini Kami Tutup Oleh Team AproZeus Invitus.\n\nDemi keamanan dan menjaga agar tidak ada hal yang tak terduga, halaman ini akan kami buka kembali besok pukul 3-7 pagi.",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontFamily: appFont, color: Colors.white70, fontSize: 12, height: 1.5),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      decoration: BoxDecoration(
        color: AppColors.surface.withOpacity(0.8),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borderLight),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10)],
      ),
      child: Column(
        children: [
          const Icon(Icons.movie_creation_rounded, color: AppColors.accent, size: 28),
          const SizedBox(height: 8),
          RichText(
            text: const TextSpan(
              style: TextStyle(fontFamily: appFont, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.5),
              children: [
                TextSpan(text: 'HE', style: TextStyle(color: Colors.white)),
                TextSpan(text: 'NTAI ', style: TextStyle(color: AppColors.accent, shadows: [Shadow(color: AppColors.accent, blurRadius: 10)])),
                TextSpan(text: 'STRE', style: TextStyle(color: AppColors.accent, shadows: [Shadow(color: AppColors.accent, blurRadius: 10)])),
                TextSpan(text: 'MING', style: TextStyle(color: Colors.white)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Pusat streaming eksklusif berkualitas HD. Temukan berbagai koleksi video pilihan, dan pastikan koneksi internet Anda stabil untuk pengalaman menonton terbaik tanpa gangguan buffering.",
            textAlign: TextAlign.center,
            style: TextStyle(fontFamily: appFont, color: AppColors.textMuted, fontSize: 10, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _buildLatestShows() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: const [
              Icon(Icons.replay_circle_filled_rounded, color: AppColors.accent, size: 18),
              SizedBox(width: 8),
              Text("Latest Shows", style: TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 180,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _watchHistory.length,
            itemBuilder: (context, index) {
              final m = _watchHistory[index];
              final imgUrl = m['slug'] != null && m['slug']!.isNotEmpty ? 'https://hentaiocean.com/thumbnail/${m['slug']}.webp' : m['cover'] ?? '';
              
              return GestureDetector(
                onTap: () => _navigateToWatch(m),
                child: Container(
                  width: 220,
                  margin: const EdgeInsets.only(right: 14),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderLight)),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            Image.network(
                              imgUrl, 
                              fit: BoxFit.cover, 
                              cacheWidth: 300, 
                              errorBuilder: (_, __, ___) => Container(color: Colors.black45, child: const Icon(Icons.broken_image, color: Colors.white24))
                            ),
                            Positioned(bottom: 8, right: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(6)), child: const Text("Play", style: TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 9)))),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(m['title'] ?? 'Unknown', style: const TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Row(
                              children: const [
                                Icon(Icons.access_time_rounded, color: AppColors.accent, size: 10),
                                SizedBox(width: 4),
                                Text("Terakhir ditonton", style: TextStyle(fontFamily: appFont, color: AppColors.accent, fontSize: 9)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSearchArea() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
      child: Container(
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderLight)),
        child: TextField(
          controller: _searchController,
          onChanged: _filterSearch,
          style: const TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 13),
          decoration: InputDecoration(
            hintText: "Cari judul...",
            hintStyle: TextStyle(fontFamily: appFont, color: Colors.white.withOpacity(0.4), fontSize: 13),
            prefixIcon: const Icon(Icons.search_rounded, color: AppColors.accent),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      ),
    );
  }

  Widget _buildCategories() {
    return SizedBox(
      height: 35,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final isSelected = _selectedCategory == _categories[index];
          return GestureDetector(
            onTap: () => setState(() => _selectedCategory = _categories[index]),
            child: Container(
              margin: const EdgeInsets.only(right: 10),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? AppColors.accent : AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: isSelected ? AppColors.accent : AppColors.borderLight),
                boxShadow: isSelected ? [BoxShadow(color: AppColors.accent.withOpacity(0.3), blurRadius: 8)] : [],
              ),
              child: Center(
                child: Text(_categories[index], style: TextStyle(fontFamily: appFont, color: isSelected ? AppColors.bg : Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMovieGrid() {
    if (_filteredMovies.isEmpty) {
      return SliverToBoxAdapter(
        child: const Padding(padding: EdgeInsets.all(40), child: Center(child: Text("Tidak ada video ditemukan", style: TextStyle(color: Colors.white54)))),
      );
    }

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.8,
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
        ),
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            final m = _filteredMovies[index];
            final imgUrl = m['slug'] != null && m['slug']!.isNotEmpty ? 'https://hentaiocean.com/thumbnail/${m['slug']}.webp' : (m['cover'] ?? '');
            
            return GestureDetector(
              onTap: () => _navigateToWatch(m),
              child: Container(
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderLight)),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 3,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.network(
                            imgUrl, 
                            fit: BoxFit.cover,
                            cacheWidth: 300, 
                            errorBuilder: (_, __, ___) => Container(color: Colors.black45, child: const Icon(Icons.broken_image, color: Colors.white24))
                          ),
                          Positioned(top: 8, right: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: AppColors.accent.withOpacity(0.8), borderRadius: BorderRadius.circular(6)), child: const Text("HD", style: TextStyle(fontFamily: appFont, color: AppColors.bg, fontSize: 9, fontWeight: FontWeight.bold)))),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(m['title']!, style: const TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
          childCount: _filteredMovies.length,
        ),
      ),
    );
  }
}

// ==================== HALAMAN NONTON (WATCH SCREEN) ====================
class WatchScreen extends StatefulWidget {
  final Map<String, String> movie;
  const WatchScreen({super.key, required this.movie});

  @override
  State<WatchScreen> createState() => _WatchScreenState();
}

class _WatchScreenState extends State<WatchScreen> {
  late final WebViewController _controller;
  bool _isLoadingVideo = true;

  // Script JS untuk mencegah auto-pause via Visibility API
  static const String _antiPauseScript = '''
    (function() {
      // Paksa document selalu dianggap "visible" oleh browser
      try {
        Object.defineProperty(document, 'hidden', {
          get: function() { return false; }, configurable: true
        });
        Object.defineProperty(document, 'visibilityState', {
          get: function() { return 'visible'; }, configurable: true
        });
        Object.defineProperty(document, 'webkitHidden', {
          get: function() { return false; }, configurable: true
        });
        Object.defineProperty(document, 'webkitVisibilityState', {
          get: function() { return 'visible'; }, configurable: true
        });
      } catch(e) {}

      // Blokir semua listener visibilitychange sebelum & sesudah load
      var _origDocAdd = EventTarget.prototype.addEventListener;
      EventTarget.prototype.addEventListener = function(type, listener, opts) {
        if (type === 'visibilitychange' || type === 'webkitvisibilitychange') return;
        return _origDocAdd.call(this, type, listener, opts);
      };

      // Cegah dispatchEvent visibilitychange
      var _origDispatch = EventTarget.prototype.dispatchEvent;
      EventTarget.prototype.dispatchEvent = function(event) {
        if (event && (event.type === 'visibilitychange' || event.type === 'webkitvisibilitychange')) return true;
        return _origDispatch.call(this, event);
      };

      // Jaga video tetap bermain jika ter-pause oleh sistem (bukan user)
      function keepPlaying() {
        document.querySelectorAll('video').forEach(function(v) {
          if (v.paused && !v._userPaused) {
            v.play().catch(function(){});
          }
        });
      }

      // Tandai pause yang disengaja user vs otomatis sistem
      document.addEventListener('click', function(e) {
        var el = e.target;
        while (el) {
          if (el.tagName === 'VIDEO') { el._userPaused = el.paused ? false : true; break; }
          el = el.parentElement;
        }
      }, true);

      setInterval(keepPlaying, 800);
    })();
  ''';

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel(
        'FlutterChannel',
        onMessageReceived: (_) {},
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            // Inject sedini mungkin agar script aktif sebelum player load
            _controller.runJavaScript(_antiPauseScript);
          },
          onPageFinished: (url) {
            // Inject ulang setelah halaman selesai untuk memastikan script aktif
            _controller.runJavaScript(_antiPauseScript).then((_) {
              if (mounted) setState(() => _isLoadingVideo = false);
            });
          },
        ),
      );

    // HTML dengan script anti-pause yang sudah tertanam langsung
    final String htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { width: 100%; height: 100%; background: #000; overflow: hidden; }
        iframe { width: 100vw; height: 100vh; border: none; display: block; }
      </style>
      <script>
        // Anti-pause dijalankan SEBELUM iframe load
        (function() {
          try {
            Object.defineProperty(document, 'hidden', { get: function(){ return false; }, configurable: true });
            Object.defineProperty(document, 'visibilityState', { get: function(){ return 'visible'; }, configurable: true });
            Object.defineProperty(document, 'webkitHidden', { get: function(){ return false; }, configurable: true });
            Object.defineProperty(document, 'webkitVisibilityState', { get: function(){ return 'visible'; }, configurable: true });
          } catch(e) {}

          var _origAdd = EventTarget.prototype.addEventListener;
          EventTarget.prototype.addEventListener = function(type, listener, opts) {
            if (type === 'visibilitychange' || type === 'webkitvisibilitychange') return;
            return _origAdd.call(this, type, listener, opts);
          };

          var _origDispatch = EventTarget.prototype.dispatchEvent;
          EventTarget.prototype.dispatchEvent = function(event) {
            if (event && (event.type === 'visibilitychange' || event.type === 'webkitvisibilitychange')) return true;
            return _origDispatch.call(this, event);
          };
        })();
      </script>
    </head>
    <body>
      <iframe 
        src="https://hentaiocean.com/embed/${widget.movie['slug']}" 
        allow="autoplay; fullscreen; encrypted-media" 
        allowfullscreen="true" 
        webkitallowfullscreen="true" 
        mozallowfullscreen="true"
        scrolling="no">
      </iframe>
    </body>
    </html>
    ''';

    _controller.loadHtmlString(htmlContent);
  }

  @override
  Widget build(BuildContext context) {
    // build() TIDAK DIUBAH sama sekali
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: AppColors.surface.withOpacity(0.8),
        elevation: 0,
        title: const Text("Streaming Player", style: TextStyle(fontFamily: appFont, fontSize: 14, color: Colors.white)),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _HexagonBackground(
        child: Column(
          children: [
            const SizedBox(height: 80),
            Container(
              width: double.infinity,
              height: 250,
              color: Colors.black,
              child: Stack(
                children: [
                  WebViewWidget(controller: _controller),
                  if (_isLoadingVideo)
                    const Center(child: CircularProgressIndicator(color: AppColors.accent)),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.movie['title']!, style: const TextStyle(fontFamily: appFont, color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.borderLight, borderRadius: BorderRadius.circular(6)), child: const Text("Hentai", style: TextStyle(fontFamily: appFont, color: Colors.white70, fontSize: 10))),
                          const SizedBox(width: 8),
                          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.borderLight, borderRadius: BorderRadius.circular(6)), child: const Text("HD 1080p", style: TextStyle(fontFamily: appFont, color: Colors.white70, fontSize: 10))),
                        ],
                      ),
                      const SizedBox(height: 30),
                      const Text("Deskripsi", style: TextStyle(fontFamily: appFont, color: AppColors.accent, fontSize: 14, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      const Text(
                        "Video saat ini sedang dimuat dan diputar di dalam *player* utama. Sistem kami telah dioptimalkan agar video berjalan dengan lancar dan stabil di dalam aplikasi tanpa adanya gangguan *pop-up* yang mengganggu.\n\nSelamat menikmati tayangan Anda dan pastikan koneksi internet yang digunakan stabil untuk mendapatkan resolusi maksimal tanpa terputus.", 
                        style: TextStyle(fontFamily: appFont, color: Colors.white54, fontSize: 12, height: 1.5)
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}