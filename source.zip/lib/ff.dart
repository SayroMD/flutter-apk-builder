// ff.dart - CYBER STYLE
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'base_page.dart';

class FreeFireToolsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const FreeFireToolsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<FreeFireToolsPage> createState() => _FreeFireToolsPageState();
}

class _FreeFireToolsPageState extends State<FreeFireToolsPage> {
  final List<String> servers = ['ind', 'sg', 'br', 'vn', 'th', 'ph', 'id', 'my', 'us', 'eu'];
  final List<String> matchModes = ['CAREER', 'NORMAL', 'RANKED'];
  final List<String> gameModes = ['br', 'cs'];

  final TextEditingController _uidController = TextEditingController();
  final TextEditingController _uidController2 = TextEditingController();
  final TextEditingController _keywordController = TextEditingController();
  final TextEditingController _callSignController = TextEditingController(text: '7');

  String _selectedServer = 'ind';
  String _selectedMatchMode = 'CAREER';
  String _selectedGameMode = 'br';
  String _selectedServer2 = 'ind';
  String _selectedServer3 = 'ind';
  bool _needGalleryInfo = true;

  bool _isLoading1 = false;
  bool _isLoading2 = false;
  bool _isLoading3 = false;

  String _response1 = '';
  String _response2 = '';
  String _response3 = '';

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: 'FREE FIRE',
      showBackButton: true,
      contentPadding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Header Info
          GlassCard(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                  ),
                  child: const Icon(Icons.sports_esports, color: AppColors.accent, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Tools Searching Player Free Fire',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Cari data player, profil, dan akun Free Fire',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textSec,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                StatusBadge(label: 'ONLINE', isOnline: true),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Tool 1: Player Stats
          _buildToolCard(
            title: 'STATISTIK PLAYER',
            subtitle: 'Ambil data statistik player lengkap',
            icon: Icons.bar_chart,
            isLoading: _isLoading1,
            response: _response1,
            content: Column(
              children: [
                CyberInputField(
                  controller: _uidController,
                  label: 'UID PLAYER',
                  hint: 'Masukkan UID player...',
                  icon: Icons.person,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _buildCyberDropdown(
                      label: 'SERVER',
                      value: _selectedServer,
                      items: servers,
                      onChanged: (v) => setState(() => _selectedServer = v!),
                    )),
                    const SizedBox(width: 12),
                    Expanded(child: _buildCyberDropdown(
                      label: 'MATCH MODE',
                      value: _selectedMatchMode,
                      items: matchModes,
                      onChanged: (v) => setState(() => _selectedMatchMode = v!),
                    )),
                  ],
                ),
                const SizedBox(height: 12),
                _buildCyberDropdown(
                  label: 'GAME MODE',
                  value: _selectedGameMode,
                  items: gameModes,
                  onChanged: (v) => setState(() => _selectedGameMode = v!),
                ),
              ],
            ),
            onExecute: _getPlayerStats,
          ),
          const SizedBox(height: 16),

          // Tool 2: Player Profile
          _buildToolCard(
            title: 'PROFIL PLAYER',
            subtitle: 'Lihat profil dan gallery player',
            icon: Icons.person_search,
            isLoading: _isLoading2,
            response: _response2,
            content: Column(
              children: [
                CyberInputField(
                  controller: _uidController2,
                  label: 'UID PLAYER',
                  hint: 'Masukkan UID player...',
                  icon: Icons.person,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _buildCyberDropdown(
                      label: 'SERVER',
                      value: _selectedServer2,
                      items: servers,
                      onChanged: (v) => setState(() => _selectedServer2 = v!),
                    )),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CyberInputField(
                        controller: _callSignController,
                        label: 'CALL SIGN',
                        hint: 'Default: 7',
                        icon: Icons.numbers,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.image, color: AppColors.accent, size: 18),
                      const SizedBox(width: 12),
                      Text(
                        'PERLU INFO GALLERY',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textSec,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      Switch(
                        value: _needGalleryInfo,
                        onChanged: (v) => setState(() => _needGalleryInfo = v),
                        activeColor: AppColors.accent,
                        activeTrackColor: AppColors.accent.withOpacity(0.3),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            onExecute: _getPlayerPersonalShow,
          ),
          const SizedBox(height: 16),

          // Tool 3: Search Account
          _buildToolCard(
            title: 'CARI AKUN',
            subtitle: 'Cari player berdasarkan nickname',
            icon: Icons.search,
            isLoading: _isLoading3,
            response: _response3,
            content: Column(
              children: [
                CyberInputField(
                  controller: _keywordController,
                  label: 'KEYWORD NICKNAME',
                  hint: 'Masukkan nickname player...',
                  icon: Icons.search,
                ),
                const SizedBox(height: 12),
                _buildCyberDropdown(
                  label: 'SERVER',
                  value: _selectedServer3,
                  items: servers,
                  onChanged: (v) => setState(() => _selectedServer3 = v!),
                ),
              ],
            ),
            onExecute: _searchAccountByKeyword,
          ),
        ],
      ),
    );
  }

  Widget _buildToolCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget content,
    required bool isLoading,
    required String response,
    required VoidCallback onExecute,
  }) {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                ),
                child: Icon(icon, color: AppColors.accent, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          content,
          const SizedBox(height: 16),
          CyberButton(
            label: 'AMBIL DATA',
            icon: Icons.rocket_launch,
            onTap: onExecute,
            isLoading: isLoading,
            width: double.infinity,
          ),
          if (response.isNotEmpty) ...[
            const SizedBox(height: 16),
            _buildResponsePanel(response),
          ],
        ],
      ),
    );
  }

  Widget _buildResponsePanel(String response) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.code, color: AppColors.green, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      'RESPONSE',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: response));
                    showCyberSnackBar(context, 'Response disalin!');
                  },
                  child: Icon(Icons.copy, color: AppColors.textSec, size: 16),
                ),
              ],
            ),
          ),
          Container(
            constraints: const BoxConstraints(maxHeight: 180),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.bg,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(12),
                bottomRight: Radius.circular(12),
              ),
            ),
            child: SingleChildScrollView(
              child: SelectableText(
                response,
                style: TextStyle(
                  color: AppColors.green,
                  fontFamily: 'monospace',
                  fontSize: 10,
                  height: 1.4,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCyberDropdown({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 4),
          child: Text(
            label,
            style: TextStyle(
              fontFamily: appFont,
              color: AppColors.textSec,
              fontSize: 9,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface2,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.borderLight),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              dropdownColor: AppColors.surface,
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 12,
                fontFamily: appFont,
              ),
              icon: Icon(Icons.arrow_drop_down, color: AppColors.textSec, size: 20),
              items: items.map((item) {
                return DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item.toUpperCase(),
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textPrimary,
                      fontSize: 12,
                    ),
                  ),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  // API Methods
  Future<void> _getPlayerStats() async {
    if (_uidController.text.isEmpty) {
      showCyberSnackBar(context, 'UID tidak boleh kosong', isError: true);
      return;
    }

    setState(() {
      _isLoading1 = true;
      _response1 = '';
    });

    try {
      final url = Uri.parse(
        'http://nodemyayun.otaxayun.cloud:5000/get_player_stats'
        '?server=${_selectedServer}'
        '&uid=${_uidController.text}'
        '&matchmode=${_selectedMatchMode}'
        '&gamemode=${_selectedGameMode}'
      );

      final response = await http.get(url).timeout(const Duration(seconds: 25));
      setState(() => _response1 = _formatJson(response.body));
    } catch (e) {
      setState(() => _response1 = 'Terjadi kesalahan: $e');
    } finally {
      setState(() => _isLoading1 = false);
    }
  }

  Future<void> _getPlayerPersonalShow() async {
    if (_uidController2.text.isEmpty) {
      showCyberSnackBar(context, 'UID tidak boleh kosong', isError: true);
      return;
    }

    setState(() {
      _isLoading2 = true;
      _response2 = '';
    });

    try {
      final url = Uri.parse(
        'http://nodemyayun.otaxayun.cloud:5000/get_player_personal_show'
        '?server=${_selectedServer2}'
        '&uid=${_uidController2.text}'
        '&need_gallery_info=$_needGalleryInfo'
        '&call_sign_src=${_callSignController.text}'
      );

      final response = await http.get(url).timeout(const Duration(seconds: 25));
      setState(() => _response2 = _formatJson(response.body));
    } catch (e) {
      setState(() => _response2 = 'Terjadi kesalahan: $e');
    } finally {
      setState(() => _isLoading2 = false);
    }
  }

  Future<void> _searchAccountByKeyword() async {
    if (_keywordController.text.isEmpty) {
      showCyberSnackBar(context, 'Keyword tidak boleh kosong', isError: true);
      return;
    }

    setState(() {
      _isLoading3 = true;
      _response3 = '';
    });

    try {
      final url = Uri.parse(
        'http://nodemyayun.otaxayun.cloud:5000/get_search_account_by_keyword'
        '?server=${_selectedServer3}'
        '&keyword=${_keywordController.text}'
      );

      final response = await http.get(url).timeout(const Duration(seconds: 25));
      setState(() => _response3 = _formatJson(response.body));
    } catch (e) {
      setState(() => _response3 = 'Terjadi kesalahan: $e');
    } finally {
      setState(() => _isLoading3 = false);
    }
  }

  String _formatJson(String jsonString) {
    try {
      final decoded = json.decode(jsonString);
      return const JsonEncoder.withIndent('  ').convert(decoded);
    } catch (e) {
      return jsonString;
    }
  }

  @override
  void dispose() {
    _uidController.dispose();
    _uidController2.dispose();
    _keywordController.dispose();
    _callSignController.dispose();
    super.dispose();
  }
}