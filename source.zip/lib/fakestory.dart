// fakestory.dart - CYBER STYLE
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'base_page.dart';

class FakeStoryPage extends StatefulWidget {
  const FakeStoryPage({Key? key}) : super(key: key);

  @override
  State<FakeStoryPage> createState() => _FakeStoryPageState();
}

class _FakeStoryPageState extends State<FakeStoryPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _captionController = TextEditingController();
  final TextEditingController _avatarUrlController = TextEditingController();

  bool _isLoading = false;
  bool _imageGenerated = false;
  Uint8List? _generatedImage;
  bool _isSharing = false;

  @override
  void initState() {
    super.initState();
    _usernameController.text = "OTAX AYUN💕";
    _captionController.text = "Bismillah Until Jannah";
    _avatarUrlController.text =
        "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
  }

  Future<void> _generateStory() async {
    if (_usernameController.text.isEmpty) {
      showCyberSnackBar(context, 'Masukkan username', isError: true);
      return;
    }
    if (_captionController.text.isEmpty) {
      showCyberSnackBar(context, 'Masukkan caption', isError: true);
      return;
    }
    if (_avatarUrlController.text.isEmpty) {
      showCyberSnackBar(context, 'Masukkan URL avatar', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
      _imageGenerated = false;
    });

    try {
      final encodedUsername = Uri.encodeComponent(_usernameController.text);
      final encodedCaption = Uri.encodeComponent(_captionController.text);
      final encodedAvatar = Uri.encodeComponent(_avatarUrlController.text);

      final apiUrl =
          'https://api.ryzumi.net/api/image/fake-story?username=$encodedUsername&caption=$encodedCaption&avatar=$encodedAvatar';

      final response = await http
          .get(
            Uri.parse(apiUrl),
            headers: {'accept': 'image/png'},
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _generatedImage = response.bodyBytes;
          _imageGenerated = true;
        });
        showCyberSnackBar(context, 'Story berhasil dibuat! 🎉');
      } else {
        throw Exception('Gagal membuat story. Status: ${response.statusCode}');
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: ${e.toString()}', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _saveToGallery() async {
    if (_generatedImage == null) {
      showCyberSnackBar(context, 'Buat story terlebih dahulu!', isError: true);
      return;
    }

    try {
      setState(() => _isSharing = true);

      final result = await ImageGallerySaverPlus.saveImage(
        _generatedImage!,
        name: "fake_story_${DateTime.now().millisecondsSinceEpoch}",
        quality: 100,
      );

      if (result['isSuccess'] == true) {
        showCyberSnackBar(context, '✅ Story disimpan ke galeri!');
      } else {
        showCyberSnackBar(context, '❌ Gagal menyimpan story', isError: true);
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: ${e.toString()}', isError: true);
    } finally {
      setState(() => _isSharing = false);
    }
  }

  Future<void> _shareStory() async {
    if (_generatedImage == null) {
      showCyberSnackBar(context, 'Buat story terlebih dahulu!', isError: true);
      return;
    }

    try {
      setState(() => _isSharing = true);

      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/fake_story_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Lihat fake story ini!',
        subject: 'Fake Instagram Story',
      );
    } catch (e) {
      showCyberSnackBar(context, 'Error membagikan story', isError: true);
    } finally {
      setState(() => _isSharing = false);
    }
  }

  void _resetForm() {
    setState(() {
      _usernameController.text = "OTAX AYUN💕";
      _captionController.text = "Bismillah Until Jannah✨";
      _avatarUrlController.text =
          "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
      _generatedImage = null;
      _imageGenerated = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: 'FAKE STORY',
      showBackButton: true,
      contentPadding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Preview Card
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                      ),
                      child: Text(
                        'PRATINJAU',
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.accent,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _generatedImage != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.memory(
                          _generatedImage!,
                          fit: BoxFit.contain,
                          height: 280,
                        ),
                      )
                    : Container(
                        height: 280,
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.photo_camera_outlined,
                              size: 48,
                              color: AppColors.textMuted,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Story akan muncul di sini',
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.textSec,
                                fontSize: 13,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Isi form di bawah untuk membuat pratinjau',
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.textMuted,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                if (_imageGenerated) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.green.withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle, color: AppColors.green, size: 16),
                        const SizedBox(width: 8),
                        Text(
                          'Story Siap Digunakan!',
                          style: TextStyle(
                            fontFamily: appFont,
                            color: AppColors.green,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Form Card
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                CyberInputField(
                  controller: _usernameController,
                  label: 'USERNAME INSTAGRAM',
                  hint: 'Masukkan username Instagram',
                  icon: Icons.person_outline,
                  maxLines: 1,
                ),
                const SizedBox(height: 16),
                CyberInputField(
                  controller: _captionController,
                  label: 'CAPTION STORY',
                  hint: 'Masukkan caption story...',
                  icon: Icons.chat_bubble_outline,
                  maxLines: 2,
                ),
                const SizedBox(height: 16),
                CyberInputField(
                  controller: _avatarUrlController,
                  label: 'URL FOTO PROFIL',
                  hint: 'https://contoh.com/avatar.jpg',
                  icon: Icons.link,
                  maxLines: 1,
                ),
                const SizedBox(height: 20),

                // Info Box
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: AppColors.accent, size: 16),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Pastikan URL adalah link langsung ke gambar (format: .jpg, .png, dll)',
                          style: TextStyle(
                            fontFamily: appFont,
                            color: AppColors.textSec,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                CyberButton(
                  label: 'BUAT FAKE STORY',
                  icon: Icons.auto_awesome,
                  onTap: _generateStory,
                  isLoading: _isLoading,
                  width: double.infinity,
                ),

                if (_imageGenerated) ...[
                  const SizedBox(height: 24),
                  const Divider(color: AppColors.borderLight, height: 1),
                  const SizedBox(height: 20),
                  Text(
                    'BAGIKAN STORY ANDA',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: CyberButton(
                          label: 'SIMPAN',
                          icon: Icons.save_alt_rounded,
                          onTap: _saveToGallery,
                          isLoading: _isSharing,
                          color: AppColors.textSec,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: CyberButton(
                          label: 'BAGIKAN',
                          icon: Icons.share_rounded,
                          onTap: _shareStory,
                          isLoading: _isSharing,
                          color: AppColors.accent,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Guide Card
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                      ),
                      child: Icon(Icons.help_outline_rounded, color: AppColors.accent, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'PANDUAN PENGGUNAAN',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildGuideStep(1, 'Masukkan username Instagram'),
                _buildGuideStep(2, 'Tulis caption story yang diinginkan'),
                _buildGuideStep(3, 'Tempel URL langsung ke foto profil'),
                _buildGuideStep(4, 'Klik tombol "Buat Fake Story"'),
                _buildGuideStep(5, 'Tunggu hingga gambar muncul'),
                _buildGuideStep(6, 'Simpan atau bagikan hasilnya'),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildGuideStep(int number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.accent.withOpacity(0.4)),
            ),
            child: Center(
              child: Text(
                "$number",
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                text,
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _captionController.dispose();
    _avatarUrlController.dispose();
    super.dispose();
  }
}