// custom_navigation.dart - Classic (Neo Brutalism) + Dark Comic 3D
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'app_theme.dart';
import 'theme_switcher_page.dart';

/// Tema aktif (dibaca ulang tiap build)
AppTheme get _t => ThemeController.instance.theme;

// Neo-Brutalism solid circle painter (thick hard border)
class BrutalCirclePainter extends CustomPainter {
  final Color color;
  final double strokeWidth;

  BrutalCirclePainter({
    required this.color,
    this.strokeWidth = 4,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// Custom Bottom Navigation - Neo Brutalism
class CustomBottomNav extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;
  final AnimationController pulseRingController;
  final AnimationController dashRingController;
  final VoidCallback onFanMenuTap;
  final bool isFanMenuOpen;

  const CustomBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.pulseRingController,
    required this.dashRingController,
    required this.onFanMenuTap,
    this.isFanMenuOpen = false,
  });

  @override
  Widget build(BuildContext context) {
    final t = _t;
    // Classic = neo-brutalism lama; Comic = full dark, aksen teal
    const black = Color(0xFF000000);
    const cream = Color(0xFFFFF8E7);
    const hotRed = Color(0xFFFF2D2D);
    const electricYellow = Color(0xFFFFE600);

    final line = t.isComic ? t.accentTeal : black;
    final ringAccent = t.isComic ? t.accentTeal : hotRed;
    final navAccent = t.isComic ? t.accentTeal : hotRed;
    final mainFill = t.isComic
        ? (isFanMenuOpen
            ? t.surfaceAlt
            : Color.alphaBlend(t.accentTeal.withOpacity(0.35), t.surface))
        : (isFanMenuOpen ? electricYellow : hotRed);

    return SizedBox(
      height: 130,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          // Background bottom nav - thick border + hard shadow
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            height: 72,
            decoration: t.isComic
                ? t.card(accent: t.accentTeal, d: 6)
                : BoxDecoration(
                    color: cream,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: black, width: 4),
                    boxShadow: const [
                      BoxShadow(
                        color: black,
                        offset: Offset(6, 6),
                        blurRadius: 0,
                      ),
                    ],
                  ),
            child: Container(
              height: 72,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _navItem(FontAwesomeIcons.house, 'HOME', 0, navAccent),
                  _navItem(FontAwesomeIcons.wrench, 'TOOLS', 1, navAccent),
                  const SizedBox(width: 56),
                  _navItem(FontAwesomeIcons.android, 'RAT', 2, navAccent),
                  _navItem(FontAwesomeIcons.comments, 'CHAT', 3, navAccent),
                ],
              ),
            ),
          ),

          // Center button - chunky circle
          Positioned(
            bottom: 18,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer hard ring (animated)
                AnimatedBuilder(
                  animation: pulseRingController,
                  builder: (ctx, child) {
                    final v = pulseRingController.value;
                    return Container(
                      width: 92 + v * 8,
                      height: 92 + v * 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: t.isComic ? line.withOpacity(0.45) : black,
                          width: 3,
                        ),
                      ),
                    );
                  },
                ),

                // Rotating thick ring
                AnimatedBuilder(
                  animation: dashRingController,
                  builder: (ctx, child) {
                    return Transform.rotate(
                      angle: dashRingController.value * 6.283,
                      child: CustomPaint(
                        size: const Size(78, 78),
                        painter: BrutalCirclePainter(
                          color: ringAccent,
                          strokeWidth: 5,
                        ),
                      ),
                    );
                  },
                ),

                // Main button
                GestureDetector(
                  onTap: onFanMenuTap,
                  child: Container(
                    width: 62,
                    height: 62,
                    decoration: BoxDecoration(
                      color: mainFill,
                      shape: BoxShape.circle,
                      border: Border.all(color: line, width: t.isComic ? 3 : 4),
                      boxShadow: t.isComic
                          ? t.slabShadow(t.accentTeal, d: 5)
                          : const [
                              BoxShadow(
                                color: black,
                                offset: Offset(5, 5),
                                blurRadius: 0,
                              ),
                            ],
                    ),
                    child: isFanMenuOpen
                        ? Icon(Icons.close, color: t.ink, size: 24)
                        : FaIcon(FontAwesomeIcons.whatsapp, color: t.ink, size: 24),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _navItem(FaIconData icon, String label, int index, Color accent) {
    final t = _t;
    final active = currentIndex == index;
    final activeFill = t.isComic
        ? Color.alphaBlend(t.accentTeal.withOpacity(0.30), t.surface)
        : accent;
    final activeLine = t.isComic ? t.accentTeal : Colors.black;
    final fg = active ? t.ink : (t.isComic ? t.textSecondary : const Color(0xFF333333));

    return GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 54,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: active ? activeFill : Colors.transparent,
          borderRadius: BorderRadius.circular(t.isComic ? 12 : 10),
          border: active
              ? Border.all(color: activeLine, width: t.isComic ? 2.5 : 3)
              : Border.all(color: Colors.transparent, width: t.isComic ? 2.5 : 3),
          boxShadow: active
              ? (t.isComic
                  ? t.slabShadow(t.accentTeal, d: 3)
                  : const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ])
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: fg, size: 18),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
                color: fg,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Fan Menu Overlay - Neo Brutalism
class FanMenuOverlay extends StatelessWidget {
  final AnimationController fanStaggerController;
  final VoidCallback onClose;
  final VoidCallback onContactBugTap;
  final VoidCallback onGroupBugTap;
  final VoidCallback onCustomBugTap;
  final VoidCallback onSenderBugTap;

  const FanMenuOverlay({
    super.key,
    required this.fanStaggerController,
    required this.onClose,
    required this.onContactBugTap,
    required this.onGroupBugTap,
    required this.onCustomBugTap,
    required this.onSenderBugTap,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Stack(
      children: [
        // Hard dim overlay (no blur)
        Positioned.fill(
          child: GestureDetector(
            onTap: onClose,
            behavior: HitTestBehavior.opaque,
            child: Container(
              color: Colors.black.withOpacity(_t.isComic ? 0.8 : 0.65),
            ),
          ),
        ),

        _fanButtonPositioned(
          screenWidth: screenWidth,
          icon: FontAwesomeIcons.user,
          label: 'CONTACT',
          bg: _t.dk(const Color(0xFF25D366)),
          angle: 165,
          radius: 95,
          delay: 0,
          onTap: () {
            onClose();
            onContactBugTap();
          },
          controller: fanStaggerController,
        ),

        _fanButtonPositioned(
          screenWidth: screenWidth,
          icon: FontAwesomeIcons.users,
          label: 'GROUP',
          bg: _t.dk(const Color(0xFF00B4D8)),
          angle: 115,
          radius: 100,
          delay: 70,
          onTap: () {
            onClose();
            onGroupBugTap();
          },
          controller: fanStaggerController,
        ),

        _fanButtonPositioned(
          screenWidth: screenWidth,
          icon: FontAwesomeIcons.code,
          label: 'CUSTOM',
          bg: _t.dk(const Color(0xFFB388FF)),
          angle: 65,
          radius: 100,
          delay: 140,
          onTap: () {
            onClose();
            onCustomBugTap();
          },
          controller: fanStaggerController,
        ),

        _fanButtonPositioned(
          screenWidth: screenWidth,
          icon: FontAwesomeIcons.star,
          label: 'SENDER',
          bg: _t.dk(const Color(0xFFFF9800)),
          angle: 15,
          radius: 95,
          delay: 210,
          onTap: () {
            onClose();
            onSenderBugTap();
          },
          controller: fanStaggerController,
        ),

        // Close button - brutal style
        Positioned(
          left: 0,
          right: 0,
          bottom: 28,
          child: Center(
            child: GestureDetector(
              onTap: onClose,
              child: AnimatedBuilder(
                animation: fanStaggerController,
                builder: (ctx, child) {
                  final v = Curves.easeOut.transform(
                    (fanStaggerController.value - 0.5).clamp(0.0, 1.0),
                  );
                  return Opacity(
                    opacity: v.clamp(0.0, 1.0),
                    child: Transform.scale(
                      scale: (0.75 + v * 0.25).clamp(0.75, 1.0),
                      child: child,
                    ),
                  );
                },
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: _t.isComic ? _t.surfaceAlt : const Color(0xFFFFE600),
                    shape: BoxShape.circle,
                    border: Border.all(color: _t.line, width: _t.bw(4)),
                    boxShadow: _t.hard(5),
                  ),
                  child: Icon(Icons.close, color: _t.ink, size: 30),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// Neo-brutal fan button
Widget _fanButtonPositioned({
  required double screenWidth,
  required FaIconData icon,
  required String label,
  required Color bg,
  required int angle,
  required double radius,
  required int delay,
  required VoidCallback onTap,
  required AnimationController controller,
}) {
  final rad = angle * math.pi / 180;
  final targetDx = radius * math.cos(rad);
  final targetDy = radius * math.sin(rad);
  const originBottom = 115.0;

  return AnimatedBuilder(
    animation: controller,
    builder: (ctx, child) {
      final delayFraction = delay / 400.0;
      final adjusted = (controller.value - delayFraction).clamp(0.0, 1.0);
      final curved = Curves.easeOutBack.transform(adjusted);
      final leftPos = (screenWidth / 2) + targetDx * curved - 32;
      final bottomPos = originBottom + targetDy * curved - 32;

      return Positioned(
        left: leftPos,
        bottom: bottomPos,
        child: Opacity(
          opacity: curved.clamp(0.0, 1.0),
          child: Transform.scale(
            scale: 0.6 + 0.4 * curved,
            child: child,
          ),
        ),
      );
    },
    child: GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: bg,
              shape: BoxShape.circle,
              border: Border.all(color: _t.line, width: _t.bw(4)),
              boxShadow: _t.hard(5),
            ),
            child: FaIcon(
              icon,
              color: _t.ink,
              size: 26,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _t.surface,
              borderRadius: _t.rr(4),
              border: Border.all(color: _t.line, width: _t.bw(3)),
              boxShadow: _t.hard(3),
            ),
            child: Text(
              label,
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 9,
                color: _t.ink,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.8,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
