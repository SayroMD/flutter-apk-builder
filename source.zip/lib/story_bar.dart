import 'package:flutter/material.dart';
import 'story_model.dart';
import 'story_api_service.dart';
import 'story_viewer_screen.dart';
import 'app_theme.dart';
import 'theme_switcher_page.dart';

const kInk = Color(0xFF111111);
const kBg = Color(0xFFF5F0E8);
const kAccentYellow = Color(0xFFFFD60A);
const kAccentRed = Color(0xFFFF3B30);
const kAccentBlue = Color(0xFF00C2FF);

/// Tema aktif (dibaca ulang tiap build). Konstanta k* di atas sengaja
/// dibiarin biar file lain yang import tetep aman.
AppTheme get _t => ThemeController.instance.theme;
Color get _lineC => _t.isComic ? _t.accentTeal : kInk;
List<BoxShadow> _slab(double d, {Color? accent}) => _t.isComic
    ? _t.slabShadow(accent ?? _t.accentTeal, d: d)
    : [BoxShadow(color: kInk, offset: Offset(d, d))];

class StoryBar extends StatelessWidget {
  final List<StoryGroup> groups;
  final VoidCallback? onAddStory;
  final String label;
  final String currentUsername;
  final Future<void> Function(String storyId)? onDelete;

  const StoryBar({
    super.key,
    required this.groups,
    required this.currentUsername,
    this.onAddStory,
    this.onDelete,
    this.label = 'STATUS STORY',
  });

  @override
  Widget build(BuildContext context) {
    final activeCount = groups.length;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: _t.surface,
        borderRadius: _t.rr(4),
        border: Border.all(color: _t.line, width: _t.bw(3)),
        boxShadow: _t.hard(5),
      ),
      padding: const EdgeInsets.only(top: 12, bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _t.isComic
                        ? Color.alphaBlend(_t.accentTeal.withOpacity(0.30), _t.surface)
                        : kInk,
                    borderRadius: _t.isComic ? BorderRadius.circular(8) : null,
                    border: Border.all(color: _lineC, width: 2),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.auto_awesome,
                          size: 12,
                          color: _t.isComic ? _t.accentTeal : kAccentYellow),
                      const SizedBox(width: 6),
                      Text(
                        label,
                        style: TextStyle(
                          color: _t.isComic ? _t.ink : Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '$activeCount aktif',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: _t.isComic ? _t.textSecondary : kInk,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 96,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _AddStoryItem(onTap: onAddStory),
                const SizedBox(width: 12),
                for (int i = 0; i < groups.length; i++) ...[
                  _StoryItem(
                    group: groups[i],
                    isOwn: groups[i].userName == currentUsername,
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => StoryViewerScreen(
                            groups: groups,
                            initialIndex: i,
                            currentUsername: currentUsername,
                            onDelete: onDelete,
                          ),
                        ),
                      );
                    },
                    onLongPress: groups[i].userName == currentUsername
                        ? () => _confirmDelete(context, groups[i])
                        : null,
                  ),
                  const SizedBox(width: 12),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, StoryGroup group) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _t.surface,
        shape: RoundedRectangleBorder(
          borderRadius: _t.rr(0),
          side: BorderSide(color: _lineC, width: 3),
        ),
        title: Text(
          'HAPUS STORY?',
          style: TextStyle(
              fontWeight: FontWeight.w900, fontSize: 14, color: _t.ink),
        ),
        content: Text('Semua story lo di sini bakal kehapus.',
            style: TextStyle(color: _t.ink)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('BATAL', style: TextStyle(color: _t.ink, fontWeight: FontWeight.w900)),
          ),
          Container(
            decoration: BoxDecoration(
              color: _t.isComic ? _t.accentPink : kAccentRed,
              borderRadius: _t.isComic ? BorderRadius.circular(8) : null,
              border: Border.all(color: _lineC, width: 2),
              boxShadow: _slab(2, accent: _t.accentPink),
            ),
            child: TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('HAPUS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true && onDelete != null) {
      for (final s in group.stories) {
        await onDelete!(s.id);
      }
    }
  }
}

class _AddStoryItem extends StatelessWidget {
  final VoidCallback? onTap;
  const _AddStoryItem({this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _t.isComic ? _t.dk(kAccentBlue) : kAccentBlue,
              border: Border.all(color: _lineC, width: 3),
              boxShadow: _slab(4),
            ),
            child: Icon(Icons.add, size: 26, color: _t.isComic ? _t.ink : kInk),
          ),
          const SizedBox(height: 6),
          Text('Buat',
              style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w900, color: _t.ink)),
        ],
      ),
    );
  }
}

class _StoryItem extends StatelessWidget {
  final StoryGroup group;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final bool isOwn;

  const _StoryItem({
    required this.group,
    required this.onTap,
    required this.isOwn,
    this.onLongPress,
  });

  Widget _fallbackAvatar(StoryGroup group) {
    return group.avatarUrl.isNotEmpty
        ? Image.network(group.avatarUrl, fit: BoxFit.cover)
        : Container(
            color: _t.isComic ? _t.surfaceAlt : kAccentYellow,
            child: Center(
              child: Text(
                group.userName[0].toUpperCase(),
                style: TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 20, color: _t.ink),
              ),
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                width: 60,
                height: 60,
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: group.seen
                      ? (_t.isComic ? const Color(0xFF26323B) : const Color(0xFFCCCCCC))
                      : (_t.isComic ? _t.accentTeal : kAccentYellow),
                  border: Border.all(color: _lineC, width: 3),
                  boxShadow: _slab(group.seen ? 2 : 4),
                ),
                child: ClipOval(
                  child: group.stories.isNotEmpty
                      ? Image.network(
                          group.stories.last.mediaUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _fallbackAvatar(group),
                        )
                      : _fallbackAvatar(group),
                ),
              ),
              // badge trash kalau story milik sendiri
              if (isOwn)
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      color: _t.isComic ? _t.accentPink : kAccentRed,
                      shape: BoxShape.circle,
                      border: Border.all(color: _lineC, width: 1.5),
                    ),
                    child: const Icon(Icons.delete, size: 10, color: Colors.white),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          SizedBox(
            width: 60,
            child: Text(
              group.userName,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w900, color: _t.ink),
            ),
          ),
        ],
      ),
    );
  }
}
