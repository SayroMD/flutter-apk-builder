import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'base_page.dart';

class PhoneLookupPage extends StatefulWidget {
  const PhoneLookupPage({super.key});

  @override
  State<PhoneLookupPage> createState() => _PhoneLookupPageState();
}

class _PhoneLookupPageState extends State<PhoneLookupPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  final TextEditingController _phoneController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  
  bool _isLoading = false;
  PhoneLookupResult? _result;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _lookupPhone() {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _result = null;
    });
    
    final phone = _phoneController.text.trim();
    
    Future.delayed(const Duration(milliseconds: 500), () {
      final result = PhoneValidator.validate(phone);
      
      setState(() {
        _result = result;
        _isLoading = false;
        if (!result.isValid && result.countryName == 'Unknown') {
          _errorMessage = 'Format nomor tidak dikenali. Gunakan format internasional (+62, +1, dll)';
        }
      });
    });
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    showCyberSnackBar(context, '$label disalin');
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "PHONE LOOKUP",
      child: Column(
        children: [
          _buildInputSection(),
          const SizedBox(height: 16),
          if (_isLoading) _buildLoadingIndicator(),
          if (_errorMessage != null && !_isLoading) _buildErrorMessage(),
          if (_result != null && !_isLoading) _buildResultCard(),
        ],
      ),
    );
  }
  
  Widget _buildInputSection() {
    return GlassCard(
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(width: 3, height: 18,
                    decoration: BoxDecoration(color: AppColors.accent, borderRadius: BorderRadius.circular(2))),
                const SizedBox(width: 8),
                const Text('Nomor Telepon Lookup',
                    style: TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _phoneController,
              label: "Nomor Telepon",
              hint: "+62 812 3456 7890",
              icon: Icons.phone_android_rounded,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.info_outline_rounded, color: AppColors.textMuted, size: 12),
                const SizedBox(width: 6),
                Expanded(
                  child: Text('Format: +62 (Indonesia), +1 (US), +44 (UK), dll',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                ),
              ],
            ),
            const SizedBox(height: 16),
            CyberButton(
              label: "LOOKUP NUMBER",
              icon: Icons.search_rounded,
              onTap: _lookupPhone,
              width: double.infinity,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildLoadingIndicator() {
    return GlassCard(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          const CyberLoadingShimmer(),
          const SizedBox(height: 16),
          const Text('Menganalisis nomor...', style: TextStyle(color: AppColors.textMuted)),
        ],
      ),
    );
  }
  
  Widget _buildErrorMessage() {
    return GlassCard(
      padding: const EdgeInsets.all(20),
      borderColor: AppColors.red.withOpacity(0.3),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: AppColors.red, size: 24),
          const SizedBox(width: 12),
          Expanded(child: Text(_errorMessage!, style: TextStyle(color: AppColors.textSec))),
        ],
      ),
    );
  }
  
  Widget _buildResultCard() {
    final result = _result!;
    
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: result.isValid ? AppColors.green.withOpacity(0.1) : AppColors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: result.isValid ? AppColors.green.withOpacity(0.3) : AppColors.red.withOpacity(0.3),
                  ),
                ),
                child: Icon(
                  result.isValid ? Icons.check_circle_rounded : Icons.error_rounded,
                  color: result.isValid ? AppColors.green : AppColors.red,
                  size: 28,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(result.phoneFormatted,
                        style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(result.isValid ? 'Nomor Valid' : 'Nomor Tidak Valid',
                        style: TextStyle(color: result.isValid ? AppColors.green : AppColors.red, fontSize: 12)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => _copyToClipboard(result.phoneFormatted, 'Nomor telepon'),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Icon(Icons.copy_rounded, color: AppColors.accent, size: 18),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 16),
          _buildInfoRow(icon: Icons.public_rounded, label: 'Country', value: '${result.countryCode} ${result.countryName}',
              onCopy: () => _copyToClipboard(result.countryName, 'Country')),
          const SizedBox(height: 12),
          if (result.carrier != 'Unknown') ...[
            _buildInfoRow(icon: Icons.signal_cellular_alt_rounded, label: 'Carrier', value: result.carrier,
                onCopy: () => _copyToClipboard(result.carrier, 'Carrier')),
            const SizedBox(height: 12),
          ],
          _buildInfoRow(icon: Icons.devices_rounded, label: 'Line Type', value: result.lineType),
          const SizedBox(height: 12),
          if (result.city != null) ...[
            _buildInfoRow(icon: Icons.location_city_rounded, label: 'Area/City', value: result.city!),
            const SizedBox(height: 12),
          ],
          if (result.operatorCode != null) ...[
            _buildInfoRow(icon: Icons.qr_code_rounded, label: 'Operator Code', value: result.operatorCode!),
            const SizedBox(height: 12),
          ],
          _buildInfoRow(icon: Icons.format_size_rounded, label: 'Length', value: '${result.details['length']} digit'),
        ],
      ),
    );
  }
  
  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    VoidCallback? onCopy,
  }) {
    return Row(
      children: [
        Icon(icon, color: AppColors.accent, size: 18),
        const SizedBox(width: 12),
        SizedBox(width: 110,
            child: Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 13))),
        Expanded(
          child: Text(value,
              style: TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
        ),
        if (onCopy != null)
          GestureDetector(
            onTap: onCopy,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: Icon(Icons.copy_rounded, color: AppColors.textMuted, size: 14),
            ),
          ),
      ],
    );
  }
}

class PhoneLookupResult {
  final String phoneNumber;
  final String phoneFormatted;
  final String countryCode;
  final String countryName;
  final String carrier;
  final String lineType;
  final bool isValid;
  final String? city;
  final String? operatorCode;
  final Map<String, dynamic> details;

  PhoneLookupResult({
    required this.phoneNumber,
    required this.phoneFormatted,
    required this.countryCode,
    required this.countryName,
    required this.carrier,
    required this.lineType,
    required this.isValid,
    this.city,
    this.operatorCode,
    required this.details,
  });
}

class PhoneValidator {
  static final Map<String, Map<String, String>> _indonesianOperators = {
    'Telkomsel': {'prefix': '0811,0812,0813,0821,0822,0823,0851,0852,0853,081,082,085', 'codes': '0811,0812,0813,0821,0822,0823,0851,0852,0853'},
    'XL Axiata': {'prefix': '0817,0818,0819,0859,0877,0878,0879', 'codes': '0817,0818,0819,0859,0877,0878,0879'},
    'Indosat (IM3/Ooredoo)': {'prefix': '0814,0815,0816,0855,0856,0857,0858', 'codes': '0814,0815,0816,0855,0856,0857,0858'},
    'Tri (3)': {'prefix': '0895,0896,0897,0898,0899', 'codes': '0895,0896,0897,0898,0899'},
    'Smartfren': {'prefix': '0881,0882,0883,0884,0885,0886,0887,0888,0889', 'codes': '0881,0882,0883,0884,0885,0886,0887,0888,0889'},
    'Axis': {'prefix': '0831,0832,0833,0834,0835,0836,0837,0838', 'codes': '0831,0832,0833,0834,0835,0836,0837,0838'},
    'By.U': {'prefix': '0851,0852,0853', 'codes': '0851,0852,0853'},
  };

  static final Map<String, Map<String, String>> _countries = {
    '+62': {'name': 'Indonesia', 'pattern': r'^(\+62|0)[0-9]{9,12}$'},
    '+1': {'name': 'United States', 'pattern': r'^\+1[0-9]{10}$'},
    '+44': {'name': 'United Kingdom', 'pattern': r'^\+44[0-9]{10}$'},
    '+91': {'name': 'India', 'pattern': r'^\+91[0-9]{10}$'},
    '+60': {'name': 'Malaysia', 'pattern': r'^\+60[0-9]{9,10}$'},
    '+65': {'name': 'Singapore', 'pattern': r'^\+65[0-9]{8}$'},
    '+63': {'name': 'Philippines', 'pattern': r'^\+63[0-9]{10}$'},
    '+66': {'name': 'Thailand', 'pattern': r'^\+66[0-9]{9}$'},
    '+84': {'name': 'Vietnam', 'pattern': r'^\+84[0-9]{9,10}$'},
    '+81': {'name': 'Japan', 'pattern': r'^\+81[0-9]{10}$'},
    '+82': {'name': 'South Korea', 'pattern': r'^\+82[0-9]{10}$'},
    '+86': {'name': 'China', 'pattern': r'^\+86[0-9]{11}$'},
    '+61': {'name': 'Australia', 'pattern': r'^\+61[0-9]{9}$'},
    '+49': {'name': 'Germany', 'pattern': r'^\+49[0-9]{10,11}$'},
    '+33': {'name': 'France', 'pattern': r'^\+33[0-9]{9}$'},
    '+39': {'name': 'Italy', 'pattern': r'^\+39[0-9]{10}$'},
    '+34': {'name': 'Spain', 'pattern': r'^\+34[0-9]{9}$'},
    '+55': {'name': 'Brazil', 'pattern': r'^\+55[0-9]{11}$'},
    '+7': {'name': 'Russia', 'pattern': r'^\+7[0-9]{10}$'},
    '+20': {'name': 'Egypt', 'pattern': r'^\+20[0-9]{10}$'},
    '+27': {'name': 'South Africa', 'pattern': r'^\+27[0-9]{9}$'},
    '+90': {'name': 'Turkey', 'pattern': r'^\+90[0-9]{10}$'},
  };

  static String detectCarrier(String phoneNumber) {
    String cleanNumber = phoneNumber.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleanNumber.startsWith('62')) { cleanNumber = cleanNumber.substring(2); }
    if (!cleanNumber.startsWith('0')) { cleanNumber = '0$cleanNumber'; }
    
    String prefix4 = cleanNumber.length >= 4 ? cleanNumber.substring(0, 4) : '';
    String prefix3 = cleanNumber.length >= 3 ? cleanNumber.substring(0, 3) : '';
    
    for (var entry in _indonesianOperators.entries) {
      if (entry.value['codes']!.contains(prefix4) || entry.value['codes']!.contains(prefix3)) {
        return entry.key;
      }
    }
    return 'Unknown';
  }

  static String detectLineType(String phoneNumber) {
    String cleanNumber = phoneNumber.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleanNumber.startsWith('62')) { cleanNumber = cleanNumber.substring(2); }
    if (!cleanNumber.startsWith('0')) { cleanNumber = '0$cleanNumber'; }
    
    if (cleanNumber.startsWith('08') || cleanNumber.startsWith('06')) { return 'Mobile / Cellular'; }
    if (cleanNumber.startsWith('02')) { return 'Landline / Fixed Line'; }
    if (cleanNumber.startsWith('001') || cleanNumber.startsWith('007')) { return 'Toll Free / Special'; }
    return 'Mobile';
  }

  static String formatPhoneNumber(String phoneNumber) {
    String clean = phoneNumber.replaceAll(RegExp(r'[^0-9+]'), '');
    if (clean.startsWith('+62')) {
      String local = clean.substring(3);
      if (local.startsWith('0')) local = local.substring(1);
      if (local.length >= 4) {
        if (local.length == 10) {
          return '+62 ${local.substring(0, 3)} ${local.substring(3, 6)} ${local.substring(6)}';
        } else if (local.length == 11) {
          return '+62 ${local.substring(0, 4)} ${local.substring(4, 7)} ${local.substring(7)}';
        } else if (local.length == 12) {
          return '+62 ${local.substring(0, 3)} ${local.substring(3, 7)} ${local.substring(7)}';
        }
      }
      return '+62 $local';
    }
    return clean;
  }

  static PhoneLookupResult validate(String rawNumber) {
    String cleanNumber = rawNumber.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    String detectedCountryCode = '';
    String detectedCountryName = '';
    bool isValid = false;
    
    for (var entry in _countries.entries) {
      if (cleanNumber.startsWith(entry.key)) {
        detectedCountryCode = entry.key;
        detectedCountryName = entry.value['name']!;
        RegExp pattern = RegExp(entry.value['pattern']!);
        isValid = pattern.hasMatch(cleanNumber);
        break;
      }
    }
    
    if (detectedCountryCode.isEmpty) {
      if (RegExp(r'^0[0-9]{9,12}$').hasMatch(cleanNumber)) {
        detectedCountryCode = '+62';
        detectedCountryName = 'Indonesia';
        isValid = true;
        cleanNumber = '+62${cleanNumber.substring(1)}';
      }
    }
    
    if (detectedCountryCode.isEmpty) {
      if (RegExp(r'^[0-9]{8,15}$').hasMatch(cleanNumber)) {
        detectedCountryCode = '+??';
        detectedCountryName = 'Unknown';
        isValid = true;
      }
    }
    
    String carrier = 'Unknown';
    String operatorCode = '';
    String? city;
    
    if (detectedCountryName == 'Indonesia') {
      carrier = detectCarrier(cleanNumber);
      String localNumber = cleanNumber.replaceAll(RegExp(r'[^0-9]'), '');
      if (localNumber.startsWith('62')) localNumber = localNumber.substring(2);
      if (!localNumber.startsWith('0')) localNumber = '0$localNumber';
      
      if (localNumber.startsWith('021')) city = 'Jakarta';
      else if (localNumber.startsWith('022')) city = 'Bandung';
      else if (localNumber.startsWith('024')) city = 'Semarang';
      else if (localNumber.startsWith('0274')) city = 'Yogyakarta';
      else if (localNumber.startsWith('031')) city = 'Surabaya';
      else if (localNumber.startsWith('0411')) city = 'Makassar';
      else if (localNumber.startsWith('061')) city = 'Medan';
      
      String numPart = localNumber.replaceFirst('0', '');
      if (numPart.length >= 4) {
        operatorCode = numPart.substring(0, 4);
      } else if (numPart.length >= 3) {
        operatorCode = numPart.substring(0, 3);
      }
    }
    
    String formatted = formatPhoneNumber(cleanNumber);
    String lineType = detectLineType(cleanNumber);
    
    return PhoneLookupResult(
      phoneNumber: rawNumber,
      phoneFormatted: formatted,
      countryCode: detectedCountryCode,
      countryName: detectedCountryName,
      carrier: carrier,
      lineType: lineType,
      isValid: isValid,
      city: city,
      operatorCode: operatorCode.isNotEmpty ? operatorCode : null,
      details: {'raw': rawNumber, 'clean': cleanNumber, 'formatted': formatted, 'length': cleanNumber.replaceAll(RegExp(r'[^0-9]'), '').length},
    );
  }
}