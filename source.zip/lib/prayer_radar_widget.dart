import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

/// ════════════════════════════════════════════════════════════════
/// PRAYER RADAR — HUD/orbit jadwal sholat (v2, kembangan)
///
/// Konsep: lingkaran 24-jam. Posisi tiap sholat di lingkaran BUKAN
/// dekoratif — sudutnya proporsional terhadap jam sebenarnya, jadi
/// bentuknya sendiri "membaca" ritme hari. Blip cyan = waktu
/// sekarang, terus bergerak mengelilingi ring. Sweep line memutar
/// pelan di belakang sebagai ambient (radar scan). Node yang sudah
/// lewat meredup, node aktif/berikutnya menyala & berdenyut.
///
/// Tambahan v2:
/// - Band warna per-periode hari (malam/subuh/dhuha/siang/sore/maghrib)
///   di sepanjang ring, biar "mood" jam kebaca sekilas.
/// - Progress arc dari sholat terakhir -> sholat berikutnya.
/// - Countdown digital (HH:MM:SS) menuju sholat berikutnya.
/// - Jam digital live + badge nama periode saat ini di header.
/// - Node tambahan Imsak & Terbit (halus, non-intrusive).
/// - Strip waktu sholat di bawah radar (5 waktu wajib, dengan status
///   sudah lewat / sedang berjalan / berikutnya).
/// ════════════════════════════════════════════════════════════════

class PrayerRadarWidget extends StatefulWidget {
  final String cityName;
  final bool isLoadingSholat;
  final bool useCurrentLocation;
  final Map<String, dynamic>? jadwalSholat;
  final VoidCallback onCityTap;

  const PrayerRadarWidget({
    super.key,
    required this.cityName,
    required this.isLoadingSholat,
    required this.useCurrentLocation,
    required this.jadwalSholat,
    required this.onCityTap,
  });

  @override
  State<PrayerRadarWidget> createState() => _PrayerRadarWidgetState();
}

class _PrayerRadarWidgetState extends State<PrayerRadarWidget>
    with TickerProviderStateMixin {
  late final AnimationController _sweepController;
  late final AnimationController _pulseController;
  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  static const List<_PrayerNode> _prayerKeys = [
    _PrayerNode('subuh', 'SUBUH', Icons.nights_stay_rounded,
        Color(0xFF4C63B6)),
    _PrayerNode('dzuhur', 'DZUHUR', Icons.wb_sunny_rounded,
        Color(0xFFE8B84B)),
    _PrayerNode('ashar', 'ASHAR', Icons.wb_twilight, Color(0xFFE0793C)),
    _PrayerNode('maghrib', 'MAGHRIB', Icons.nightlight_round,
        Color(0xFFB23B4E)),
    _PrayerNode('isya', 'ISYA', Icons.bedtime_rounded, Color(0xFF1E2A4A)),
  ];

  static const Map<String, String> _periodLabel = {
    'subuh': 'SUBUH',
    'terbit': 'DHUHA',
    'dzuhur': 'SIANG',
    'ashar': 'SORE',
    'maghrib': 'MAGHRIB',
    'isya': 'MALAM',
  };

  @override
  void initState() {
    super.initState();
    _sweepController =
        AnimationController(vsync: this, duration: const Duration(seconds: 8))
          ..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _sweepController.dispose();
    _pulseController.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }

  double? _timeToHours(String? hhmm) {
    if (hhmm == null || !hhmm.contains(':')) return null;
    final parts = hhmm.split(':');
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    if (h == null || m == null) return null;
    return h + m / 60.0;
  }

  /// Cari sholat wajib berikutnya berdasarkan data yang tersedia.
  ({String key, double hours})? _nextPrayer(Map<String, double> hoursMap) {
    final nowHours = _now.hour + _now.minute / 60.0;
    ({String key, double hours})? next;
    double bestDelta = 999;
    for (final node in _prayerKeys) {
      final h = hoursMap[node.key];
      if (h == null) continue;
      double delta = h - nowHours;
      if (delta < 0) delta += 24;
      if (delta < bestDelta) {
        bestDelta = delta;
        next = (key: node.key, hours: h);
      }
    }
    return next;
  }

  /// Cari sholat wajib yang paling terakhir lewat (periode aktif sekarang).
  ({String key, double hours})? _previousPrayer(
      Map<String, double> hoursMap) {
    final nowHours = _now.hour + _now.minute / 60.0;
    ({String key, double hours})? prev;
    double bestDelta = 999;
    for (final node in _prayerKeys) {
      final h = hoursMap[node.key];
      if (h == null) continue;
      double delta = nowHours - h;
      if (delta < 0) delta += 24;
      if (delta < bestDelta) {
        bestDelta = delta;
        prev = (key: node.key, hours: h);
      }
    }
    return prev;
  }

  String _fmtCountdown(double deltaHours) {
    final totalSeconds = (deltaHours * 3600).round().clamp(0, 24 * 3600);
    final h = totalSeconds ~/ 3600;
    final m = (totalSeconds % 3600) ~/ 60;
    final s = totalSeconds % 60;
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(h)}:${two(m)}:${two(s)}';
  }

  @override
  Widget build(BuildContext context) {
    final jadwal = widget.jadwalSholat?['jadwal'] as Map?;
    final Map<String, double> hoursMap = {};
    for (final node in _prayerKeys) {
      final h = _timeToHours(jadwal?[node.key]?.toString());
      if (h != null) hoursMap[node.key] = h;
    }
    final imsakHour = _timeToHours(jadwal?['imsak']?.toString());
    final terbitHour = _timeToHours(jadwal?['terbit']?.toString());

    final next = hoursMap.isEmpty ? null : _nextPrayer(hoursMap);
    final prev = hoursMap.isEmpty ? null : _previousPrayer(hoursMap);
    final nextNode = next == null
        ? null
        : _prayerKeys.firstWhere((n) => n.key == next.key);
    final nextTimeStr = next == null ? '--:--' : jadwal?[next.key]?.toString();

    // Periode saat ini (termasuk terbit sebagai penanda dhuha)
    final Map<String, double> periodMap = {
      ...hoursMap,
      if (terbitHour != null) 'terbit': terbitHour,
    };
    String currentPeriod = 'MALAM';
    if (periodMap.isNotEmpty) {
      final nowHours = _now.hour + _now.minute / 60.0;
      double bestDelta = 999;
      for (final entry in periodMap.entries) {
        double delta = nowHours - entry.value;
        if (delta < 0) delta += 24;
        if (delta < bestDelta) {
          bestDelta = delta;
          currentPeriod = _periodLabel[entry.key] ?? 'MALAM';
        }
      }
    }

    final nowHoursExact =
        _now.hour + _now.minute / 60.0 + _now.second / 3600.0;
    double? countdownHours;
    if (next != null) {
      double d = next.hours - nowHoursExact;
      if (d < 0) d += 24;
      countdownHours = d;
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF060B14), Color(0xFF0A121F)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD32F2F).withOpacity(0.18)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFD32F2F).withOpacity(0.08),
            blurRadius: 30,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          const SizedBox(height: 10),
          _buildStatusRow(currentPeriod),
          const SizedBox(height: 14),
          if (widget.isLoadingSholat)
            const SizedBox(
              height: 260,
              child: Center(
                child: CircularProgressIndicator(
                  color: Color(0xFFD32F2F),
                  strokeWidth: 2,
                ),
              ),
            )
          else ...[
            _buildRadar(
              hoursMap: hoursMap,
              next: next,
              prev: prev,
              nextNode: nextNode,
              nextTimeStr: nextTimeStr,
              countdownHours: countdownHours,
              imsakHour: imsakHour,
              terbitHour: terbitHour,
            ),
            const SizedBox(height: 18),
            _buildTimesStrip(jadwal, next?.key, prev?.key),
          ],
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, _) {
                return Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFD32F2F),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFD32F2F)
                            .withOpacity(0.5 + _pulseController.value * 0.4),
                        blurRadius: 6 + _pulseController.value * 4,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(width: 8),
            const Text(
              'JADWAL SHOLAT',
              style: TextStyle(
                color: Color(0xFFD32F2F),
                fontFamily: 'Orbitron',
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 2.0,
              ),
            ),
          ],
        ),
        GestureDetector(
          onTap: widget.onCityTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFD32F2F).withOpacity(0.4)),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  widget.useCurrentLocation
                      ? Icons.gps_fixed
                      : Icons.edit_location_alt_rounded,
                  size: 12,
                  color: const Color(0xFFD32F2F),
                ),
                const SizedBox(width: 5),
                Text(
                  widget.cityName.toUpperCase(),
                  style: const TextStyle(
                    color: Color(0xFFD32F2F),
                    fontFamily: 'RobotoMono',
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusRow(String currentPeriod) {
    final clockStr =
        '${_now.hour.toString().padLeft(2, '0')}:${_now.minute.toString().padLeft(2, '0')}:${_now.second.toString().padLeft(2, '0')}';
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          clockStr,
          style: TextStyle(
            color: Colors.white.withOpacity(0.55),
            fontFamily: 'RobotoMono',
            fontSize: 11,
            letterSpacing: 1.0,
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: const Color(0xFFD32F2F).withOpacity(0.08),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            'PERIODE • $currentPeriod',
            style: TextStyle(
              color: const Color(0xFFD32F2F).withOpacity(0.85),
              fontFamily: 'RobotoMono',
              fontSize: 9,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.0,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRadar({
    required Map<String, double> hoursMap,
    required ({String key, double hours})? next,
    required ({String key, double hours})? prev,
    required _PrayerNode? nextNode,
    required String? nextTimeStr,
    required double? countdownHours,
    required double? imsakHour,
    required double? terbitHour,
  }) {
    final nowHours = _now.hour + _now.minute / 60.0 + _now.second / 3600.0;

    return AspectRatio(
      aspectRatio: 1,
      child: AnimatedBuilder(
        animation: Listenable.merge([_sweepController, _pulseController]),
        builder: (context, _) {
          return CustomPaint(
            painter: _RadarPainter(
              sweepAngle: _sweepController.value * 2 * pi,
              pulse: _pulseController.value,
              nowHours: nowHours,
              hoursMap: hoursMap,
              nextKey: next?.key,
              prevKey: prev?.key,
              nextHours: next?.hours,
              prevHours: prev?.hours,
              imsakHour: imsakHour,
              terbitHour: terbitHour,
              prayerKeys: _prayerKeys,
            ),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'MENUJU',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontFamily: 'RobotoMono',
                      fontSize: 10,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    nextNode?.label ?? '--',
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    nextTimeStr ?? '--:--',
                    style: const TextStyle(
                      color: Color(0xFFD32F2F),
                      fontFamily: 'RobotoMono',
                      fontSize: 28,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    countdownHours == null
                        ? '--:--:--'
                        : '-${_fmtCountdown(countdownHours)}',
                    style: TextStyle(
                      color: const Color(0xFFFFFFFF).withOpacity(0.85),
                      fontFamily: 'RobotoMono',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTimesStrip(Map? jadwal, String? nextKey, String? prevKey) {
    return Row(
      children: _prayerKeys.map((node) {
        final timeStr = jadwal?[node.key]?.toString() ?? '--:--';
        final isNext = node.key == nextKey;
        final isCurrent = node.key == prevKey && !isNext;
        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: isNext
                  ? const Color(0xFFFFFFFF).withOpacity(0.10)
                  : isCurrent
                      ? const Color(0xFFD32F2F).withOpacity(0.08)
                      : Colors.white.withOpacity(0.03),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isNext
                    ? const Color(0xFFFFFFFF).withOpacity(0.5)
                    : isCurrent
                        ? const Color(0xFFD32F2F).withOpacity(0.35)
                        : Colors.white.withOpacity(0.06),
              ),
            ),
            child: Column(
              children: [
                Icon(
                  node.icon,
                  size: 14,
                  color: isNext
                      ? const Color(0xFFFFFFFF)
                      : isCurrent
                          ? const Color(0xFFD32F2F)
                          : Colors.white.withOpacity(0.35),
                ),
                const SizedBox(height: 4),
                Text(
                  node.label,
                  style: TextStyle(
                    color: isNext
                        ? const Color(0xFFFFFFFF)
                        : isCurrent
                            ? const Color(0xFFD32F2F)
                            : Colors.white.withOpacity(0.4),
                    fontFamily: 'RobotoMono',
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  timeStr,
                  style: TextStyle(
                    color: isNext || isCurrent
                        ? Colors.white
                        : Colors.white.withOpacity(0.5),
                    fontFamily: 'RobotoMono',
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _PrayerNode {
  final String key;
  final String label;
  final IconData icon;
  final Color periodColor;
  const _PrayerNode(this.key, this.label, this.icon, this.periodColor);
}

class _RadarPainter extends CustomPainter {
  final double sweepAngle;
  final double pulse;
  final double nowHours;
  final Map<String, double> hoursMap;
  final String? nextKey;
  final String? prevKey;
  final double? nextHours;
  final double? prevHours;
  final double? imsakHour;
  final double? terbitHour;
  final List<_PrayerNode> prayerKeys;

  _RadarPainter({
    required this.sweepAngle,
    required this.pulse,
    required this.nowHours,
    required this.hoursMap,
    required this.nextKey,
    required this.prevKey,
    required this.nextHours,
    required this.prevHours,
    required this.imsakHour,
    required this.terbitHour,
    required this.prayerKeys,
  });

  // Jam 00:00 di puncak lingkaran (jam 12 arah jam analog), searah jarum jam.
  double _angleForHour(double hour) => (hour / 24.0) * 2 * pi - pi / 2;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 24;

    _paintPeriodBand(canvas, center, radius);

    // Ring grid (3 lingkaran konsentris, tipis)
    final ringPaint = Paint()
      ..color = const Color(0xFFD32F2F).withOpacity(0.10)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (final f in [0.35, 0.65, 1.0]) {
      canvas.drawCircle(center, radius * f, ringPaint);
    }

    // Garis jam-jam utama (00/06/12/18) sebagai tick tipis
    final tickPaint = Paint()
      ..color = Colors.white.withOpacity(0.06)
      ..strokeWidth = 1;
    for (int h = 0; h < 24; h += 3) {
      final a = _angleForHour(h.toDouble());
      final p1 = center + Offset(cos(a), sin(a)) * (radius * 0.35);
      final p2 = center + Offset(cos(a), sin(a)) * radius;
      canvas.drawLine(p1, p2, tickPaint);
    }

    // Sweep line ambient (radar scan), memudar di belakangnya
    final sweepGradient = SweepGradient(
      startAngle: 0,
      endAngle: pi / 2.4,
      colors: [
        const Color(0xFFD32F2F).withOpacity(0.16),
        const Color(0xFFD32F2F).withOpacity(0.0),
      ],
      transform: GradientRotation(sweepAngle),
    );
    final sweepPaint = Paint()
      ..shader = sweepGradient.createShader(
        Rect.fromCircle(center: center, radius: radius),
      );
    canvas.drawCircle(center, radius, sweepPaint);

    _paintProgressArc(canvas, center, radius);

    // Node halus: Imsak & Terbit
    _paintMinorNode(canvas, center, radius, imsakHour, 'IMSAK');
    _paintMinorNode(canvas, center, radius, terbitHour, 'TERBIT');

    // Node tiap sholat wajib
    for (final node in prayerKeys) {
      final hour = hoursMap[node.key];
      if (hour == null) continue;
      final angle = _angleForHour(hour);
      final pos = center + Offset(cos(angle), sin(angle)) * radius;
      final isNext = node.key == nextKey;

      if (isNext) {
        final glowPaint = Paint()
          ..color = const Color(0xFFFFFFFF).withOpacity(0.25 + pulse * 0.25)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
        canvas.drawCircle(pos, 16 + pulse * 6, glowPaint);
      }

      final nodePaint = Paint()
        ..color = isNext ? const Color(0xFFFFFFFF) : const Color(0xFF3A4A5C);
      canvas.drawCircle(pos, isNext ? 7 : 5, nodePaint);

      final ringStroke = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = isNext
            ? const Color(0xFFFFFFFF)
            : const Color(0xFFD32F2F).withOpacity(0.5);
      canvas.drawCircle(pos, isNext ? 11 : 8, ringStroke);

      // Label
      final labelPos = center + Offset(cos(angle), sin(angle)) * (radius + 16);
      final tp = TextPainter(
        text: TextSpan(
          text: node.label,
          style: TextStyle(
            color: isNext ? const Color(0xFFFFFFFF) : Colors.white.withOpacity(0.55),
            fontFamily: 'RobotoMono',
            fontSize: 9,
            fontWeight: isNext ? FontWeight.w800 : FontWeight.w500,
            letterSpacing: 0.5,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, labelPos - Offset(tp.width / 2, tp.height / 2));
    }

    // Blip "sekarang" — bergerak mengelilingi ring sepanjang hari
    final nowAngle = _angleForHour(nowHours);
    final nowPos = center + Offset(cos(nowAngle), sin(nowAngle)) * (radius * 0.35);
    final nowGlow = Paint()
      ..color = const Color(0xFFD32F2F).withOpacity(0.4 + pulse * 0.3)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawCircle(nowPos, 8 + pulse * 3, nowGlow);
    final nowDot = Paint()..color = Colors.white;
    canvas.drawCircle(nowPos, 4, nowDot);

    // Garis penghubung dari pusat ke blip (jarum jam HUD)
    final needlePaint = Paint()
      ..color = const Color(0xFFD32F2F).withOpacity(0.35)
      ..strokeWidth = 1.5;
    canvas.drawLine(center, nowPos, needlePaint);
  }

  /// Band warna tipis di sekeliling ring, satu warna per periode hari,
  /// biar "mood" waktu (malam/siang/senja) kebaca sekilas.
  void _paintPeriodBand(Canvas canvas, Offset center, double radius) {
    final entries = prayerKeys
        .where((n) => hoursMap[n.key] != null)
        .map((n) => (node: n, hour: hoursMap[n.key]!))
        .toList()
      ..sort((a, b) => a.hour.compareTo(b.hour));
    if (entries.length < 2) return;

    final bandRect = Rect.fromCircle(center: center, radius: radius);
    for (int i = 0; i < entries.length; i++) {
      final cur = entries[i];
      final nextEntry = entries[(i + 1) % entries.length];
      double span = nextEntry.hour - cur.hour;
      if (span <= 0) span += 24;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..color = cur.node.periodColor.withOpacity(0.16);
      canvas.drawArc(
        bandRect,
        _angleForHour(cur.hour),
        (span / 24.0) * 2 * pi,
        false,
        paint,
      );
    }
  }

  /// Arc terang menunjukkan progres dari sholat terakhir ke berikutnya.
  void _paintProgressArc(Canvas canvas, Offset center, double radius) {
    if (prevHours == null || nextHours == null) return;
    double totalSpan = nextHours! - prevHours!;
    if (totalSpan <= 0) totalSpan += 24;
    double elapsed = nowHours - prevHours!;
    if (elapsed < 0) elapsed += 24;
    final progress = (elapsed / totalSpan).clamp(0.0, 1.0);

    final rect = Rect.fromCircle(center: center, radius: radius);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFFFFFFFF).withOpacity(0.55 + pulse * 0.2)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawArc(
      rect,
      _angleForHour(prevHours!),
      (totalSpan / 24.0) * 2 * pi * progress,
      false,
      paint,
    );
  }

  void _paintMinorNode(
      Canvas canvas, Offset center, double radius, double? hour, String label) {
    if (hour == null) return;
    final angle = _angleForHour(hour);
    final pos = center + Offset(cos(angle), sin(angle)) * radius;

    final dotPaint = Paint()..color = Colors.white.withOpacity(0.35);
    canvas.drawCircle(pos, 3, dotPaint);

    final labelPos = center + Offset(cos(angle), sin(angle)) * (radius + 13);
    final tp = TextPainter(
      text: TextSpan(
        text: label,
        style: TextStyle(
          color: Colors.white.withOpacity(0.3),
          fontFamily: 'RobotoMono',
          fontSize: 7,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.3,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, labelPos - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _RadarPainter oldDelegate) => true;
}
