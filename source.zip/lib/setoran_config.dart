import 'main.dart';

// diturunkan dari [baseUrl] global (main.dart), yang di-load dari config.json
String get kSetoranBaseUrl => '$baseUrl/api/setoran';
String get kUndanganBaseUrl => '$baseUrl/api/undangan';
String get kStoranBaseUrl => '$baseUrl/api/storan';
String get kSetoranFileBaseUrl => baseUrl;

const String kSetoranAdminKey = 'ganti-ke-secret-key-lo'; // samain sama SETORAN_ADMIN_KEY di index.js
