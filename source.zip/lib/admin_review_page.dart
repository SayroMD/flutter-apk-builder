import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'setoran_config.dart';
import 'storan_theme.dart';
import 'main.dart';

/// Halaman admin gabungan buat semua review: Storan (buat akun),
/// Up Role (sendiri), Up Role Buyer, dan Riwayat gabungan ketiganya.
class AdminReviewPage extends StatefulWidget {
  const AdminReviewPage({super.key});

  @override
  State<AdminReviewPage> createState() => _AdminReviewPageState();
}

class _AdminReviewPageState extends State<AdminReviewPage> {
  int _tab = 0;
  static const _labels = ['STORAN', 'UP ROLE', 'UP ROLE BUYER', 'RIWAYAT'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NBColors.bg,
      appBar: AppBar(
        backgroundColor: NBColors.bg,
        elevation: 0,
        title: const Text('REVIEW ADMIN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(_labels.length, (i) {
                    final selected = _tab == i;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _tab = i),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            color: selected ? NBColors.gold : NBColors.surface,
                            border: Border.all(color: Colors.black, width: 3),
                            boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(3, 3))] : null,
                          ),
                          child: Text(_labels[i],
                              style: TextStyle(color: selected ? Colors.black : NBColors.textDim, fontWeight: FontWeight.w900, fontSize: 12)),
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: IndexedStack(
                index: _tab,
                children: const [
                  _StoranPendingList(),
                  _UpRoleSelfPendingList(),
                  _UpRoleBuyerPendingList(),
                  _RiwayatList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _kv(String k, String v) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 2),
    child: Row(children: [
      SizedBox(width: 90, child: Text(k, style: const TextStyle(color: NBColors.textDim, fontSize: 12))),
      Expanded(child: Text(v, style: const TextStyle(color: NBColors.white, fontSize: 12, fontWeight: FontWeight.bold))),
    ]),
  );
}

Future<List<dynamic>> _fetchList(String path) async {
  try {
    final res = await http.get(Uri.parse('$baseUrl$path'), headers: {'x-admin-key': kSetoranAdminKey});
    if (res.statusCode == 200) return jsonDecode(res.body);
  } catch (_) {}
  return [];
}

Future<void> _postAction(String path) async {
  await http.post(Uri.parse('$baseUrl$path'), headers: {'x-admin-key': kSetoranAdminKey});
}

// ============================================================
// TAB 1 — STORAN (buat akun)
// ============================================================
class _StoranPendingList extends StatefulWidget {
  const _StoranPendingList();
  @override
  State<_StoranPendingList> createState() => _StoranPendingListState();
}

class _StoranPendingListState extends State<_StoranPendingList> {
  List<dynamic> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _items = await _fetchList('/api/storan/pending');
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: NBColors.gold));
    if (_items.isEmpty) return const _EmptyState(text: 'GAK ADA STORAN PENDING');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: _items.length,
        itemBuilder: (context, i) {
          final item = _items[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: NBCard(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    NBBadge(text: item['targetRole'], color: NBColors.red, textColor: Colors.white),
                    const SizedBox(width: 6),
                    NBBadge(text: item['packageType'].toString().toUpperCase(), color: NBColors.gold),
                    const Spacer(),
                    Text('${item['days']}H', style: const TextStyle(color: NBColors.textDim, fontWeight: FontWeight.bold, fontSize: 11)),
                  ]),
                  const SizedBox(height: 10),
                  _kv('Harga', 'Rp${item['harga']}'),
                  _kv('Sektor', 'Rp${item['sektor']}'),
                  _kv('Transfer', 'Rp${item['amount']}'),
                  const Divider(color: Colors.black, thickness: 2, height: 20),
                  _kv('Reseller', item['resellerUsername']),
                  _kv('Buyer', item['buyerUsername']),
                  const SizedBox(height: 10),
                  _BuktiImage(url: item['buktiUrl']),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: NBButton(
                        color: NBColors.green,
                        onPressed: () async {
                          await _postAction('/api/storan/approve/${item['depositId']}');
                          _load();
                        },
                        child: const Text('APPROVE'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: NBButton(
                        color: NBColors.red,
                        textColor: Colors.white,
                        onPressed: () async {
                          await _postAction('/api/storan/reject/${item['depositId']}');
                          _load();
                        },
                        child: const Text('TOLAK'),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// TAB 2 — UP ROLE SENDIRI
// ============================================================
class _UpRoleSelfPendingList extends StatefulWidget {
  const _UpRoleSelfPendingList();
  @override
  State<_UpRoleSelfPendingList> createState() => _UpRoleSelfPendingListState();
}

class _UpRoleSelfPendingListState extends State<_UpRoleSelfPendingList> {
  List<dynamic> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _items = await _fetchList('/api/up-role/pending');
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: NBColors.gold));
    if (_items.isEmpty) return const _EmptyState(text: 'GAK ADA REQUEST PENDING');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: _items.length,
        itemBuilder: (context, i) {
          final item = _items[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: NBCard(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    NBBadge(text: item['currentRole'], color: NBColors.surfaceAlt, textColor: Colors.white),
                    const SizedBox(width: 6),
                    const Icon(Icons.arrow_forward, color: NBColors.textDim, size: 14),
                    const SizedBox(width: 6),
                    NBBadge(text: item['targetRole'], color: NBColors.red, textColor: Colors.white),
                  ]),
                  const SizedBox(height: 10),
                  _kv('Username', item['username']),
                  _kv('Selisih', 'Rp${item['selisih']}'),
                  _kv('Transfer', 'Rp${item['amount']}'),
                  const SizedBox(height: 10),
                  _BuktiImage(url: item['buktiUrl']),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: NBButton(
                        color: NBColors.green,
                        onPressed: () async {
                          await _postAction('/api/up-role/approve/${item['depositId']}');
                          _load();
                        },
                        child: const Text('APPROVE'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: NBButton(
                        color: NBColors.red,
                        textColor: Colors.white,
                        onPressed: () async {
                          await _postAction('/api/up-role/reject/${item['depositId']}');
                          _load();
                        },
                        child: const Text('TOLAK'),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// TAB 3 — UP ROLE BUYER
// ============================================================
class _UpRoleBuyerPendingList extends StatefulWidget {
  const _UpRoleBuyerPendingList();
  @override
  State<_UpRoleBuyerPendingList> createState() => _UpRoleBuyerPendingListState();
}

class _UpRoleBuyerPendingListState extends State<_UpRoleBuyerPendingList> {
  List<dynamic> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _items = await _fetchList('/api/up-role-buyer/pending');
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: NBColors.gold));
    if (_items.isEmpty) return const _EmptyState(text: 'GAK ADA REQUEST PENDING');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: _items.length,
        itemBuilder: (context, i) {
          final item = _items[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: NBCard(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    NBBadge(text: item['currentRole'], color: NBColors.surfaceAlt, textColor: Colors.white),
                    const SizedBox(width: 6),
                    const Icon(Icons.arrow_forward, color: NBColors.textDim, size: 14),
                    const SizedBox(width: 6),
                    NBBadge(text: item['targetRole'], color: NBColors.red, textColor: Colors.white),
                  ]),
                  const SizedBox(height: 10),
                  _kv('Seller', item['resellerUsername']),
                  _kv('Akun buyer', item['targetUsername']),
                  _kv('Selisih', 'Rp${item['selisih']}'),
                  _kv('Transfer', 'Rp${item['amount']}'),
                  const SizedBox(height: 10),
                  _BuktiImage(url: item['buktiUrl']),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: NBButton(
                        color: NBColors.green,
                        onPressed: () async {
                          await _postAction('/api/up-role-buyer/approve/${item['depositId']}');
                          _load();
                        },
                        child: const Text('APPROVE'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: NBButton(
                        color: NBColors.red,
                        textColor: Colors.white,
                        onPressed: () async {
                          await _postAction('/api/up-role-buyer/reject/${item['depositId']}');
                          _load();
                        },
                        child: const Text('TOLAK'),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// TAB 4 — RIWAYAT (gabungan ketiganya)
// ============================================================
class _RiwayatList extends StatefulWidget {
  const _RiwayatList();
  @override
  State<_RiwayatList> createState() => _RiwayatListState();
}

class _RiwayatEntry {
  final String jenis;
  final String judul;
  final String subjudul;
  final String status;
  final int at;

  _RiwayatEntry({required this.jenis, required this.judul, required this.subjudul, required this.status, required this.at});
}

class _RiwayatListState extends State<_RiwayatList> {
  List<_RiwayatEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final storan = await _fetchList('/api/storan/history');
    final upRole = await _fetchList('/api/up-role/history');
    final upRoleBuyer = await _fetchList('/api/up-role-buyer/history');

    final entries = <_RiwayatEntry>[
      ...storan.map((d) => _RiwayatEntry(
            jenis: 'STORAN',
            judul: '${d['buyerUsername']} · ${d['targetRole']}',
            subjudul: 'Reseller: ${d['resellerUsername']} · Rp${d['sektor']}',
            status: d['status'],
            at: d['at'] ?? 0,
          )),
      ...upRole.map((d) => _RiwayatEntry(
            jenis: 'UP ROLE',
            judul: '${d['username']} · ${d['currentRole']} \u2192 ${d['targetRole']}',
            subjudul: 'Selisih Rp${d['selisih']}',
            status: d['status'],
            at: d['at'] ?? 0,
          )),
      ...upRoleBuyer.map((d) => _RiwayatEntry(
            jenis: 'UP ROLE BUYER',
            judul: '${d['targetUsername']} · ${d['currentRole']} \u2192 ${d['targetRole']}',
            subjudul: 'Seller: ${d['resellerUsername']} · Selisih Rp${d['selisih']}',
            status: d['status'],
            at: d['at'] ?? 0,
          )),
    ];
    entries.sort((a, b) => b.at.compareTo(a.at));

    setState(() {
      _entries = entries;
      _loading = false;
    });
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'selesai':
        return NBColors.green;
      case 'ditolak':
      case 'gagal':
        return NBColors.red;
      default:
        return NBColors.gold;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: NBColors.gold));
    if (_entries.isEmpty) return const _EmptyState(text: 'BELUM ADA RIWAYAT');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: _entries.length,
        itemBuilder: (context, i) {
          final e = _entries[i];
          final dt = e.at > 0 ? DateTime.fromMillisecondsSinceEpoch(e.at) : null;
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: NBCard(
              padding: const EdgeInsets.all(12),
              shadowOffset: const Offset(3, 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(width: 6, height: 44, color: _statusColor(e.status)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          NBBadge(text: e.jenis, color: NBColors.surfaceAlt, textColor: Colors.white),
                          const Spacer(),
                          NBBadge(text: e.status.toUpperCase(), color: _statusColor(e.status)),
                        ]),
                        const SizedBox(height: 6),
                        Text(e.judul, style: const TextStyle(color: NBColors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                        const SizedBox(height: 2),
                        Text(e.subjudul, style: const TextStyle(color: NBColors.textDim, fontSize: 11)),
                        if (dt != null) ...[
                          const SizedBox(height: 4),
                          Text('${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}',
                              style: const TextStyle(color: NBColors.textDim, fontSize: 10)),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// Shared widgets
// ============================================================
class _EmptyState extends StatelessWidget {
  final String text;
  const _EmptyState({required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text(text, style: const TextStyle(color: NBColors.textDim, fontWeight: FontWeight.w900)));
  }
}

class _BuktiImage extends StatelessWidget {
  final String url;
  const _BuktiImage({required this.url});

  @override
  Widget build(BuildContext context) {
    final fullUrl = '$kSetoranFileBaseUrl$url';
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => _FullscreenImagePage(url: fullUrl)),
      ),
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(border: Border.all(color: Colors.black, width: 3)),
            child: Image.network(
              fullUrl,
              fit: BoxFit.cover,
              height: 220,
              width: double.infinity,
              errorBuilder: (_, __, ___) =>
                  const SizedBox(height: 100, child: Center(child: Icon(Icons.broken_image, color: NBColors.textDim))),
            ),
          ),
          Positioned(
            right: 6,
            bottom: 6,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: NBColors.gold, border: Border.all(color: Colors.black, width: 2)),
              child: const Icon(Icons.zoom_in, color: Colors.black, size: 18),
            ),
          ),
        ],
      ),
    );
  }
}

class _FullscreenImagePage extends StatelessWidget {
  final String url;
  const _FullscreenImagePage({required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 5,
          child: Image.network(
            url,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white38, size: 64),
          ),
        ),
      ),
    );
  }
}
