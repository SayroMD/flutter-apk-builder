import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/io.dart';

import 'main.dart';
import 'nav_bar_visibility.dart';
import 'chat_public.dart';

// ─────────────────────────────────────────────
// DEPENDENCIES (pubspec.yaml):
//   web_socket_channel: ^2.4.0
// ─────────────────────────────────────────────

// ==================== THEME — NEO BRUTALISM (LIGHT) ====================
class _C {
  // Light Neo-Brutal (match tools / news — cream bg)
  static const bg = Color(0xFFF5F0E8);           // cream off-white
  static const surface = Color(0xFFFFFFFF);      // pure white card
  static const surface2 = Color(0xFFFFF8E7);     // light yellow
  static const border = Color(0xFF1A1A1A);       // thick black
  static const borderAccent = Color(0xFF1A1A1A); // sama (light theme)
  static const yellow = Color(0xFFFFE566);
  static const pink = Color(0xFFFF6B9D);
  static const blue = Color(0xFF5B8DEF);
  static const white = Color(0xFFFFFFFF);
  static const text = Color(0xFF1A1A1A);         // dark text
  static const textDim = Color(0xFF666666);
  static const bubbleMine = Color(0xFFFFE566);
  static const bubbleOther = Color(0xFFFFFFFF);
  static const bubbleMineText = Color(0xFF1A1A1A);
}

TextStyle _brutal({
  double size = 13,
  FontWeight weight = FontWeight.w800,
  Color color = _C.text,
  double spacing = 0.4,
}) {
  return TextStyle(
    fontFamily: 'Orbitron',
    fontSize: size,
    fontWeight: weight,
    color: color,
    letterSpacing: spacing,
  );
}

BoxDecoration _hardCard({
  Color fill = _C.surface,
  Color borderColor = _C.borderAccent,
  double borderWidth = 3,
  double radius = 0,
  List<BoxShadow>? shadows,
}) {
  return BoxDecoration(
    color: fill,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: borderColor, width: borderWidth),
    boxShadow: shadows ??
        const [
          BoxShadow(
            color: Color(0xFF000000),
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
  );
}

class ChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final String androidId;

  const ChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.androidId,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  IOWebSocketChannel? _channel;
  StreamSubscription? _sub;

  List<String> chatUsers = [];
  String? selectedUser;
  List<Map<String, dynamic>> messages = [];
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  bool _isConnecting = true;
  bool _isAuthenticated = false;
  String? _authError;
  bool _isOtherTyping = false;
  Timer? _typingHideTimer;
  bool _isSendingTyping = false;
  Timer? _stopTypingTimer;

  // Reconnect
  Timer? _reconnectTimer;
  Timer? _authTimeoutTimer;
  bool _disposed = false;

  @override
  void initState() {
    super.initState();
    _connect();
  }

  // ── WEBSOCKET ─────────────────────────────────

  void _connect() async {
    if (_disposed) return;
    setState(() {
      _isConnecting = true;
      _authError = null;
    });

    try {
      final base = wsBaseUrl
          .replaceFirst('https://', 'wss://')
          .replaceFirst('http://', 'ws://');

      // WAJIB tambah /ws
      final ws = base.endsWith('/') ? '${base}ws' : '$base/ws';

      // Matiin permessage-deflate — biang kerok protocol error (code 1002)
      // pas nego compression dart:io vs lib 'ws' di Node gak sinkron.
      final rawWs = await WebSocket.connect(
        ws,
        compression: CompressionOptions.compressionOff,
      );

      if (_disposed) {
        rawWs.close();
        return;
      }

      _channel = IOWebSocketChannel(rawWs);

      // Timeout kalau server gak bales auth_response dalam 8 detik
      _authTimeoutTimer?.cancel();
      _authTimeoutTimer = Timer(const Duration(seconds: 8), () {
        if (!_disposed && mounted && _isConnecting) {
          setState(() {
            _isConnecting = false;
            _authError = 'Server tidak merespon. Mencoba ulang...';
          });
          _sub?.cancel();
          _channel?.sink.close();
          _scheduleReconnect();
        }
      });

      // Kirim auth segera setelah connect
      _channel!.sink.add(jsonEncode({
        "type": "auth",
        "key": widget.sessionKey,
        "androidId": widget.androidId,
      }));

      _sub = _channel!.stream.listen(
        _onMessage,
        onError: (err) {
          if (!_disposed && mounted) {
            _authTimeoutTimer?.cancel();
            setState(() {
              _isConnecting = false;
              _authError = 'Koneksi error: $err. Mencoba ulang...';
            });
            _scheduleReconnect();
          }
        },
        onDone: () {
          if (!_disposed && mounted) {
            _authTimeoutTimer?.cancel();
            setState(() {
              _isConnecting = false;
              _isAuthenticated = false;
              _authError ??=
                  'Ditutup server. code=${_channel?.closeCode} reason=${_channel?.closeReason}';
            });
            _scheduleReconnect();
          }
        },
        cancelOnError: true,
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          _isConnecting = false;
          _authError = 'Gagal konek: $e';
        });
        _scheduleReconnect();
      }
    }
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    if (_disposed) return;
    _reconnectTimer = Timer(const Duration(seconds: 4), () {
      if (!_disposed && mounted) _connect();
    });
  }

  void _onMessage(dynamic raw) {
    try {
      final data = jsonDecode(raw as String) as Map<String, dynamic>;
      final type = data['type'] as String?;

      switch (type) {
        // ── Auth response ──────────────────────
        case 'auth_response':
          if (data['valid'] == true) {
            _authTimeoutTimer?.cancel();
            setState(() {
              _isAuthenticated = true;
              _isConnecting = false;
              _authError = null;
            });
          } else {
            _authTimeoutTimer?.cancel();
            setState(() {
              _isAuthenticated = false;
              _isConnecting = false;
              _authError = data['message']?.toString() ?? 'Auth gagal';
            });
          }
          break;

        // ── Daftar user yang pernah chat ───────
        case 'chatList':
          if (mounted) {
            setState(() {
              chatUsers = List<String>.from(data['users'] ?? []);
            });
          }
          break;

        // ── Pesan masuk real-time ──────────────
        case 'chat':
          final msg = Map<String, dynamic>.from(data['message'] as Map);
          if (selectedUser != null &&
              (msg['from'] == selectedUser || msg['to'] == selectedUser)) {
            if (mounted) {
              setState(() => messages.add(msg));
              _scrollToBottom();
            }
          } else {
            // Tambah user ke chatList jika belum ada
            final other =
                (msg['from'] == widget.username) ? msg['to'] : msg['from'];
            if (other != null && !chatUsers.contains(other)) {
              if (mounted) setState(() => chatUsers.add(other.toString()));
            }
          }
          break;

        // ── Riwayat pesan ──────────────────────
        case 'messages':
          if (mounted) {
            setState(() {
              messages = List<Map<String, dynamic>>.from(data['messages'] ?? []);
            });
            _scrollToBottom();
          }
          break;

        // ── Pesan dihapus ──────────────────────
        case 'messageDeleted':
          if (mounted) {
            setState(() {
              messages.removeWhere((m) => m['id'] == data['messageId']);
            });
          }
          break;

        // ── Typing indicator ───────────────────
        case 'typing':
          if (data['from'] == selectedUser) {
            final isTyping = data['isTyping'] == true;
            if (mounted) setState(() => _isOtherTyping = isTyping);
            if (isTyping) {
              _typingHideTimer?.cancel();
              _typingHideTimer = Timer(const Duration(seconds: 3), () {
                if (mounted) setState(() => _isOtherTyping = false);
              });
            } else {
              _typingHideTimer?.cancel();
            }
          }
          break;

        // ── Force logout ────────────────────────
        case 'forceLogout':
          if (mounted) {
            setState(() {
              _isAuthenticated = false;
              _authError = data['reason']?.toString() ?? 'Session diakhiri';
            });
          }
          break;

        case 'error':
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Error: ${data['message']}',
                  style: const TextStyle(
                    color: _C.border,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                backgroundColor: _C.yellow,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0),
                  side: const BorderSide(color: _C.border, width: 3),
                ),
              ),
            );
          }
          break;
      }
    } catch (_) {}
  }

  // ── ACTIONS ───────────────────────────────────

  void _loadMessages(String user) {
    if (!_isAuthenticated || _channel == null) return;
    NavBarVisibility.hidden.value = true;
    setState(() {
      selectedUser = user;
      messages.clear();
      _isOtherTyping = false;
    });
    _channel!.sink.add(jsonEncode({"type": "getMessages", "with": user}));

    // Mark as read
    _channel!.sink.add(jsonEncode({"type": "readMessages", "from": user}));
  }

  void _sendMessage() {
    final msg = _msgCtrl.text.trim();
    if (msg.isEmpty || msg.length > 250 || selectedUser == null || !_isAuthenticated) return;

    _channel!.sink.add(jsonEncode({
      "type": "chat",
      "to": selectedUser,
      "message": msg,
    }));

    _msgCtrl.clear();
    _sendTyping(false);
    _stopTypingTimer?.cancel();
  }

  void _deleteMessage(String messageId) {
    if (!_isAuthenticated || _channel == null) return;
    _channel!.sink.add(jsonEncode({
      "type": "deleteMessage",
      "messageId": messageId,
    }));
  }

  void _onTextChanged(String text) {
    if (selectedUser == null) return;
    if (text.isNotEmpty) {
      if (!_isSendingTyping) _sendTyping(true);
      _stopTypingTimer?.cancel();
      _stopTypingTimer = Timer(const Duration(seconds: 2), () => _sendTyping(false));
    } else {
      _sendTyping(false);
      _stopTypingTimer?.cancel();
    }
  }

  void _sendTyping(bool typing) {
    if (_isSendingTyping == typing) return;
    _isSendingTyping = typing;
    if (!_isAuthenticated || selectedUser == null || _channel == null) return;
    _channel!.sink.add(jsonEncode({
      "type": "typing",
      "to": selectedUser,
      "isTyping": typing,
    }));
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── DIALOG BARU CHAT ──────────────────────────

  void _startNewChat() {
    String newUser = '';
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
          side: const BorderSide(color: _C.borderAccent, width: 4),
        ),
        title: Text("CHAT BARU", style: _brutal(size: 16, color: _C.yellow)),
        content: TextField(
          onChanged: (v) => newUser = v.trim(),
          style: const TextStyle(
            color: _C.text,
            fontWeight: FontWeight.w700,
          ),
          decoration: InputDecoration(
            hintText: "Masukkan username...",
            hintStyle: const TextStyle(color: _C.textDim, fontWeight: FontWeight.w600),
            filled: true,
            fillColor: _C.bg,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(0),
              borderSide: const BorderSide(color: _C.borderAccent, width: 3),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(0),
              borderSide: const BorderSide(color: _C.borderAccent, width: 3),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(0),
              borderSide: const BorderSide(color: _C.yellow, width: 3),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL", style: _brutal(size: 12, color: _C.textDim)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.yellow,
              foregroundColor: _C.border,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0),
                side: const BorderSide(color: _C.border, width: 3),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            ),
            onPressed: () {
              Navigator.pop(context);
              if (newUser.isNotEmpty && newUser != widget.username) {
                if (!chatUsers.contains(newUser)) {
                  setState(() => chatUsers.insert(0, newUser));
                }
                _loadMessages(newUser);
              }
            },
            child: Text("MULAI", style: _brutal(size: 12, color: _C.border)),
          ),
        ],
      ),
    );
  }

  // ── DELETE CONFIRM ────────────────────────────

  void _showDeleteDialog(String messageId) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
          side: const BorderSide(color: _C.pink, width: 4),
        ),
        title: Text("HAPUS PESAN?", style: _brutal(size: 15, color: _C.pink)),
        content: const Text(
          "Pesan ini akan dihapus.",
          style: TextStyle(color: _C.textDim, fontWeight: FontWeight.w600),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL", style: _brutal(size: 12, color: _C.textDim)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteMessage(messageId);
            },
            child: Text("HAPUS", style: _brutal(size: 12, color: _C.pink)),
          ),
        ],
      ),
    );
  }

  // ── DISPOSE ───────────────────────────────────

  @override
  void dispose() {
    NavBarVisibility.hidden.value = false;
    _disposed = true;
    _reconnectTimer?.cancel();
    _authTimeoutTimer?.cancel();
    _typingHideTimer?.cancel();
    _stopTypingTimer?.cancel();
    _sub?.cancel();
    _channel?.sink.close();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isConnecting) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: _hardCard(
                fill: _C.yellow,
                borderColor: _C.border,
                borderWidth: 4,
              ),
              child: const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    color: _C.border,
                    strokeWidth: 4,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text("MENGHUBUNGKAN...", style: _brutal(size: 12, color: _C.yellow)),
          ],
        ),
      );
    }

    if (_authError != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: _hardCard(
                  fill: _C.pink,
                  borderColor: _C.border,
                  borderWidth: 4,
                ),
                child: const Icon(Icons.error_outline, color: _C.white, size: 40),
              ),
              const SizedBox(height: 20),
              Text(
                _authError!,
                style: const TextStyle(
                  color: _C.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: const Icon(Icons.refresh, color: _C.border),
                label: Text("RECONNECT", style: _brutal(size: 12, color: _C.border)),
                onPressed: _connect,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _C.yellow,
                  foregroundColor: _C.border,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(0),
                    side: const BorderSide(color: _C.border, width: 3),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (!_isAuthenticated) {
      return Center(
        child: Text("AUTENTIKASI...", style: _brutal(size: 13, color: _C.textDim)),
      );
    }

    return selectedUser == null ? _buildChatList() : _buildChatScreen();
  }

  // ── DAFTAR CHAT ───────────────────────────────

  Widget _buildChatList() {
    return Container(
      color: _C.bg,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: _hardCard(
                      fill: _C.yellow,
                      borderColor: _C.border,
                      borderWidth: 3,
                      shadows: const [
                        BoxShadow(
                          color: Color(0xFF000000),
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.forum_outlined, color: _C.border, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text("CHAT PRIVAT", style: _brutal(size: 16, color: _C.text)),
                  const Spacer(),
                  GestureDetector(
                    onTap: _startNewChat,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: _hardCard(
                        fill: _C.blue,
                        borderColor: _C.border,
                        borderWidth: 3,
                        shadows: const [
                          BoxShadow(
                            color: Color(0xFF000000),
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.add_comment_outlined,
                          color: _C.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),

            // Card entry Public Chat
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: _hardCard(
                fill: _C.surface,
                borderColor: _C.pink,
                borderWidth: 3,
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    NavBarVisibility.hidden.value = true;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChatPublicPage(
                          username: widget.username,
                          role: widget.role,
                          apiKey: widget.sessionKey,
                        ),
                      ),
                    ).then((_) => NavBarVisibility.hidden.value = false);
                  },
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: _hardCard(
                            fill: _C.pink,
                            borderColor: _C.border,
                            borderWidth: 3,
                            shadows: const [],
                          ),
                          child: const Icon(Icons.public, color: _C.white, size: 22),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("PUBLIC // UPLINK",
                                  style: _brutal(size: 13, color: _C.pink)),
                              const SizedBox(height: 4),
                              const Text(
                                "Chat publik semua user",
                                style: TextStyle(
                                  color: _C.textDim,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: _hardCard(
                            fill: _C.yellow,
                            borderColor: _C.border,
                            borderWidth: 2,
                            shadows: const [],
                          ),
                          child: const Icon(Icons.chevron_right,
                              color: _C.border, size: 18),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 6),

            Expanded(
              child: chatUsers.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: _hardCard(
                              fill: _C.surface2,
                              borderColor: _C.borderAccent,
                              borderWidth: 3,
                            ),
                            child: Icon(Icons.chat_bubble_outline,
                                color: _C.textDim, size: 48),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            "BELUM ADA CHAT.\nMULAI CHAT BARU!",
                            textAlign: TextAlign.center,
                            style: _brutal(size: 13, color: _C.textDim),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: chatUsers.length,
                      itemBuilder: (context, i) {
                        final user = chatUsers[i];
                        return Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: _hardCard(
                            fill: _C.surface,
                            borderColor: _C.borderAccent,
                            borderWidth: 3,
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () => _loadMessages(user),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 12),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 48,
                                      height: 48,
                                      decoration: _hardCard(
                                        fill: _C.yellow,
                                        borderColor: _C.border,
                                        borderWidth: 3,
                                        shadows: const [],
                                      ),
                                      alignment: Alignment.center,
                                      child: Text(
                                        user.isNotEmpty
                                            ? user[0].toUpperCase()
                                            : '?',
                                        style: _brutal(size: 16, color: _C.border),
                                      ),
                                    ),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "@$user",
                                            style: const TextStyle(
                                              color: _C.text,
                                              fontSize: 15,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          const Text(
                                            "Ketuk untuk membuka chat",
                                            style: TextStyle(
                                              color: _C.textDim,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: _hardCard(
                                        fill: _C.surface2,
                                        borderColor: _C.borderAccent,
                                        borderWidth: 2,
                                        shadows: const [],
                                      ),
                                      child: const Icon(Icons.chevron_right,
                                          color: _C.text, size: 18),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ── LAYAR CHAT ────────────────────────────────

  Widget _buildChatScreen() {
    return Column(
      children: [
        // AppBar neo-brutal
        Container(
          padding: const EdgeInsets.fromLTRB(8, 12, 16, 14),
          decoration: const BoxDecoration(
            color: _C.surface,
            border: Border(
              bottom: BorderSide(color: _C.borderAccent, width: 3),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    _sendTyping(false);
                    NavBarVisibility.hidden.value = false;
                    setState(() {
                      selectedUser = null;
                      messages.clear();
                      _isOtherTyping = false;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: _hardCard(
                      fill: _C.yellow,
                      borderColor: _C.border,
                      borderWidth: 3,
                      shadows: const [
                        BoxShadow(
                          color: Color(0xFF000000),
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.arrow_back_ios_new,
                        color: _C.border, size: 16),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  width: 42,
                  height: 42,
                  decoration: _hardCard(
                    fill: _C.blue,
                    borderColor: _C.border,
                    borderWidth: 3,
                    shadows: const [],
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    selectedUser!.isNotEmpty
                        ? selectedUser![0].toUpperCase()
                        : '?',
                    style: _brutal(size: 15, color: _C.white),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "@$selectedUser",
                        style: _brutal(size: 14, color: _C.text, weight: FontWeight.w800),
                      ),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 200),
                        child: _isOtherTyping
                            ? Text(
                                "SEDANG MENGETIK...",
                                key: const ValueKey('typing'),
                                style: _brutal(size: 10, color: _C.pink),
                              )
                            : const SizedBox.shrink(key: ValueKey('idle')),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // Pesan
        Expanded(
          child: Container(
            color: _C.bg,
            child: messages.isEmpty
                ? Center(
                    child: Text(
                      "BELUM ADA PESAN.\nKIRIM PESAN PERTAMA!",
                      textAlign: TextAlign.center,
                      style: _brutal(size: 13, color: _C.textDim),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                    itemCount: messages.length,
                    itemBuilder: (_, i) => _chatBubble(messages[i]),
                  ),
          ),
        ),

        // Input
        Container(
          padding: EdgeInsets.only(
            left: 12,
            right: 12,
            top: 12,
            bottom: 12 + MediaQuery.of(context).padding.bottom,
          ),
          decoration: const BoxDecoration(
            color: _C.surface,
            border: Border(
              top: BorderSide(color: _C.borderAccent, width: 3),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _msgCtrl,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLength: 250,
                  maxLines: null,
                  onChanged: _onTextChanged,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: InputDecoration(
                    counterText: '',
                    hintText: "Ketik pesan...",
                    hintStyle: const TextStyle(
                      color: _C.textDim,
                      fontWeight: FontWeight.w600,
                    ),
                    filled: true,
                    fillColor: _C.bg,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(0),
                      borderSide: const BorderSide(color: _C.borderAccent, width: 3),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(0),
                      borderSide: const BorderSide(color: _C.borderAccent, width: 3),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(0),
                      borderSide: const BorderSide(color: _C.yellow, width: 3),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _sendMessage,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: _hardCard(
                    fill: _C.yellow,
                    borderColor: _C.border,
                    borderWidth: 3,
                  ),
                  child: const Icon(Icons.send, color: _C.border, size: 20),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── BUBBLE PESAN ──────────────────────────────

  Widget _chatBubble(Map<String, dynamic> msg) {
    final isMe = msg['fromMe'] == true;
    final messageId = (msg['id'] ?? '').toString();
    final text = (msg['message'] ?? '').toString();
    final time = _formatTime((msg['time'] ?? '').toString());

    return GestureDetector(
      onLongPress: isMe && messageId.isNotEmpty
          ? () => _showDeleteDialog(messageId)
          : null,
      child: Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
          constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.72),
          decoration: BoxDecoration(
            color: isMe ? _C.bubbleMine : _C.bubbleOther,
            borderRadius: BorderRadius.circular(0),
            border: Border.all(
              color: isMe ? _C.border : _C.borderAccent,
              width: 3,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0xFF000000),
                offset: Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!isMe)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    (msg['from'] ?? '').toString(),
                    style: _brutal(size: 11, color: _C.yellow),
                  ),
                ),
              Text(
                text,
                style: TextStyle(
                  color: isMe ? _C.bubbleMineText : _C.text,
                  fontSize: 14,
                  height: 1.35,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  time,
                  style: TextStyle(
                    fontSize: 10,
                    color: isMe ? _C.border.withOpacity(0.55) : _C.textDim,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTime(String iso) {
    try {
      final t = DateTime.parse(iso).toLocal();
      return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }
}
