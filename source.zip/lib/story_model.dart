class Story {
  final String id;
  final String userName;
  final String avatarUrl;
  final String mediaUrl;
  final bool isVideo;
  final DateTime createdAt;

  Story({
    required this.id,
    required this.userName,
    required this.avatarUrl,
    required this.mediaUrl,
    this.isVideo = false,
    required this.createdAt,
  });
}

class StoryGroup {
  final String userId;
  final String userName;
  final String avatarUrl;
  final List<Story> stories;
  bool seen;

  StoryGroup({
    required this.userId,
    required this.userName,
    required this.avatarUrl,
    required this.stories,
    this.seen = false,
  });
}