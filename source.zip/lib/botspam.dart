// bot_spam_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class BotSpamPage extends StatefulWidget {
  const BotSpamPage({super.key});

  @override
  State<BotSpamPage> createState() => _BotSpamPageState();
}

class _BotSpamPageState extends State<BotSpamPage> {
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _tokenController = TextEditingController();
  final TextEditingController _targetIdController = TextEditingController();

  bool _isSpamming = false;
  int _counter = 0;
  String _statusLog = "";
  Timer? _spamTimer;

  @override
  void dispose() {
    _stopSpam();
    _messageController.dispose();
    _tokenController.dispose();
    _targetIdController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    final token = _tokenController.text.trim();
    final targetId = _targetIdController.text.trim();

    if (message.isEmpty || token.isEmpty || targetId.isEmpty) {
      setState(() => _statusLog = "⚠️ Semua field harus diisi!");
      return;
    }

    final url = Uri.parse("https://api.telegram.org/bot$token/sendMessage");
    final body = {
      "chat_id": targetId,
      "text": message,
      "parse_mode": "HTML",
    };

    try {
      final response = await http.post(url, body: body);
      final data = jsonDecode(response.body);

      if (data['ok'] == true) {
        setState(() {
          _counter++;
          _statusLog = "✅ Pesan ke-$_counter terkirim ke $targetId";
        });
      } else {
        setState(() {
          _statusLog = "❌ Gagal: ${data['description']}";
        });
        _stopSpam();
      }
    } catch (e) {
      setState(() {
        _statusLog = "⚠️ Error: $e";
      });
      _stopSpam();
    }
  }

  void _startSpam() {
    final message = _messageController.text.trim();
    final token = _tokenController.text.trim();
    final targetId = _targetIdController.text.trim();

    if (message.isEmpty || token.isEmpty || targetId.isEmpty) {
      setState(() => _statusLog = "⚠️ Isi semua field sebelum memulai spam!");
      return;
    }

    setState(() {
      _isSpamming = true;
      _counter = 0;
      _statusLog = "▶️ Memulai spam ke $targetId...";
    });

    _spamTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (_isSpamming) _sendMessage();
    });
  }

  void _stopSpam() {
    setState(() {
      _isSpamming = false;
      _statusLog = "⏹️ Dihentikan. Total: $_counter pesan";
    });
    _spamTimer?.cancel();
    _spamTimer = null;
  }

  Color _getStatusColor(String status) {
    if (status.contains('✅')) return AppColors.green;
    if (status.contains('❌')) return AppColors.red;
    if (status.contains('⚠️')) return AppColors.orange;
    if (status.contains('▶️')) return AppColors.accent;
    if (status.contains('⏹️')) return AppColors.orange;
    return AppColors.textSec;
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
        title: "SPAM BOT TELEGRAM",
        actions: [
          if (_isSpamming)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                color: AppColors.green.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.green.withOpacity(0.4)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      color: AppColors.green,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: AppColors.green, blurRadius: 6)],
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    "ACTIVE",
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.green,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
        ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            child: Column(
              children: [
                CyberInputField(
                  controller: _messageController,
                  label: "PESAN SPAM",
                  hint: "Masukkan pesan yang akan dikirim...",
                  icon: Icons.message_rounded,
                  maxLines: 3,
                ),
                const SizedBox(height: 14),
                CyberInputField(
                  controller: _tokenController,
                  label: "TOKEN BOT",
                  hint: "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz",
                  icon: Icons.vpn_key_rounded,
                ),
                const SizedBox(height: 14),
                CyberInputField(
                  controller: _targetIdController,
                  label: "ID TARGET",
                  hint: "Contoh: 123456789",
                  icon: Icons.people_rounded,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: CyberButton(
                  label: _isSpamming ? "SPAMMING..." : "START SPAM",
                  icon: _isSpamming ? Icons.hourglass_top : Icons.play_arrow_rounded,
                  onTap: _isSpamming ? () {} : _startSpam,
                  isLoading: _isSpamming,
                  color: AppColors.green,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: CyberButton(
                  label: "STOP",
                  icon: Icons.stop_rounded,
                  onTap: _isSpamming ? _stopSpam : () {},
                  color: AppColors.red,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          const SectionTitle(
            icon: Icons.terminal_rounded,
            title: "STATUS LOG",
          ),
          const SizedBox(height: 8),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
                  ),
                  child: Text(
                    _statusLog.isEmpty ? "Menunggu perintah..." : _statusLog,
                    style: TextStyle(
                      color: _getStatusColor(_statusLog),
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      fontFamily: appFont,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.accent.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.send_rounded, color: AppColors.accent, size: 18),
                      const SizedBox(width: 10),
                      const Text(
                        "Total Terkirim: ",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textSec,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        "$_counter",
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.info_outline, color: AppColors.textMuted, size: 12),
                    const SizedBox(width: 6),
                    const Expanded(
                      child: Text(
                        "Spam dikirim setiap 2 detik. STOP manual jika sudah cukup.",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textMuted,
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}