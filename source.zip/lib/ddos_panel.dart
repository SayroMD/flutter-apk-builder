import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'main.dart';
import 'base_page.dart';

enum AttackMode { ipPort, domain }

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    this.listDoos = const [],
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();

  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _slideAnimation;

  double attackDuration = 60;
  AttackMode _attackMode = AttackMode.ipPort;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  void _onModeChanged(AttackMode mode) {
    setState(() {
      _attackMode = mode;
      if (mode == AttackMode.domain) {
        portController.text = "80";
      }
    });
  }

  Future<void> _sendAttack() async {
    final target = targetController.text.trim();
    if (target.isEmpty) {
      _showAlert("Input Tidak Valid", "Target tidak boleh kosong.");
      return;
    }

    int port;
    if (_attackMode == AttackMode.ipPort) {
      final portStr = portController.text.trim();
      if (portStr.isEmpty || int.tryParse(portStr) == null) {
        _showAlert("Port Tidak Valid", "Harap masukkan port yang benar (angka).");
        return;
      }
      port = int.parse(portStr);
    } else {
      port = 80;
    }

    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    try {
      final uri = Uri.parse("$baseUrl/sendCommand");
      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': key,
          'target': target,
          'port': port,
          'duration': duration,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 401) {
        _showAlert("❌ Kunci Tidak Valid", data['error'] ?? "Sesi tidak valid.");
      } else if (response.statusCode == 400) {
        _showAlert("⚠️ Permintaan Salah", data['error'] ?? "Data yang dikirim tidak lengkap.");
      } else if (response.statusCode == 200 && data['success'] == true) {
        _showAlert("✅ Berhasil", data['message'] ?? "Serangan diluncurkan.");
      } else {
        _showAlert("❌ Gagal", data['error'] ?? "Terjadi kesalahan tak terduga.");
      }
    } catch (e) {
      _showAlert("❌ Error", "Koneksi gagal. Periksa jaringan Anda.");
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: AppColors.red.withOpacity(0.3), width: 1.5),
        ),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.red)),
        content: Text(msg, style: TextStyle(color: AppColors.textSec)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: AppColors.red)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberPage(
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              GlassCard(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.rocket_launch, color: AppColors.red, size: 28),
                    const SizedBox(width: 12),
                    const Text(
                      "ATTACK PANEL",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: AppColors.textPrimary,
                        fontFamily: appFont,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.computer, color: AppColors.red),
                        const SizedBox(width: 10),
                        const Text(
                          "Target Input",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                            fontFamily: appFont,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    CyberInputField(
                      controller: targetController,
                      label: _attackMode == AttackMode.ipPort ? "Target IP" : "Domain",
                      hint: _attackMode == AttackMode.ipPort
                          ? "Contoh: 1.1.1.1"
                          : "Contoh: example.com",
                      icon: Icons.computer,
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: SegmentedButton<AttackMode>(
                        segments: const [
                          ButtonSegment(
                            value: AttackMode.ipPort,
                            label: Text('IP + Port'),
                            icon: Icon(Icons.computer),
                          ),
                          ButtonSegment(
                            value: AttackMode.domain,
                            label: Text('Domain'),
                            icon: Icon(Icons.public),
                          ),
                        ],
                        selected: {_attackMode},
                        onSelectionChanged: (Set<AttackMode> newSelection) {
                          _onModeChanged(newSelection.first);
                        },
                        style: ButtonStyle(
                          backgroundColor: WidgetStateProperty.resolveWith<Color?>(
                            (Set<WidgetState> states) {
                              if (states.contains(WidgetState.selected)) {
                                return AppColors.red.withOpacity(0.3);
                              }
                              return AppColors.surface2;
                            },
                          ),
                          foregroundColor: WidgetStateProperty.all(AppColors.textPrimary),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.wifi_tethering, color: AppColors.red),
                        const SizedBox(width: 10),
                        const Text(
                          "Port",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                            fontFamily: appFont,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (_attackMode == AttackMode.ipPort)
                      CyberInputField(
                        controller: portController,
                        label: "Port",
                        hint: "Contoh: 80, 443, 22",
                        icon: Icons.wifi_tethering,
                        keyboardType: TextInputType.number,
                      )
                    else
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.red.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.wifi_tethering, color: AppColors.textMuted),
                            const SizedBox(width: 12),
                            const Text(
                              "Port default: 80",
                              style: TextStyle(color: AppColors.textSec, fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.timer, color: AppColors.red),
                        const SizedBox(width: 10),
                        const Text(
                          "Durasi Serangan",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                            fontFamily: appFont,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Icon(Icons.timer_outlined, color: AppColors.red),
                        const SizedBox(width: 8),
                        Text(
                          "⏱ ${attackDuration.toInt()} detik",
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Slider(
                      value: attackDuration,
                      min: 10,
                      max: 300,
                      divisions: 29,
                      label: "${attackDuration.toInt()}s",
                      activeColor: AppColors.red,
                      inactiveColor: AppColors.textMuted,
                      thumbColor: AppColors.red,
                      onChanged: (value) => setState(() => attackDuration = value),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              CyberButton(
                label: "LAUNCH ATTACK",
                icon: Icons.bolt,
                onTap: _sendAttack,
                color: AppColors.red,
                width: double.infinity,
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }
}