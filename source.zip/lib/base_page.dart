// base_page.dart - VERSION FIX
import 'package:flutter/material.dart';
import 'dart:math' as dart_math;
import 'dart:ui';

// ==================== APP COLORS ====================
class AppColors {
  static const bg          = Color(0xFF060B19); 
  static const surface     = Color(0xFF0D1424);
  static const surface2    = Color(0xFF131D33);
  static const border      = Color(0xFF1E2A44);
  static const borderLight = Color(0xFF3B4859); 
  static const accent      = Color(0xFF00E5FF); 
  static const textPrimary = Color(0xFFFFFFFF);
  static const textSec     = Color(0xFF8B9BB4);
  static const textMuted   = Color(0xFF4A5A75);
  static const highlight   = Color(0xFF00E5FF);
  static const green       = Color(0xFF00E676);
  static const red         = Color(0xFFFF1744);
  static const orange      = Color(0xFFFF9100);
  static const darkBlue    = Color(0xFF0044CC);
  static const white       = Color(0xFFFFFFFF); 
}

const String appFont = 'Orbitron';

// ==================== HEXAGON BACKGROUND ====================
class HexagonBackground extends StatelessWidget {
  final Widget child;
  const HexagonBackground({super.key, required this.child});
  
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: const Color(0xFF030712)),
        Positioned(
          top: -150, left: -150,
          child: Container(
            width: 400, height: 400,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: AppColors.accent.withOpacity(0.12), blurRadius: 200)]
            ),
          ),
        ),
        Positioned(
          bottom: -150, right: -150,
          child: Container(
            width: 400, height: 400,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: AppColors.darkBlue.withOpacity(0.25), blurRadius: 200)]
            ),
          ),
        ),
        Positioned.fill(child: CustomPaint(painter: _HexagonPainter())),
        child,
      ],
    );
  }
}

class _HexagonPainter extends CustomPainter {
  void drawHexagon(Canvas canvas, Paint paint, double x, double y, double size) {
    final path = Path();
    for (int i = 0; i <= 6; i++) {
      double angle = (i * 60) * dart_math.pi / 180;
      double px = x + size * dart_math.cos(angle);
      double py = y + size * dart_math.sin(angle);
      if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
    }
    path.close(); 
    canvas.drawPath(path, paint);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final fillPaint = Paint()
      ..color = AppColors.accent.withOpacity(0.04)
      ..style = PaintingStyle.fill;
    final strokePaint = Paint()
      ..color = AppColors.accent.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    double hexSize = 45.0; 
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        double x = size.width - 20 + (i * 78) - (j * 39);
        double y = -20.0 + (j * 68) + (i * 34);
        drawHexagon(canvas, fillPaint, x, y, hexSize); 
        drawHexagon(canvas, strokePaint, x, y, hexSize);
      }
    }
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        double x = -40.0 + (i * 78) - (j * 39);
        double y = size.height - 150 + (j * 68) + (i * 34);
        drawHexagon(canvas, fillPaint, x, y, hexSize); 
        drawHexagon(canvas, strokePaint, x, y, hexSize);
      }
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==================== GLASS CARD ====================
class GlassCard extends StatelessWidget {
  final Widget child;
  final double? width;
  final double? height;
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final Color? borderColor;
  final double? borderRadius;
  final BoxDecoration? decoration;
  
  const GlassCard({
    super.key,
    required this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.borderColor,
    this.borderRadius = 16,
    this.decoration,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      margin: margin ?? EdgeInsets.zero,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: decoration ??
          BoxDecoration(
            color: AppColors.surface.withOpacity(0.5),
            borderRadius: BorderRadius.circular(borderRadius ?? 16),
            border: Border.all(
              color: borderColor ?? AppColors.borderLight.withOpacity(0.4),
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.accent.withOpacity(0.05),
                blurRadius: 10,
              ),
            ],
          ),
      child: child,
    );
  }
}

// ==================== SECTION TITLE ====================
class SectionTitle extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? badge;
  final VoidCallback? onTap;

  const SectionTitle({
    super.key,
    required this.icon,
    required this.title,
    this.badge,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.accent.withOpacity(0.3)),
              ),
              child: Icon(icon, color: AppColors.accent, size: 14),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                fontFamily: appFont,
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        if (badge != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.accent.withOpacity(0.5)),
            ),
            child: Text(
              badge!,
              style: const TextStyle(
                fontFamily: appFont,
                color: AppColors.accent,
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
      ],
    );
  }
}

// ==================== CYBER BUTTON ====================
class CyberButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  final bool isLoading;
  final double? width;

  const CyberButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onTap,
    this.color,
    this.isLoading = false,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final btnColor = color ?? AppColors.accent;
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: width,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [btnColor, btnColor.withOpacity(0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: btnColor.withOpacity(0.3),
              blurRadius: 15,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isLoading)
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
            else
              Icon(icon, color: Colors.white, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontFamily: appFont,
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== STATUS BADGE ====================
class StatusBadge extends StatelessWidget {
  final String label;
  final bool isOnline;

  const StatusBadge({super.key, required this.label, this.isOnline = true});

  @override
  Widget build(BuildContext context) {
    final color = isOnline ? AppColors.green : AppColors.red;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)],
            ),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontFamily: appFont,
              color: color,
              fontSize: 8,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== LOADING SHIMMER ====================
class CyberLoadingShimmer extends StatelessWidget {
  const CyberLoadingShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: SizedBox(
        width: 24,
        height: 24,
        child: CircularProgressIndicator(
          color: AppColors.accent,
          strokeWidth: 2.5,
        ),
      ),
    );
  }
}

// ==================== EMPTY STATE ====================
class CyberEmptyState extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onRetry;

  const CyberEmptyState({
    super.key,
    required this.title,
    required this.subtitle,
    this.icon = Icons.inbox_rounded,
    this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: AppColors.textMuted, size: 48),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(
              fontFamily: appFont,
              color: AppColors.textSec,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              fontFamily: appFont,
              color: AppColors.textMuted,
              fontSize: 11,
            ),
            textAlign: TextAlign.center,
          ),
          if (onRetry != null) ...[
            const SizedBox(height: 16),
            CyberButton(
              label: 'Coba Lagi',
              icon: Icons.refresh_rounded,
              onTap: onRetry!,
            ),
          ],
        ],
      ),
    );
  }
}

// ==================== CYBER INPUT FIELD ====================
class CyberInputField extends StatelessWidget {
  final TextEditingController? controller;
  final String label;
  final String hint;
  final IconData? icon;
  final bool obscureText;
  final TextInputType keyboardType;
  final int maxLines;
  final String? errorText;
  final void Function(String)? onChanged;
  final void Function(String)? onSubmitted;
  final String? Function(String?)? validator;

  const CyberInputField({
    super.key,
    this.controller,
    required this.label,
    required this.hint,
    this.icon,
    this.obscureText = false,
    this.keyboardType = TextInputType.text,
    this.maxLines = 1,
    this.errorText,
    this.onChanged,
    this.onSubmitted,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Row(
            children: [
              if (icon != null) ...[
                Icon(icon, color: AppColors.accent, size: 12),
                const SizedBox(width: 6),
              ],
              Text(
                label,
                style: const TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface2,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: errorText != null ? AppColors.red : AppColors.borderLight,
            ),
          ),
          child: TextFormField(
            controller: controller,
            obscureText: obscureText,
            keyboardType: keyboardType,
            maxLines: maxLines,
            validator: validator,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 13,
              fontFamily: appFont,
            ),
            cursorColor: AppColors.accent,
            onChanged: onChanged,
            onFieldSubmitted: onSubmitted,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 12,
                fontFamily: appFont,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              errorText: errorText,
              errorStyle: const TextStyle(
                fontFamily: appFont,
                fontSize: 10,
                color: AppColors.red,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ==================== CYBER APP BAR (OLD - KEEP FOR COMPATIBILITY) ====================
class CyberAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Widget? leading;
  final List<Widget>? actions;
  final bool showBackButton;
  final VoidCallback? onBack;

  const CyberAppBar({
    super.key,
    required this.title,
    this.leading,
    this.actions,
    this.showBackButton = true,
    this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: showBackButton
          ? GestureDetector(
              onTap: onBack ?? () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.surface2.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: AppColors.textSec,
                  size: 18,
                ),
              ),
            )
          : leading,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.accent.withOpacity(0.3)),
            ),
            child: const Icon(Icons.star_rounded, color: AppColors.accent, size: 14),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: const TextStyle(
              fontFamily: appFont,
              color: AppColors.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
      centerTitle: true,
      actions: actions,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(60);
}

// ==================== CYBER APP BAR V2 (NEW STYLE) ====================
class CyberAppBarV2 extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBack;
  final List<Widget>? actions;
  final bool showBackButton;

  const CyberAppBarV2({
    super.key,
    required this.title,
    this.onBack,
    this.actions,
    this.showBackButton = true,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(  // <-- TAMBAHKAN INI
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 18),
        child: Row(
          children: [
            if (showBackButton)
              GestureDetector(
                onTap: onBack ?? () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: AppColors.accent,
                    size: 16,
                  ),
                ),
              ),
            if (!showBackButton) const SizedBox(width: 32),
            Expanded(
              child: Center(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontFamily: appFont,
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    shadows: [Shadow(color: AppColors.accent, blurRadius: 10)],
                  ),
                ),
              ),
            ),
            if (actions != null && actions!.isNotEmpty)
              Row(
                children: actions!,
              )
            else
              const SizedBox(width: 32),
          ],
        ),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(80);
}

// ==================== CYBER PAGE ====================
class CyberPage extends StatelessWidget {
  final Widget child;
  final bool showHexagon;
  final bool useSafeArea;
  final EdgeInsets? padding;

  const CyberPage({
    super.key,
    required this.child,
    this.showHexagon = true,
    this.useSafeArea = true,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = child;
    
    if (padding != null) {
      content = Padding(padding: padding!, child: content);
    }
    
    if (useSafeArea) {
      content = SafeArea(child: content);
    }
    
    if (showHexagon) {
      content = HexagonBackground(child: content);
    } else {
      content = Container(color: AppColors.bg, child: content);
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: content,
    );
  }
}

// ==================== SCROLLABLE CYBER PAGE ====================
class CyberScrollPage extends StatelessWidget {
  final Widget child;
  final bool showHexagon;
  final EdgeInsets? padding;
  final EdgeInsets? contentPadding;
  final PreferredSizeWidget? appBar;

  const CyberScrollPage({
    super.key,
    required this.child,
    this.showHexagon = true,
    this.padding,
    this.contentPadding,
    this.appBar,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: appBar,
      body: CyberPage(
        showHexagon: showHexagon,
        padding: padding,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: contentPadding ?? const EdgeInsets.all(16),
          child: child,
        ),
      ),
    );
  }
}

// base_page.dart - tambahkan ini

class CyberScrollPageV2 extends StatelessWidget {
  final Widget child;
  final String title;
  final List<Widget>? actions;
  final bool showBackButton;
  final VoidCallback? onBack;
  final bool showHexagon;
  final EdgeInsets? padding;
  final EdgeInsets? contentPadding;

  const CyberScrollPageV2({
    super.key,
    required this.child,
    required this.title,
    this.actions,
    this.showBackButton = true,
    this.onBack,
    this.showHexagon = true,
    this.padding,
    this.contentPadding,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: HexagonBackground(
        child: Column(
          children: [
            CyberAppBarV2(
              title: title,
              actions: actions,
              showBackButton: showBackButton,
              onBack: onBack,
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: contentPadding ?? const EdgeInsets.all(16),
                child: child,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== NOTIFICATION SNACKBAR ====================
void showCyberSnackBar(
  BuildContext context,
  String message, {
  bool isError = false,
  Duration duration = const Duration(seconds: 3),
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: Colors.white,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                fontFamily: appFont,
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
      backgroundColor: isError ? AppColors.red : AppColors.accent,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      duration: duration,
    ),
  );
}