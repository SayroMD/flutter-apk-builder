import 'package:flutter/material.dart';

/// Dua mode tema OTAX:
///  - classic     : neo brutalism lama (kuning-hitam, siku tajam)
///  - darkComic3D : gelap, outline tebal, bayangan slab 3D, sudut membulat
enum AppThemeMode { classic, darkComic3D }

class AppTheme {
  final AppThemeMode mode;
  const AppTheme(this.mode);

  bool get isComic => mode == AppThemeMode.darkComic3D;

  // ---------- Palet ----------
  Color get scaffoldBg =>
      isComic ? const Color(0xFF06090C) : const Color(0xFFFFF8E7);
  Color get surface =>
      isComic ? const Color(0xFF0D141A) : const Color(0xFFFFFFFF);
  Color get surfaceAlt =>
      isComic ? const Color(0xFF131D25) : const Color(0xFFFFFBF0);
  Color get outline =>
      isComic ? const Color(0xFF020405) : const Color(0xFF000000);
  Color get textPrimary =>
      isComic ? const Color(0xFFE8F3EF) : const Color(0xFF000000);
  Color get textSecondary =>
      isComic ? const Color(0xFF8FA3AD) : const Color(0xFF555555);

  Color get accentTeal => isComic ? const Color(0xFF19F5C8) : const Color(0xFF3DE8C0);
  // comic: nggak ada kuning — 'gold' jadi biru neon
  Color get accentGold => isComic ? const Color(0xFF3D8BFF) : const Color(0xFFFFD84A);
  Color get accentPink => isComic ? const Color(0xFFFF2E93) : const Color(0xFFFF4D8D);
  Color get accentPurple => isComic ? const Color(0xFFA35CFF) : const Color(0xFF9B7BFF);

  double get radius => isComic ? 18.0 : 0.0;
  double get borderWidth => isComic ? 3.0 : 4.0;

  /// Versi gelap dari warna aksen — dipakai buat sisi "tebal" slab 3D.
  Color deep(Color c) {
    final hsl = HSLColor.fromColor(c);
    // sisi tebal slab: tetep jenuh (neon gelap) biar keliatan di background gelap
    return hsl.withLightness((hsl.lightness * 0.62).clamp(0.16, 0.36)).toColor();
  }

  // ---------- Shadow ----------
  /// Classic: hitam keras. Comic: slab warna aksen versi gelap, offset ke bawah
  /// biar keliatan kayak balok 3D yang nonjol.
  List<BoxShadow> slabShadow(Color accent, {double d = 5}) {
    if (!isComic) {
      return [BoxShadow(color: Colors.black, offset: Offset(d, d), blurRadius: 0)];
    }
    return [
      // slab 3D (sisi tebal, neon gelap) — kanan & bawah, kayak classic
      BoxShadow(color: deep(accent), offset: Offset(d, d), blurRadius: 0),
      // glow neon
      BoxShadow(
          color: accent.withOpacity(0.55),
          offset: Offset(d, d),
          blurRadius: 18,
          spreadRadius: -1),
    ];
  }

  // ---------- Decoration ----------
  BoxDecoration card({Color? accent, bool tinted = false, double d = 5}) {
    final a = accent ?? accentTeal;
    if (!isComic) {
      return BoxDecoration(
        color: tinted ? a : Colors.white,
        border: Border.all(color: Colors.black, width: 3),
        boxShadow: slabShadow(a, d: d),
      );
    }
    return BoxDecoration(
      color: tinted ? Color.alphaBlend(a.withOpacity(0.14), surface) : surface,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: a, width: borderWidth),
      boxShadow: slabShadow(a, d: d),
    );
  }

  /// Tombol ikon kecil (AppBar dll)
  BoxDecoration iconButton(Color accent, {Color? classicFill}) {
    if (!isComic) {
      return BoxDecoration(
        color: classicFill ?? Colors.white,
        border: Border.all(color: Colors.black, width: 2.5),
        boxShadow: slabShadow(accent, d: 2),
      );
    }
    return BoxDecoration(
      color: Color.alphaBlend(accent.withOpacity(0.16), surface),
      borderRadius: BorderRadius.circular(12),
      boxShadow: slabShadow(accent, d: 3),
    );
  }

  /// Stiker/badge kecil: kuning, teks hitam, outline hitam (comic) 
  BoxDecoration sticker([Color? fill]) => BoxDecoration(
        color: isComic ? deep(accentTeal) : (fill ?? accentGold),
        borderRadius: BorderRadius.circular(isComic ? 10 : 0),
        border: Border.all(color: isComic ? accentTeal : outline, width: 2.5),
        boxShadow: [
          BoxShadow(
              color: isComic ? Colors.black : outline,
              offset: const Offset(2, 3),
              blurRadius: 0),
        ],
      );

  TextStyle titleStyle({double size = 16}) => TextStyle(
        color: textPrimary,
        fontSize: size,
        fontWeight: FontWeight.w900,
        letterSpacing: isComic ? 0.6 : 1.2,
      );

  TextStyle subtitleStyle({double size = 12}) => TextStyle(
        color: textSecondary,
        fontSize: size,
        fontWeight: FontWeight.w600,
      );

  // ---------- Helper dipakai codemod dashboard ----------
  /// Warna garis/border default (classic: hitam, comic: teal)
  Color get line => isComic ? accentTeal : Colors.black;

  /// Warna teks/ikon di atas permukaan (classic: hitam, comic: terang)
  Color get ink => isComic ? textPrimary : Colors.black;
  Color get inkSub => isComic ? textSecondary : const Color(0xFF555555);

  /// Ketebalan border: comic dibatasi maks 3
  double bw(num w) => isComic ? (w > 3 ? 3.0 : w.toDouble()) : w.toDouble();

  /// Sudut membulat: classic ikut angka asli, comic dibulatin
  BorderRadius rr(num n) =>
      BorderRadius.circular(isComic ? (n <= 0 ? 16.0 : (n <= 4 ? 14.0 : n.toDouble())) : n.toDouble());

  /// Bayangan keras. Classic: hitam offset (d,d). Comic: slab 3D warna teal gelap.
  List<BoxShadow> hard(num d) => slabShadow(accentTeal, d: d.toDouble());

  /// Pengganti "kuning" di comic: permukaan gelap (classic tetap kuning)
  Color get yellow => isComic ? surfaceAlt : const Color(0xFFFFE566);

  /// Warna fill versi neon-gelap (comic): jenuh tapi nggak nyilaukin.
  /// Kuning digeser ke mint biar nggak ada kuning. Abu gelap dibiarin.
  Color dk(Color? c) {
    final col = c ?? Colors.grey;
    if (!isComic) return col;
    final h = HSLColor.fromColor(col);
    if (h.saturation < 0.2 && h.lightness < 0.5) return col;
    var hue = h.hue;
    if (hue >= 35 && hue <= 75) hue = 168; // kuning -> teal neon
    if (hue <= 12 || hue >= 350) hue = 331; // merah polos -> pink neon
    return HSLColor.fromAHSL(
      col.alpha / 255.0,
      hue,
      h.saturation.clamp(0.75, 1.0),
      (h.lightness * 0.8).clamp(0.34, 0.46),
    ).toColor();
  }

  /// Versi buat teks/ikon: neon terang, kebaca di background gelap.
  Color tx(Color? c) {
    final col = c ?? Colors.grey;
    if (!isComic) return col;
    final h = HSLColor.fromColor(col);
    if (h.saturation < 0.2) return col;
    var hue = h.hue;
    if (hue >= 35 && hue <= 75) hue = 168; // kuning -> teal neon
    if (hue <= 12 || hue >= 350) hue = 331; // merah polos -> pink neon
    return HSLColor.fromAHSL(
      col.alpha / 255.0,
      hue,
      h.saturation.clamp(0.8, 1.0),
      h.lightness.clamp(0.58, 0.68),
    ).toColor();
  }
}

// ============================================================
// COMIC BACKDROP — background "rame": grid halus + blob neon +
// halftone dots pojokan. Dipasang di belakang konten (Positioned.fill),
// no-op total di mode classic.
// ============================================================
class ComicBackdrop extends StatelessWidget {
  final AppTheme theme;
  const ComicBackdrop({super.key, required this.theme});

  @override
  Widget build(BuildContext context) {
    if (!theme.isComic) return const SizedBox.shrink();
    return Positioned.fill(
      child: IgnorePointer(
        child: CustomPaint(
          painter: _ComicBackdropPainter(theme),
        ),
      ),
    );
  }
}

class _ComicBackdropPainter extends CustomPainter {
  final AppTheme t;
  _ComicBackdropPainter(this.t);

  // ---------- helper gambar ----------
  void _blob(Canvas c, Offset center, double r, Color color, double op) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [color.withOpacity(op), color.withOpacity(0)],
      ).createShader(Rect.fromCircle(center: center, radius: r))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40);
    c.drawCircle(center, r, paint);
  }

  /// Halftone: grid titik yang mengecil menjauhi pojok (dx/dy = arah)
  void _halftone(Canvas c, Offset origin, int cols, int rows, double gap,
      double maxR, Color color, {int dx = 1, int dy = 1}) {
    final p = Paint()..color = color;
    for (int r = 0; r < rows; r++) {
      for (int k = 0; k < cols; k++) {
        final double rad = (maxR - (r + k) * (maxR / (cols + rows - 2)) * 1.1)
            .clamp(0.5, maxR)
            .toDouble();
        c.drawCircle(
          Offset(origin.dx + dx * k * gap, origin.dy + dy * r * gap),
          rad,
          p,
        );
      }
    }
  }

  /// Garis diagonal ala speed-line
  void _speedLines(Canvas c, Offset start, Offset dir, int n, double gap,
      double len, Color color) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    // tegak lurus arah gerak
    final perp = Offset(-dir.dy, dir.dx);
    for (int i = 0; i < n; i++) {
      final s = start + perp * (i * gap);
      c.drawLine(s, s + dir * len, p);
    }
  }

  void _sparkle(Canvas c, Offset o, double r, Color color, double op) {
    final path = Path()
      ..moveTo(o.dx, o.dy - r)
      ..quadraticBezierTo(o.dx, o.dy, o.dx + r, o.dy)
      ..quadraticBezierTo(o.dx, o.dy, o.dx, o.dy + r)
      ..quadraticBezierTo(o.dx, o.dy, o.dx - r, o.dy)
      ..quadraticBezierTo(o.dx, o.dy, o.dx, o.dy - r)
      ..close();
    c.drawPath(path, Paint()..color = color.withOpacity(op));
  }

  void _plus(Canvas c, Offset o, double r, Color color, double op) {
    final p = Paint()
      ..color = color.withOpacity(op)
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    c.drawLine(Offset(o.dx - r, o.dy), Offset(o.dx + r, o.dy), p);
    c.drawLine(Offset(o.dx, o.dy - r), Offset(o.dx, o.dy + r), p);
  }

  void _ring(Canvas c, Offset o, double r, Color color, double op) {
    c.drawCircle(
        o,
        r,
        Paint()
          ..color = color.withOpacity(op)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5);
  }

  void _square(Canvas c, Offset o, double r, double rot, Color color, double op,
      {bool filled = false}) {
    c.save();
    c.translate(o.dx, o.dy);
    c.rotate(rot);
    final rect = Rect.fromCenter(center: Offset.zero, width: r * 2, height: r * 2);
    c.drawRect(
        rect,
        Paint()
          ..color = color.withOpacity(op)
          ..style = filled ? PaintingStyle.fill : PaintingStyle.stroke
          ..strokeWidth = 2.5);
    c.restore();
  }

  void _triangle(Canvas c, Offset o, double r, double rot, Color color, double op) {
    c.save();
    c.translate(o.dx, o.dy);
    c.rotate(rot);
    final path = Path()
      ..moveTo(0, -r)
      ..lineTo(r, r * 0.8)
      ..lineTo(-r, r * 0.8)
      ..close();
    c.drawPath(
        path,
        Paint()
          ..color = color.withOpacity(op)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..strokeJoin = StrokeJoin.round);
    c.restore();
  }

  void _zigzag(Canvas c, Offset o, double w, Color color, double op,
      {bool vertical = false}) {
    final path = Path()..moveTo(o.dx, o.dy);
    const seg = 5;
    for (int i = 1; i <= seg; i++) {
      final off = (i.isOdd ? -6.0 : 6.0);
      if (vertical) {
        path.lineTo(o.dx + off, o.dy + w / seg * i);
      } else {
        path.lineTo(o.dx + w / seg * i, o.dy + off);
      }
    }
    c.drawPath(
        path,
        Paint()
          ..color = color.withOpacity(op)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..strokeJoin = StrokeJoin.round
          ..strokeCap = StrokeCap.round);
  }

  /// Garis putus-putus vertikal (rel tepi)
  void _dashedV(Canvas c, double x, double h, Color color, double op) {
    final p = Paint()
      ..color = color.withOpacity(op)
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    for (double y = 30; y < h - 30; y += 22) {
      c.drawLine(Offset(x, y), Offset(x, y + 10), p);
    }
  }

  /// Deretan aksesoris di sepanjang satu sisi (kiri/kanan)
  void _sideColumn(Canvas c, Size s, {required bool left}) {
    final x = left ? 15.0 : s.width - 15.0;
    final colors = [t.accentTeal, t.accentPink, t.accentGold, t.accentPurple];
    int i = 0;
    for (double y = 70; y < s.height - 40; y += 96) {
      final col = colors[(i + (left ? 0 : 2)) % colors.length];
      final o = Offset(x + (i.isEven ? 0 : (left ? 5 : -5)), y);
      final rot = (i * 0.5) * (left ? 1 : -1);
      switch ((i + (left ? 0 : 1)) % 5) {
        case 0:
          _plus(c, o, 7, col, 0.45);
          break;
        case 1:
          _ring(c, o, 6, col, 0.45);
          break;
        case 2:
          _triangle(c, o, 7, rot, col, 0.45);
          break;
        case 3:
          _square(c, o, 6, rot, col, 0.45, filled: i % 3 == 0);
          break;
        default:
          _sparkle(c, o, 10, col, 0.55);
      }
      i++;
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    canvas.drawRect(Offset.zero & size, Paint()..color = t.scaffoldBg);

    // ===== LAYER 1: blob glow neon — 6 titik, sampai ke sisi kiri/kanan =====
    _blob(canvas, Offset(w * 0.08, h * 0.04), w * 0.55, t.accentTeal, 0.22);
    _blob(canvas, Offset(w * 0.95, h * 0.18), w * 0.45, t.accentPink, 0.16);
    _blob(canvas, Offset(w * 0.85, h * 0.75), w * 0.50, t.accentPurple, 0.14);
    _blob(canvas, Offset(w * 0.05, h * 0.85), w * 0.40, t.accentGold, 0.13);
    _blob(canvas, Offset(-w * 0.05, h * 0.45), w * 0.38, t.accentGold, 0.12); // kiri
    _blob(canvas, Offset(w * 1.02, h * 0.50), w * 0.36, t.accentTeal, 0.12); // kanan

    // ===== LAYER 2: dot-grid halus =====
    final dot = Paint()..color = t.accentTeal.withOpacity(0.07);
    for (double y = 0; y < h; y += 26) {
      for (double x = 0; x < w; x += 26) {
        canvas.drawCircle(Offset(x, y), 1.1, dot);
      }
    }

    // ===== LAYER 3: speed-lines — 3 sumber (kanan-atas, kiri-atas, kiri-bawah) =====
    _speedLines(canvas, Offset(w - 30, -20), const Offset(0.35, 0.94), 6, 22,
        150, t.accentTeal.withOpacity(0.10));
    _speedLines(canvas, Offset(30, -20), const Offset(-0.35, 0.94), 5, 22, 120,
        t.accentPink.withOpacity(0.09));
    _speedLines(canvas, Offset(-10, h - 200), const Offset(0.94, 0.35), 5, 22,
        130, t.accentPurple.withOpacity(0.09));

    // ===== LAYER 4: halftone — bawah-kiri, bawah-kanan, tepi kiri, tepi kanan =====
    _halftone(canvas, Offset(18, h - 90), 5, 5, 14, 2.6,
        t.accentPink.withOpacity(0.18)); // bawah kiri
    _halftone(canvas, Offset(w - 18, h - 90), 5, 5, 14, 2.6,
        t.accentGold.withOpacity(0.20), dx: -1); // bawah kanan
    _halftone(canvas, Offset(8, h * 0.30), 4, 7, 13, 2.4,
        t.accentPurple.withOpacity(0.16)); // tepi kiri
    _halftone(canvas, Offset(w - 8, h * 0.58), 4, 7, 13, 2.4,
        t.accentTeal.withOpacity(0.16), dx: -1); // tepi kanan

    // ===== LAYER 5: rel putus-putus di kedua sisi =====
    _dashedV(canvas, 5, h, t.accentTeal, 0.22);
    _dashedV(canvas, w - 5, h, t.accentPink, 0.22);

    // ===== LAYER 6: aksesoris berjejer di sisi kiri & kanan =====
    _sideColumn(canvas, size, left: true);
    _sideColumn(canvas, size, left: false);

    // ===== LAYER 7: zigzag & sparkle tersebar =====
    _zigzag(canvas, Offset(w * 0.55, h * 0.03), 70, t.accentTeal, 0.28);
    _zigzag(canvas, Offset(w * 0.06, h * 0.62), 60, t.accentPink, 0.26,
        vertical: true);
    _zigzag(canvas, Offset(w * 0.93, h * 0.36), 60, t.accentGold, 0.28,
        vertical: true);
    _zigzag(canvas, Offset(w * 0.42, h * 0.97), 80, t.accentPurple, 0.26);

    _sparkle(canvas, Offset(w * 0.30, h * 0.10), 11, t.accentTeal, 0.5);
    _sparkle(canvas, Offset(w * 0.78, h * 0.08), 8, t.accentPink, 0.5);
    _sparkle(canvas, Offset(w * 0.90, h * 0.44), 12, t.accentGold, 0.45);
    _sparkle(canvas, Offset(w * 0.10, h * 0.50), 9, t.accentPurple, 0.5);
    _sparkle(canvas, Offset(w * 0.70, h * 0.90), 11, t.accentTeal, 0.45);
    _sparkle(canvas, Offset(w * 0.25, h * 0.93), 8, t.accentPink, 0.5);
  }

  @override
  bool shouldRepaint(covariant _ComicBackdropPainter old) => old.t.mode != t.mode;
}
