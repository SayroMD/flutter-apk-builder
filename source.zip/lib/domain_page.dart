import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage>
    with TickerProviderStateMixin {
  final TextEditingController _domainController = TextEditingController();

  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<Map<String, dynamic>> _certRecords = [];
  List<String> _uniqueSubdomains = [];
  String? _errorMessage;
  String? _scannedDomain;

  late final AnimationController _pulseAnim;
  late final AnimationController _scanAnim;
  late final AnimationController _resultAnim;
  late final Animation<double> _pulse;
  late final Animation<double> _scan;
  late final Animation<double> _fadeIn;
  late final Animation<Offset> _slideUp;

  @override
  void initState() {
    super.initState();
    _pulseAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _scanAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _resultAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 750));

    _pulse = Tween<double>(begin: 0.6, end: 1.0).animate(CurvedAnimation(parent: _pulseAnim, curve: Curves.easeInOut));
    _scan = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _scanAnim, curve: Curves.easeInOut));
    _fadeIn = CurvedAnimation(parent: _resultAnim, curve: Curves.easeOutQuint);
    _slideUp = Tween<Offset>(begin: const Offset(0, 0.16), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultAnim, curve: Curves.easeOutExpo));
  }

  @override
  void dispose() {
    _domainController.dispose();
    _pulseAnim.dispose();
    _scanAnim.dispose();
    _resultAnim.dispose();
    super.dispose();
  }

  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim().toLowerCase();
    if (domain.isEmpty) {
      _setError('Masukkan nama domain terlebih dahulu.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _certRecords = [];
      _uniqueSubdomains = [];
      _scannedDomain = domain;
    });
    _scanAnim.repeat();

    try {
      final results = await Future.wait([
        _fetchDns(domain),
        _fetchSubdomains(domain),
      ]);

      final dns = results[0] as Map<String, dynamic>?;
      final certs = results[1] as List<Map<String, dynamic>>;

      final Set<String> subSet = {};
      for (final c in certs) {
        final nm = c['name_value']?.toString() ?? '';
        final cn = c['common_name']?.toString() ?? '';
        for (final s in [nm, cn]) {
          if (s.isNotEmpty) {
            for (final part in s.split('\n')) {
              final t = part.trim();
              if (t.isNotEmpty) subSet.add(t);
            }
          }
        }
      }
      final subList = subSet.toList()..sort();

      if (dns != null || certs.isNotEmpty) {
        setState(() {
          _dnsData = dns;
          _certRecords = certs;
          _uniqueSubdomains = subList;
        });
        _resultAnim.forward(from: 0);
      } else {
        _setError('Tidak ada data ditemukan untuk domain ini.');
      }
    } catch (e) {
      _setError('Koneksi gagal. Periksa jaringan Anda.');
    } finally {
      _scanAnim.stop();
      _scanAnim.reset();
      setState(() => _isLoading = false);
    }
  }

  Future<Map<String, dynamic>?> _fetchDns(String domain) async {
    try {
      final url = Uri.parse('https://api.siputzx.my.id/api/tools/dns?domain=$domain');
      final resp = await http.get(url).timeout(const Duration(seconds: 12));
      if (resp.statusCode == 200) {
        final j = jsonDecode(resp.body);
        return j['status'] == true ? j['data'] as Map<String, dynamic>? : null;
      }
    } catch (_) {}
    return null;
  }

  Future<List<Map<String, dynamic>>> _fetchSubdomains(String domain) async {
    try {
      final url = Uri.parse('https://api.siputzx.my.id/api/tools/dns?domain=$domain');
      final resp = await http.get(url).timeout(const Duration(seconds: 20));
      if (resp.statusCode == 200) {
        final j = jsonDecode(resp.body);
        if (j['success'] == true && j['result'] is List) {
          return (j['result'] as List).whereType<Map<String, dynamic>>().toList();
        }
      }
    } catch (_) {}
    return [];
  }

  void _setError(String msg) {
    setState(() {
      _errorMessage = msg;
      _dnsData = null;
      _certRecords = [];
      _uniqueSubdomains = [];
      _isLoading = false;
    });
    _scanAnim.stop();
    _scanAnim.reset();
  }

  void _copy(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    showCyberSnackBar(context, '$label disalin');
  }

  @override
  Widget build(BuildContext context) {
    final hasResult = _dnsData != null || _certRecords.isNotEmpty || _uniqueSubdomains.isNotEmpty;

    return CyberScrollPageV2(
      title: "DOMAIN OSINT",
      child: Column(
        children: [
          _buildInputCard(),
          if (_errorMessage != null) ...[
            const SizedBox(height: 12),
            _buildError(),
          ],
          if (hasResult) ...[
            const SizedBox(height: 14),
            FadeTransition(
              opacity: _fadeIn,
              child: SlideTransition(
                position: _slideUp,
                child: Column(
                  children: [
                    _buildSummaryBanner(),
                    const SizedBox(height: 14),
                    _buildDnsSection(),
                    const SizedBox(height: 14),
                    _buildSubdomainSection(),
                    const SizedBox(height: 14),
                    _buildCertSection(),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return GlassCard(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.red.withOpacity(0.1),
                  border: Border.all(color: AppColors.red.withOpacity(0.3)),
                ),
                child: const Icon(Icons.travel_explore, color: AppColors.red, size: 18),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'DOMAIN OSINT',
                    style: TextStyle(
                      fontFamily: appFont,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                      letterSpacing: 2.5,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Text(
                    'Subdomain & Certificate Scanner',
                    style: TextStyle(
                      fontFamily: appFont,
                      fontSize: 11,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Opacity(
                  opacity: _pulse.value,
                  child: Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.red,
                      boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.6), blurRadius: 6)],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          CyberInputField(
            controller: _domainController,
            label: "Domain",
            hint: "contoh: example.com",
            icon: Icons.dns_rounded,
            keyboardType: TextInputType.url,
          ),
          const SizedBox(height: 12),
          CyberButton(
            label: _isLoading ? "MEMINDAI..." : "SCAN DOMAIN",
            icon: _isLoading ? Icons.hourglass_top : Icons.radar_rounded,
            onTap: _isLoading ? () {} : _checkDomain,
            isLoading: _isLoading,
            width: double.infinity,
          ),
        ],
      ),
    );
  }

  Widget _buildError() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      borderColor: AppColors.red.withOpacity(0.25),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.red.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.error_outline_rounded, color: AppColors.red, size: 19),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w500,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryBanner() {
    final subCount = _uniqueSubdomains.length;
    final certCount = (() {
      final Map<String, bool> seen = {};
      for (final c in _certRecords) {
        seen[c['serial_number']?.toString() ?? c['id'].toString()] = true;
      }
      return seen.length;
    })();
    final hasDns = _dnsData != null;

    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.red.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.red.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Container(width: 6, height: 6,
                        decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    const Text(
                      'SCAN SELESAI',
                      style: TextStyle(
                        fontFamily: appFont,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5,
                        color: AppColors.red,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Icon(Icons.language_rounded, size: 14, color: AppColors.textMuted),
              const SizedBox(width: 5),
              Text(
                _scannedDomain ?? '',
                style: TextStyle(
                  fontFamily: appFont,
                  fontSize: 13,
                  color: AppColors.textMuted,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _statChip(icon: Icons.language_rounded, label: 'Subdomains', value: subCount.toString(), color: AppColors.orange),
              const SizedBox(width: 10),
              _statChip(icon: Icons.verified_rounded, label: 'Sertifikat', value: certCount.toString(), color: AppColors.accent),
              const SizedBox(width: 10),
              _statChip(icon: Icons.dns_rounded, label: 'DNS', value: hasDns ? 'OK' : '-', color: AppColors.red),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statChip({required IconData icon, required String label, required String value, required Color color}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.07),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.18)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(height: 5),
            Text(value, style: TextStyle(fontFamily: appFont, fontWeight: FontWeight.w800, fontSize: 16, color: color)),
            Text(label, style: TextStyle(fontFamily: appFont, fontSize: 10, color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }

  Widget _buildDnsSection() {
    if (_dnsData == null) return const SizedBox.shrink();
    final dns = _dnsData!;
    final records = dns['records'] as Map<String, dynamic>? ?? {};

    final List<Widget> rows = [
      _buildRow('Domain', dns['unicodeDomain']?.toString(), copy: true),
      _divider(),
      _buildRow('Punycode', dns['punycodeDomain']?.toString(), copy: true),
    ];

    final nsAnswers = records['ns']?['response']?['answer'] as List? ?? [];
    if (nsAnswers.isNotEmpty) {
      rows.add(_divider());
      rows.add(_sectionLabel('Name Servers'));
      for (final ns in nsAnswers) {
        final t = ns['record']?['target']?.toString();
        if (t != null && t.isNotEmpty) {
          rows.add(_buildRow('NS', t, copy: true));
        }
      }
    }

    final aAnswers = records['a']?['response']?['answer'] as List? ?? [];
    if (aAnswers.isNotEmpty) {
      rows.add(_divider());
      rows.add(_sectionLabel('A Records'));
      for (final a in aAnswers) {
        final d = a['record']?['data']?.toString();
        if (d != null && d.isNotEmpty) {
          rows.add(_buildRow('IP', d, copy: true, valueColor: AppColors.accent));
        }
      }
    }

    final soaAnswers = records['soa']?['response']?['answer'] as List? ?? [];
    if (soaAnswers.isNotEmpty) {
      final soa = soaAnswers.first['record'];
      rows.add(_divider());
      rows.add(_sectionLabel('SOA Record'));
      rows.add(_buildRow('Primary NS', soa?['host']?.toString(), copy: true));
      rows.add(_buildRow('Admin', soa?['admin']?.toString(), copy: true));
      rows.add(_buildRow('Serial', soa?['serial']?.toString()));
      rows.add(_buildRow('Refresh', soa?['refresh']?.toString()));
      rows.add(_buildRow('Retry', soa?['retry']?.toString()));
      rows.add(_buildRow('Expire', soa?['expire']?.toString()));
      rows.add(_buildRow('Min TTL', soa?['minimum']?.toString()));
    }

    return _buildSection(
      title: 'DNS INFORMATION',
      icon: Icons.dns_rounded,
      accent: AppColors.red,
      children: rows,
    );
  }

  Widget _divider() => Container(height: 1, color: AppColors.border, margin: const EdgeInsets.symmetric(vertical: 2));

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 2),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: appFont,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.5,
          color: AppColors.textMuted,
        ),
      ),
    );
  }

  Widget _buildRow(String label, String? value, {bool copy = false, Color? valueColor}) {
    if (value == null || value.trim().isEmpty) return const SizedBox.shrink();
    return InkWell(
      onTap: copy ? () => _copy(value, label) : null,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 110,
              child: Text(label,
                  style: TextStyle(fontFamily: appFont, fontSize: 12, color: AppColors.textMuted)),
            ),
            Expanded(
              child: Text(value,
                  style: TextStyle(
                    fontFamily: appFont,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                    color: valueColor ?? AppColors.textPrimary,
                    height: 1.35,
                  )),
            ),
            if (copy)
              Padding(
                padding: const EdgeInsets.only(left: 6),
                child: Icon(Icons.copy_all_rounded, size: 13, color: AppColors.textMuted),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required IconData icon, required Color accent, required List<Widget> children}) {
    final visible = children.where((c) => c is SizedBox && c.child == null ? false : true).toList();
    if (visible.isEmpty) return const SizedBox.shrink();

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: accent, size: 15),
                ),
                const SizedBox(width: 10),
                Text(title,
                    style: TextStyle(
                      fontFamily: appFont,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                      letterSpacing: 2,
                      color: accent,
                    )),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildSubdomainSection() {
    if (_uniqueSubdomains.isEmpty) return const SizedBox.shrink();

    return _buildSection(
      title: 'SUBDOMAINS (${_uniqueSubdomains.length})',
      icon: Icons.language_rounded,
      accent: AppColors.orange,
      children: [
        const SizedBox(height: 4),
        ..._uniqueSubdomains.map((s) => Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.surface2.withOpacity(0.5),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: InkWell(
            onTap: () => _copy(s, s),
            child: Row(
              children: [
                Container(width: 5, height: 5,
                    decoration: const BoxDecoration(color: AppColors.orange, shape: BoxShape.circle)),
                const SizedBox(width: 12),
                Expanded(child: Text(s,
                    style: TextStyle(
                      fontFamily: appFont,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ))),
                Icon(Icons.copy_all_rounded, size: 13, color: AppColors.textMuted),
              ],
            ),
          ),
        )).toList(),
      ],
    );
  }

  Widget _buildCertSection() {
    if (_certRecords.isEmpty) return const SizedBox.shrink();

    final Map<String, Map<String, dynamic>> bySerial = {};
    for (final c in _certRecords) {
      final serial = c['serial_number']?.toString() ?? c['id'].toString();
      bySerial.putIfAbsent(serial, () => c);
    }
    final unique = bySerial.values.toList();

    return _buildSection(
      title: 'SSL CERTIFICATES (${unique.length})',
      icon: Icons.verified_rounded,
      accent: AppColors.accent,
      children: [
        const SizedBox(height: 4),
        ...unique.map((c) => _buildCertCard(c)).toList(),
      ],
    );
  }

  Widget _buildCertCard(Map<String, dynamic> cert) {
    final cn = cert['common_name']?.toString() ?? '';
    final issuer = cert['issuer_name']?.toString() ?? '';
    final notBefore = _fmtDate(cert['not_before']?.toString());
    final notAfter = _fmtDate(cert['not_after']?.toString());
    final serial = cert['serial_number']?.toString() ?? '';

    final expiry = cert['not_after']?.toString();
    bool isExpired = false;
    if (expiry != null) {
      try {
        isExpired = DateTime.parse(expiry).isBefore(DateTime.now());
      } catch (_) {}
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface2.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isExpired ? AppColors.red.withOpacity(0.2) : AppColors.accent.withOpacity(0.12),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(cn,
                  style: TextStyle(
                    fontFamily: appFont,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: isExpired ? AppColors.red.withOpacity(0.12) : AppColors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: isExpired ? AppColors.red.withOpacity(0.3) : AppColors.green.withOpacity(0.3),
                  ),
                ),
                child: Text(
                  isExpired ? 'EXPIRED' : 'VALID',
                  style: TextStyle(
                    fontFamily: appFont,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                    color: isExpired ? AppColors.red : AppColors.green,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(height: 1, color: AppColors.border),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.account_balance_rounded, size: 12, color: AppColors.textMuted),
              const SizedBox(width: 6),
              Expanded(child: Text(_shortIssuer(issuer),
                  style: TextStyle(fontFamily: appFont, fontSize: 12, color: AppColors.textMuted))),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.date_range_rounded, size: 12, color: AppColors.textMuted),
              const SizedBox(width: 6),
              Text('$notBefore  →  $notAfter',
                  style: TextStyle(
                    fontFamily: appFont,
                    fontSize: 12,
                    color: isExpired ? AppColors.red.withOpacity(0.7) : AppColors.accent.withOpacity(0.8),
                  )),
            ],
          ),
          if (serial.isNotEmpty) ...[
            const SizedBox(height: 6),
            InkWell(
              onTap: () => _copy(serial, 'Serial'),
              child: Row(
                children: [
                  Icon(Icons.fingerprint, size: 12, color: AppColors.textMuted),
                  const SizedBox(width: 6),
                  Expanded(child: Text(serial,
                      style: TextStyle(
                        fontFamily: appFont,
                        fontSize: 11,
                        color: AppColors.textMuted,
                      ),
                      overflow: TextOverflow.ellipsis)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _shortIssuer(String issuer) {
    final cnMatch = RegExp(r'CN=([^,]+)').firstMatch(issuer);
    final oMatch = RegExp(r'O=([^,]+)').firstMatch(issuer);
    if (cnMatch != null && oMatch != null) {
      return '${oMatch.group(1)} — ${cnMatch.group(1)}';
    }
    return issuer;
  }

  String _fmtDate(String? raw) {
    if (raw == null || raw.isEmpty) return '';
    try {
      final dt = DateTime.parse(raw);
      final months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
      return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
    } catch (_) {
      return raw.split('T').first;
    }
  }
}