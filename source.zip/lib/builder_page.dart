import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';
import 'main.dart';

class BuilderPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const BuilderPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<BuilderPage> createState() => _BuilderPageState();
}

class _BuilderPageState extends State<BuilderPage> {
  final TextEditingController _appNameCtrl = TextEditingController();
  final TextEditingController _uidCtrl = TextEditingController();
  File? _selectedIcon;
  bool _isBuilding = false;
  String _buildLog = '';
  String? _downloadUrl;

  // Neo Brutalism Colors
  static const _bg = Color(0xFFF5F0E8);          // Cream
  static const _card = Color(0xFFFFFFFF);         // White
  static const _black = Color(0xFF111111);
  static const _yellow = Color(0xFFFFE566);
  static const _pink = Color(0xFFFF6B9D);
  static const _blue = Color(0xFF4D9DE0);
  static const _green = Color(0xFF6BCB77);
  static const _orange = Color(0xFFFF8C42);

  @override
  void dispose() {
    _appNameCtrl.dispose();
    _uidCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickIcon() async {
    final picker = ImagePicker();
    final XFile? result = await picker.pickImage(source: ImageSource.gallery);
    if (result != null) {
      setState(() => _selectedIcon = File(result.path));
    }
  }

  Future<void> _startBuild() async {
    final appName = _appNameCtrl.text.trim();
    final uid = _uidCtrl.text.trim();

    if (appName.isEmpty) {
      _showError('Nama APK wajib diisi');
      return;
    }
    if (uid.isEmpty) {
      _showError('UID wajib diisi');
      return;
    }

    setState(() {
      _isBuilding = true;
      _downloadUrl = null;
      _buildLog = '⏳ Menghubungkan ke server...\n';
    });

    try {
      var uri = Uri.parse('$baseUrl/api/build-apk');
      var request = http.MultipartRequest('POST', uri)
        ..fields['appName'] = appName
        ..fields['uid'] = uid
        ..fields['key'] = widget.sessionKey
        ..fields['username'] = widget.username;

      setState(() {
        _buildLog += '📦 Upload konfigurasi...\n';
        _buildLog += '👤 Owner : ${widget.username}\n';
        _buildLog += '📱 Nama  : $appName\n';
        _buildLog += '🔑 UID   : $uid\n';
      });

      if (_selectedIcon != null) {
        request.files.add(
          await http.MultipartFile.fromPath('icon', _selectedIcon!.path),
        );
        setState(() => _buildLog += '🖼️  Icon berhasil diupload\n');
      }

      setState(() => _buildLog += '🔨 Sedang merepack APK...\n');

      var response = await request.send().timeout(const Duration(minutes: 5));
      var responseData = await response.stream.bytesToString();
      var json = jsonDecode(responseData);

      setState(() => _isBuilding = false);

      if (response.statusCode == 200 && json['success'] == true) {
        final rawUrl = json['downloadUrl'] as String;
        final dl = rawUrl.startsWith('http') ? rawUrl : '$baseUrl$rawUrl';
        setState(() {
          _downloadUrl = dl;
          _buildLog += '✅ APK berhasil dibuild!\n';
          _buildLog += '📥 Siap didownload\n';
        });
      } else {
        setState(() {
          _buildLog += '❌ Gagal: ${json['error'] ?? 'Unknown error'}\n';
        });
        _showError(json['error'] ?? 'Gagal membuild APK');
      }
    } catch (e) {
      setState(() {
        _isBuilding = false;
        _buildLog += '❌ Error: $e\n';
      });
      _showError('Kesalahan jaringan: $e');
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: _pink,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
          side: const BorderSide(color: _black, width: 3),
        ),
      ),
    );
  }

  // Neo Brutalism Card
  Widget _brutalCard({
    required String title,
    required Color accent,
    required Widget child,
    IconData? icon,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: _card,
        border: Border.all(color: _black, width: 3),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(6, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: accent,
            child: Row(
              children: [
                if (icon != null) ...[
                  Icon(icon, color: _black, size: 18),
                  const SizedBox(width: 8),
                ],
                Text(
                  title.toUpperCase(),
                  style: const TextStyle(
                    color: _black,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: child,
          ),
        ],
      ),
    );
  }

  Widget _brutalTextField(
    TextEditingController ctrl,
    String hint, {
    IconData? prefixIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _bg,
        border: Border.all(color: _black, width: 2.5),
      ),
      child: TextField(
        controller: ctrl,
        style: const TextStyle(
          color: _black,
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: _black.withOpacity(0.4),
            fontWeight: FontWeight.w500,
          ),
          prefixIcon: prefixIcon != null
              ? Icon(prefixIcon, color: _black, size: 20)
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildIconPicker() {
    return Row(
      children: [
        GestureDetector(
          onTap: _pickIcon,
          child: Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: _selectedIcon != null ? _green : _bg,
              border: Border.all(color: _black, width: 3),
              boxShadow: const [
                BoxShadow(color: _black, offset: Offset(4, 4), blurRadius: 0),
              ],
            ),
            child: _selectedIcon != null
                ? Image.file(_selectedIcon!, fit: BoxFit.cover)
                : const Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add_photo_alternate, color: _black, size: 28),
                      SizedBox(height: 4),
                      Text(
                        'PILIH',
                        style: TextStyle(
                          color: _black,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _selectedIcon != null ? 'ICON SIAP' : 'BELUM ADA ICON',
                style: TextStyle(
                  color: _selectedIcon != null ? _green : _black,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                _selectedIcon != null
                    ? _selectedIcon!.path.split('/').last
                    : 'Tap kotak untuk pilih logo (PNG/JPG)',
                style: TextStyle(
                  color: _black.withOpacity(0.6),
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              if (_selectedIcon != null) ...[
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: () => setState(() => _selectedIcon = null),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _pink,
                      border: Border.all(color: _black, width: 2),
                    ),
                    child: const Text(
                      'HAPUS',
                      style: TextStyle(
                        color: _black,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // Header
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _yellow,
                  border: Border.all(color: _black, width: 3),
                  boxShadow: const [
                    BoxShadow(color: _black, offset: Offset(6, 6), blurRadius: 0),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _black,
                            border: Border.all(color: _black, width: 2),
                          ),
                          child: const Text(
                            'BUILDER',
                            style: TextStyle(
                              color: _yellow,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                        const Spacer(),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close, color: _black, size: 26),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'CUSTOM APK',
                      style: TextStyle(
                        color: _black,
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        height: 1.1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Ganti Nama • Logo • UID',
                      style: TextStyle(
                        color: _black.withOpacity(0.7),
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Content
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  // Section: Info Akun
                  _brutalCard(
                    title: 'Akun Terhubung',
                    accent: _blue,
                    icon: Icons.person,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.username,
                          style: const TextStyle(
                            color: _black,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Session aktif • Auto inject owner',
                          style: TextStyle(
                            color: _black.withOpacity(0.6),
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Section: Nama APK
                  _brutalCard(
                    title: 'Nama Aplikasi',
                    accent: _orange,
                    icon: Icons.android,
                    child: _brutalTextField(
                      _appNameCtrl,
                      'Contoh: Sync Pro /  Tik Tok',
                      prefixIcon: Icons.edit,
                    ),
                  ),

                  // Section: UID
                  _brutalCard(
                    title: 'UID',
                    accent: _pink,
                    icon: Icons.vpn_key,
                    child: _brutalTextField(
                      _uidCtrl,
                      'Masukkan UID unik',
                      prefixIcon: Icons.fingerprint,
                    ),
                  ),

                  // Section: Logo
                  _brutalCard(
                    title: 'Logo Aplikasi',
                    accent: _green,
                    icon: Icons.image,
                    child: _buildIconPicker(),
                  ),

                  // Section: Ringkasan
                  _brutalCard(
                    title: 'Ringkasan Build',
                    accent: _yellow,
                    icon: Icons.checklist,
                    child: Column(
                      children: [
                        _summaryRow('Nama APK', _appNameCtrl.text.isEmpty ? '-' : _appNameCtrl.text),
                        const SizedBox(height: 8),
                        _summaryRow('UID', _uidCtrl.text.isEmpty ? '-' : _uidCtrl.text),
                        const SizedBox(height: 8),
                        _summaryRow('Logo', _selectedIcon != null ? 'Sudah dipilih' : 'Belum ada'),
                      ],
                    ),
                  ),

                  // Build Log
                  if (_buildLog.isNotEmpty)
                    _brutalCard(
                      title: _isBuilding ? 'Building...' : 'Build Log',
                      accent: _isBuilding ? _green : _blue,
                      icon: Icons.terminal,
                      child: Text(
                        _buildLog,
                        style: const TextStyle(
                          color: _black,
                          fontFamily: 'monospace',
                          fontSize: 13,
                          height: 1.6,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),

                  // Download Button
                  if (_downloadUrl != null)
                    GestureDetector(
                      onTap: () async {
                        try {
                          final uri = Uri.parse(_downloadUrl!);
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri, mode: LaunchMode.externalApplication);
                          }
                        } catch (e) {
                          _showError('Gagal membuka link');
                        }
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: _green,
                          border: Border.all(color: _black, width: 3),
                          boxShadow: const [
                            BoxShadow(color: _black, offset: Offset(6, 6), blurRadius: 0),
                          ],
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.download, color: _black, size: 26),
                            SizedBox(width: 14),
                            Expanded(
                              child: Text(
                                'APK SIAP • TAP UNTUK DOWNLOAD',
                                style: TextStyle(
                                  color: _black,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                  // Build Button
                  GestureDetector(
                    onTap: _isBuilding ? null : _startBuild,
                    child: Container(
                      height: 64,
                      decoration: BoxDecoration(
                        color: _isBuilding ? Colors.grey.shade400 : _black,
                        border: Border.all(color: _black, width: 3),
                        boxShadow: const [
                          BoxShadow(color: _black, offset: Offset(6, 6), blurRadius: 0),
                        ],
                      ),
                      child: Center(
                        child: _isBuilding
                            ? const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      color: _black,
                                      strokeWidth: 3,
                                    ),
                                  ),
                                  SizedBox(width: 14),
                                  Text(
                                    'MEMBANGUN APK...',
                                    style: TextStyle(
                                      color: _black,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 15,
                                    ),
                                  ),
                                ],
                              )
                            : const Text(
                                'BUILD APK SEKARANG',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16,
                                  letterSpacing: 1,
                                ),
                              ),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 90,
          child: Text(
            label,
            style: TextStyle(
              color: _black.withOpacity(0.6),
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: _black,
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}