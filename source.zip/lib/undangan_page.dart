import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'setoran_config.dart';

class UndanganPage extends StatefulWidget {
  const UndanganPage({super.key});

  @override
  State<UndanganPage> createState() => _UndanganPageState();
}

class _UndanganPageState extends State<UndanganPage> {
  static const deepBlack = Color(0xFF0D0D0D);
  static const accentRed = Color(0xFFD32F2F);
  static const cardDark = Color(0xFF1A1A1A);

  String _role = 'fullup'; // 'fullup' | 'reseller'
  final _idController = TextEditingController();
  bool _submitting = false;
  bool _caraExpanded = false;
  bool _riwayatExpanded = false;
  List<dynamic> _riwayat = [];
  bool _riwayatLoading = false;

  @override
  void dispose() {
    _idController.dispose();
    super.dispose();
  }

  Future<void> _loadRiwayat() async {
    setState(() => _riwayatLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$kUndanganBaseUrl/riwayat'),
        headers: {'x-admin-key': kSetoranAdminKey},
      );
      if (res.statusCode == 200) {
        setState(() => _riwayat = jsonDecode(res.body) as List);
      }
    } catch (_) {}
    setState(() => _riwayatLoading = false);
  }

  Future<void> _buatUndangan() async {
    final val = _idController.text.trim();
    if (val.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi username / ID pembeli dulu')),
      );
      return;
    }

    setState(() => _submitting = true);
    try {
      final res = await http.post(
        Uri.parse('$kUndanganBaseUrl/create'),
        headers: {'Content-Type': 'application/json', 'x-admin-key': kSetoranAdminKey},
        body: jsonEncode({
          'role': _role,
          'username': val,
          'telegramUserId': val, // kalau lo pisahin username vs ID Telegram, sesuaikan di sini
        }),
      );
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Undangan dibuat: ${j['detail'] ?? 'sukses'}')),
        );
        _idController.clear();
        if (_riwayatExpanded) _loadRiwayat();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(j['error'] ?? 'Gagal bikin undangan')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal konek ke server: $e')),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _roleButton(String value, String label) {
    final selected = _role == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _role = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: selected ? accentRed : cardDark,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: selected ? accentRed : const Color(0xFF2A2A2A)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(selected ? Icons.check_circle : Icons.circle_outlined,
                  color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(label.toUpperCase(),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: deepBlack,
      appBar: AppBar(
        backgroundColor: deepBlack,
        title: const Text('Storan'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Pilih Role', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [_roleButton('fullup', 'Fullup'), _roleButton('reseller', 'Reseller')]),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(color: cardDark, borderRadius: BorderRadius.circular(10)),
              child: Row(
                children: [
                  const Icon(Icons.person_search, color: accentRed),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _idController,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        hintText: 'Username / ID pembeli (mis. budi123)',
                        hintStyle: TextStyle(color: Colors.white38),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _submitting ? null : _buatUndangan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentRed,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                icon: _submitting
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.rocket_launch),
                label: Text(_submitting ? 'MEMPROSES...' : 'BUAT UNDANGAN',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
            _expandCard(
              icon: Icons.menu_book,
              title: 'Cara Storan',
              expanded: _caraExpanded,
              onTap: () => setState(() => _caraExpanded = !_caraExpanded),
              child: const Padding(
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  '1. Pilih role (Fullup/Reseller)\n'
                  '2. Isi username/ID pembeli\n'
                  '3. Tekan Buat Undangan\n'
                  '4. Buyer bakal dikirim link/approve otomatis lewat bot',
                  style: TextStyle(color: Colors.white60),
                ),
              ),
            ),
            const SizedBox(height: 10),
            _expandCard(
              icon: Icons.history,
              title: 'Riwayat Undangan (${_riwayat.length})',
              expanded: _riwayatExpanded,
              onTap: () {
                setState(() => _riwayatExpanded = !_riwayatExpanded);
                if (_riwayatExpanded) _loadRiwayat();
              },
              child: _riwayatLoading
                  ? const Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Center(child: CircularProgressIndicator(color: accentRed)),
                    )
                  : Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Column(
                        children: _riwayat.isEmpty
                            ? [const Text('Belum ada undangan', style: TextStyle(color: Colors.white60))]
                            : _riwayat.map((e) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          '${e['groupNama']} · @${e['username']} · ${e['source']}',
                                          style: const TextStyle(color: Colors.white70, fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _expandCard({
    required IconData icon,
    required String title,
    required bool expanded,
    required VoidCallback onTap,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: cardDark, borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: onTap,
            child: Row(
              children: [
                Icon(icon, color: accentRed),
                const SizedBox(width: 10),
                Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                Icon(expanded ? Icons.expand_less : Icons.expand_more, color: Colors.white60),
              ],
            ),
          ),
          if (expanded) child,
        ],
      ),
    );
  }
}
