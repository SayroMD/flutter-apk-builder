// Tambahin dependency ini kalau belum ada di pubspec.yaml:
// web_socket_channel: ^2.4.0
// file_picker: ^8.0.0

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'main.dart';

// ==================== THEME — NEO BRUTALISM ====================
class _C {
  static const bg = Color(0xFF0A0A0A);
  static const surface = Color(0xFF111111);
  static const surface2 = Color(0xFF1A1A1A);
  static const border = Color(0xFF000000);
  static const borderAccent = Color(0xFFFFFFFF);
  static const yellow = Color(0xFFFFE600);
  static const pink = Color(0xFFFF2D55);
  static const blue = Color(0xFF00A3FF);
  static const white = Color(0xFFFFFFFF);
  static const text = Color(0xFFFFFFFF);
  static const textDim = Color(0xFFAAAAAA);
  static const bubbleMine = Color(0xFFFFE600);
  static const bubbleOther = Color(0xFF1A1A1A);
  static const bubbleMineText = Color(0xFF000000);
  static const owner = Color(0xFFFFE600);
  static const admin = Color(0xFFFF2D55);
  static const vip = Color(0xFF00A3FF);
  static const online = Color(0xFF00FF88);
}

TextStyle _brutal({
  double size = 13,
  FontWeight weight = FontWeight.w800,
  Color color = _C.text,
  double spacing = 0.4,
}) {
  return TextStyle(
    fontFamily: 'Orbitron',
    fontSize: size,
    fontWeight: weight,
    color: color,
    letterSpacing: spacing,
  );
}

BoxDecoration _hardCard({
  Color fill = _C.surface,
  Color borderColor = _C.borderAccent,
  double borderWidth = 3,
  double radius = 0,
  List<BoxShadow>? shadows,
}) {
  return BoxDecoration(
    color: fill,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: borderColor, width: borderWidth),
    boxShadow: shadows ??
        const [
          BoxShadow(
            color: Color(0xFF000000),
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
  );
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case "owner":
      return _C.owner;
    case "admin":
      return _C.admin;
    case "vip":
      return _C.vip;
    default:
      return _C.yellow;
  }
}

// ==================== PAGE ====================
class ChatPublicPage extends StatefulWidget {
  final String username;
  final String role;
  final String apiKey;

  const ChatPublicPage({
    super.key,
    required this.username,
    required this.role,
    required this.apiKey,
  });

  @override
  State<ChatPublicPage> createState() => _ChatPublicPageState();
}

class _ChatPublicPageState extends State<ChatPublicPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<Map<String, dynamic>> _messages = [];
  int _onlineCount = 0;
  bool _isLoading = true;
  bool _isSending = false;
  bool _isUploading = false;

  WebSocketChannel? _channel;
  Timer? _reconnectTimer;
  Timer? _authTimeoutTimer;
  Timer? _usersPollTimer;
  bool _wsConnected = false;

  Map<String, dynamic>? _replyTo;
  String? _editingId;

  bool get _isAdminOrOwner =>
      widget.role.toLowerCase() == "admin" || widget.role.toLowerCase() == "owner";

  Map<String, dynamic>? get _pinnedMessage {
    try {
      return _messages.firstWhere((m) => m['isPinned'] == true);
    } catch (_) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await _loadMessages();
    await _loadUsers();
    if (mounted) setState(() => _isLoading = false);
    _connectWebSocket();
    _usersPollTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      _loadUsers();
    });
  }

  // ==================== WEBSOCKET ====================
  void _connectWebSocket() {
    try {
      final uri = Uri.parse(wsBaseUrl);
      _channel = IOWebSocketChannel.connect(uri);
      _wsConnected = false;

      // Kirim auth begitu socket terbuka
      _channel!.ready.then((_) {
        _channel?.sink.add(jsonEncode({
          "type": "public_auth",
          "key": widget.apiKey,
        }));
      }).catchError((_) => _scheduleReconnect());

      _authTimeoutTimer?.cancel();
      _authTimeoutTimer = Timer(const Duration(seconds: 8), () {
        if (!_wsConnected) {
          _channel?.sink.close();
          _scheduleReconnect();
        }
      });

      _channel!.stream.listen(
        _handleWsEvent,
        onError: (_) => _scheduleReconnect(),
        onDone: () => _scheduleReconnect(),
        cancelOnError: true,
      );
    } catch (_) {
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    _wsConnected = false;
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) _connectWebSocket();
    });
  }

  void _handleWsEvent(dynamic raw) {
    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final type = data['type'];

      switch (type) {
        case 'public_auth':
          _authTimeoutTimer?.cancel();
          if (data['valid'] == true) {
            _wsConnected = true;
          } else {
            // key invalid, jangan spam reconnect terus, fallback ke REST polling
            _wsConnected = false;
          }
          break;

        case 'public_messages':
          final list = List<Map<String, dynamic>>.from(data['messages'] ?? []);
          if (!mounted) return;
          setState(() => _messages = list);
          _scrollToBottom();
          break;

        case 'public_message':
          final msg = Map<String, dynamic>.from(data['message']);
          if (!mounted) return;
          setState(() => _messages.add(msg));
          _scrollToBottom();
          break;

        case 'public_message_edited':
          final id = data['messageId'];
          final idx = _messages.indexWhere((m) => m['id'] == id);
          if (idx != -1 && mounted) {
            setState(() {
              _messages[idx]['message'] = data['newMessage'];
              _messages[idx]['isEdited'] = true;
            });
          }
          break;

        case 'public_message_deleted':
          final id = data['messageId'];
          if (mounted) {
            setState(() => _messages.removeWhere((m) => m['id'] == id));
          }
          break;

        case 'public_message_reaction':
          final id = data['messageId'];
          final idx = _messages.indexWhere((m) => m['id'] == id);
          if (idx != -1 && mounted) {
            setState(() {
              _messages[idx]['reactions'] = Map<String, dynamic>.from(
                data['reactions'] ?? {},
              );
            });
          }
          break;

        case 'public_message_pinned':
          final id = data['messageId'];
          if (mounted) {
            setState(() {
              for (final m in _messages) {
                m['isPinned'] = m['id'] == id;
              }
            });
          }
          break;
      }
    } catch (_) {
      // ignore malformed frame
    }
  }

  // ==================== REST ====================
  Future<void> _loadMessages() async {
    try {
      final uri = Uri.parse(
        "$baseUrl/api/chatpublic/messages?key=${Uri.encodeQueryComponent(widget.apiKey)}&limit=150",
      );
      final response = await http.get(uri);
      if (response.statusCode != 200) return;

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (data['success'] != true) return;

      final list = List<Map<String, dynamic>>.from(data['messages'] ?? []);
      list.sort(
        (a, b) => (a['timestamp'] ?? '').toString().compareTo(
          (b['timestamp'] ?? '').toString(),
        ),
      );

      if (!mounted) return;
      setState(() => _messages = list);
      _scrollToBottom();
    } catch (_) {}
  }

  Future<void> _loadUsers() async {
    try {
      final uri = Uri.parse(
        "$baseUrl/api/chatpublic/users?key=${Uri.encodeQueryComponent(widget.apiKey)}",
      );
      final response = await http.get(uri);
      if (response.statusCode != 200) return;
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _onlineCount = (data['count'] ?? 0) as int);
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;

    if (_editingId != null) {
      await _submitEdit(_editingId!, text);
      return;
    }

    setState(() => _isSending = true);
    try {
      final uri = Uri.parse("$baseUrl/api/chatpublic/message");
      final response = await http.post(
        uri,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "key": widget.apiKey,
          "username": widget.username,
          "role": widget.role,
          "message": text,
          "replyToId": _replyTo?['id'],
          "replyToUsername": _replyTo?['username'],
          "replyToMessage": _replyTo?['message'],
        }),
      );
      if (response.statusCode == 200) {
        _messageController.clear();
        _cancelReply();
        if (!_wsConnected) await _loadMessages();
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _pickAndUploadFile() async {
    final result = await FilePicker.platform.pickFiles(withData: false);
    if (result == null || result.files.isEmpty) return;
    final picked = result.files.single;
    if (picked.path == null) return;

    setState(() => _isUploading = true);
    try {
      final uri = Uri.parse("$baseUrl/api/chatpublic/upload");
      final request = http.MultipartRequest("POST", uri)
        ..fields['key'] = widget.apiKey
        ..fields['username'] = widget.username
        ..fields['role'] = widget.role
        ..files.add(await http.MultipartFile.fromPath('file', picked.path!));

      if (_replyTo != null) {
        request.fields['replyToId'] = _replyTo!['id'] ?? '';
        request.fields['replyToUsername'] = _replyTo!['username'] ?? '';
        request.fields['replyToMessage'] = _replyTo!['message'] ?? '';
      }

      final streamed = await request.send();
      if (streamed.statusCode == 200) {
        _cancelReply();
        if (!_wsConnected) await _loadMessages();
      }
    } catch (_) {
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  Future<void> _submitEdit(String id, String newText) async {
    setState(() => _isSending = true);
    try {
      final uri = Uri.parse("$baseUrl/api/chatpublic/message/$id");
      final response = await http.put(
        uri,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "key": widget.apiKey,
          "username": widget.username,
          "message": newText,
        }),
      );
      if (response.statusCode == 200) {
        _messageController.clear();
        setState(() => _editingId = null);
        if (!_wsConnected) await _loadMessages();
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _deleteMessage(String id) async {
    final uri = Uri.parse(
      "$baseUrl/api/chatpublic/message/$id?key=${Uri.encodeQueryComponent(widget.apiKey)}&username=${Uri.encodeQueryComponent(widget.username)}",
    );
    await http.delete(uri);
    if (!_wsConnected) await _loadMessages();
  }

  Future<void> _addReaction(String id, String emoji) async {
    final uri = Uri.parse("$baseUrl/api/chatpublic/reaction");
    await http.post(
      uri,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "key": widget.apiKey,
        "messageId": id,
        "emoji": emoji,
        "username": widget.username,
      }),
    );
    if (!_wsConnected) await _loadMessages();
  }

  Future<void> _pinMessage(String id) async {
    final uri = Uri.parse("$baseUrl/api/chatpublic/pin");
    await http.post(
      uri,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "key": widget.apiKey,
        "messageId": id,
        "username": widget.username,
      }),
    );
    if (!_wsConnected) await _loadMessages();
  }

  // ==================== HELPERS ====================
  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _setReplyTo(Map<String, dynamic> msg) {
    setState(() {
      _editingId = null;
      _replyTo = msg;
    });
  }

  void _cancelReply() {
    setState(() => _replyTo = null);
  }

  void _startEdit(Map<String, dynamic> msg) {
    setState(() {
      _replyTo = null;
      _editingId = msg['id'];
      _messageController.text = msg['message'] ?? '';
      _messageController.selection = TextSelection.collapsed(
        offset: _messageController.text.length,
      );
    });
  }

  void _cancelEdit() {
    setState(() {
      _editingId = null;
      _messageController.clear();
    });
  }

  String _formatSize(dynamic bytes) {
    final b = (bytes ?? 0) is int ? bytes as int : int.tryParse('$bytes') ?? 0;
    if (b < 1024) return "$b B";
    if (b < 1024 * 1024) return "${(b / 1024).toStringAsFixed(1)} KB";
    return "${(b / (1024 * 1024)).toStringAsFixed(1)} MB";
  }

  void _showMessageActions(Map<String, dynamic> msg) {
    final id = (msg['id'] ?? '').toString();
    final author = (msg['username'] ?? '').toString();
    final mine = author == widget.username;
    final type = (msg['type'] ?? 'text').toString();
    final canEdit = mine && type == 'text';
    final canDelete = mine || _isAdminOrOwner;

    showModalBottomSheet(
      context: context,
      backgroundColor: _C.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(0)),
        side: BorderSide(color: _C.borderAccent, width: 3),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: _hardCard(
                    fill: _C.yellow,
                    borderColor: _C.border,
                    borderWidth: 2,
                    shadows: const [],
                  ),
                  child: const Icon(Icons.reply, color: _C.bg, size: 18),
                ),
                title: Text("REPLY", style: _brutal(size: 13, color: _C.text)),
                onTap: () {
                  Navigator.pop(ctx);
                  _setReplyTo(msg);
                },
              ),
              if (canEdit)
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: _hardCard(
                      fill: _C.blue,
                      borderColor: _C.border,
                      borderWidth: 2,
                      shadows: const [],
                    ),
                    child: const Icon(Icons.edit, color: _C.white, size: 18),
                  ),
                  title: Text("EDIT", style: _brutal(size: 13, color: _C.text)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _startEdit(msg);
                  },
                ),
              if (_isAdminOrOwner)
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: _hardCard(
                      fill: _C.pink,
                      borderColor: _C.border,
                      borderWidth: 2,
                      shadows: const [],
                    ),
                    child: const Icon(Icons.push_pin, color: _C.white, size: 18),
                  ),
                  title: Text(
                    msg['isPinned'] == true ? "UNPIN" : "PIN",
                    style: _brutal(size: 13, color: _C.text),
                  ),
                  onTap: () {
                    Navigator.pop(ctx);
                    if (id.isNotEmpty) _pinMessage(id);
                  },
                ),
              if (canDelete)
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: _hardCard(
                      fill: _C.admin,
                      borderColor: _C.border,
                      borderWidth: 2,
                      shadows: const [],
                    ),
                    child: const Icon(Icons.delete_outline, color: _C.white, size: 18),
                  ),
                  title: Text(
                    "DELETE",
                    style: _brutal(size: 13, color: _C.admin),
                  ),
                  onTap: () {
                    Navigator.pop(ctx);
                    if (id.isNotEmpty) _deleteMessage(id);
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _reconnectTimer?.cancel();
    _authTimeoutTimer?.cancel();
    _usersPollTimer?.cancel();
    _channel?.sink.close();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    final pinned = _pinnedMessage;

    return Scaffold(
      backgroundColor: _C.bg,
      body: Column(
        children: [
          _buildAppBar(pinned),
          Expanded(
            child: _isLoading
                ? Center(
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: _hardCard(
                        fill: _C.yellow,
                        borderColor: _C.border,
                        borderWidth: 4,
                      ),
                      child: const Center(
                        child: SizedBox(
                          width: 28,
                          height: 28,
                          child: CircularProgressIndicator(
                            color: _C.bg,
                            strokeWidth: 4,
                          ),
                        ),
                      ),
                    ),
                  )
                : _messages.isEmpty
                    ? Center(
                        child: Text(
                          "BELUM ADA PESAN",
                          style: _brutal(size: 14, color: _C.textDim),
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.fromLTRB(12, 14, 12, 10),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) =>
                            _buildMessageRow(_messages[index]),
                      ),
          ),
          if (_replyTo != null) _buildReplyPreview(),
          if (_editingId != null) _buildEditingBanner(),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildAppBar(Map<String, dynamic>? pinned) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: const BoxDecoration(
        color: _C.surface,
        border: Border(
          bottom: BorderSide(color: _C.borderAccent, width: 3),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).maybePop(),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: _hardCard(
                      fill: _C.yellow,
                      borderColor: _C.border,
                      borderWidth: 3,
                      shadows: const [
                        BoxShadow(
                          color: Color(0xFF000000),
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.arrow_back_ios_new,
                        color: _C.bg, size: 16),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: _hardCard(
                    fill: _C.pink,
                    borderColor: _C.border,
                    borderWidth: 3,
                    shadows: const [],
                  ),
                  child: const Icon(Icons.public, color: _C.white, size: 18),
                ),
                const SizedBox(width: 10),
                Text("PUBLIC // UPLINK", style: _brutal(size: 14, color: _C.white)),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: _hardCard(
                    fill: _C.bg,
                    borderColor: _C.online,
                    borderWidth: 3,
                    shadows: const [
                      BoxShadow(
                        color: Color(0xFF000000),
                        offset: Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: _C.online,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        "$_onlineCount ONLINE",
                        style: _brutal(size: 10, color: _C.online),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (pinned != null) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 10),
                decoration: _hardCard(
                  fill: _C.surface2,
                  borderColor: _C.pink,
                  borderWidth: 3,
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: _hardCard(
                        fill: _C.pink,
                        borderColor: _C.border,
                        borderWidth: 2,
                        shadows: const [],
                      ),
                      child: const Icon(Icons.push_pin, size: 12, color: _C.white),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "${pinned['username']} — ${pinned['message']}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _C.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildMessageRow(Map<String, dynamic> msg) {
    final id = (msg['id'] ?? '').toString();
    final author = (msg['username'] ?? 'unknown').toString();
    final role = (msg['role'] ?? 'member').toString();
    final text = (msg['message'] ?? '').toString();
    final type = (msg['type'] ?? 'text').toString();
    final mine = author == widget.username;
    final isEdited = msg['isEdited'] == true;
    final isPinned = msg['isPinned'] == true;
    final reactions = Map<String, dynamic>.from(msg['reactions'] ?? {});
    final replyUser = msg['replyToUsername'];
    final replyText = msg['replyToMessage'];
    final roleColor = _roleColor(role);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment:
            mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!mine) _buildAvatar(author, roleColor),
          if (!mine) const SizedBox(width: 10),
          Flexible(
            child: GestureDetector(
              onLongPress: () => _showMessageActions(msg),
              child: Column(
                crossAxisAlignment:
                    mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (isPinned)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: _hardCard(
                          fill: _C.pink,
                          borderColor: _C.border,
                          borderWidth: 2,
                          shadows: const [],
                        ),
                        child: Text("PINNED",
                            style: _brutal(size: 9, color: _C.white)),
                      ),
                    ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        author,
                        style: const TextStyle(
                          color: _C.text,
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: _hardCard(
                          fill: roleColor,
                          borderColor: _C.border,
                          borderWidth: 2,
                          shadows: const [],
                        ),
                        child: Text(
                          role.toUpperCase(),
                          style: _brutal(size: 8, color: _C.bg),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  if (replyUser != null && replyText != null)
                    Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      constraints: const BoxConstraints(maxWidth: 230),
                      padding:
                          const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      decoration: _hardCard(
                        fill: _C.bg,
                        borderColor: _C.yellow,
                        borderWidth: 2,
                        shadows: const [],
                      ),
                      child: Text(
                        "↩ $replyUser: $replyText",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _C.textDim,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  _buildBubble(msg, mine, type, text, isEdited),
                  if (reactions.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    _buildReactionsRow(id, reactions),
                  ],
                ],
              ),
            ),
          ),
          if (mine) const SizedBox(width: 10),
          if (mine) _buildAvatar(author, _C.yellow),
        ],
      ),
    );
  }

  Widget _buildAvatar(String author, Color color) {
    return Container(
      width: 32,
      height: 32,
      margin: const EdgeInsets.only(top: 16),
      decoration: _hardCard(
        fill: color,
        borderColor: _C.border,
        borderWidth: 3,
        shadows: const [],
      ),
      alignment: Alignment.center,
      child: Text(
        author.isEmpty ? "U" : author[0].toUpperCase(),
        style: _brutal(size: 12, color: _C.bg),
      ),
    );
  }

  Widget _buildBubble(
    Map<String, dynamic> msg,
    bool mine,
    String type,
    String text,
    bool isEdited,
  ) {
    final fileUrl = msg['fileUrl'];
    final fileName = (msg['fileName'] ?? '').toString();
    final fileSize = msg['fileSize'];

    Widget content;
    if (type == 'image' && fileUrl != null) {
      content = ClipRRect(
        borderRadius: BorderRadius.circular(0),
        child: Image.network(
          fileUrl,
          width: 200,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            width: 200,
            height: 120,
            color: _C.surface2,
            alignment: Alignment.center,
            child: const Icon(Icons.broken_image, color: _C.textDim),
          ),
        ),
      );
    } else if (fileUrl != null) {
      final icon = type == 'video'
          ? Icons.videocam_outlined
          : type == 'audio'
              ? Icons.audiotrack_outlined
              : Icons.insert_drive_file_outlined;
      content = Container(
        constraints: const BoxConstraints(maxWidth: 220),
        padding: const EdgeInsets.all(10),
        decoration: _hardCard(
          fill: _C.bg,
          borderColor: _C.yellow,
          borderWidth: 2,
          shadows: const [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: _hardCard(
                fill: _C.yellow,
                borderColor: _C.border,
                borderWidth: 2,
                shadows: const [],
              ),
              alignment: Alignment.center,
              child: Icon(icon, size: 16, color: _C.bg),
            ),
            const SizedBox(width: 10),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    fileName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.text,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    _formatSize(fileSize),
                    style: const TextStyle(
                      color: _C.textDim,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    } else {
      content = Text(
        text,
        style: TextStyle(
          color: mine ? _C.bubbleMineText : _C.text,
          fontSize: 14,
          height: 1.35,
          fontWeight: FontWeight.w700,
        ),
      );
    }

    return Container(
      padding: EdgeInsets.all(type == 'image' ? 6 : 12),
      decoration: BoxDecoration(
        color: mine ? _C.bubbleMine : _C.bubbleOther,
        borderRadius: BorderRadius.circular(0),
        border: Border.all(
          color: mine ? _C.border : _C.borderAccent,
          width: 3,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0xFF000000),
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          content,
          if (isEdited)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                "(diedit)",
                style: TextStyle(
                  color: mine
                      ? _C.bg.withOpacity(0.6)
                      : _C.textDim.withOpacity(0.8),
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildReactionsRow(String id, Map<String, dynamic> reactions) {
    const emojis = ["👍", "❤️", "😂", "😮", "😢", "😠"];
    return Wrap(
      spacing: 6,
      children: emojis.map((e) {
        final users = List<String>.from(reactions[e] ?? []);
        if (users.isEmpty) return const SizedBox.shrink();
        final active = users.contains(widget.username);
        return GestureDetector(
          onTap: id.isEmpty ? null : () => _addReaction(id, e),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: _hardCard(
              fill: active ? _C.yellow : _C.surface2,
              borderColor: active ? _C.border : _C.borderAccent,
              borderWidth: 2,
              shadows: const [],
            ),
            child: Text(
              "$e ${users.length}",
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: active ? _C.bg : _C.text,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildReplyPreview() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: _hardCard(
        fill: _C.surface2,
        borderColor: _C.yellow,
        borderWidth: 3,
        shadows: const [],
      ),
      child: Row(
        children: [
          Container(width: 4, height: 28, color: _C.yellow),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  (_replyTo?['username'] ?? '').toString(),
                  style: _brutal(size: 11, color: _C.yellow),
                ),
                Text(
                  (_replyTo?['message'] ?? '').toString(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.textDim,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _cancelReply,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: _hardCard(
                fill: _C.pink,
                borderColor: _C.border,
                borderWidth: 2,
                shadows: const [],
              ),
              child: const Icon(Icons.close, size: 14, color: _C.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEditingBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: _hardCard(
        fill: _C.surface2,
        borderColor: _C.pink,
        borderWidth: 3,
        shadows: const [],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: _hardCard(
              fill: _C.pink,
              borderColor: _C.border,
              borderWidth: 2,
              shadows: const [],
            ),
            child: const Icon(Icons.edit, size: 12, color: _C.white),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "EDITING MESSAGE...",
              style: _brutal(size: 11, color: _C.pink),
            ),
          ),
          GestureDetector(
            onTap: _cancelEdit,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: _hardCard(
                fill: _C.surface,
                borderColor: _C.borderAccent,
                borderWidth: 2,
                shadows: const [],
              ),
              child: const Icon(Icons.close, size: 14, color: _C.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(
        12,
        12,
        12,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: const BoxDecoration(
        color: _C.surface,
        border: Border(
          top: BorderSide(color: _C.borderAccent, width: 3),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: _isUploading ? null : _pickAndUploadFile,
            child: Container(
              width: 44,
              height: 44,
              decoration: _hardCard(
                fill: _isUploading ? _C.surface2 : _C.blue,
                borderColor: _C.border,
                borderWidth: 3,
              ),
              alignment: Alignment.center,
              child: _isUploading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        color: _C.yellow,
                      ),
                    )
                  : const Icon(Icons.attach_file, size: 20, color: _C.white),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _messageController,
              style: const TextStyle(
                color: _C.text,
                fontWeight: FontWeight.w700,
              ),
              decoration: InputDecoration(
                hintText: _editingId != null
                    ? "Edit pesan..."
                    : "Ketik pesan...",
                hintStyle: const TextStyle(
                  color: _C.textDim,
                  fontWeight: FontWeight.w600,
                ),
                filled: true,
                fillColor: _C.bg,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(0),
                  borderSide: const BorderSide(color: _C.borderAccent, width: 3),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(0),
                  borderSide: const BorderSide(color: _C.borderAccent, width: 3),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(0),
                  borderSide: const BorderSide(color: _C.yellow, width: 3),
                ),
              ),
              onSubmitted: (_) => _sendMessage(),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _isSending ? null : _sendMessage,
            child: Container(
              width: 48,
              height: 48,
              decoration: _hardCard(
                fill: _isSending ? _C.surface2 : _C.yellow,
                borderColor: _C.border,
                borderWidth: 3,
              ),
              alignment: Alignment.center,
              child: Icon(
                _editingId != null ? Icons.check : Icons.send,
                size: 20,
                color: _isSending ? _C.textDim : _C.bg,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
