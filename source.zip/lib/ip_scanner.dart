// ip_scanner.dart - CYBER STYLE
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'base_page.dart';

class IpScannerResult {
  final String ip;
  final String country;
  final String countryCode;
  final String region;
  final String regionName;
  final String city;
  final String zip;
  final double lat;
  final double lon;
  final String timezone;
  final String isp;
  final String org;
  final String as;
  final bool isValid;

  IpScannerResult({
    required this.ip,
    required this.country,
    required this.countryCode,
    required this.region,
    required this.regionName,
    required this.city,
    required this.zip,
    required this.lat,
    required this.lon,
    required this.timezone,
    required this.isp,
    required this.org,
    required this.as,
    required this.isValid,
  });

  factory IpScannerResult.fromJson(Map<String, dynamic> json, String queryIp) {
    return IpScannerResult(
      ip: json['ip'] ?? queryIp,
      country: json['country'] ?? 'Unknown',
      countryCode: json['countryCode'] ?? 'Unknown',
      region: json['region'] ?? 'Unknown',
      regionName: json['regionName'] ?? 'Unknown',
      city: json['city'] ?? 'Unknown',
      zip: json['zip'] ?? 'Unknown',
      lat: (json['lat'] ?? 0).toDouble(),
      lon: (json['lon'] ?? 0).toDouble(),
      timezone: json['timezone'] ?? 'Unknown',
      isp: json['isp'] ?? 'Unknown',
      org: json['org'] ?? 'Unknown',
      as: json['as'] ?? 'Unknown',
      isValid: json['ip'] != null,
    );
  }

  factory IpScannerResult.local(String ip) {
    return IpScannerResult(
      ip: ip,
      country: 'Local Network',
      countryCode: 'LOCAL',
      region: 'Local',
      regionName: 'Local Network',
      city: 'Local',
      zip: 'N/A',
      lat: 0,
      lon: 0,
      timezone: 'Local',
      isp: 'Local Network',
      org: 'Local',
      as: 'N/A',
      isValid: true,
    );
  }

  factory IpScannerResult.invalid(String ip) {
    return IpScannerResult(
      ip: ip,
      country: 'Invalid',
      countryCode: 'INVALID',
      region: 'Invalid',
      regionName: 'Invalid',
      city: 'Invalid',
      zip: 'N/A',
      lat: 0,
      lon: 0,
      timezone: 'Unknown',
      isp: 'Unknown',
      org: 'Unknown',
      as: 'Unknown',
      isValid: false,
    );
  }
}

class IpValidator {
  static bool isValidIPv4(String ip) {
    final RegExp ipv4Regex = RegExp(
      r'^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    );
    return ipv4Regex.hasMatch(ip);
  }

  static bool isPrivateIP(String ip) {
    final RegExp privateRegex = RegExp(
      r'^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|127\.|169\.254\.)',
    );
    return privateRegex.hasMatch(ip);
  }

  static bool isLoopback(String ip) {
    return ip.startsWith('127.') || ip == 'localhost';
  }

  static String getIPClass(String ip) {
    if (!isValidIPv4(ip)) return 'Invalid';
    final firstOctet = int.parse(ip.split('.')[0]);
    if (firstOctet >= 1 && firstOctet <= 126) return 'Class A';
    if (firstOctet >= 128 && firstOctet <= 191) return 'Class B';
    if (firstOctet >= 192 && firstOctet <= 223) return 'Class C';
    if (firstOctet >= 224 && firstOctet <= 239) return 'Class D (Multicast)';
    if (firstOctet >= 240 && firstOctet <= 255) return 'Class E (Reserved)';
    return 'Unknown';
  }
}

class IpScannerPage extends StatefulWidget {
  const IpScannerPage({super.key});

  @override
  State<IpScannerPage> createState() => _IpScannerPageState();
}

class _IpScannerPageState extends State<IpScannerPage> {
  final TextEditingController _ipController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  
  bool _isLoading = false;
  IpScannerResult? _result;
  String? _errorMessage;

  static const String _apiUrl = 'http://ip-api.com/json/';

  Future<void> _scanIp() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _result = null;
    });
    
    final ip = _ipController.text.trim();
    
    if (IpValidator.isPrivateIP(ip) || IpValidator.isLoopback(ip)) {
      setState(() {
        _result = IpScannerResult.local(ip);
        _isLoading = false;
      });
      return;
    }
    
    if (!IpValidator.isValidIPv4(ip)) {
      setState(() {
        _result = IpScannerResult.invalid(ip);
        _isLoading = false;
        _errorMessage = 'Format IP tidak valid';
      });
      return;
    }
    
    try {
      final response = await http.get(
        Uri.parse('$_apiUrl$ip?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query'),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _result = IpScannerResult.fromJson(data, ip);
            _isLoading = false;
          });
        } else {
          setState(() {
            _result = IpScannerResult.local(ip);
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _result = IpScannerResult.local(ip);
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal terhubung ke server';
        _isLoading = false;
        _result = IpScannerResult.local(ip);
      });
      showCyberSnackBar(context, 'Gagal mengambil data, menampilkan info lokal', isError: true);
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    showCyberSnackBar(context, '$label disalin!');
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: 'IP SCANNER',
      showBackButton: true,
      contentPadding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Input Section
          GlassCard(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  CyberInputField(
                    controller: _ipController,
                    label: 'IP ADDRESS',
                    hint: '8.8.8.8 atau 192.168.1.1',
                    icon: Icons.dns_rounded,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    children: [
                      _buildExampleChip('8.8.8.8', 'Google DNS'),
                      _buildExampleChip('1.1.1.1', 'Cloudflare'),
                      _buildExampleChip('192.168.1.1', 'Local'),
                    ],
                  ),
                  const SizedBox(height: 16),
                  CyberButton(
                    label: 'SCAN IP',
                    icon: Icons.search_rounded,
                    onTap: _scanIp,
                    isLoading: _isLoading,
                    width: double.infinity,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          if (_isLoading) ...[
            GlassCard(
              padding: const EdgeInsets.all(32),
              child: Column(
                children: [
                  const CyberLoadingShimmer(),
                  const SizedBox(height: 12),
                  Text(
                    'Mendapatkan informasi IP...',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],

          if (_errorMessage != null && !_isLoading)
            GlassCard(
              padding: const EdgeInsets.all(16),
              borderColor: AppColors.red.withOpacity(0.3),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: AppColors.red, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _errorMessage!,
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          if (_result != null && !_isLoading)
            _buildResultCard(_result!),
        ],
      ),
    );
  }

  Widget _buildExampleChip(String ip, String label) {
    return GestureDetector(
      onTap: () {
        _ipController.text = ip;
        _scanIp();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.surface2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.borderLight),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.copy_rounded, color: AppColors.accent, size: 12),
            const SizedBox(width: 4),
            Text(
              ip,
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.textPrimary,
                fontSize: 10,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.textMuted,
                fontSize: 8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard(IpScannerResult result) {
    final bool isLocal = result.countryCode == 'LOCAL' || result.country == 'Local Network';
    
    return Column(
      children: [
        GlassCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: result.isValid ? AppColors.green.withOpacity(0.1) : AppColors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: result.isValid ? AppColors.green.withOpacity(0.3) : AppColors.red.withOpacity(0.3),
                      ),
                    ),
                    child: Icon(
                      result.isValid ? Icons.check_circle_rounded : Icons.error_rounded,
                      color: result.isValid ? AppColors.green : AppColors.red,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          result.ip,
                          style: TextStyle(
                            fontFamily: appFont,
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          result.isValid ? 'IP Address Valid' : 'IP Address Invalid',
                          style: TextStyle(
                            fontFamily: appFont,
                            color: result.isValid ? AppColors.green : AppColors.red,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () => _copyToClipboard(result.ip, 'IP Address'),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.borderLight),
                      ),
                      child: Icon(Icons.copy_rounded, color: AppColors.accent, size: 16),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Divider(color: AppColors.borderLight, height: 1),
              const SizedBox(height: 16),

              if (!isLocal) ...[
                _buildInfoRow('🌍', 'Country', '${result.country} (${result.countryCode})'),
                _buildInfoRow('🏙️', 'City', result.city),
                _buildInfoRow('📍', 'Region', result.regionName),
                if (result.zip != 'Unknown') _buildInfoRow('📮', 'Postal Code', result.zip),
                _buildInfoRow('🏢', 'ISP', result.isp),
                _buildInfoRow('🔗', 'AS Number', result.as),
              ],

              _buildInfoRow('📊', 'IP Class', IpValidator.getIPClass(result.ip)),
              _buildInfoRow('🔒', 'IP Type', 
                IpValidator.isPrivateIP(result.ip) ? 'Private IP' : 
                (IpValidator.isLoopback(result.ip) ? 'Loopback' : 'Public IP')),
              
              if (!isLocal && result.lat != 0)
                _buildInfoRow('📌', 'Coordinates', '${result.lat}, ${result.lon}'),
              if (!isLocal && result.timezone != 'Unknown')
                _buildInfoRow('🕐', 'Timezone', result.timezone),
            ],
          ),
        ),
        const SizedBox(height: 16),
        GlassCard(
          padding: const EdgeInsets.all(14),
          borderColor: AppColors.borderLight.withOpacity(0.3),
          child: Row(
            children: [
              Icon(Icons.info_outline_rounded, color: AppColors.accent, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  isLocal
                      ? 'IP ini adalah alamat lokal/private. Informasi geolokasi tidak tersedia.'
                      : 'Informasi IP diperoleh dari database real-time. Lokasi mungkin tidak 100% akurat.',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 11,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Text(icon, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 12),
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.textSec,
                fontSize: 11,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontFamily: appFont,
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _ipController.dispose();
    super.dispose();
  }
}