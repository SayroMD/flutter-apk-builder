import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'setoran_config.dart';
import 'storan_theme.dart';

class StoranPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StoranPage({super.key, required this.sessionKey, required this.username});

  @override
  State<StoranPage> createState() => _StoranPageState();
}

class _StoranPageState extends State<StoranPage> {
  Map<String, dynamic>? _products;
  bool _loadingProducts = true;
  Map<String, dynamic>? _stats;

  String _targetRole = 'FULLUP';
  String _packageType = 'permanen';
  final _customDaysController = TextEditingController();
  final _customHargaController = TextEditingController();
  final _buyerUserController = TextEditingController();
  final _buyerPassController = TextEditingController();

  String _status = 'form'; // form -> creating -> pending -> menunggu_review -> selesai | gagal | ditolak | expired
  String? _depositId;
  int? _amount;
  int? _sektor;
  DateTime? _expiresAt;
  Timer? _pollTimer;
  Timer? _tickTimer;
  Duration _remaining = Duration.zero;
  bool _uploading = false;
  String? _formError;

  @override
  void initState() {
    super.initState();
    _loadProducts();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final res = await http.get(Uri.parse('$kStoranBaseUrl/stats?sessionKey=${widget.sessionKey}'));
      if (res.statusCode == 200) setState(() => _stats = jsonDecode(res.body));
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _customDaysController.dispose();
    _customHargaController.dispose();
    _buyerUserController.dispose();
    _buyerPassController.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    try {
      final res = await http.get(Uri.parse('$kStoranBaseUrl/products'));
      if (res.statusCode == 200) {
        setState(() {
          _products = jsonDecode(res.body);
          _loadingProducts = false;
        });
      }
    } catch (_) {
      setState(() => _loadingProducts = false);
    }
  }

  Map<String, dynamic>? get _selectedPackage {
    if (_products == null) return null;
    return _products![_targetRole]?['packages']?[_packageType];
  }

  int get _displayHarga {
    if (_packageType == 'custom') return int.tryParse(_customHargaController.text) ?? 0;
    return (_selectedPackage?['harga'] ?? 0) as int;
  }

  Future<void> _submit() async {
    setState(() => _formError = null);

    if (_buyerUserController.text.trim().isEmpty || _buyerPassController.text.trim().isEmpty) {
      setState(() => _formError = 'Username & password buyer wajib diisi');
      return;
    }
    if (_packageType == 'custom') {
      final d = int.tryParse(_customDaysController.text);
      final h = int.tryParse(_customHargaController.text);
      if (d == null || d <= 0 || h == null || h <= 0) {
        setState(() => _formError = 'Durasi & harga custom harus angka > 0');
        return;
      }
    } else if (_displayHarga <= 0) {
      setState(() => _formError = 'Paket ini belum diaktifin admin (harga masih 0)');
      return;
    }

    setState(() => _status = 'creating');
    try {
      final res = await http.post(
        Uri.parse('$kStoranBaseUrl/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': widget.sessionKey,
          'targetRole': _targetRole,
          'packageType': _packageType,
          if (_packageType == 'custom') 'customDays': _customDaysController.text,
          if (_packageType == 'custom') 'customHarga': _customHargaController.text,
          'buyerUsername': _buyerUserController.text.trim(),
          'buyerPassword': _buyerPassController.text.trim(),
        }),
      );
      final j = jsonDecode(res.body);
      if (res.statusCode == 200) {
        setState(() {
          _depositId = j['depositId'];
          _amount = j['amount'];
          _sektor = j['sektor'];
          _expiresAt = DateTime.fromMillisecondsSinceEpoch(j['expiresAt']);
          _status = 'pending';
        });
        _startPolling();
        _startCountdown();
      } else {
        setState(() {
          _status = 'form';
          _formError = j['error'] ?? 'Gagal bikin storan';
        });
      }
    } catch (e) {
      setState(() {
        _status = 'form';
        _formError = 'Gagal konek ke server: $e';
      });
    }
  }

  Future<void> _uploadBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null || _depositId == null) return;

    setState(() => _uploading = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$kStoranBaseUrl/upload-bukti'));
      req.fields['depositId'] = _depositId!;
      req.files.add(await http.MultipartFile.fromPath('bukti', picked.path));
      final streamed = await req.send();
      final res = await http.Response.fromStream(streamed);
      if (res.statusCode == 200) {
        setState(() => _status = 'menunggu_review');
      } else if (mounted) {
        final j = jsonDecode(res.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(j['error'] ?? 'Gagal upload')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal upload, coba lagi')));
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _startCountdown() {
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final diff = _expiresAt!.difference(DateTime.now());
      setState(() => _remaining = diff.isNegative ? Duration.zero : diff);
      if (diff.isNegative) _tickTimer?.cancel();
    });
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (_depositId == null) return;
      try {
        final res = await http.get(Uri.parse('$kStoranBaseUrl/status/$_depositId'));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          setState(() => _status = j['status']);
          if (['selesai', 'gagal', 'ditolak', 'expired'].contains(j['status'])) {
            _pollTimer?.cancel();
            _tickTimer?.cancel();
          }
        }
      } catch (_) {}
    });
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _reset() {
    setState(() {
      _status = 'form';
      _depositId = null;
      _amount = null;
      _sektor = null;
      _buyerUserController.clear();
      _buyerPassController.clear();
      _customDaysController.clear();
      _customHargaController.clear();
    });
    _loadStats();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NBColors.bg,
      appBar: AppBar(
        backgroundColor: NBColors.bg,
        elevation: 0,
        title: const Text('BUAT STORAN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      ),
      body: SafeArea(
        child: _loadingProducts
            ? const Center(child: CircularProgressIndicator(color: NBColors.gold))
            : Padding(padding: const EdgeInsets.all(16), child: _buildBody()),
      ),
    );
  }

  Widget _buildBody() {
    switch (_status) {
      case 'form':
        return _buildForm();
      case 'creating':
        return const Center(child: CircularProgressIndicator(color: NBColors.gold));
      case 'pending':
        return _buildPending();
      case 'menunggu_review':
        return _statusCard(Icons.hourglass_top, 'BUKTI DITERIMA', 'Lagi ditinjau admin. Biasanya diproses dalam beberapa menit.', color: NBColors.gold);
      case 'selesai':
        return _statusCard(Icons.check_circle, 'AKUN BERHASIL DIBUAT!', 'Sektor Rp$_sektor udah dikonfirm.', color: NBColors.green, action: _reset, actionLabel: 'BUAT STORAN LAGI');
      case 'gagal':
        return _statusCard(Icons.error, 'AKUN GAGAL DIBUAT', 'Sektor diterima tapi gagal — hubungin admin.', color: NBColors.gold, action: _reset, actionLabel: 'COBA LAGI');
      case 'ditolak':
        return _statusCard(Icons.cancel, 'BUKTI DITOLAK', 'Bukti transfer ditolak admin.', color: NBColors.red, action: _reset, actionLabel: 'ULANGI STORAN');
      case 'expired':
        return _statusCard(Icons.timer_off, 'WAKTU HABIS', 'Waktu transfer udah lewat.', color: NBColors.red, action: _reset, actionLabel: 'COBA LAGI');
      default:
        return _buildForm();
    }
  }

  Widget _statusCard(IconData icon, String title, String? subtitle, {required Color color, VoidCallback? action, String? actionLabel}) {
    return Center(
      child: NBCard(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: color, border: Border.all(color: Colors.black, width: 3)),
              child: Icon(icon, color: Colors.black, size: 40),
            ),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.white, fontSize: 16, fontWeight: FontWeight.w900)),
            if (subtitle != null) ...[
              const SizedBox(height: 6),
              Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: NBColors.textDim)),
            ],
            if (action != null) ...[
              const SizedBox(height: 18),
              NBButton(onPressed: action, color: color, child: Text(actionLabel ?? 'OK')),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPending() {
    return Center(
      child: SingleChildScrollView(
        child: NBCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const NBBadge(text: 'MENUNGGU TRANSFER', color: NBColors.gold),
              const SizedBox(height: 14),
              Text('Rp$_amount', style: const TextStyle(color: NBColors.white, fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              const Text('TRANSFER TEPAT NOMINAL INI', style: TextStyle(color: NBColors.textDim, fontSize: 11, letterSpacing: 0.5)),
              const SizedBox(height: 4),
              Text('(sektor 10% dari Rp$_displayHarga)', style: const TextStyle(color: NBColors.textDim, fontSize: 11)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Colors.black, border: Border.all(color: NBColors.red, width: 2)),
                child: Text(_fmt(_remaining), style: const TextStyle(color: NBColors.red, fontSize: 26, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 20),
              const Text('Abis transfer, upload screenshot bukti', textAlign: TextAlign.center, style: TextStyle(color: NBColors.textDim)),
              const SizedBox(height: 14),
              _uploading
                  ? const CircularProgressIndicator(color: NBColors.gold)
                  : NBButton(
                      onPressed: _uploadBukti,
                      color: NBColors.gold,
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.upload, color: Colors.black, size: 18),
                        SizedBox(width: 8),
                        Text('UPLOAD BUKTI TRANSFER'),
                      ]),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    final s = _stats!;
    return NBCard(
      color: NBColors.gold,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(children: [
                Icon(Icons.receipt_long, color: Colors.black),
                SizedBox(width: 8),
                Text('PENGHASILAN JUALAN', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 12)),
              ]),
              Text('${s['totalAkun']} AKUN', style: const TextStyle(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 10),
          Text('Rp${s['totalPenghasilan']}', style: const TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Dari akun yang sudah dibuat (ACC)', style: TextStyle(color: Colors.black87, fontSize: 11)),
          const SizedBox(height: 4),
          Text('ACC Rp${s['accSektor']} · Menunggu ${s['menunggu']} · Ditolak ${s['ditolak']}',
              style: const TextStyle(color: Colors.black87, fontSize: 11, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildForm() {
    final roles = _products?.keys.toList() ?? ['FULLUP', 'RESELLER', 'PT'];
    final packages = _products?[_targetRole]?['packages'] as Map<String, dynamic>?;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_stats != null) _buildStatsCard(),
          if (_stats != null) const SizedBox(height: 24),
          const NBSectionLabel('JENIS AKUN (ROLE)'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: roles.map((r) {
              final selected = r == _targetRole;
              return GestureDetector(
                onTap: () => setState(() {
                  _targetRole = r;
                  _packageType = 'permanen';
                }),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: selected ? NBColors.gold : NBColors.surface,
                    border: Border.all(color: Colors.black, width: 3),
                    boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(3, 3))] : null,
                  ),
                  child: Text(_products?[r]?['label'] ?? r,
                      style: TextStyle(
                        color: selected ? Colors.black : NBColors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                      )),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          const NBSectionLabel('PAKET'),
          const SizedBox(height: 10),
          if (packages != null)
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.0,
              children: packages.entries.map((e) {
                final selected = e.key == _packageType;
                final harga = e.value['harga'];
                return GestureDetector(
                  onTap: () => setState(() => _packageType = e.key),
                  child: Container(
                    decoration: BoxDecoration(
                      color: selected ? NBColors.red : NBColors.surface,
                      border: Border.all(color: Colors.black, width: 3),
                      boxShadow: selected ? const [BoxShadow(color: Colors.black, offset: Offset(3, 3))] : null,
                    ),
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(e.key.toUpperCase(),
                            style: TextStyle(color: selected ? Colors.white : NBColors.white, fontWeight: FontWeight.w900, fontSize: 12)),
                        Text(e.key == 'custom' ? 'CUSTOM' : 'Rp${harga ?? 0}',
                            style: TextStyle(color: selected ? Colors.white70 : NBColors.textDim, fontSize: 11, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          if (_packageType == 'custom') ...[
            const SizedBox(height: 12),
            TextField(
              controller: _customDaysController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: nbInputDecoration('Durasi (hari)', icon: Icons.calendar_today),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _customHargaController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: nbInputDecoration('Harga (Rp)', icon: Icons.payments),
            ),
          ],
          const SizedBox(height: 24),
          const NBSectionLabel('DATA BUYER'),
          const SizedBox(height: 10),
          NBCard(
            child: Column(
              children: [
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('DATA BUYER', style: TextStyle(color: NBColors.white, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 2),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('isi data pembeli akun di bawah ini.', style: TextStyle(color: NBColors.textDim, fontSize: 12)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _buyerUserController,
                  style: const TextStyle(color: Colors.white),
                  decoration: nbInputDecoration('Username buyer', icon: Icons.person),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _buyerPassController,
                  obscureText: true,
                  style: const TextStyle(color: Colors.white),
                  decoration: nbInputDecoration('Password buyer', icon: Icons.lock),
                ),
              ],
            ),
          ),
          if (_formError != null) ...[
            const SizedBox(height: 10),
            Text(_formError!, style: const TextStyle(color: NBColors.red, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: NBButton(
              onPressed: _submit,
              color: NBColors.gold,
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: const Text('BUAT STORAN'),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
