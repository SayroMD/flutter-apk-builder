import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'tools_gateway.dart';

class ToolsLandingPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;
  final List<Map<String, dynamic>> listDoos;
  final String uid;

  const ToolsLandingPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.username,
    required this.listDoos,
    required this.uid,
  });

  @override
  State<ToolsLandingPage> createState() => _ToolsLandingPageState();
}

class _ToolsLandingPageState extends State<ToolsLandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  // Neo-Brutalism palette
  static const String appFont = 'Orbitron';
  static const Color neoBg = Color(0xFFF5F0E8);
  static const Color neoBlack = Color(0xFF1A1A1A);
  static const Color neoYellow = Color(0xFFFFE566);
  static const Color neoPink = Color(0xFFFF6B9D);
  static const Color neoCyan = Color(0xFF00E5FF);
  static const Color neoOrange = Color(0xFFFF8C42);
  static const Color neoGreen = Color(0xFF39FF14);
  static const Color neoPurple = Color(0xFFB388FF);
  static const Color neoWhite = Color(0xFFFFFFFF);
  static const Color neoGray = Color(0xFFE8E0D5);

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _copyToClipboard(String label, String value) {
    Clipboard.setData(ClipboardData(text: value));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: neoBlack,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
          side: const BorderSide(color: neoYellow, width: 3),
        ),
        content: Text(
          '$label DISALIN',
          style: const TextStyle(
            color: neoYellow,
            fontFamily: appFont,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }

  void _enterTools() {
    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, __, ___) => ToolsPage(
          sessionKey: widget.sessionKey,
          userRole: widget.userRole,
          username: widget.username,
          listDoos: widget.listDoos,
        ),
        transitionsBuilder: (_, anim, __, child) {
          return FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.06, 0),
                end: Offset.zero,
              ).animate(
                  CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
              child: child,
            ),
          );
        },
      ),
    );
  }

  // Hard offset shadow typical of neo-brutalism
  List<BoxShadow> get _hardShadow => [
        const BoxShadow(
          color: neoBlack,
          offset: Offset(5, 5),
          blurRadius: 0,
        ),
      ];

  List<BoxShadow> get _hardShadowSm => [
        const BoxShadow(
          color: neoBlack,
          offset: Offset(3, 3),
          blurRadius: 0,
        ),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: neoBg,
      body: Stack(
        children: [
          // Subtle geometric background accents
          Positioned(
            top: -40,
            right: -30,
            child: Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                color: neoYellow.withOpacity(0.35),
                shape: BoxShape.circle,
                border: Border.all(color: neoBlack, width: 3),
              ),
            ),
          ),
          Positioned(
            bottom: 80,
            left: -50,
            child: Transform.rotate(
              angle: 0.4,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: neoPink.withOpacity(0.25),
                  border: Border.all(color: neoBlack, width: 3),
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildHeroCard(),
                      const SizedBox(height: 22),
                      _buildSectionLabel(),
                      const SizedBox(height: 14),
                      _buildOpenToolsCard(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Hero card ──
  Widget _buildHeroCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: neoWhite,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: neoBlack, width: 3.5),
        boxShadow: _hardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: neoCyan,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 3),
                  boxShadow: _hardShadowSm,
                ),
                child: const Icon(Icons.dashboard_rounded,
                    color: neoBlack, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'DNA TOOLS',
                      style: TextStyle(
                        color: neoBlack.withOpacity(0.55),
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                        letterSpacing: 2.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Tools Gateway',
                      style: TextStyle(
                        color: neoBlack,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                        height: 1.1,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: neoGreen,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 2.5),
                  boxShadow: _hardShadowSm,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: neoBlack,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      widget.userRole.toUpperCase(),
                      style: const TextStyle(
                        color: neoBlack,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: neoYellow,
              borderRadius: BorderRadius.circular(3),
              border: Border.all(color: neoBlack, width: 2.5),
            ),
            child: const Text(
              'Berbagai menu tools Apk DNA serta alat pembantu untuk hosting atau kebutuhan sehari-hari.',
              style: TextStyle(
                color: neoBlack,
                fontSize: 13,
                height: 1.4,
                fontWeight: FontWeight.w600,
                fontFamily: appFont,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Role box
              Container(
                width: 96,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: neoPink,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 3),
                  boxShadow: _hardShadowSm,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ROLE',
                      style: TextStyle(
                        color: neoBlack.withOpacity(0.7),
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      widget.userRole.toUpperCase(),
                      style: const TextStyle(
                        color: neoBlack,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              // Session ID box
              Expanded(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: neoWhite,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 3),
                  boxShadow: _hardShadowSm,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'UID',  // ← UBAH DARI 'SESSION ID'
                      style: TextStyle(
                        color: neoBlack.withOpacity(0.55),
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      widget.uid,  // ← UBAH DARI widget.sessionKey
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: neoBlack,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        fontFamily: appFont,
                        letterSpacing: 0.4,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _miniButton(
                            icon: Icons.badge_outlined,
                            label: 'SALIN UID',  // ← UBAH DARI 'SALIN ID'
                            bg: neoCyan,
                            onTap: () => _copyToClipboard(
                                'UID', widget.uid),  // ← UBAH KE uid
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _miniButton(
                            icon: Icons.data_object_rounded,
                            label: 'SALIN CODE',
                            bg: neoOrange,
                            onTap: () => _copyToClipboard(
                                'Code', widget.sessionKey),  // ← TETAP SESSION KEY
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

  Widget _miniButton({
    required IconData icon,
    required String label,
    required Color bg,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(3),
            border: Border.all(color: neoBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                color: neoBlack,
                offset: Offset(2, 2),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 12, color: neoBlack),
              const SizedBox(width: 4),
              Text(
                label,
                style: const TextStyle(
                  color: neoBlack,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  fontFamily: appFont,
                  letterSpacing: 0.6,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Section label ──
  Widget _buildSectionLabel() {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: neoYellow,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: neoBlack, width: 3),
            boxShadow: _hardShadowSm,
          ),
          child: const Icon(Icons.widgets_rounded, color: neoBlack, size: 20),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Tool DNA',
              style: TextStyle(
                color: neoBlack,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: appFont,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              'Satu Apk Untuk Semua Kebutuhanmu',
              style: TextStyle(
                color: neoBlack.withOpacity(0.65),
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: appFont,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ─── Open Tools card ──
  Widget _buildOpenToolsCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: neoWhite,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: neoBlack, width: 3.5),
        boxShadow: _hardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: neoPurple,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 3),
                  boxShadow: _hardShadowSm,
                ),
                child: const Icon(Icons.grid_view_rounded,
                    color: neoBlack, size: 26),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: neoOrange,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 2.5),
                  boxShadow: _hardShadowSm,
                ),
                child: Text(
                  '${widget.listDoos.isNotEmpty ? widget.listDoos.length : 9} TOOLS',
                  style: const TextStyle(
                    color: neoBlack,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: appFont,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'Buka Tools DNA',
            style: TextStyle(
              color: neoBlack,
              fontSize: 22,
              fontWeight: FontWeight.w900,
              fontFamily: appFont,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Semua tools ditampilkan dalam layar penuh dengan design elegan serta pengembangan langsung oleh tim dna.',
            style: TextStyle(
              color: neoBlack.withOpacity(0.7),
              fontSize: 13,
              height: 1.45,
              fontWeight: FontWeight.w500,
              fontFamily: appFont,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _tagChip(
                icon: Icons.cloud_outlined,
                label: 'HOSTING',
                color: neoCyan,
              ),
              _tagChip(
                icon: Icons.sports_esports_outlined,
                label: 'GAME & AI',
                color: neoPurple,
              ),
              _tagChip(
                icon: Icons.bolt_rounded,
                label: 'DDOS',
                color: neoOrange,
              ),
              _tagChip(
                icon: Icons.wifi_rounded,
                label: 'NETWORK',
                color: neoGreen,
              ),
            ],
          ),
          const SizedBox(height: 20),
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: _enterTools,
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                decoration: BoxDecoration(
                  color: neoYellow,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: neoBlack, width: 3.5),
                  boxShadow: _hardShadow,
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'MASUK KE SEMUA MENU',
                      style: TextStyle(
                        color: neoBlack,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: appFont,
                        letterSpacing: 1,
                      ),
                    ),
                    Icon(Icons.arrow_forward_rounded,
                        color: neoBlack, size: 22),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tagChip({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(3),
        border: Border.all(color: neoBlack, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: neoBlack,
            offset: Offset(2, 2),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: neoBlack),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: neoBlack,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              fontFamily: appFont,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}
