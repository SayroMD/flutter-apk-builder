// cpanel.dart - CYBER STYLE
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'base_page.dart';

class CpanelPage extends StatefulWidget {
  final String username;
  final String role;

  const CpanelPage({
    super.key,
    required this.username,
    required this.role,
  });

  @override
  State<CpanelPage> createState() => _CpanelPageState();
}

class _CpanelPageState extends State<CpanelPage> with SingleTickerProviderStateMixin {
  final TextEditingController _aliasController = TextEditingController();
  final TextEditingController _ptlaController = TextEditingController();
  final TextEditingController _ptlcController = TextEditingController();
  final TextEditingController _domainController = TextEditingController();
  final TextEditingController _panelNameController = TextEditingController();
  final TextEditingController _telegramIdController = TextEditingController();

  List<Map<String, dynamic>> _adpList = [];
  List<Map<String, dynamic>> _panelsList = [];
  String? _selectedAdpKey;
  double _memorySize = 1.0;
  String NODE_PACKAGES = '';
  String UNNODE_PACKAGES = '';
  String CMD_RUN = 'npm start';
  bool _isUnlimited = false;
  bool _isCreating = false;
  bool _isLoading = true;
  Map<String, dynamic>? _createdPanel;
  int _activeTab = 0;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  final String _storageKey = 'otax_adp_data';

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
    _loadData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _aliasController.dispose();
    _ptlaController.dispose();
    _ptlcController.dispose();
    _domainController.dispose();
    _panelNameController.dispose();
    _telegramIdController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await Future.wait([
      _loadAdpFromLocal(),
      _loadPanelsFromLocal(),
    ]);
    setState(() => _isLoading = false);
  }

  Future<void> _loadAdpFromLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? encryptedData = prefs.getString('${_storageKey}_${widget.username}');
      
      if (encryptedData != null) {
        final jsonData = jsonDecode(encryptedData);
        setState(() {
          _adpList = List<Map<String, dynamic>>.from(jsonData);
          if (_adpList.isNotEmpty) _selectedAdpKey = _adpList.first['alias'];
        });
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error loading ADP: $e', isError: true);
    }
  }

  Future<void> _saveAdpToLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        '${_storageKey}_${widget.username}',
        jsonEncode(_adpList)
      );
    } catch (e) {
      showCyberSnackBar(context, 'Error saving ADP: $e', isError: true);
    }
  }

  Future<void> _loadPanelsFromLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? panelsData = prefs.getString('${_storageKey}_panels_${widget.username}');
      
      if (panelsData != null) {
        final jsonData = jsonDecode(panelsData);
        setState(() {
          _panelsList = List<Map<String, dynamic>>.from(jsonData);
        });
      }
    } catch (e) {
      // Silent error
    }
  }

  Future<void> _savePanelsToLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        '${_storageKey}_panels_${widget.username}',
        jsonEncode(_panelsList)
      );
    } catch (e) {
      // Silent error
    }
  }

  // ==================== API METHODS ====================
  Future<void> _saveAdp() async {
    if (_aliasController.text.isEmpty) {
      showCyberSnackBar(context, 'Alias harus diisi!', isError: true);
      return;
    }
    if (_ptlaController.text.isEmpty) {
      showCyberSnackBar(context, 'PTLA harus diisi!', isError: true);
      return;
    }
    if (_domainController.text.isEmpty) {
      showCyberSnackBar(context, 'Domain harus diisi!', isError: true);
      return;
    }

    final newAdp = {
      'alias': _aliasController.text.trim(),
      'ptla': _ptlaController.text.trim(),
      'ptlc': _ptlcController.text.trim(),
      'domain': _domainController.text.trim(),
      'createdAt': DateTime.now().toIso8601String(),
    };

    setState(() {
      _adpList.add(newAdp);
      _selectedAdpKey = newAdp['alias'];
    });

    await _saveAdpToLocal();

    _aliasController.clear();
    _ptlaController.clear();
    _ptlcController.clear();
    _domainController.clear();
    
    showCyberSnackBar(context, '✅ ADP berhasil disimpan!');
    setState(() => _activeTab = 1);
  }

  Future<Map<String, dynamic>> _createUserPterodactyl(String domain, String ptla, String username, bool isAdmin) async {
    try {
      final email = isAdmin ? 
        '$username@admin.OTAX' : 
        (_isUnlimited ? '$username@unli.OTAX' : '$username@panel.OTAX');
      
      final password = isAdmin ? '${username}117' : '${username}001';

      final response = await http.post(
        Uri.parse('$domain/api/application/users'),
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $ptla',
        },
        body: jsonEncode({
          'email': email,
          'username': username,
          'first_name': username,
          'last_name': username,
          'language': 'en',
          'root_admin': isAdmin,
          'password': password,
        }),
      );

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'user': data['attributes'],
          'email': email,
          'password': password,
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['errors']?[0]['detail'] ?? 'Gagal membuat user',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  Future<Map<String, dynamic>> _createServerPterodactyl(String domain, String ptla, Map<String, dynamic> user, String username, int memory, {bool isUnlimited = false}) async {
    try {
      const eggId = 15;
      const dockerImage = 'ghcr.io/parkervcp/yolks:nodejs_22';

      final startupCommand = 
        'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; '
        'if [[ ! -z {{NODE_PACKAGES}} ]]; then /usr/local/bin/npm install {{NODE_PACKAGES}}; fi; '
        'if [[ ! -z {{UNNODE_PACKAGES}} ]]; then /usr/local/bin/npm uninstall {{UNNODE_PACKAGES}}; fi; '
        'if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; '
        '/usr/local/bin/{{CMD_RUN}}';

      final serverName = isUnlimited ? '${username}unli' : username;
      final locations = [1, 2, 3, 4, 5];
      final List<String> failedServerIds = [];

      for (final location in locations) {
        final response = await http.post(
          Uri.parse('$domain/api/application/servers'),
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $ptla',
          },
          body: jsonEncode({
            'name': serverName,
            'description': '',
            'user': user['id'],
            'egg': eggId,
            'docker_image': dockerImage,
            'startup': startupCommand,
            'environment': {
              'INST': 'npm',
              'USER_UPLOAD': '0',
              'AUTO_UPDATE': '0',
              'NODE_PACKAGES': NODE_PACKAGES,
              'UNNODE_PACKAGES': UNNODE_PACKAGES,
              'CMD_RUN': CMD_RUN,
            },
            'limits': {
              'memory': isUnlimited ? 0 : memory,
              'swap': 0,
              'disk': isUnlimited ? 0 : memory * 2,
              'io': 500,
              'cpu': isUnlimited ? 0 : 100,
            },
            'feature_limits': {
              'databases': 5,
              'backups': 5,
              'allocations': 1,
            },
            'deploy': {
              'locations': [location],
              'dedicated_ip': false,
              'port_range': [],
            },
          }),
        );

        final data = jsonDecode(response.body);
        
        if (response.statusCode == 201 && data['attributes'] != null) {
          for (final serverId in failedServerIds) {
            await http.delete(
              Uri.parse('$domain/api/application/servers/$serverId'),
              headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer $ptla',
              },
            );
          }
          
          return {
            'success': true,
            'server': data['attributes'],
            'location': location,
          };
        } else if (data['meta']?['server_id'] != null) {
          failedServerIds.add(data['meta']['server_id'].toString());
        }
      }

      return {
        'success': false,
        'error': 'Gagal membuat server di semua lokasi',
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  Future<void> _createPanel() async {
    if (_selectedAdpKey == null) {
      showCyberSnackBar(context, 'Pilih ADP terlebih dahulu!', isError: true);
      return;
    }
    if (_panelNameController.text.isEmpty) {
      showCyberSnackBar(context, 'Nama panel wajib diisi!', isError: true);
      return;
    }

    setState(() {
      _isCreating = true;
      _createdPanel = null;
    });

    try {
      final selectedAdp = _adpList.firstWhere((adp) => adp['alias'] == _selectedAdpKey);
      final domain = _ensureHttps(selectedAdp['domain']);
      final ptla = selectedAdp['ptla'];
      final username = _panelNameController.text.trim();
      final memory = (_memorySize * 1024).toInt();

      final userResult = await _createUserPterodactyl(domain, ptla, username, false);
      
      if (!userResult['success']) {
        showCyberSnackBar(context, userResult['error'], isError: true);
        return;
      }

      final user = userResult['user'];
      final serverResult = await _createServerPterodactyl(
        domain, ptla, user, username, memory, 
        isUnlimited: _isUnlimited
      );
      
      if (!serverResult['success']) {
        showCyberSnackBar(context, serverResult['error'], isError: true);
        return;
      }

      final panelData = {
        'domain': domain,
        'username': user['username'],
        'email': userResult['email'],
        'password': userResult['password'],
        'userId': user['id'],
        'serverId': serverResult['server']['id'],
        'memory': _isUnlimited ? 0 : memory,
        'disk': _isUnlimited ? 0 : memory * 2,
        'cpu': _isUnlimited ? 0 : 100,
        'isUnlimited': _isUnlimited,
        'location': serverResult['location'],
        'createdAt': DateTime.now().toIso8601String(),
        'alias': _selectedAdpKey,
        'ptla': ptla,
        'ptlc': selectedAdp['ptlc'],
      };

      setState(() {
        _panelsList.add(panelData);
        _createdPanel = panelData;
      });

      await _savePanelsToLocal();

      _panelNameController.clear();
      _telegramIdController.clear();
      
      showCyberSnackBar(context, '✨ Panel berhasil dibuat!');
      setState(() => _activeTab = 2);
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
    } finally {
      setState(() => _isCreating = false);
    }
  }

  Future<void> _createAdminPanel() async {
    if (_selectedAdpKey == null) {
      showCyberSnackBar(context, 'Pilih ADP terlebih dahulu!', isError: true);
      return;
    }
    if (_panelNameController.text.isEmpty) {
      showCyberSnackBar(context, 'Nama admin wajib diisi!', isError: true);
      return;
    }

    setState(() => _isCreating = true);
    try {
      final selectedAdp = _adpList.firstWhere((adp) => adp['alias'] == _selectedAdpKey);
      final domain = _ensureHttps(selectedAdp['domain']);
      final ptla = selectedAdp['ptla'];
      final username = _panelNameController.text.trim();

      final userResult = await _createUserPterodactyl(domain, ptla, username, true);
      
      if (!userResult['success']) {
        showCyberSnackBar(context, userResult['error'], isError: true);
        return;
      }

      final user = userResult['user'];
      
      showCyberSnackBar(context, '👑 Admin panel berhasil dibuat!');
      _panelNameController.clear();

      final adminData = '''
TYPE: user
➟ ID: ${user['id']}
➟ USERNAME: ${user['username']}
➟ EMAIL: ${userResult['email']}
➟ NAME: ${user['first_name']} ${user['last_name']}
➟ LANGUAGE: ${user['language']}
➟ ADMIN: ${user['root_admin']}
➟ CREATED AT: ${user['created_at']}
      ''';

      _copyToClipboard(adminData);
    } catch (e) {
      showCyberSnackBar(context, 'Error: $e', isError: true);
    } finally {
      setState(() => _isCreating = false);
    }
  }

  Future<List<Map<String, dynamic>>> _listServersPterodactyl(String domain, String ptla) async {
    try {
      final List<Map<String, dynamic>> servers = [];
      int page = 1;
      
      while (true) {
        final response = await http.get(
          Uri.parse('$domain/api/application/servers?page=$page&per_page=100'),
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $ptla',
          },
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          final List<dynamic> serverList = data['data'] ?? [];
          
          for (final server in serverList) {
            final attrs = server['attributes'];
            servers.add({
              'id': attrs['id'],
              'identifier': attrs['identifier'],
              'name': attrs['name'],
              'memory': attrs['limits']['memory'],
              'disk': attrs['limits']['disk'],
              'cpu': attrs['limits']['cpu'],
              'status': 'unknown',
            });
          }

          final pagination = data['meta']['pagination'];
          if (page >= pagination['total_pages']) break;
          page++;
        } else {
          break;
        }
      }

      return servers;
    } catch (e) {
      return [];
    }
  }

  Future<String> _getServerStatus(String domain, String ptlc, String serverIdentifier) async {
    try {
      final response = await http.get(
        Uri.parse('$domain/api/client/servers/$serverIdentifier/resources'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $ptlc',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final state = data['attributes']['current_state'];
        
        if (state == 'running') return 'Online';
        if (state == 'offline') return 'Offline';
        return 'Unknown';
      }
      return 'Unknown';
    } catch (e) {
      return 'Unknown';
    }
  }

  Future<bool> _deleteServerPterodactyl(String domain, String ptla, String serverId) async {
    try {
      final response = await http.delete(
        Uri.parse('$domain/api/application/servers/$serverId'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $ptla',
        },
      );
      return response.statusCode == 204;
    } catch (e) {
      return false;
    }
  }

  Future<void> _deleteAdp(String alias) async {
    final confirm = await _showConfirmDialog('Hapus ADP?', 'Yakin ingin menghapus ADP "$alias"?');
    if (!confirm) return;

    setState(() {
      _adpList.removeWhere((adp) => adp['alias'] == alias);
      if (_selectedAdpKey == alias) {
        _selectedAdpKey = _adpList.isNotEmpty ? _adpList.first['alias'] : null;
      }
    });

    await _saveAdpToLocal();
    showCyberSnackBar(context, '🗑️ ADP berhasil dihapus!');
  }

  Future<void> _deletePanel(String serverId) async {
    final confirm = await _showConfirmDialog('Hapus Panel?', 'Yakin ingin menghapus panel ini?');
    if (!confirm) return;

    final panelIndex = _panelsList.indexWhere((panel) => panel['serverId'] == serverId);
    if (panelIndex == -1) return;

    final panel = _panelsList[panelIndex];
    
    try {
      final domain = _ensureHttps(panel['domain']);
      final ptla = panel['ptla'];
      
      if (ptla != null && ptla.isNotEmpty) {
        final success = await _deleteServerPterodactyl(domain, ptla, serverId);
        if (!success) {
          showCyberSnackBar(context, 'Gagal menghapus server dari Pterodactyl', isError: true);
          return;
        }
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error menghapus server: $e', isError: true);
    }

    setState(() {
      _panelsList.removeAt(panelIndex);
    });

    await _savePanelsToLocal();
    showCyberSnackBar(context, '🗑️ Panel berhasil dihapus!');
  }

  Future<void> _listServers() async {
    if (_selectedAdpKey == null) {
      showCyberSnackBar(context, 'Pilih ADP terlebih dahulu!', isError: true);
      return;
    }

    final selectedAdp = _adpList.firstWhere((adp) => adp['alias'] == _selectedAdpKey);
    final domain = _ensureHttps(selectedAdp['domain']);
    final ptla = selectedAdp['ptla'];
    final ptlc = selectedAdp['ptlc'] ?? '';

    setState(() => _isLoading = true);

    try {
      final servers = await _listServersPterodactyl(domain, ptla);
      
      if (servers.isEmpty) {
        showCyberSnackBar(context, 'Tidak ada server ditemukan');
        return;
      }

      List<String> serverLines = [];
      for (int i = 0; i < servers.length; i++) {
        final server = servers[i];
        String status = 'Unknown';
        
        if (ptlc.isNotEmpty) {
          status = await _getServerStatus(domain, ptlc, server['identifier']);
        }
        
        serverLines.add(
          '#${i + 1}. ${server['name']} — $status (id:${server['id']})'
        );
      }

      final message = '''
OTAX — LIST SERVER
ADP: $_selectedAdpKey | Domain: $domain

${serverLines.join('\n')}
      ''';

      await _showServerListDialog(message);
    } catch (e) {
      showCyberSnackBar(context, 'Gagal mengambil data server: $e', isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showServerListDialog(String message) async {
    await showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          padding: const EdgeInsets.all(24),
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.list, color: AppColors.accent, size: 48),
              const SizedBox(height: 12),
              Text(
                'DAFTAR SERVER',
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                height: 280,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.bg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.borderLight),
                ),
                child: SingleChildScrollView(
                  child: SelectableText(
                    message,
                    style: TextStyle(
                      fontFamily: 'monospace',
                      color: AppColors.textPrimary,
                      fontSize: 11,
                      height: 1.5,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: CyberButton(
                      label: 'TUTUP',
                      icon: Icons.close,
                      onTap: () => Navigator.pop(context),
                      color: AppColors.textSec,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CyberButton(
                      label: 'SALIN',
                      icon: Icons.copy,
                      onTap: () {
                        _copyToClipboard(message);
                        Navigator.pop(context);
                      },
                      color: AppColors.accent,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _ensureHttps(String url) {
    if (!url.startsWith('http')) {
      return 'https://$url';
    }
    return url.replaceFirst('http://', 'https://');
  }

  void _copyToClipboard(String text) {
    Clipboard.setData(ClipboardData(text: text));
    showCyberSnackBar(context, '✅ Disalin ke clipboard!');
  }

  Future<bool> _showConfirmDialog(String title, String message) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.warning, color: AppColors.red, size: 48),
              const SizedBox(height: 12),
              Text(
                title,
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: CyberButton(
                      label: 'BATAL',
                      icon: Icons.close,
                      onTap: () => Navigator.pop(context, false),
                      color: AppColors.textSec,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CyberButton(
                      label: 'HAPUS',
                      icon: Icons.delete,
                      onTap: () => Navigator.pop(context, true),
                      color: AppColors.red,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return result ?? false;
  }

  // ==================== WIDGETS ====================
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(bottom: BorderSide(color: AppColors.borderLight.withOpacity(0.3))),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.accent.withOpacity(0.3)),
            ),
            child: const Icon(Icons.dashboard_customize, color: AppColors.accent, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'OTAX CREATE PANEL',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  'Fitur Create Panel Untuk Memudahkan Anda',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Row(
              children: [
                Icon(Icons.person, color: AppColors.textSec, size: 14),
                const SizedBox(width: 6),
                Text(
                  widget.username,
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          _buildTabButton(0, 'ADP', Icons.save_alt),
          _buildTabButton(1, 'Buat', Icons.add_box),
          _buildTabButton(2, 'Panel', Icons.dashboard),
          _buildTabButton(3, 'List', Icons.list),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String label, IconData icon) {
    final isActive = _activeTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (index == 3) {
            _listServers();
          } else {
            setState(() => _activeTab = index);
          }
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            gradient: isActive
                ? LinearGradient(
                    colors: [
                      AppColors.accent.withOpacity(0.15),
                      AppColors.accent.withOpacity(0.05),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
            borderRadius: BorderRadius.circular(10),
            border: isActive
                ? Border.all(color: AppColors.accent.withOpacity(0.3))
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: isActive ? AppColors.accent : AppColors.textMuted,
                size: 18,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontFamily: appFont,
                  color: isActive ? AppColors.accent : AppColors.textMuted,
                  fontSize: 9,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdpForm() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            GlassCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'TAMBAH ADP BARU',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Simpan informasi ADP untuk digunakan nanti',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _aliasController,
              label: 'ALIAS/NICKNAME',
              hint: 'Contoh: server-utama',
              icon: Icons.label_important,
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _ptlaController,
              label: 'PTLA',
              hint: 'Token akses panel',
              icon: Icons.vpn_key,
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _ptlcController,
              label: 'PTLC (OPSIONAL)',
              hint: 'Token tambahan jika ada',
              icon: Icons.vpn_key_outlined,
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _domainController,
              label: 'DOMAIN PANEL',
              hint: 'https://panel.domain.com',
              icon: Icons.public,
            ),
            const SizedBox(height: 24),
            CyberButton(
              label: 'SIMPAN ADP',
              icon: Icons.save,
              onTap: _saveAdp,
              width: double.infinity,
            ),
            if (_adpList.isNotEmpty) ...[
              const SizedBox(height: 24),
              GlassCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.storage, color: AppColors.accent, size: 18),
                        const SizedBox(width: 10),
                        Text(
                          'ADP TERSIMPAN',
                          style: TextStyle(
                            fontFamily: appFont,
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ..._adpList.map((adp) => _buildAdpCard(adp)).toList(),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAdpCard(Map<String, dynamic> adp) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.accent.withOpacity(0.2)),
            ),
            child: Icon(Icons.cloud, color: AppColors.accent.withOpacity(0.7), size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  adp['alias'],
                  style: TextStyle(
                    fontFamily: appFont,
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Domain: ${adp['domain']}',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: AppColors.textSec,
                    fontSize: 11,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                if (adp['createdAt'] != null) ...[
                  Text(
                    'Ditambahkan: ${_formatDate(adp['createdAt'])}',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textMuted,
                      fontSize: 9,
                    ),
                  ),
                ],
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _deleteAdp(adp['alias']),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.red.withOpacity(0.3)),
              ),
              child: Icon(Icons.delete_outline, color: AppColors.red, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreatePanelForm() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            GlassCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'BUAT PANEL BARU',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Pilih ADP dan konfigurasi panel Anda',
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (_adpList.isNotEmpty)
              _buildAdpSelector()
            else
              GlassCard(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Icon(Icons.cloud_off, color: AppColors.textMuted, size: 40),
                    const SizedBox(height: 12),
                    Text(
                      'Belum ada ADP',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Simpan ADP terlebih dahulu di tab "ADP"',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _panelNameController,
              label: 'NAMA PANEL',
              hint: 'Contoh: mypanel01',
              icon: Icons.badge,
            ),
            const SizedBox(height: 16),
            CyberInputField(
              controller: _telegramIdController,
              label: 'ID TELEGRAM (OPSIONAL)',
              hint: '@username atau ID numerik',
              icon: Icons.telegram,
            ),
            const SizedBox(height: 16),
            _buildMemoryConfig(),
            const SizedBox(height: 24),
            CyberButton(
              label: 'BUAT PANEL',
              icon: Icons.rocket_launch,
              onTap: _isCreating ? () {} : _createPanel,
              isLoading: _isCreating,
              width: double.infinity,
            ),
            const SizedBox(height: 12),
            CyberButton(
              label: 'BUAT ADMIN PANEL',
              icon: Icons.admin_panel_settings,
              onTap: _isCreating ? () {} : _createAdminPanel,
              isLoading: _isCreating,
              color: AppColors.accent.withOpacity(0.6),
              width: double.infinity,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdpSelector() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.cloud_queue, color: AppColors.accent, size: 18),
              const SizedBox(width: 10),
              Text(
                'PILIH ADP',
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedAdpKey,
                isExpanded: true,
                dropdownColor: AppColors.surface,
                icon: Icon(Icons.arrow_drop_down, color: AppColors.accent),
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 13,
                  fontFamily: appFont,
                ),
                items: _adpList.map((adp) {
                  return DropdownMenuItem<String>(
                    value: adp['alias'],
                    child: Row(
                      children: [
                        Icon(Icons.cloud, color: AppColors.accent, size: 14),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(adp['alias'], 
                                  style: TextStyle(color: AppColors.textPrimary)),
                              Text(
                                adp['domain'],
                                style: TextStyle(
                                  color: AppColors.textSec,
                                  fontSize: 10,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) => setState(() => _selectedAdpKey = value),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMemoryConfig() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.memory, color: AppColors.accent, size: 18),
              const SizedBox(width: 10),
              Text(
                'KONFIGURASI MEMORY',
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'RAM Allocation:',
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 12,
                ),
              ),
              Text(
                _isUnlimited ? 'UNLIMITED' : '${_memorySize.toInt()} GB',
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.accent,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: AppColors.accent,
              inactiveTrackColor: AppColors.borderLight,
              thumbColor: Colors.white,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
              overlayColor: AppColors.accent.withOpacity(0.2),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
              trackHeight: 4,
            ),
            child: Slider(
              value: _memorySize,
              min: 1,
              max: 100,
              divisions: 99,
              onChanged: _isUnlimited ? null : (value) => setState(() => _memorySize = value),
            ),
          ),
          Row(
            children: [
              Transform.scale(
                scale: 0.85,
                child: Checkbox(
                  value: _isUnlimited,
                  activeColor: AppColors.accent,
                  checkColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4),
                  ),
                  onChanged: (value) => setState(() => _isUnlimited = value!),
                ),
              ),
              Text(
                'Unlimited Memory',
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 12,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _isUnlimited ? AppColors.accent.withOpacity(0.15) : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _isUnlimited ? AppColors.accent : Colors.transparent,
                  ),
                ),
                child: Text(
                  'PREMIUM',
                  style: TextStyle(
                    fontFamily: appFont,
                    color: _isUnlimited ? AppColors.accent : AppColors.textMuted,
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMyPanelsTab() {
    if (_isLoading) {
      return const Center(child: CyberLoadingShimmer());
    }

    if (_panelsList.isEmpty) {
      return FadeTransition(
        opacity: _fadeAnimation,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.dashboard_customize, color: AppColors.textMuted, size: 48),
              const SizedBox(height: 16),
              Text(
                'Belum ada panel',
                style: TextStyle(
                  fontFamily: appFont,
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Buat panel pertama Anda di tab "Buat"',
                style: TextStyle(
                  fontFamily: appFont,
                  color: AppColors.textSec,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 24),
              CyberButton(
                label: 'BUAT PANEL',
                icon: Icons.add,
                onTap: () => setState(() => _activeTab = 1),
                color: AppColors.accent,
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadPanelsFromLocal,
      backgroundColor: AppColors.surface,
      color: AppColors.accent,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _panelsList.length,
        itemBuilder: (context, index) {
          final panel = _panelsList[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildPanelCard(panel),
          );
        },
      ),
    );
  }

  Widget _buildPanelCard(Map<String, dynamic> panel) {
    final domain = panel['domain'] ?? '';
    final username = panel['username'] ?? '';
    final memory = panel['memory'] ?? 0;
    final isUnlimited = panel['isUnlimited'] == true;

    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: isUnlimited ? AppColors.accent.withOpacity(0.1) : AppColors.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isUnlimited ? AppColors.accent : AppColors.accent,
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      isUnlimited ? Icons.all_inclusive : Icons.memory,
                      color: AppColors.accent,
                      size: 12,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      isUnlimited ? 'UNLIMITED' : '${memory ~/ 1024} GB',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.accent,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => _deletePanel(panel['serverId']?.toString() ?? ''),
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppColors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.red.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.delete_outline, color: AppColors.red, size: 14),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.accent.withOpacity(0.2)),
                ),
                child: Icon(Icons.cloud, color: AppColors.accent, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      domain,
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textSec,
                        fontSize: 11,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (panel['createdAt'] != null) ...[
                      Text(
                        'Dibuat: ${_formatDate(panel['createdAt'])}',
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.textMuted,
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: CyberButton(
                  label: 'SALIN DATA',
                  icon: Icons.copy,
                  onTap: () {
                    final panelData = '''
Login: $domain
Username: $username
Password: ${panel['password'] ?? ''}
ID: ${panel['userId'] ?? ''}
Memory: ${isUnlimited ? "Unlimited" : "${panel['memory'] ?? 0} MB"}
Disk: ${isUnlimited ? "Unlimited" : "${(panel['memory'] ?? 0) * 2} MB"}
CPU: ${panel['cpu'] ?? 100}%
                    '''.trim();
                    _copyToClipboard(panelData);
                  },
                  color: AppColors.textSec,
                ),
              ),
              const SizedBox(width: 10),
              CyberButton(
                label: 'DETAIL',
                icon: Icons.visibility,
                onTap: () => _showPanelDetails(panel),
                color: AppColors.accent,
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showPanelDetails(Map<String, dynamic> panel) {
    final domain = panel['domain'] ?? '';
    final username = panel['username'] ?? '';
    final password = panel['password'] ?? '';
    final email = panel['email'] ?? '';
    final userId = panel['userId']?.toString() ?? '';
    final serverId = panel['serverId']?.toString() ?? '';
    final memory = panel['memory'] ?? 0;
    final disk = panel['disk'] ?? 0;
    final cpu = panel['cpu'] ?? 0;
    final location = panel['location'] ?? 'N/A';
    final isUnlimited = panel['isUnlimited'] == true;

    final panelData = '''
Login: $domain
Username: $username
Password: $password
Email: $email
User ID: $userId
Server ID: $serverId
Memory: ${isUnlimited ? "Unlimited" : "$memory MB"}
Disk: ${isUnlimited ? "Unlimited" : "$disk MB"}
CPU: $cpu%
Location: $location
    '''.trim();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.85,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.surface.withOpacity(0.95),
                AppColors.bg.withOpacity(0.95),
              ],
            ),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
            border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                  border: Border(
                    bottom: BorderSide(color: AppColors.borderLight.withOpacity(0.3)),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: AppColors.accent, size: 24),
                    const SizedBox(width: 12),
                    Text(
                      'DETAIL PANEL',
                      style: TextStyle(
                        fontFamily: appFont,
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.surface2,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.borderLight),
                        ),
                        child: Icon(Icons.close, color: AppColors.textSec, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      GlassCard(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            CircleAvatar(
                              radius: 28,
                              backgroundColor: AppColors.accent.withOpacity(0.15),
                              child: Icon(Icons.cloud, color: AppColors.accent, size: 28),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              username,
                              style: TextStyle(
                                fontFamily: appFont,
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              domain,
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.textSec,
                                fontSize: 13,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      ..._buildDetailRow('🌐 Domain', domain),
                      ..._buildDetailRow('👤 Username', username),
                      ..._buildDetailRow('🔐 Password', password),
                      ..._buildDetailRow('📧 Email', email),
                      ..._buildDetailRow('🆔 User ID', userId),
                      ..._buildDetailRow('🆔 Server ID', serverId),
                      ..._buildDetailRow('🧠 Memory', isUnlimited ? 'Unlimited' : '$memory MB'),
                      ..._buildDetailRow('💾 Disk', isUnlimited ? 'Unlimited' : '$disk MB'),
                      ..._buildDetailRow('⚡ CPU', '$cpu%'),
                      ..._buildDetailRow('📍 Location', location.toString()),
                      ..._buildDetailRow('📅 Dibuat', panel['createdAt']?.toString().split('T')[0] ?? ''),
                      const SizedBox(height: 20),
                      CyberButton(
                        label: 'SALIN SEMUA DATA',
                        icon: Icons.copy_all,
                        onTap: () => _copyToClipboard(panelData),
                        width: double.infinity,
                      ),
                      const SizedBox(height: 12),
                      CyberButton(
                        label: 'HAPUS PANEL',
                        icon: Icons.delete,
                        onTap: () => _deletePanel(serverId),
                        color: AppColors.red,
                        width: double.infinity,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildDetailRow(String label, String value) {
    return [
      Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface2.withOpacity(0.5),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.borderLight.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: TextStyle(
                      fontFamily: appFont,
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => _copyToClipboard(value),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.accent.withOpacity(0.2)),
                ),
                child: Icon(Icons.copy, color: AppColors.accent, size: 14),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  String _formatDate(String isoDate) {
    try {
      final date = DateTime.parse(isoDate);
      return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
    } catch (e) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildTabBar(),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: _isLoading
                    ? const Center(child: CyberLoadingShimmer())
                    : IndexedStack(
                        index: _activeTab,
                        children: [
                          _buildAdpForm(),
                          _buildCreatePanelForm(),
                          _buildMyPanelsTab(),
                          Container(),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}