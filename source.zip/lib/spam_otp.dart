// spam_otp_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class SpamOtpPage extends StatefulWidget {
  final String sessionKey;
  
  const SpamOtpPage({super.key, required this.sessionKey});

  @override
  State<SpamOtpPage> createState() => _SpamOtpPageState();
}

class _SpamOtpPageState extends State<SpamOtpPage> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _jumlahController = TextEditingController();
  
  bool _isRunning = false;
  List<String> _logs = [];
  int _successCount = 0;
  int _failedCount = 0;
  
  final ScrollController _scrollController = ScrollController();

  final String _apiUrl = "https://api102.singa.id/new/login/sendWaOtp";

  @override
  void dispose() {
    _targetController.dispose();
    _jumlahController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _addLog(String message, {bool isSuccess = false, bool isError = false}) {
    final timestamp = DateTime.now().toString().substring(11, 19);
    setState(() {
      _logs.insert(0, "[$timestamp] $message");
      if (_logs.length > 100) _logs.removeLast();
    });
  }

  void _clearLogs() {
    setState(() {
      _logs.clear();
      _successCount = 0;
      _failedCount = 0;
    });
    _addLog("Log dibersihkan");
  }

  String _formatNumber(String number) {
    String cleaned = number.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleaned.startsWith('0')) {
      cleaned = '62${cleaned.substring(1)}';
    } else if (!cleaned.startsWith('62')) {
      cleaned = '62$cleaned';
    }
    return cleaned;
  }

  Future<void> _startSpam() async {
    String rawTarget = _targetController.text.trim();
    String jumlahStr = _jumlahController.text.trim();
    
    if (rawTarget.isEmpty) {
      showCyberSnackBar(context, "Nomor target tidak boleh kosong!", isError: true);
      return;
    }
    
    String target = _formatNumber(rawTarget);
    
    if (!target.startsWith('62')) {
      showCyberSnackBar(context, "Nomor harus format 62 (contoh: 628123456789)!", isError: true);
      return;
    }
    
    if (target.length < 10 || target.length > 15) {
      showCyberSnackBar(context, "Nomor tidak valid! Panjang 10-15 digit.", isError: true);
      return;
    }
    
    int jumlah = int.tryParse(jumlahStr) ?? 0;
    if (jumlah <= 0 || jumlah > 100) {
      showCyberSnackBar(context, "Jumlah harus antara 1-100!", isError: true);
      return;
    }
    
    if (_isRunning) {
      showCyberSnackBar(context, "Spam sedang berjalan!", isError: true);
      return;
    }
    
    setState(() {
      _isRunning = true;
      _successCount = 0;
      _failedCount = 0;
    });
    
    _addLog("🚀 Memulai spam OTP ke $target sebanyak $jumlah kali");
    
    for (int i = 1; i <= jumlah; i++) {
      if (!_isRunning) break;
      
      _addLog("⏳ Mengirim OTP ke $target... [$i/$jumlah]");
      
      try {
        final response = await http.post(
          Uri.parse(_apiUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "mobile_phone": target,
            "type": "mobile",
            "is_switchable": 1,
          }),
        ).timeout(const Duration(seconds: 15));
        
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['status'] == 'success') {
            setState(() => _successCount++);
            _addLog("✅ [$i/$jumlah] OTP berhasil dikirim", isSuccess: true);
          } else {
            setState(() => _failedCount++);
            _addLog("❌ [$i/$jumlah] Gagal: ${data['message']}", isError: true);
          }
        } else {
          setState(() => _failedCount++);
          _addLog("❌ [$i/$jumlah] HTTP ${response.statusCode}", isError: true);
        }
      } catch (e) {
        setState(() => _failedCount++);
        _addLog("❌ [$i/$jumlah] Error: $e", isError: true);
      }
      
      if (i < jumlah) await Future.delayed(const Duration(seconds: 5));
    }
    
    setState(() => _isRunning = false);
    _addLog("🏁 Selesai! Berhasil: $_successCount, Gagal: $_failedCount");
    showCyberSnackBar(context, "Selesai! Berhasil: $_successCount, Gagal: $_failedCount");
  }
  
  void _stopSpam() {
    setState(() => _isRunning = false);
    _addLog("🛑 Spam dihentikan manual");
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
        title: "SPAM OTP WA",
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted, size: 20),
            onPressed: _clearLogs,
          ),
        ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: AppColors.accent, size: 20),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    "Format nomor: 628xxxxxxxx (tanpa +62 atau 0)",
                    style: TextStyle(
                      fontFamily: appFont,
                      color: AppColors.textSec,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          CyberInputField(
            controller: _targetController,
            label: "NOMOR TARGET",
            hint: "62858xxxxxxxx",
            icon: Icons.phone_android_rounded,
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 14),

          CyberInputField(
            controller: _jumlahController,
            label: "JUMLAH SPAM",
            hint: "1 - 100",
            icon: Icons.numbers_rounded,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: CyberButton(
                  label: _isRunning ? "PROSES..." : "MULAI SPAM",
                  icon: _isRunning ? Icons.hourglass_top : Icons.play_arrow_rounded,
                  onTap: _isRunning ? () {} : _startSpam,
                  isLoading: _isRunning,
                ),
              ),
              if (_isRunning) ...[
                const SizedBox(width: 12),
                Expanded(
                  child: CyberButton(
                    label: "STOP",
                    icon: Icons.stop_rounded,
                    onTap: _stopSpam,
                    color: AppColors.red,
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 20),

          Row(
            children: [
              Expanded(
                child: GlassCard(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    children: [
                      const Text(
                        "BERHASIL",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.green,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "$_successCount",
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.green,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GlassCard(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    children: [
                      const Text(
                        "GAGAL",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.red,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "$_failedCount",
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.red,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GlassCard(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    children: [
                      const Text(
                        "TOTAL",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.accent,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "${_successCount + _failedCount}",
                        style: const TextStyle(
                          fontFamily: appFont,
                          color: AppColors.accent,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          const SectionTitle(
            icon: Icons.terminal_rounded,
            title: "LOG OUTPUT",
          ),
          const SizedBox(height: 8),
          GlassCard(
            height: 180,
            padding: const EdgeInsets.all(12),
            child: _logs.isEmpty
                ? const Center(
                    child: Text(
                      "Belum ada log",
                      style: TextStyle(
                        fontFamily: appFont,
                        color: AppColors.textMuted,
                        fontSize: 12,
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollController,
                    reverse: true,
                    itemCount: _logs.length,
                    itemBuilder: (context, index) {
                      final log = _logs[index];
                      Color logColor = AppColors.textSec;
                      if (log.contains('✅')) logColor = AppColors.green;
                      if (log.contains('❌')) logColor = AppColors.red;
                      if (log.contains('🚀')) logColor = AppColors.accent;
                      if (log.contains('🏁')) logColor = AppColors.orange;
                      if (log.contains('🛑')) logColor = AppColors.red;
                      
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text(
                          log,
                          style: TextStyle(
                            color: logColor,
                            fontSize: 11,
                            fontFamily: 'monospace',
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}