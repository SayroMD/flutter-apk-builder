import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_theme.dart';

/// Notifier tema global. Dengerin pake AnimatedBuilder biar UI rebuild
/// otomatis pas tema diganti.
class ThemeController extends ChangeNotifier {
  static final ThemeController instance = ThemeController._();
  ThemeController._();

  static const _prefKey = 'app_theme_mode';

  AppThemeMode _mode = AppThemeMode.darkComic3D; // default baru
  AppThemeMode get mode => _mode;
  AppTheme get theme => AppTheme(_mode);

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_prefKey);
    _mode = saved == AppThemeMode.classic.name
        ? AppThemeMode.classic
        : AppThemeMode.darkComic3D;
    notifyListeners();
  }

  Future<void> setMode(AppThemeMode m) async {
    if (m == _mode) return;
    _mode = m;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, m.name);
  }
}

class ThemeSwitcherPage extends StatelessWidget {
  const ThemeSwitcherPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ThemeController.instance,
      builder: (context, _) {
        final t = ThemeController.instance.theme;
        final current = ThemeController.instance.mode;

        return Scaffold(
          backgroundColor: t.scaffoldBg,
          appBar: AppBar(
            backgroundColor: t.isComic ? t.surface : const Color(0xFFFFE566),
            elevation: 0,
            iconTheme: IconThemeData(color: t.textPrimary),
            shape: t.isComic
                ? Border(bottom: BorderSide(color: t.accentTeal, width: 3))
                : const Border(
                    bottom: BorderSide(color: Colors.black, width: 3)),
            title: Text("TAMPILAN APP", style: t.titleStyle(size: 17)),
          ),
          body: Stack(
            children: [
              ComicBackdrop(theme: t),
              ListView(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                children: [
              Text("Pilih gaya UI. Tersimpan permanen di HP.",
                  style: t.subtitleStyle(size: 13)),
              const SizedBox(height: 18),
              _ModeTile(
                mode: AppThemeMode.darkComic3D,
                title: "DARK COMIC 3D",
                desc: "Gelap, outline tebal, bayangan slab 3D",
                active: current == AppThemeMode.darkComic3D,
              ),
              const SizedBox(height: 18),
              _ModeTile(
                mode: AppThemeMode.classic,
                title: "CLASSIC",
                desc: "Neo brutalism — kuning, hitam, siku tajam",
                active: current == AppThemeMode.classic,
              ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Kartu pilihan. Digambar pake style tema-nya sendiri (bukan tema aktif)
/// jadi langsung keliatan hasilnya kayak apa.
class _ModeTile extends StatelessWidget {
  final AppThemeMode mode;
  final String title;
  final String desc;
  final bool active;

  const _ModeTile({
    required this.mode,
    required this.title,
    required this.desc,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    final p = AppTheme(mode); // tema preview
    final accent = p.isComic ? p.accentTeal : const Color(0xFFFFE566);

    return GestureDetector(
      onTap: () => ThemeController.instance.setMode(mode),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: p.card(accent: accent),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: p.titleStyle(size: 16))),
                if (active)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: p.sticker(),
                    child: Text("AKTIF",
                        style: TextStyle(
                          color: p.isComic ? p.textPrimary : Colors.black,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        )),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(desc, style: p.subtitleStyle()),
            const SizedBox(height: 14),
            // mini preview: 3 blok kecil pake style tema tsb
            Row(
              children: [
                _mini(p, p.accentTeal, Icons.bolt_rounded),
                const SizedBox(width: 10),
                _mini(p, p.accentGold, Icons.star_rounded),
                const SizedBox(width: 10),
                _mini(p, p.accentPink, Icons.favorite_rounded),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _mini(AppTheme p, Color c, IconData icon) {
    return Expanded(
      child: Container(
        height: 46,
        decoration: p.card(accent: c, tinted: !p.isComic, d: 3),
        child: Icon(icon,
            color: p.isComic ? c : Colors.black, size: 22),
      ),
    );
  }
}
