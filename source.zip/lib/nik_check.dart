import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'base_page.dart';

class NikCheckerPage extends StatefulWidget {
  const NikCheckerPage({super.key});

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage>
    with TickerProviderStateMixin {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _result;
  String? _errorMessage;
  String? _responseTime;

  late final AnimationController _resultAnim;
  late final AnimationController _scanAnim;
  late final AnimationController _pulseAnim;
  late final Animation<double> _fadeIn;
  late final Animation<Offset> _slideUp;
  late final Animation<double> _scanLine;
  late final Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _resultAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _scanAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _pulseAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);

    _fadeIn = CurvedAnimation(parent: _resultAnim, curve: Curves.easeOutQuint);
    _slideUp = Tween<Offset>(begin: const Offset(0, 0.18), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultAnim, curve: Curves.easeOutExpo));
    _scanLine = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _scanAnim, curve: Curves.easeInOut));
    _pulse = Tween<double>(begin: 0.7, end: 1.0).animate(CurvedAnimation(parent: _pulseAnim, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _nikController.dispose();
    _resultAnim.dispose();
    _scanAnim.dispose();
    _pulseAnim.dispose();
    super.dispose();
  }

  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) { _setError('NIK tidak boleh kosong.'); return; }
    if (!RegExp(r'^\d{16}$').hasMatch(nik)) {
      _setError('Format NIK tidak valid (harus 16 digit angka).');
      return;
    }

    setState(() { _isLoading = true; _errorMessage = null; _result = null; });
    _scanAnim.repeat();

    try {
      final url = Uri.parse('https://rynekoo-api.hf.space/tools/nikparser?nik=$nik');
      final response = await http.get(url).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body) as Map<String, dynamic>;
        if (decoded['success'] == true && decoded['result'] != null) {
          setState(() {
            _result = decoded['result'] as Map<String, dynamic>;
            _responseTime = decoded['responseTime']?.toString();
            _errorMessage = null;
          });
          _resultAnim.forward(from: 0);
        } else {
          _setError('Data tidak ditemukan untuk NIK tersebut.');
        }
      } else {
        _setError('Server error: ${response.statusCode}');
      }
    } catch (_) {
      _setError('Koneksi gagal. Periksa jaringan Anda.');
    } finally {
      _scanAnim.stop();
      _scanAnim.reset();
      setState(() => _isLoading = false);
    }
  }

  void _setError(String msg) {
    setState(() { _errorMessage = msg; _result = null; _isLoading = false; });
    _scanAnim.stop();
    _scanAnim.reset();
  }

  void _copy(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    showCyberSnackBar(context, '$label disalin');
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "NIK CHECKER",
      child: Column(
        children: [
          _buildInputCard(),
          if (_errorMessage != null) ...[
            const SizedBox(height: 12),
            _buildError(),
          ],
          if (_result != null) ...[
            const SizedBox(height: 14),
            FadeTransition(
              opacity: _fadeIn,
              child: SlideTransition(
                position: _slideUp,
                child: _buildResults(),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return GlassCard(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.red.withOpacity(0.12),
                  border: Border.all(color: AppColors.red.withOpacity(0.3)),
                ),
                child: const Icon(Icons.fingerprint, color: AppColors.red, size: 20),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('VERIFIKASI NIK',
                      style: TextStyle(fontFamily: appFont, fontWeight: FontWeight.w800, fontSize: 14, letterSpacing: 2.5, color: AppColors.textPrimary)),
                  Text('Nomor Induk Kependudukan — 16 digit',
                      style: TextStyle(fontFamily: appFont, fontSize: 11.5, color: AppColors.textMuted)),
                ],
              ),
              const Spacer(),
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Opacity(
                  opacity: _pulse.value,
                  child: Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.red,
                      boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.6), blurRadius: 6)],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          CyberInputField(
            controller: _nikController,
            label: "NIK",
            hint: "0000000000000000",
            icon: Icons.credit_card_rounded,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 12),
          CyberButton(
            label: _isLoading ? "MEMINDAI NIK..." : "VERIFIKASI NIK",
            icon: _isLoading ? Icons.hourglass_top : Icons.verified_user_rounded,
            onTap: _isLoading ? () {} : _checkNik,
            isLoading: _isLoading,
            width: double.infinity,
          ),
        ],
      ),
    );
  }

  Widget _buildError() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      borderColor: AppColors.red.withOpacity(0.25),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.red.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.error_outline_rounded, color: AppColors.red, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(_errorMessage!,
                style: TextStyle(color: AppColors.textPrimary, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  Widget _buildResults() {
    final r = _result!;

    final String nik = r['nik']?.toString() ?? _nikController.text.trim();
    final String kelamin = r['kelamin']?.toString() ?? '';
    final String lahir = r['lahir']?.toString() ?? '';
    final String lahirFull = r['lahir_lengkap']?.toString() ?? '';

    final Map provinsi = r['provinsi'] as Map? ?? {};
    final Map kotakab = r['kotakab'] as Map? ?? {};
    final Map kecamatan = r['kecamatan'] as Map? ?? {};
    final Map tambahan = r['tambahan'] as Map? ?? {};

    final String provinsiNama = provinsi['nama']?.toString() ?? '';
    final String kotaNama = kotakab['nama']?.toString() ?? '';
    final String kecNama = kecamatan['nama']?.toString() ?? '';

    return Column(
      children: [
        GlassCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.green.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.green.withOpacity(0.35)),
                    ),
                    child: Row(
                      children: [
                        Container(width: 6, height: 6,
                            decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle)),
                        const SizedBox(width: 6),
                        const Text('TERVERIFIKASI',
                            style: TextStyle(fontFamily: appFont, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.green)),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Icon(kelamin.contains('PEREMPUAN') ? Icons.face_4_rounded : Icons.face_6_rounded,
                      color: AppColors.red.withOpacity(0.5), size: 18),
                  const SizedBox(width: 6),
                  Text(kelamin,
                      style: TextStyle(fontFamily: appFont, fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.red)),
                ],
              ),
              const SizedBox(height: 16),
              Text(_formatNik(nik),
                  style: TextStyle(fontFamily: appFont, fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.textPrimary, letterSpacing: 4)),
              const SizedBox(height: 14),
              Container(height: 1, color: AppColors.border),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8, runSpacing: 8,
                children: [
                  if (lahir.isNotEmpty) _heroChip(Icons.cake_rounded, lahirFull.isNotEmpty ? lahirFull : lahir),
                  if (tambahan['usia'] != null) _heroChip(Icons.hourglass_bottom_rounded, tambahan['usia'].toString()),
                  if (tambahan['kategori_usia'] != null) _heroChip(Icons.person_rounded, tambahan['kategori_usia'].toString()),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        _buildSection(
          title: 'IDENTITAS',
          icon: Icons.badge_outlined,
          accent: AppColors.red,
          rows: [
            _RowItem('NIK', nik, copy: true),
            _RowItem('Jenis Kelamin', kelamin),
            _RowItem('Tanggal Lahir', lahirFull.isNotEmpty ? lahirFull : lahir),
            _RowItem('Usia', tambahan['usia']?.toString()),
            _RowItem('Kategori Usia', tambahan['kategori_usia']?.toString()),
          ],
        ),
        const SizedBox(height: 12),
        _buildSection(
          title: 'DOMISILI',
          icon: Icons.location_city_rounded,
          accent: AppColors.orange,
          rows: [
            _RowItem('Provinsi', provinsiNama),
            _RowItem('Kota/Kabupaten', kotaNama),
            _RowItem('Kecamatan', kecNama.isNotEmpty ? kecNama : null),
          ],
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.bolt_rounded, size: 13, color: AppColors.textMuted.withOpacity(0.5)),
              const SizedBox(width: 5),
              Text(_responseTime != null ? 'Diproses dalam $_responseTime' : 'Data dari sumber resmi',
                  style: TextStyle(fontFamily: appFont, fontSize: 11.5, color: AppColors.textMuted.withOpacity(0.5))),
            ],
          ),
        ),
      ],
    );
  }

  Widget _heroChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.red.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.red.withOpacity(0.15)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: AppColors.textMuted),
          const SizedBox(width: 7),
          Text(text, style: TextStyle(fontFamily: appFont, fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
        ],
      ),
    );
  }

  Widget _buildSection({required String title, required IconData icon, required Color accent, required List<_RowItem> rows}) {
    final visible = rows.where((r) => r.value != null && r.value!.trim().isNotEmpty).toList();
    if (visible.isEmpty) return const SizedBox.shrink();

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(color: accent.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                  child: Icon(icon, color: accent, size: 15),
                ),
                const SizedBox(width: 10),
                Text(title,
                    style: TextStyle(fontFamily: appFont, fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 2, color: accent)),
              ],
            ),
          ),
          Container(height: 1, color: accent.withOpacity(0.08)),
          ...visible.map((row) => Column(
            children: [
              InkWell(
                onTap: row.copy ? () => _copy(row.value!, row.label) : null,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(width: 118,
                          child: Text(row.label,
                              style: TextStyle(fontFamily: appFont, fontSize: 12.5, fontWeight: FontWeight.w500, color: AppColors.textMuted))),
                      Expanded(
                        child: Text(row.value!,
                            style: TextStyle(fontFamily: appFont, fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                      ),
                      if (row.copy)
                        Padding(
                          padding: const EdgeInsets.only(left: 6),
                          child: Icon(Icons.copy_all_rounded, size: 14, color: accent.withOpacity(0.35)),
                        ),
                    ],
                  ),
                ),
              ),
              Container(height: 1, color: AppColors.border.withOpacity(0.3)),
            ],
          )).toList(),
        ],
      ),
    );
  }

  String _formatNik(String nik) {
    if (nik.length != 16) return nik;
    return '${nik.substring(0, 4)} ${nik.substring(4, 8)} ${nik.substring(8, 12)} ${nik.substring(12, 16)}';
  }
}

class _RowItem {
  final String label;
  final String? value;
  final bool copy;
  const _RowItem(this.label, this.value, {this.copy = false});
}