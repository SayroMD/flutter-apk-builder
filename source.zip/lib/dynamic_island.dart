import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'music_service.dart';

/// App-wide floating neo-brutalism "Dynamic Island" now-playing pill.
///
/// Mount once at the root (`MaterialApp.builder`). Reads from
/// [MusicService.instance] so it works on every page.
///
/// Style matches OTAX: thick black borders, hard offset shadows, yellow/red
/// accents, bold uppercase type.
class DynamicIslandOverlay extends StatefulWidget {
  const DynamicIslandOverlay({
    super.key,
    this.topOffset = 8,
  });

  final double topOffset;

  @override
  State<DynamicIslandOverlay> createState() => _DynamicIslandOverlayState();
}

class _DynamicIslandOverlayState extends State<DynamicIslandOverlay>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  late final AnimationController _eqController;

  Offset? _dragOffset;
  Offset? _dragStartLocal;
  Offset? _dragStartOffset;
  bool _isDragging = false;

  // ===== OTAX NEO-BRUTALISM =====
  static const Color _bg = Color(0xFF000000);
  static const Color _surface = Color(0xFFFFFFFF);
  static const Color _accent = Color(0xFFFFDE00); // brutal yellow
  static const Color _accentRed = Color(0xFFFF3B3B);
  static const Color _border = Color(0xFF000000);
  static const Color _text = Color(0xFF000000);
  static const Color _textOnDark = Color(0xFFFFFFFF);
  static const Color _muted = Color(0xFF4A4A4A);

  static const double _collapsedW = 220;
  static const double _collapsedH = 42;
  static const double _expandedH = 210;

  List<BoxShadow> get _hardShadow => const [
        BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
      ];

  List<BoxShadow> get _hardShadowSmall => const [
        BoxShadow(color: Colors.black, offset: Offset(3, 3), blurRadius: 0),
      ];

  @override
  void initState() {
    super.initState();
    _eqController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
    MusicService.instance.addListener(_onServiceChanged);
  }

  void _onServiceChanged() {
    if (!mounted) return;
    if (MusicService.instance.currentTrack == null && _expanded) {
      _expanded = false;
    }
    setState(() {});
  }

  @override
  void dispose() {
    MusicService.instance.removeListener(_onServiceChanged);
    _eqController.dispose();
    super.dispose();
  }

  void _collapse() => setState(() => _expanded = false);
  void _toggleExpand() => setState(() => _expanded = !_expanded);

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    if (d.inHours > 0) return '${d.inHours}:$m:$s';
    return '$m:$s';
  }

  double _pillWidth(double screenWidth) {
    if (_expanded) return (screenWidth - 32).clamp(300.0, 420.0);
    return _collapsedW;
  }

  double _pillHeight() => _expanded ? _expandedH : _collapsedH;

  Offset _defaultOrigin(Size screen, EdgeInsets safe) {
    final w = _pillWidth(screen.width);
    final top = safe.top + widget.topOffset + (_expanded ? 10 : 0);
    final left = (screen.width - w) / 2;
    return Offset(left, top);
  }

  Offset _clampedOffset(Offset raw, Size screen, EdgeInsets safe) {
    final w = _pillWidth(screen.width);
    final h = _pillHeight();
    final minX = 8.0;
    final maxX = math.max(minX, screen.width - w - 8);
    final minY = safe.top + 4;
    final maxY = math.max(minY, screen.height - h - safe.bottom - 8);
    return Offset(raw.dx.clamp(minX, maxX), raw.dy.clamp(minY, maxY));
  }

  void _onPanStart(DragStartDetails details) {
    _isDragging = false;
    _dragStartLocal = details.globalPosition;
    final screen = MediaQuery.of(context).size;
    final safe = MediaQuery.of(context).padding;
    _dragStartOffset = _dragOffset ?? _defaultOrigin(screen, safe);
  }

  void _onPanUpdate(DragUpdateDetails details) {
    if (_dragStartLocal == null || _dragStartOffset == null) return;
    final delta = details.globalPosition - _dragStartLocal!;
    if (!_isDragging && delta.distance > 6) _isDragging = true;
    if (!_isDragging) return;
    final screen = MediaQuery.of(context).size;
    final safe = MediaQuery.of(context).padding;
    setState(() {
      _dragOffset = _clampedOffset(_dragStartOffset! + delta, screen, safe);
    });
  }

  void _onPanEnd(DragEndDetails details) {
    final wasDragging = _isDragging;
    final velocity = details.velocity.pixelsPerSecond;
    _isDragging = false;
    _dragStartLocal = null;
    _dragStartOffset = null;
    if (wasDragging) return;

    final service = MusicService.instance;
    if (velocity.dx.abs() > velocity.dy.abs()) {
      if (velocity.dx < -250) {
        service.requestNext();
      } else if (velocity.dx > 250) {
        service.requestPrevious();
      }
    } else {
      if (velocity.dy < -80) {
        _collapse();
      } else if (velocity.dy > 80) {
        setState(() => _expanded = true);
      }
    }
  }

  void _seekFromDx(MusicService service, double dx, double width) {
    if (service.duration.inMilliseconds <= 0 || width <= 0) return;
    final t = (dx / width).clamp(0.0, 1.0);
    service.seek(Duration(
      milliseconds: (t * service.duration.inMilliseconds).round(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final service = MusicService.instance;
    final show = service.currentTrack != null;
    final media = MediaQuery.of(context);
    final screen = media.size;
    final safe = media.padding;
    final w = _pillWidth(screen.width);
    final h = _pillHeight();

    final origin = show
        ? _clampedOffset(
            _dragOffset ?? _defaultOrigin(screen, safe),
            screen,
            safe,
          )
        : Offset((screen.width - w) / 2, -160);

    return AnimatedPositioned(
      duration: _isDragging ? Duration.zero : const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      left: origin.dx,
      top: origin.dy,
      width: w,
      height: h,
      child: IgnorePointer(
        ignoring: !show,
        child: GestureDetector(
          onTap: () {
            if (!show || _isDragging) return;
            _toggleExpand();
          },
          onPanStart: _onPanStart,
          onPanUpdate: _onPanUpdate,
          onPanEnd: _onPanEnd,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            width: w,
            height: h,
            decoration: BoxDecoration(
              color: _expanded ? _surface : _bg,
              border: Border.all(color: _border, width: 3),
              boxShadow: _hardShadow,
            ),
            clipBehavior: Clip.antiAlias,
            child: !show
                ? const SizedBox.shrink()
                : AnimatedSwitcher(
                    duration: const Duration(milliseconds: 180),
                    child: _expanded
                        ? _buildExpanded(service)
                        : _buildCollapsed(service),
                  ),
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Collapsed — black bar, yellow EQ, yellow play chip
  // ---------------------------------------------------------------------------
  Widget _buildCollapsed(MusicService service) {
    final track = service.currentTrack!;
    return Padding(
      key: const ValueKey('island_collapsed'),
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Row(
        children: [
          _thumb(track, size: 28, radius: 0, bordered: true),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              (track['title']?.toString() ?? 'UNKNOWN').toUpperCase(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _textOnDark,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
            ),
          ),
          const SizedBox(width: 6),
          _buildMiniEqualizer(service),
          const SizedBox(width: 6),
          _playPauseChip(service, size: 26, iconSize: 14),
          const SizedBox(width: 2),
          const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Color(0xFFAAAAAA),
            size: 18,
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Expanded — white card, hard borders, yellow controls
  // ---------------------------------------------------------------------------
  Widget _buildExpanded(MusicService service) {
    final track = service.currentTrack!;
    final progress = service.duration.inMilliseconds > 0
        ? (service.position.inMilliseconds / service.duration.inMilliseconds)
            .clamp(0.0, 1.0)
        : 0.0;

    return Container(
      key: const ValueKey('island_expanded'),
      color: _surface,
      padding: const EdgeInsets.fromLTRB(12, 10, 10, 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header strip
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: _accent,
                  border: Border.all(color: _border, width: 2),
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'OTAX MUSIC',
                style: TextStyle(
                  color: _text,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(width: 8),
              _buildMiniEqualizer(service, compact: true, onLight: true),
              const Spacer(),
              _squareIconBtn(
                Icons.keyboard_arrow_up_rounded,
                _collapse,
                size: 28,
              ),
              const SizedBox(width: 6),
              _squareIconBtn(
                Icons.close_rounded,
                () {
                  service.pause();
                  _collapse();
                },
                size: 28,
                danger: true,
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Track
          Row(
            children: [
              _thumb(track, size: 52, radius: 0, bordered: true),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      (track['title']?.toString() ?? 'UNKNOWN').toUpperCase(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _text,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      (track['artist']?.toString() ?? 'UNKNOWN').toUpperCase(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _muted,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Progress
          Row(
            children: [
              SizedBox(
                width: 36,
                child: Text(
                  _fmt(service.position),
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTapDown: (d) => _seekFromDx(
                        service,
                        d.localPosition.dx,
                        constraints.maxWidth,
                      ),
                      onHorizontalDragUpdate: (d) => _seekFromDx(
                        service,
                        d.localPosition.dx,
                        constraints.maxWidth,
                      ),
                      child: SizedBox(
                        height: 22,
                        child: Center(
                          child: Container(
                            height: 8,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: const Color(0xFFE8E0D0),
                              border: Border.all(color: _border, width: 2),
                            ),
                            child: FractionallySizedBox(
                              alignment: Alignment.centerLeft,
                              widthFactor: progress,
                              child: Container(color: _accent),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 36,
                child: Text(
                  _fmt(service.duration),
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Transport
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _squareIconBtn(
                Icons.skip_previous_rounded,
                service.onRequestPrevious == null
                    ? null
                    : service.requestPrevious,
                size: 36,
              ),
              const SizedBox(width: 14),
              _playPauseChip(service, size: 48, iconSize: 28, elevated: true),
              const SizedBox(width: 14),
              _squareIconBtn(
                Icons.skip_next_rounded,
                service.onRequestNext == null ? null : service.requestNext,
                size: 36,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _squareIconBtn(
    IconData icon,
    VoidCallback? onTap, {
    double size = 32,
    bool danger = false,
  }) {
    final enabled = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: danger
              ? _accentRed
              : (enabled ? _surface : const Color(0xFFE8E0D0)),
          border: Border.all(color: _border, width: 2.5),
          boxShadow: enabled ? _hardShadowSmall : null,
        ),
        child: Icon(
          icon,
          size: size * 0.55,
          color: enabled ? _text : _muted.withOpacity(0.5),
        ),
      ),
    );
  }

  Widget _playPauseChip(
    MusicService service, {
    required double size,
    required double iconSize,
    bool elevated = false,
  }) {
    return GestureDetector(
      onTap: () {
        if (service.isPlaying) {
          service.pause();
        } else {
          service.resume();
        }
      },
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: _accent,
          border: Border.all(color: _border, width: elevated ? 3 : 2.5),
          boxShadow: elevated ? _hardShadow : _hardShadowSmall,
        ),
        child: Icon(
          service.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
          color: _text,
          size: iconSize,
        ),
      ),
    );
  }

  Widget _thumb(
    Map<String, dynamic> track, {
    required double size,
    required double radius,
    bool bordered = false,
  }) {
    final imageUrl = track['imageUrl']?.toString() ?? '';
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        border: bordered ? Border.all(color: _border, width: 2) : null,
      ),
      child: imageUrl.isNotEmpty
          ? Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: _accent,
                child: Icon(
                  Icons.music_note_rounded,
                  size: size * 0.5,
                  color: _text,
                ),
              ),
            )
          : Container(
              color: _accent,
              child: Icon(
                Icons.music_note_rounded,
                size: size * 0.5,
                color: _text,
              ),
            ),
    );
  }

  Widget _buildMiniEqualizer(
    MusicService service, {
    bool compact = false,
    bool onLight = false,
  }) {
    final barCount = compact ? 4 : 3;
    final maxH = compact ? 10.0 : 14.0;
    final minH = 3.0;
    final width = compact ? 14.0 : 16.0;
    final barColor = onLight ? _text : _accent;

    if (!service.isPlaying) {
      return SizedBox(
        width: width,
        height: maxH,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(barCount, (i) {
            return Container(
              width: compact ? 2.5 : 3,
              height: minH + (i % 2) * 3,
              color: barColor.withOpacity(0.4),
            );
          }),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _eqController,
      builder: (context, _) {
        return SizedBox(
          width: width,
          height: maxH,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(barCount, (i) {
              final phase = _eqController.value * 2 * math.pi + (i * 1.35);
              final h =
                  minH + ((maxH - minH) * (0.45 + 0.55 * math.sin(phase)));
              return Container(
                width: compact ? 2.5 : 3,
                height: h.clamp(minH, maxH),
                color: barColor,
              );
            }),
          ),
        );
      },
    );
  }
}
