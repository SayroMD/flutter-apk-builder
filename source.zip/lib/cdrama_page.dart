// cdrama_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'base_page.dart';

class CDramaPage extends StatefulWidget {
  const CDramaPage({super.key});

  @override
  State<CDramaPage> createState() => _CDramaPageState();
}

class _CDramaPageState extends State<CDramaPage> {
  static const String baseUrl = "https://api.tvmaze.com";
  
  List<dynamic> _dramas = [];
  List<dynamic> _searchResults = [];
  bool _isLoading = true;
  bool _isSearching = false;
  String _errorMessage = "";
  
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  Map<String, dynamic>? _selectedDrama;
  List<dynamic> _episodes = [];
  bool _isLoadingDetail = false;

  final Map<String, List<String>> _youtubeMapping = {
    "Hidden Love": [
      "njdsTooO8Cs", "O2picCb-xos", "YwYNtUL6Yb4", "X08uqhxWtDw", "os-ACoJoqNE",
      "LmtOllEwxt0", "uhH98kd_BpQ", "XqjVAhsefKk", "7qpxeiDciUA", "zGGKxwomZ_4",
      "hPc8WmvSB4g", "vRfou8f4ldc", "3NFAO9jOC3w", "oah1P0QF62k", "k05z7EQbENM",
    ],
    "The Untamed": ["BfKhREVFLkQ", "b6vMPr_9VIs", "L10Xv_87U18"],
  };

  String _getYoutubeId(String title, int episodeNumber) {
    String? matchKey = _youtubeMapping.keys.firstWhere(
      (key) => title.toLowerCase().contains(key.toLowerCase()),
      orElse: () => "",
    );

    if (matchKey.isNotEmpty) {
      List<String> ids = _youtubeMapping[matchKey]!;
      if (episodeNumber > 0 && episodeNumber <= ids.length) {
        return ids[episodeNumber - 1];
      }
      return ids[0];
    }
    return "njdsTooO8Cs";
  }

  @override
  void initState() {
    super.initState();
    _fetchDramas();
  }

  Future<void> _fetchDramas() async {
    setState(() {
      _isLoading = true;
      _errorMessage = "";
    });
    
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/shows?page=0"),
      ).timeout(const Duration(seconds: 15));
      
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        final chineseDramas = data.where((show) {
          final network = show['network']?['country']?['code'] ?? '';
          final webChannel = show['webChannel']?['country']?['code'] ?? '';
          final name = show['name']?.toLowerCase() ?? '';
          return (network == 'CN' || webChannel == 'CN' || 
                  name.contains('chinese') || name.contains('china') ||
                  _youtubeMapping.keys.any((k) => name.contains(k.toLowerCase())) ||
                  show['genres']?.contains('Drama') == true);
        }).toList();
        
        setState(() {
          _dramas = chineseDramas;
          _isLoading = false;
        });
      } else {
        setState(() {
          _errorMessage = "Gagal memuat data";
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Error: ${e.toString()}";
        _isLoading = false;
      });
    }
  }

  Future<void> _searchDramas(String query) async {
    if (query.isEmpty) {
      setState(() {
        _isSearching = false;
        _searchResults = [];
      });
      return;
    }
    
    setState(() {
      _isSearching = true;
      _isLoading = true;
    });
    
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/search/shows?q=${Uri.encodeComponent(query)}"),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _searchResults = data.map((item) => item['show']).toList();
          _isLoading = false;
        });
      } else {
        setState(() {
          _searchResults = [];
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _searchResults = [];
        _isLoading = false;
      });
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      _isSearching = false;
      _searchResults = [];
    });
  }

  Future<void> _fetchDramaDetail(int dramaId) async {
    setState(() => _isLoadingDetail = true);
    
    try {
      final showResponse = await http.get(
        Uri.parse("$baseUrl/shows/$dramaId"),
      ).timeout(const Duration(seconds: 10));
      
      final episodesResponse = await http.get(
        Uri.parse("$baseUrl/shows/$dramaId/episodes"),
      ).timeout(const Duration(seconds: 10));
      
      if (showResponse.statusCode == 200) {
        setState(() {
          _selectedDrama = jsonDecode(showResponse.body);
          _episodes = episodesResponse.statusCode == 200 
              ? jsonDecode(episodesResponse.body) 
              : [];
          _isLoadingDetail = false;
        });
      } else {
        setState(() => _isLoadingDetail = false);
      }
    } catch (e) {
      setState(() => _isLoadingDetail = false);
    }
  }

  void _showDramaDetail(Map<String, dynamic> drama) async {
    await _fetchDramaDetail(drama['id']);
    if (!mounted) return;
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildDramaDetailSheet(),
    ).then((_) {
      setState(() {
        _selectedDrama = null;
        _episodes = [];
      });
    });
  }

  Widget _buildDramaDetailSheet() {
    if (_selectedDrama == null || _isLoadingDetail) {
      return Container(
        height: 400,
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(28),
        ),
        child: const Center(child: CyberLoadingShimmer()),
      );
    }
    
    final drama = _selectedDrama!;
    final genres = drama['genres'] ?? [];
    final imageUrl = drama['image']?['original'] ?? drama['image']?['medium'] ?? '';
    final rating = drama['rating']?['average']?.toString() ?? 'N/A';
    final year = drama['premiered']?.toString().split('-')[0] ?? 'Unknown';
    final network = drama['network']?['name'] ?? drama['webChannel']?['name'] ?? 'Unknown';
    final summary = drama['summary']?.replaceAll(RegExp(r'<[^>]*>'), '') ?? 'No synopsis available.';
    
    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      margin: const EdgeInsets.all(16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.borderLight.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 240,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                  image: imageUrl.isNotEmpty
                      ? DecorationImage(image: NetworkImage(imageUrl), fit: BoxFit.cover)
                      : null,
                ),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, AppColors.surface.withOpacity(0.95)],
                    ),
                  ),
                  child: SafeArea(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.close, color: AppColors.textPrimary, size: 28),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          margin: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppColors.orange.withOpacity(0.9),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.star, size: 14, color: Colors.black),
                              const SizedBox(width: 4),
                              Text(
                                rating,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                  fontFamily: appFont,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        drama['name'] ?? 'Unknown Title',
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          fontFamily: appFont,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (drama['language'] != null)
                        Text(
                          drama['language'],
                          style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 14,
                            fontFamily: appFont,
                          ),
                        ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 16,
                        runSpacing: 8,
                        children: [
                          _buildInfoChip(Icons.calendar_today, year),
                          _buildInfoChip(Icons.tv, network),
                          _buildInfoChip(Icons.public, "China"),
                        ],
                      ),
                      const SizedBox(height: 16),
                      if (genres.isNotEmpty)
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: genres.map<Widget>((genre) => Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.accent.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: AppColors.accent.withOpacity(0.2)),
                            ),
                            child: Text(
                              genre,
                              style: const TextStyle(
                                fontFamily: appFont,
                                color: AppColors.accent,
                                fontSize: 10,
                              ),
                            ),
                          )).toList(),
                        ),
                      const SizedBox(height: 20),
                      const Text(
                        "SYNOPSIS",
                        style: TextStyle(
                          fontFamily: appFont,
                          color: AppColors.accent,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        summary,
                        style: TextStyle(
                          color: AppColors.textSec,
                          fontSize: 12,
                          height: 1.5,
                          fontFamily: appFont,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Container(
                            width: 3,
                            height: 18,
                            decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            "EPISODES",
                            style: TextStyle(
                              fontFamily: appFont,
                              color: AppColors.accent,
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 3,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            "${_episodes.length} Available",
                            style: TextStyle(
                              fontFamily: appFont,
                              color: AppColors.textMuted,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      
                      if (_episodes.isEmpty)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(40),
                            child: Text(
                              "No episodes available yet",
                              style: TextStyle(
                                fontFamily: appFont,
                                color: AppColors.textMuted,
                              ),
                            ),
                          ),
                        )
                      else
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _episodes.length > 50 ? 50 : _episodes.length,
                          itemBuilder: (context, index) {
                            final episode = _episodes[index];
                            final season = episode['season'] ?? 1;
                            final number = episode['number'] ?? index + 1;
                            
                            return Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: GestureDetector(
                                onTap: () {
                                  final String ytId = _getYoutubeId(drama['name'] ?? '', number);
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => DramaPlayerScreen(
                                        videoId: ytId,
                                        episodeTitle: "${drama['name']} - S${season}E$number",
                                      ),
                                    ),
                                  );
                                },
                                child: GlassCard(
                                  padding: const EdgeInsets.all(12),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 45,
                                        height: 45,
                                        decoration: BoxDecoration(
                                          color: AppColors.accent.withOpacity(0.15),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "$number",
                                            style: TextStyle(
                                              fontFamily: appFont,
                                              color: AppColors.accent,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 14),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "S${season.toString().padLeft(2, '0')}E${number.toString().padLeft(2, '0')}",
                                              style: TextStyle(
                                                fontFamily: appFont,
                                                color: AppColors.textMuted,
                                                fontSize: 11,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            Text(
                                              episode['name'] ?? "Episode $number",
                                              style: const TextStyle(
                                                fontFamily: appFont,
                                                color: AppColors.textPrimary,
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                          color: AppColors.accent.withOpacity(0.1),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(
                                          Icons.play_arrow_rounded,
                                          color: AppColors.accent,
                                          size: 20,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: AppColors.textMuted),
        const SizedBox(width: 4),
        Text(
          label,
          style: const TextStyle(
            fontFamily: appFont,
            color: AppColors.textMuted,
            fontSize: 11,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return CyberScrollPageV2(
        title: "C-DRAMA",
        actions: [
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: AppColors.textSec, size: 20),
            onPressed: _fetchDramas,
          ),
        ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CyberInputField(
            controller: _searchController,
            label: "CARI DRAMA",
            hint: "Cari Chinese drama...",
            icon: Icons.search_rounded,
            onChanged: _searchDramas,
          ),
          const SizedBox(height: 16),
          
          if (_isLoading && _dramas.isEmpty)
            const Center(child: CyberLoadingShimmer())
          else if (_errorMessage.isNotEmpty)
            Center(
              child: CyberEmptyState(
                title: "Error",
                subtitle: _errorMessage,
                icon: Icons.error_outline_rounded,
                onRetry: _fetchDramas,
              ),
            )
          else
            _buildDramaGrid(),
        ],
      ),
    );
  }

  Widget _buildDramaGrid() {
    final displayList = _isSearching ? _searchResults : _dramas;
    
    if (displayList.isEmpty) {
      return CyberEmptyState(
        title: "Tidak ada drama",
        subtitle: "Coba cari dengan kata kunci lain",
        icon: Icons.movie_rounded,
      );
    }
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.65,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: displayList.length,
      itemBuilder: (context, index) {
        final drama = displayList[index];
        return _buildDramaCard(drama);
      },
    );
  }

  Widget _buildDramaCard(Map<String, dynamic> drama) {
    final title = drama['name'] ?? 'Unknown';
    final imageUrl = drama['image']?['medium'] ?? drama['image']?['original'] ?? '';
    final rating = drama['rating']?['average']?.toString() ?? 'N/A';
    final year = drama['premiered']?.toString().split('-')[0] ?? '';
    
    return GestureDetector(
      onTap: () => _showDramaDetail(drama),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(
                children: [
                  imageUrl.isNotEmpty
                      ? Image.network(
                          imageUrl,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: AppColors.surface2,
                            child: const Icon(Icons.image_not_supported, color: AppColors.textMuted, size: 40),
                          ),
                        )
                      : Container(
                          color: AppColors.surface2,
                          child: const Icon(Icons.movie_rounded, color: AppColors.textMuted, size: 40),
                        ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.orange.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.star, size: 10, color: Colors.black),
                          const SizedBox(width: 2),
                          Text(
                            rating,
                            style: const TextStyle(
                              fontFamily: appFont,
                              color: Colors.black,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              fontFamily: appFont,
              color: AppColors.textPrimary,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          if (year.isNotEmpty)
            Text(
              year,
              style: TextStyle(
                fontFamily: appFont,
                color: AppColors.textMuted,
                fontSize: 10,
              ),
            ),
        ],
      ),
    );
  }
}

// ==================== DRAMA PLAYER SCREEN ====================
class DramaPlayerScreen extends StatefulWidget {
  final String videoId;
  final String episodeTitle;

  const DramaPlayerScreen({
    Key? key,
    required this.videoId,
    required this.episodeTitle,
  }) : super(key: key);

  @override
  State<DramaPlayerScreen> createState() => _DramaPlayerScreenState();
}

class _DramaPlayerScreenState extends State<DramaPlayerScreen> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController(
      initialVideoId: widget.videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: true,
        forceHD: true,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayerBuilder(
      player: YoutubePlayer(
        controller: _controller,
        showVideoProgressIndicator: true,
        progressIndicatorColor: AppColors.accent,
        progressColors: ProgressBarColors(
          playedColor: AppColors.accent,
          handleColor: AppColors.textPrimary,
          bufferedColor: AppColors.accent.withOpacity(0.3),
          backgroundColor: AppColors.surface2,
        ),
      ),
      builder: (context, player) {
        return CyberPage(
          showHexagon: false,
          child: Column(
            children: [
              CyberAppBarV2(
                title: widget.episodeTitle,
                showBackButton: true,
              ),
              player,
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: GlassCard(
                  child: Row(
                    children: [
                      Icon(Icons.play_arrow_rounded, color: AppColors.accent, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          "NOW PLAYING",
                          style: TextStyle(
                            fontFamily: appFont,
                            color: AppColors.accent,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      StatusBadge(label: "LIVE", isOnline: true),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}