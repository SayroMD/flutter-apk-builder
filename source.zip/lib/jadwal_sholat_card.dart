import 'dart:async';
import 'package:flutter/material.dart';

/// Drop-in pengganti PrayerRadarWidget. Pakai struktur data yang sama
/// persis (_jadwalSholat?['jadwal']?['subuh'], dst — key Indonesia,
/// nested di bawah 'jadwal'), jadi tinggal swap widget di call site,
/// gak perlu nambah state baru di dashboard.
class JadwalSholatCard extends StatefulWidget {
  final String cityName;
  final bool isLoadingSholat;
  final bool useCurrentLocation;
  final Map<String, dynamic>? jadwalSholat;
  final VoidCallback onCityTap;

  const JadwalSholatCard({
    super.key,
    required this.cityName,
    required this.isLoadingSholat,
    required this.useCurrentLocation,
    required this.jadwalSholat,
    required this.onCityTap,
  });

  @override
  State<JadwalSholatCard> createState() => _JadwalSholatCardState();
}

class _JadwalSholatCardState extends State<JadwalSholatCard> {
  Timer? _timer;
  DateTime _now = DateTime.now();

  static const List<String> _wajibKeys = [
    'subuh',
    'dzuhur',
    'ashar',
    'maghrib',
    'isya'
  ];
  static const Map<String, IconData> _wajibIcon = {
    'subuh': Icons.nights_stay_rounded,
    'dzuhur': Icons.wb_sunny_rounded,
    'ashar': Icons.sunny,
    'maghrib': Icons.cloudy_snowing,
    'isya': Icons.dark_mode_rounded,
  };
  static const Map<String, String> _wajibLabel = {
    'subuh': 'Subuh',
    'dzuhur': 'Dzuhur',
    'ashar': 'Ashar',
    'maghrib': 'Maghrib',
    'isya': 'Isya',
  };

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  double? _timeToHours(String? hhmm) {
    if (hhmm == null || !hhmm.contains(':')) return null;
    final parts = hhmm.split(':');
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    if (h == null || m == null) return null;
    return h + m / 60.0;
  }

  String _fmtCountdown(double deltaHours) {
    final totalSeconds = (deltaHours * 3600).round().clamp(0, 24 * 3600);
    final h = totalSeconds ~/ 3600;
    final m = (totalSeconds % 3600) ~/ 60;
    final s = totalSeconds % 60;
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(h)}:${two(m)}:${two(s)}';
  }

  @override
  Widget build(BuildContext context) {
    final jadwal = widget.jadwalSholat?['jadwal'] as Map?;
    final Map<String, double> hoursMap = {};
    for (final k in _wajibKeys) {
      final h = _timeToHours(jadwal?[k]?.toString());
      if (h != null) hoursMap[k] = h;
    }

    final nowHours = _now.hour + _now.minute / 60.0 + _now.second / 3600.0;
    String? nextKey;
    double bestDelta = 999;
    for (final k in _wajibKeys) {
      final h = hoursMap[k];
      if (h == null) continue;
      double delta = h - nowHours;
      if (delta < 0) delta += 24;
      if (delta < bestDelta) {
        bestDelta = delta;
        nextKey = k;
      }
    }
    final nextLabel = nextKey == null ? '' : _wajibLabel[nextKey]!;
    final nextCountdown = nextKey == null ? '--:--:--' : _fmtCountdown(bestDelta);

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned(
          right: -14,
          bottom: -18,
          child: IgnorePointer(
            child: Opacity(
              opacity: 0.9,
              child: Image.asset('assets/images/indonesia_map.png', width: 130),
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(24),
          margin: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF0F172A).withOpacity(0.9),
                const Color(0xFF1E293B),
                const Color(0xFF334155),
              ],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: const Color(0xFF475569).withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: const Color(0xFFD32F2F).withOpacity(0.15),
                blurRadius: 24,
                spreadRadius: 2,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: widget.onCityTap,
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const LinearGradient(
                                  colors: [Color(0xFFD32F2F), Color(0xFFFFD700)],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFD32F2F).withOpacity(0.4),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                              child: const Icon(Icons.mosque_rounded,
                                  color: Colors.white, size: 16),
                            ),
                            const SizedBox(width: 10),
                            Flexible(
                              child: Text(
                                widget.jadwalSholat?['lokasi'] ?? widget.cityName,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            if (widget.useCurrentLocation) ...[
                              const SizedBox(width: 4),
                              const Icon(Icons.my_location,
                                  size: 11, color: Color(0xFFFFD700)),
                            ],
                          ],
                        ),
                      ),
                    ),
                    if (nextKey != null)
                      Container(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              const Color(0xFFD32F2F).withOpacity(0.25),
                              const Color(0xFFFFD700).withOpacity(0.15),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: const Color(0xFFFFD700).withOpacity(0.4),
                          ),
                        ),
                        child: Row(
                          children: [
                            Text(
                              "Menuju $nextLabel  ",
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            ShaderMask(
                              shaderCallback: (bounds) => const LinearGradient(
                                colors: [Color(0xFFFFD700), Color(0xFFD32F2F)],
                              ).createShader(bounds),
                              child: Text(
                                nextCountdown,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 20),
                Divider(color: Colors.white.withOpacity(0.1), height: 1),
                const SizedBox(height: 20),
                if (widget.isLoadingSholat)
                  const Center(
                    child: CircularProgressIndicator(color: Color(0xFFFFD700)),
                  )
                else
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    child: Row(
                      children: _wajibKeys.map((k) {
                        final isNext = k == nextKey;
                        final timeStr = jadwal?[k]?.toString() ?? '--:--';
                        return Container(
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            gradient: isNext
                                ? const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [Color(0xFFD32F2F), Color(0xFFFFD700)],
                                  )
                                : null,
                            color: isNext ? null : Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isNext
                                  ? Colors.transparent
                                  : Colors.white.withOpacity(0.08),
                            ),
                            boxShadow: isNext
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFFD32F2F)
                                          .withOpacity(0.35),
                                      blurRadius: 10,
                                      offset: const Offset(0, 3),
                                    ),
                                  ]
                                : null,
                          ),
                          child: Column(
                            children: [
                              Icon(_wajibIcon[k],
                                  size: 18,
                                  color: isNext
                                      ? Colors.white
                                      : Colors.white.withOpacity(0.5)),
                              const SizedBox(height: 6),
                              Text(
                                _wajibLabel[k]!,
                                style: TextStyle(
                                  color: isNext
                                      ? Colors.white
                                      : Colors.white.withOpacity(0.6),
                                  fontSize: 10,
                                  fontWeight:
                                      isNext ? FontWeight.w700 : FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                timeStr,
                                style: TextStyle(
                                  color: isNext
                                      ? Colors.white
                                      : Colors.white.withOpacity(0.45),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
              ],
            ),
          ),
        ),
        Positioned(
          top: -16,
          left: 0,
          right: 0,
          child: IgnorePointer(
            child: Center(
              child: Image.asset('assets/images/merdeka_garland.png', width: 240),
            ),
          ),
        ),
      ],
    );
  }
}
